package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Defines a symbol to be used as prefix when generating code artifacts.
 */
public interface MIImplementationProps extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "ImplementationProps";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIImplementationProps> mdfGetClass();
  // attribute : symbol generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SYMBOL = "symbol";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SYMBOL_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SYMBOL,"ar3x.commonstructure.implementation.ImplementationProps",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The symbol to be used as prefix.
   * Attribute-Kind = versionAttribute   */
  public String getSymbol();
  /**
   * The symbol to be used as prefix.
   * Attribute-Kind = versionAttribute   */
  public void setSymbol(String newValue);
}
