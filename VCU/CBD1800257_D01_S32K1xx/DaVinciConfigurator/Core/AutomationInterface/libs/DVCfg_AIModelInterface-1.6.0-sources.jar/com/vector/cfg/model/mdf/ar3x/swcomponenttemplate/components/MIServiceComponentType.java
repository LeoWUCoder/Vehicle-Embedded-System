package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * ServiceComponentType is used for configuring services for a given ECU. Instances of this class are only to be created in ECU Configuration phase for the specific purpose of the service configuration.
 */
public interface MIServiceComponentType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType
{
  public final static String CLASS_NAME = "ServiceComponentType";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIServiceComponentType> mdfGetClass();
  // reference : serviceComponentTypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SERVICE_COMPONENT_TYPE_ARREF_REF_TARGETS_OWNER = "serviceComponentTypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_COMPONENT_TYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_COMPONENT_TYPE_ARREF_REF_TARGETS_OWNER,"ar3x.swcomponenttemplate.components.ServiceComponentType",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentTypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentTypeARRef> getServiceComponentTypeARRefRefTargetsOwner();
  // reference : bswModuleDescription generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_DESCRIPTION = "bswModuleDescription";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: serviceComponentType_bswModuleDescription_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DESCRIPTION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DESCRIPTION,"ar3x.swcomponenttemplate.components.ServiceComponentType",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef.SERVICE_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER_RELATION_INFO;}};
  /**
   * Reference from the ServiceComponentType to the Basic Software Module Description describing the BSW part of the Service Component.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef> getBswModuleDescription();
}
