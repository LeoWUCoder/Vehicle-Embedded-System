package com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints;
import javax.jmi.model.*;

public enum MIScaleConstrValidityEnum implements javax.jmi.reflect.RefEnum
{
  NOT_AVAILABLE("NOT-AVAILABLE"),
  NOT_DEFINED("NOT-DEFINED"),
  NOT_VALID("NOT-VALID"),
  VALID("VALID");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "globalconstraints" );
    temp.add( "ScaleConstrValidityEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIScaleConstrValidityEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
