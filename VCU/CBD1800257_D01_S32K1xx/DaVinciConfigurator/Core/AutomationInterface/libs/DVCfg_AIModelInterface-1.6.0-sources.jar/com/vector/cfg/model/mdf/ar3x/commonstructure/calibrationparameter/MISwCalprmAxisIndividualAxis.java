package com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Container for the properties of an individual axis.
 */
public interface MISwCalprmAxisIndividualAxis extends com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxisTypeProps
{
  public final static String CLASS_NAME = "SwCalprmAxisIndividualAxis";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwCalprmAxisIndividualAxis> mdfGetClass();
  // reference : swAxisIndividual generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_AXIS_INDIVIDUAL = "swAxisIndividual";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swCalprmAxisIndividualAxis_swAxisIndividual_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_AXIS_INDIVIDUAL_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_AXIS_INDIVIDUAL,"ar3x.commonstructure.calibrationparameter.SwCalprmAxisIndividualAxis",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisIndividual.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisIndividual.SW_CALPRM_AXIS_INDIVIDUAL_AXIS_SW_AXIS_INDIVIDUAL_OWNER_RELATION_INFO;}};
  /**
   * The grouped axis contained.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisIndividual getSwAxisIndividual();
  /**
   * The grouped axis contained.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwAxisIndividual(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisIndividual newValue);
}
