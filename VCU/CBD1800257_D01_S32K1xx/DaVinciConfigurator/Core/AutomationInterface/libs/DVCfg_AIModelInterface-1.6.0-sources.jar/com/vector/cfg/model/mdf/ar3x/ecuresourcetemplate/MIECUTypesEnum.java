package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;
import javax.jmi.model.*;

public enum MIECUTypesEnum implements javax.jmi.reflect.RefEnum
{
  ECU("ECU");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "ecuresourcetemplate" );
    temp.add( "ECUTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIECUTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
