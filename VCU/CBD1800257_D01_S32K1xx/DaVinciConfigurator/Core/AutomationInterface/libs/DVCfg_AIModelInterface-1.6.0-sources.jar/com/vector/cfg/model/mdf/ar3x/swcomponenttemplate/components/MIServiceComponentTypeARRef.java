package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIServiceComponentTypeARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "ServiceComponentTypeARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIServiceComponentTypeARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.swcomponenttemplate.components.ServiceComponentTypeARRef",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentTypeTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentTypeTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentTypeTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: serviceComponentTypeARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.swcomponenttemplate.components.ServiceComponentTypeARRef",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentType.SERVICE_COMPONENT_TYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentType> getRefTargets();
  // reference : serviceComponentPrototype_serviceComponent_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVICE_COMPONENT_PROTOTYPE_SERVICE_COMPONENT_OWNER = "serviceComponentPrototype_serviceComponent_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: serviceComponent
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_COMPONENT_PROTOTYPE_SERVICE_COMPONENT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_COMPONENT_PROTOTYPE_SERVICE_COMPONENT_OWNER,"ar3x.swcomponenttemplate.components.ServiceComponentTypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIServiceComponentPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIServiceComponentPrototype.SERVICE_COMPONENT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIServiceComponentPrototype getServiceComponentPrototypeServiceComponentOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setServiceComponentPrototypeServiceComponentOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.services.MIServiceComponentPrototype newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentType getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentType newRefTarget);

}
