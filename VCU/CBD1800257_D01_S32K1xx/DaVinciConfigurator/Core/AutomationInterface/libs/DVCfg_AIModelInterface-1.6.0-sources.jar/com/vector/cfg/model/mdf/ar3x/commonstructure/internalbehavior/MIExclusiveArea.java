package com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Prevents an executable entity running in the area from being preempted.
 */
public interface MIExclusiveArea extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "ExclusiveArea";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIExclusiveArea> mdfGetClass();
  // reference : exclusiveAreaARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String EXCLUSIVE_AREA_ARREF_REF_TARGETS_OWNER = "exclusiveAreaARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXCLUSIVE_AREA_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXCLUSIVE_AREA_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.internalbehavior.ExclusiveArea",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaARRef> getExclusiveAreaARRefRefTargetsOwner();
  // reference : hasExclusiveArea_exclusiveArea_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_EXCLUSIVE_AREA_EXCLUSIVE_AREA_OWNER = "hasExclusiveArea_exclusiveArea_Owner";
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: exclusiveArea
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_EXCLUSIVE_AREA_EXCLUSIVE_AREA_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_EXCLUSIVE_AREA_EXCLUSIVE_AREA_OWNER,"ar3x.commonstructure.internalbehavior.ExclusiveArea",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIHasExclusiveArea.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIHasExclusiveArea.EXCLUSIVE_AREA_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIHasExclusiveArea getHasExclusiveAreaExclusiveAreaOwner();
  public void setHasExclusiveAreaExclusiveAreaOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIHasExclusiveArea newValue);
}
