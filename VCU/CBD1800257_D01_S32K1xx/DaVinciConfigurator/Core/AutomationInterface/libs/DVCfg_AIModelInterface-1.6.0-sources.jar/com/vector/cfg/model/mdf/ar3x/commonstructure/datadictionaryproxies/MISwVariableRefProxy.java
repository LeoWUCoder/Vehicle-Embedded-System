package com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Parent class for several kinds of references to a variable.
 */
public interface MISwVariableRefProxy extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwVariableRefProxy";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwVariableRefProxy> mdfGetClass();
  // reference : hasSwVariableRefSwVariableRefProxy_swVariableRef_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_SW_VARIABLE_REF_SW_VARIABLE_REF_PROXY_SW_VARIABLE_REF_OWNER = "hasSwVariableRefSwVariableRefProxy_swVariableRef_Owner";
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swVariableRef
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_SW_VARIABLE_REF_SW_VARIABLE_REF_PROXY_SW_VARIABLE_REF_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_SW_VARIABLE_REF_SW_VARIABLE_REF_PROXY_SW_VARIABLE_REF_OWNER,"ar3x.commonstructure.datadictionaryproxies.SwVariableRefProxy",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRefSwVariableRefProxy.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRefSwVariableRefProxy.SW_VARIABLE_REF_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRefSwVariableRefProxy getHasSwVariableRefSwVariableRefProxySwVariableRefOwner();
  public void setHasSwVariableRefSwVariableRefProxySwVariableRefOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRefSwVariableRefProxy newValue);
  // reference : hasSwVariableRef1SwVariableRefProxy_swVariableRef1_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_SW_VARIABLE_REF1_SW_VARIABLE_REF_PROXY_SW_VARIABLE_REF1_OWNER = "hasSwVariableRef1SwVariableRefProxy_swVariableRef1_Owner";
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swVariableRef1
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_SW_VARIABLE_REF1_SW_VARIABLE_REF_PROXY_SW_VARIABLE_REF1_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_SW_VARIABLE_REF1_SW_VARIABLE_REF_PROXY_SW_VARIABLE_REF1_OWNER,"ar3x.commonstructure.datadictionaryproxies.SwVariableRefProxy",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRef1SwVariableRefProxy.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRef1SwVariableRefProxy.SW_VARIABLE_REF1_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRef1SwVariableRefProxy getHasSwVariableRef1SwVariableRefProxySwVariableRef1Owner();
  public void setHasSwVariableRef1SwVariableRefProxySwVariableRef1Owner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MIHasSwVariableRef1SwVariableRefProxy newValue);
}
