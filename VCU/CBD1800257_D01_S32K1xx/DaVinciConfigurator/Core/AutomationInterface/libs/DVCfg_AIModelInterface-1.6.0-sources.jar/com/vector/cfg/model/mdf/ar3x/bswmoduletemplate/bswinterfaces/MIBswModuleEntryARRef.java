package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIBswModuleEntryARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "BswModuleEntryARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBswModuleEntryARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntryARRef",null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: bswModuleEntryARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntryARRef",3,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntry.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntry.BSW_MODULE_ENTRY_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntry> getRefTargets();
  // reference : bswModuleDescription_providedEntry_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_DESCRIPTION_PROVIDED_ENTRY_OWNER = "bswModuleDescription_providedEntry_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: providedEntry
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DESCRIPTION_PROVIDED_ENTRY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DESCRIPTION_PROVIDED_ENTRY_OWNER,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntryARRef",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription.PROVIDED_ENTRY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription getBswModuleDescriptionProvidedEntryOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswModuleDescriptionProvidedEntryOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription newValue);
  // reference : bswModuleDescription_outgoingCallback_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_DESCRIPTION_OUTGOING_CALLBACK_OWNER = "bswModuleDescription_outgoingCallback_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: outgoingCallback
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DESCRIPTION_OUTGOING_CALLBACK_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DESCRIPTION_OUTGOING_CALLBACK_OWNER,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntryARRef",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription.OUTGOING_CALLBACK_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription getBswModuleDescriptionOutgoingCallbackOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswModuleDescriptionOutgoingCallbackOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription newValue);
  // reference : bswModuleDependency_expectedCallback_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_DEPENDENCY_EXPECTED_CALLBACK_OWNER = "bswModuleDependency_expectedCallback_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: expectedCallback
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DEPENDENCY_EXPECTED_CALLBACK_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DEPENDENCY_EXPECTED_CALLBACK_OWNER,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntryARRef",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency.EXPECTED_CALLBACK_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency getBswModuleDependencyExpectedCallbackOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswModuleDependencyExpectedCallbackOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency newValue);
  // reference : bswModuleDependency_requiredEntry_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_DEPENDENCY_REQUIRED_ENTRY_OWNER = "bswModuleDependency_requiredEntry_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: requiredEntry
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DEPENDENCY_REQUIRED_ENTRY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DEPENDENCY_REQUIRED_ENTRY_OWNER,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntryARRef",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency.REQUIRED_ENTRY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency getBswModuleDependencyRequiredEntryOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswModuleDependencyRequiredEntryOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleDependency newValue);
  // reference : bswModuleEntity_implementedEntry_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_ENTITY_IMPLEMENTED_ENTRY_OWNER = "bswModuleEntity_implementedEntry_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: implementedEntry
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_ENTITY_IMPLEMENTED_ENTRY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_ENTITY_IMPLEMENTED_ENTRY_OWNER,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntryARRef",64,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity.IMPLEMENTED_ENTRY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity getBswModuleEntityImplementedEntryOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswModuleEntityImplementedEntryOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity newValue);
  // reference : bswModuleEntity_calledEntry_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_ENTITY_CALLED_ENTRY_OWNER = "bswModuleEntity_calledEntry_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: calledEntry
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_ENTITY_CALLED_ENTRY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_ENTITY_CALLED_ENTRY_OWNER,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleEntryARRef",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity.CALLED_ENTRY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity getBswModuleEntityCalledEntryOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswModuleEntityCalledEntryOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntry getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntry newRefTarget);

}
