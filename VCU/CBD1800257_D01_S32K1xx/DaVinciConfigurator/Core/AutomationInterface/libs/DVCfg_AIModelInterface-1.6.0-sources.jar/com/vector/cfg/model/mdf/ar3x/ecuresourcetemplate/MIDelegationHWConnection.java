package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Is used to connect HWPorts of a HWContainer with HWPorts of the contained HWElements.
 */
public interface MIDelegationHWConnection extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWConnection
{
  public final static String CLASS_NAME = "DelegationHWConnection";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDelegationHWConnection> mdfGetClass();
  // reference : outerPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OUTER_PORT = "outerPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: delegationHWConnection_outerPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OUTER_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OUTER_PORT,"ar3x.ecuresourcetemplate.DelegationHWConnection",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef.DELEGATION_HWCONNECTION_OUTER_PORT_OWNER_RELATION_INFO;}};
  /**
   * Reference to the HWPort of the connected outer HWElement.  A single HWPort can only be referenced by exactly one DelegationHWConnection.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef getOuterPort();
  /**
   * Reference to the HWPort of the connected outer HWElement.  A single HWPort can only be referenced by exactly one DelegationHWConnection.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setOuterPort(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef newValue);
  // reference : innerPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INNER_PORT = "innerPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: delegationHWConnection_innerPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INNER_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INNER_PORT,"ar3x.ecuresourcetemplate.DelegationHWConnection",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef.DELEGATION_HWCONNECTION_INNER_PORT_OWNER_RELATION_INFO;}};
  /**
   * Reference to the HWPort of the connected inner HWElement.  A single HWPort can only be referenced by exactly one DelegationHWConnection.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef getInnerPort();
  /**
   * Reference to the HWPort of the connected inner HWElement.  A single HWPort can only be referenced by exactly one DelegationHWConnection.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setInnerPort(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPortARRef newValue);
}
