package com.vector.cfg.model.mdf.ar3x.commonstructure.axis;
import javax.jmi.model.*;

public enum MISwAxisTypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  SW_AXIS_TYPE("SW-AXIS-TYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "axis" );
    temp.add( "SwAxisTypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwAxisTypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
