package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;
import javax.jmi.model.*;

public enum MIMemorySegmentUsageEnum implements javax.jmi.reflect.RefEnum
{
  CODE("CODE"),
  DATA("DATA"),
  STACK("STACK"),
  BOOT("BOOT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "memory" );
    temp.add( "MemorySegmentUsageEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIMemorySegmentUsageEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
