package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This is a class which allows to refer to any identifiable object. It could be modeled as an association to Identifiable. But for compatibility reasons to ASAM it is left as it is.
 */
public interface MISdx extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "Sdx";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISdx> mdfGetClass();
  // attribute : gid generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String GID = "gid";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo GID_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,GID,"ar3x.genericstructure.commonpatterns.specialdata.Sdx",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This attributes specifies an identifier. Gid comes from the SGML-Term "Generic Identifier" which is the element name in XML. The role of this attribute is the same as the name of an XML - element.
   * Attribute-Kind = versionAttribute   */
  public String getGid();
  /**
   * This attributes specifies an identifier. Gid comes from the SGML-Term "Generic Identifier" which is the element name in XML. The role of this attribute is the same as the name of an XML - element.
   * Attribute-Kind = versionAttribute   */
  public void setGid(String newValue);
  // attribute : idClass generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ID_CLASS = "idClass";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ID_CLASS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ID_CLASS,"ar3x.genericstructure.commonpatterns.specialdata.Sdx",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This specifies the class of the referenced object.
   * Attribute-Kind = versionAttribute   */
  public String getIdClass();
  /**
   * This specifies the class of the referenced object.
   * Attribute-Kind = versionAttribute   */
  public void setIdClass(String newValue);
  // reference : sdxChildren generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SDX_CHILDREN = "sdxChildren";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: sdx_sdxChildren_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SDX_CHILDREN_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SDX_CHILDREN,"ar3x.genericstructure.commonpatterns.specialdata.Sdx",133,null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.MISdxChild.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.MISdxChild.SDX_SDX_CHILDREN_OWNER_RELATION_INFO;}};
  public java.util.List<com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.MISdxChild> getSdxChildren();
}
