package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Pulse Width Modulation refers to a method of carrying information on a train of pulses, the information being encoded in the width of the pulses. The frequency is normally not changed. It's only relationship between the high and low level of the signal which are changed. A PWM interface is usually a part of a processing unit. It provides the capability to communicate with another system with an easy protocol.
 */
public interface MIPWM extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPulseWidthPeripheral
{
  public final static String CLASS_NAME = "PWM";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPWM> mdfGetClass();
}
