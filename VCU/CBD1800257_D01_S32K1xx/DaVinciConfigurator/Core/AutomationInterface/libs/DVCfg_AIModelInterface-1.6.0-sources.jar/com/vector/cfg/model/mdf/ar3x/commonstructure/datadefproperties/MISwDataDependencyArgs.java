package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element specifies the elements used in a SwDataDependency.
 */
public interface MISwDataDependencyArgs extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwDataDependencyArgs";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwDataDependencyArgs> mdfGetClass();
  // reference : swDataDependency_swDataDependencyArgs_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_DATA_DEPENDENCY_SW_DATA_DEPENDENCY_ARGS_OWNER = "swDataDependency_swDataDependencyArgs_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swDataDependencyArgs
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEPENDENCY_SW_DATA_DEPENDENCY_ARGS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEPENDENCY_SW_DATA_DEPENDENCY_ARGS_OWNER,"ar3x.commonstructure.datadefproperties.SwDataDependencyArgs",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency.SW_DATA_DEPENDENCY_ARGS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency getSwDataDependencySwDataDependencyArgsOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwDataDependencySwDataDependencyArgsOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency newValue);
  // reference : swDataDependencyArgsChildren generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_DATA_DEPENDENCY_ARGS_CHILDREN = "swDataDependencyArgsChildren";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swDataDependencyArgs_swDataDependencyArgsChildren_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEPENDENCY_ARGS_CHILDREN_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEPENDENCY_ARGS_CHILDREN,"ar3x.commonstructure.datadefproperties.SwDataDependencyArgs",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgsChild.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgsChild.SW_DATA_DEPENDENCY_ARGS_SW_DATA_DEPENDENCY_ARGS_CHILDREN_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgsChild> getSwDataDependencyArgsChildren();
}
