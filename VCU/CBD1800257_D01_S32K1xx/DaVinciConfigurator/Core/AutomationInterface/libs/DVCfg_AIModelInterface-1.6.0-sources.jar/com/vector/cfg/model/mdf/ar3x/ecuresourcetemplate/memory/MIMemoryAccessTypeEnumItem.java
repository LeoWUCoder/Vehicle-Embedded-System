package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIMemoryAccessTypeEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "MemoryAccessTypeEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIMemoryAccessTypeEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.ecuresourcetemplate.memory.MemoryAccessTypeEnumItem",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccessTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccessTypeEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryAccessTypeEnum newValue);
}
