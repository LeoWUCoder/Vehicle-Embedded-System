package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes specific to unqueued receiving.
 */
public interface MIUnqueuedReceiverComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIReceiverComSpec
{
  public final static String CLASS_NAME = "UnqueuedReceiverComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIUnqueuedReceiverComSpec> mdfGetClass();
  // attribute : aliveTimeout generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ALIVE_TIMEOUT = "aliveTimeout";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ALIVE_TIMEOUT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ALIVE_TIMEOUT,"ar3x.swcomponenttemplate.communication.UnqueuedReceiverComSpec",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specify the amount of time (in seconds) after which the software component (via the RTE)  needs to be notified if the corresponding data item have not been received according to the specified timing description.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getAliveTimeout();
  /**
   * Specify the amount of time (in seconds) after which the software component (via the RTE)  needs to be notified if the corresponding data item have not been received according to the specified timing description.
   * Attribute-Kind = versionAttribute   */
  public void setAliveTimeout(java.math.BigDecimal newValue);
  // attribute : enableUpdate generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ENABLE_UPDATE = "enableUpdate";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ENABLE_UPDATE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ENABLE_UPDATE,"ar3x.swcomponenttemplate.communication.UnqueuedReceiverComSpec",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This attribute controls whether application code is entitled to check whether the value of the corresponding DataElementPrototype has been updated.
   * Attribute-Kind = versionAttribute   */
  public Boolean getEnableUpdate();
  /**
   * This attribute controls whether application code is entitled to check whether the value of the corresponding DataElementPrototype has been updated.
   * Attribute-Kind = versionAttribute   */
  public void setEnableUpdate(Boolean newValue);
  // attribute : handleInvalid generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HANDLE_INVALID = "handleInvalid";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo HANDLE_INVALID_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,HANDLE_INVALID,"ar3x.swcomponenttemplate.communication.UnqueuedReceiverComSpec",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIHandleInvalidType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies strategy of handling the reception of invalidValue.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIHandleInvalidType getHandleInvalid();
  /**
   * Specifies strategy of handling the reception of invalidValue.
   * Attribute-Kind = versionAttribute   */
  public void setHandleInvalid(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIHandleInvalidType newValue);
  // attribute : handleNeverReceived generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HANDLE_NEVER_RECEIVED = "handleNeverReceived";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo HANDLE_NEVER_RECEIVED_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,HANDLE_NEVER_RECEIVED,"ar3x.swcomponenttemplate.communication.UnqueuedReceiverComSpec",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This attribute specifies whether for the corresponding DataElementPrototype the "never received" flag is available. If yes, the RTE is supposed to assume that initially the DataElementPrototype has not been received before. After the first reception of the corresponding DataElementPrototype the flag is cleared. If the value of this attribute is set to TRUE the flag is required. If set to FALSE, the RTE shall not support the "never received" functionality for the corresponding DataElementPrototype. 
   * Attribute-Kind = versionAttribute   */
  public Boolean getHandleNeverReceived();
  /**
   * This attribute specifies whether for the corresponding DataElementPrototype the "never received" flag is available. If yes, the RTE is supposed to assume that initially the DataElementPrototype has not been received before. After the first reception of the corresponding DataElementPrototype the flag is cleared. If the value of this attribute is set to TRUE the flag is required. If set to FALSE, the RTE shall not support the "never received" functionality for the corresponding DataElementPrototype. 
   * Attribute-Kind = versionAttribute   */
  public void setHandleNeverReceived(Boolean newValue);
  // attribute : resyncTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.obsolete)
  public static final String RESYNC_TIME = "resyncTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.obsolete)
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESYNC_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESYNC_TIME,"ar3x.swcomponenttemplate.communication.UnqueuedReceiverComSpec",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.obsolete)
  /**
   * Time allowed for resynchronization of data values after current data is lost, e.g. after an ECU reset.  Please note that this attribute is considered obsolete and shall not be used. It is kept only for the sake of backwards compatibility.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getResyncTime();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.obsolete)
  /**
   * Time allowed for resynchronization of data values after current data is lost, e.g. after an ECU reset.  Please note that this attribute is considered obsolete and shall not be used. It is kept only for the sake of backwards compatibility.
   * Attribute-Kind = versionAttribute   */
  public void setResyncTime(java.math.BigDecimal newValue);
  // reference : initValue generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INIT_VALUE = "initValue";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: unqueuedReceiverComSpec_initValue_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INIT_VALUE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INIT_VALUE,"ar3x.swcomponenttemplate.communication.UnqueuedReceiverComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef.UNQUEUED_RECEIVER_COM_SPEC_INIT_VALUE_OWNER_RELATION_INFO;}};
  /**
   * Initial value to be used in case the sending component is not yet initialized. If the sender also specifies an init value the receiver's value will be used.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef getInitValue();
  /**
   * Initial value to be used in case the sending component is not yet initialized. If the sender also specifies an init value the receiver's value will be used.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setInitValue(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef newValue);
}
