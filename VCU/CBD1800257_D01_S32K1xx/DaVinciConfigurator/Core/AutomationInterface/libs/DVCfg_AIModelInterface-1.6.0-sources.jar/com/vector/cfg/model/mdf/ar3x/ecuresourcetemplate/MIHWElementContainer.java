package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Abstract class to enable the collection of HW Elements.
 */
public interface MIHWElementContainer extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement
{
  public final static String CLASS_NAME = "HWElementContainer";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIHWElementContainer> mdfGetClass();
  // reference : connection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CONNECTION = "connection";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hWElementContainer_connection_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CONNECTION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CONNECTION,"ar3x.ecuresourcetemplate.HWElementContainer",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWConnection.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWConnection.H_WELEMENT_CONTAINER_CONNECTION_OWNER_RELATION_INFO;}};
  /**
   * The connections gathered within the HWElementContainer.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWConnection> getConnection();
  // reference : containedElement generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CONTAINED_ELEMENT = "containedElement";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hWElementContainer_containedElement_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CONTAINED_ELEMENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CONTAINED_ELEMENT,"ar3x.ecuresourcetemplate.HWElementContainer",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.H_WELEMENT_CONTAINER_CONTAINED_ELEMENT_OWNER_RELATION_INFO;}};
  /**
   * The HW Elements contained in the HW Element Container.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement> getContainedElement();
}
