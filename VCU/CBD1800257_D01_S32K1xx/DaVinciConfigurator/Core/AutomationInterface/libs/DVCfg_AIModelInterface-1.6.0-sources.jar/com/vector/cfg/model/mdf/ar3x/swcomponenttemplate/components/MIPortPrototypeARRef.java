package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIPortPrototypeARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "PortPrototypeARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPortPrototypeARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: portPrototypeARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype> getRefTargets();
  // reference : arCalprmRefCalprmElementPrototype_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String AR_CALPRM_REF_CALPRM_ELEMENT_PROTOTYPE_PORT_PROTOTYPE_OWNER = "arCalprmRefCalprmElementPrototype_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo AR_CALPRM_REF_CALPRM_ELEMENT_PROTOTYPE_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(AR_CALPRM_REF_CALPRM_ELEMENT_PROTOTYPE_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MIArCalprmRefCalprmElementPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MIArCalprmRefCalprmElementPrototype.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MIArCalprmRefCalprmElementPrototype getArCalprmRefCalprmElementPrototypePortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setArCalprmRefCalprmElementPrototypePortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MIArCalprmRefCalprmElementPrototype newValue);
  // reference : dataPrototypeRefDataPrototype_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_PROTOTYPE_REF_DATA_PROTOTYPE_PORT_PROTOTYPE_OWNER = "dataPrototypeRefDataPrototype_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_PROTOTYPE_REF_DATA_PROTOTYPE_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_PROTOTYPE_REF_DATA_PROTOTYPE_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype getDataPrototypeRefDataPrototypePortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataPrototypeRefDataPrototypePortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype newValue);
  // reference : recordElementRefRecordElement_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RECORD_ELEMENT_REF_RECORD_ELEMENT_PORT_PROTOTYPE_OWNER = "recordElementRefRecordElement_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RECORD_ELEMENT_REF_RECORD_ELEMENT_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RECORD_ELEMENT_REF_RECORD_ELEMENT_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement getRecordElementRefRecordElementPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRecordElementRefRecordElementPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement newValue);
  // reference : ioHwAbstractionServerAnnotation_failureMonitoring_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IO_HW_ABSTRACTION_SERVER_ANNOTATION_FAILURE_MONITORING_OWNER = "ioHwAbstractionServerAnnotation_failureMonitoring_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: failureMonitoring
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IO_HW_ABSTRACTION_SERVER_ANNOTATION_FAILURE_MONITORING_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IO_HW_ABSTRACTION_SERVER_ANNOTATION_FAILURE_MONITORING_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation.FAILURE_MONITORING_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation getIoHwAbstractionServerAnnotationFailureMonitoringOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setIoHwAbstractionServerAnnotationFailureMonitoringOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation newValue);
  // reference : swcNvBlockNeeds_nvDataPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SWC_NV_BLOCK_NEEDS_NV_DATA_PORT_PROTOTYPE_OWNER = "swcNvBlockNeeds_nvDataPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: nvDataPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SWC_NV_BLOCK_NEEDS_NV_DATA_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SWC_NV_BLOCK_NEEDS_NV_DATA_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MISwcNvBlockNeeds.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MISwcNvBlockNeeds.NV_DATA_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MISwcNvBlockNeeds getSwcNvBlockNeedsNvDataPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwcNvBlockNeedsNvDataPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MISwcNvBlockNeeds newValue);
  // reference : roleBasedPortAssignment_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ROLE_BASED_PORT_ASSIGNMENT_PORT_PROTOTYPE_OWNER = "roleBasedPortAssignment_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ROLE_BASED_PORT_ASSIGNMENT_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ROLE_BASED_PORT_ASSIGNMENT_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedPortAssignment.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedPortAssignment.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedPortAssignment getRoleBasedPortAssignmentPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRoleBasedPortAssignmentPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedPortAssignment newValue);
  // reference : delegationConnectorPrototype_outerPort_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DELEGATION_CONNECTOR_PROTOTYPE_OUTER_PORT_OWNER = "delegationConnectorPrototype_outerPort_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: outerPort
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DELEGATION_CONNECTOR_PROTOTYPE_OUTER_PORT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DELEGATION_CONNECTOR_PROTOTYPE_OUTER_PORT_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIDelegationConnectorPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIDelegationConnectorPrototype.OUTER_PORT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIDelegationConnectorPrototype getDelegationConnectorPrototypeOuterPortOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDelegationConnectorPrototypeOuterPortOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIDelegationConnectorPrototype newValue);
  // reference : delegationConnectorPrototypeInnerPort_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_PORT_PROTOTYPE_OWNER = "delegationConnectorPrototypeInnerPort_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort getDelegationConnectorPrototypeInnerPortPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDelegationConnectorPrototypeInnerPortPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort newValue);
  // reference : serviceConnectorPrototypeApplicationPort_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_PORT_PROTOTYPE_OWNER = "serviceConnectorPrototypeApplicationPort_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort getServiceConnectorPrototypeApplicationPortPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setServiceConnectorPrototypeApplicationPortPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort newValue);
  // reference : serviceConnectorPrototypeServicePort_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVICE_CONNECTOR_PROTOTYPE_SERVICE_PORT_PORT_PROTOTYPE_OWNER = "serviceConnectorPrototypeServicePort_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_CONNECTOR_PROTOTYPE_SERVICE_PORT_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_CONNECTOR_PROTOTYPE_SERVICE_PORT_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeServicePort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeServicePort.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeServicePort getServiceConnectorPrototypeServicePortPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setServiceConnectorPrototypeServicePortPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeServicePort newValue);
  // reference : portGroup_portGroupOuterPort_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_GROUP_PORT_GROUP_OUTER_PORT_OWNER = "portGroup_portGroupOuterPort_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: portGroupOuterPort
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_GROUP_PORT_GROUP_OUTER_PORT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_GROUP_PORT_GROUP_OUTER_PORT_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup.PORT_GROUP_OUTER_PORT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup getPortGroupPortGroupOuterPortOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortGroupPortGroupOuterPortOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup newValue);
  // reference : calprmAccessCalprmElementPrototype_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CALPRM_ACCESS_CALPRM_ELEMENT_PROTOTYPE_PORT_PROTOTYPE_OWNER = "calprmAccessCalprmElementPrototype_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CALPRM_ACCESS_CALPRM_ELEMENT_PROTOTYPE_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CALPRM_ACCESS_CALPRM_ELEMENT_PROTOTYPE_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MICalprmAccessCalprmElementPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MICalprmAccessCalprmElementPrototype.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MICalprmAccessCalprmElementPrototype getCalprmAccessCalprmElementPrototypePortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCalprmAccessCalprmElementPrototypePortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MICalprmAccessCalprmElementPrototype newValue);
  // reference : portAPIOption_port_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_APIOPTION_PORT_OWNER = "portAPIOption_port_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: port
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_APIOPTION_PORT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_APIOPTION_PORT_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.portapioptions.MIPortAPIOption.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.portapioptions.MIPortAPIOption.PORT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.portapioptions.MIPortAPIOption getPortAPIOptionPortOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortAPIOptionPortOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.portapioptions.MIPortAPIOption newValue);
  // reference : clientServerToSignalGroupMappingMappedOperation_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CLIENT_SERVER_TO_SIGNAL_GROUP_MAPPING_MAPPED_OPERATION_PORT_PROTOTYPE_OWNER = "clientServerToSignalGroupMappingMappedOperation_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CLIENT_SERVER_TO_SIGNAL_GROUP_MAPPING_MAPPED_OPERATION_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CLIENT_SERVER_TO_SIGNAL_GROUP_MAPPING_MAPPED_OPERATION_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MIClientServerToSignalGroupMappingMappedOperation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MIClientServerToSignalGroupMappingMappedOperation.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MIClientServerToSignalGroupMappingMappedOperation getClientServerToSignalGroupMappingMappedOperationPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setClientServerToSignalGroupMappingMappedOperationPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MIClientServerToSignalGroupMappingMappedOperation newValue);
  // reference : senderReceiverToSignalGroupMappingDataElement_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SENDER_RECEIVER_TO_SIGNAL_GROUP_MAPPING_DATA_ELEMENT_PORT_PROTOTYPE_OWNER = "senderReceiverToSignalGroupMappingDataElement_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SENDER_RECEIVER_TO_SIGNAL_GROUP_MAPPING_DATA_ELEMENT_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SENDER_RECEIVER_TO_SIGNAL_GROUP_MAPPING_DATA_ELEMENT_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalGroupMappingDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalGroupMappingDataElement.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalGroupMappingDataElement getSenderReceiverToSignalGroupMappingDataElementPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSenderReceiverToSignalGroupMappingDataElementPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalGroupMappingDataElement newValue);
  // reference : senderReceiverToSignalMappingDataElement_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SENDER_RECEIVER_TO_SIGNAL_MAPPING_DATA_ELEMENT_PORT_PROTOTYPE_OWNER = "senderReceiverToSignalMappingDataElement_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SENDER_RECEIVER_TO_SIGNAL_MAPPING_DATA_ELEMENT_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SENDER_RECEIVER_TO_SIGNAL_MAPPING_DATA_ELEMENT_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalMappingDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalMappingDataElement.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalMappingDataElement getSenderReceiverToSignalMappingDataElementPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSenderReceiverToSignalMappingDataElementPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalMappingDataElement newValue);
  // reference : swcToSwcSignalDataElement_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SWC_TO_SWC_SIGNAL_DATA_ELEMENT_PORT_PROTOTYPE_OWNER = "swcToSwcSignalDataElement_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SWC_TO_SWC_SIGNAL_DATA_ELEMENT_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SWC_TO_SWC_SIGNAL_DATA_ELEMENT_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcSignalDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcSignalDataElement.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcSignalDataElement getSwcToSwcSignalDataElementPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwcToSwcSignalDataElementPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcSignalDataElement newValue);
  // reference : swcToSwcOperationArgumentsOperation_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SWC_TO_SWC_OPERATION_ARGUMENTS_OPERATION_PORT_PROTOTYPE_OWNER = "swcToSwcOperationArgumentsOperation_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SWC_TO_SWC_OPERATION_ARGUMENTS_OPERATION_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SWC_TO_SWC_OPERATION_ARGUMENTS_OPERATION_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcOperationArgumentsOperation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcOperationArgumentsOperation.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcOperationArgumentsOperation getSwcToSwcOperationArgumentsOperationPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwcToSwcOperationArgumentsOperationPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcOperationArgumentsOperation newValue);
  // reference : endToEndProtectionDataElementPrototypeDataElement_portPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String END_TO_END_PROTECTION_DATA_ELEMENT_PROTOTYPE_DATA_ELEMENT_PORT_PROTOTYPE_OWNER = "endToEndProtectionDataElementPrototypeDataElement_portPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo END_TO_END_PROTECTION_DATA_ELEMENT_PROTOTYPE_DATA_ELEMENT_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(END_TO_END_PROTECTION_DATA_ELEMENT_PROTOTYPE_DATA_ELEMENT_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.endtoendprotection.MIEndToEndProtectionDataElementPrototypeDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.endtoendprotection.MIEndToEndProtectionDataElementPrototypeDataElement.PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.endtoendprotection.MIEndToEndProtectionDataElementPrototypeDataElement getEndToEndProtectionDataElementPrototypeDataElementPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEndToEndProtectionDataElementPrototypeDataElementPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.endtoendprotection.MIEndToEndProtectionDataElementPrototypeDataElement newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype newRefTarget);

}
