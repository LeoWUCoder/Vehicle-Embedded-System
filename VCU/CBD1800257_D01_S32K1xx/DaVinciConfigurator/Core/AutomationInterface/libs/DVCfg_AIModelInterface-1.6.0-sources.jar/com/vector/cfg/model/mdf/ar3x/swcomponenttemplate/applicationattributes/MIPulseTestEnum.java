package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;
import javax.jmi.model.*;

public enum MIPulseTestEnum implements javax.jmi.reflect.RefEnum
{
  DISABLE("DISABLE"),
  ENABLE("ENABLE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "applicationattributes" );
    temp.add( "PulseTestEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIPulseTestEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
