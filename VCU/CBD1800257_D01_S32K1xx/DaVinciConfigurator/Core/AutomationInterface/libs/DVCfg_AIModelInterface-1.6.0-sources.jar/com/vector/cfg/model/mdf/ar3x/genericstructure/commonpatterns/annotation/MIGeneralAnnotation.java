package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This class represents textual comments (called annotations) which relate to the object in which it is aggregated. These are intended for use during the development process, to transfer information from one stage of the development process to the next one.   The approach is similar to the "yellow pads ..."  This abstract class can be specialized in order to add some further formal properties. 
 */
public interface MIGeneralAnnotation extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.model.autosar.commonpatterns.textmodel.multilanguagedata.MIHasLabelMultilanguageLongName
{
  public final static String CLASS_NAME = "GeneralAnnotation";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIGeneralAnnotation> mdfGetClass();
  // attribute : annotationOrigin generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ANNOTATION_ORIGIN = "annotationOrigin";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ANNOTATION_ORIGIN_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ANNOTATION_ORIGIN,"ar3x.genericstructure.commonpatterns.annotation.GeneralAnnotation",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element identifies the origin of the annotation. It is an arbitrary string since it can be an individual's name as well as the name of a tool or even the name of a process step.
   * Attribute-Kind = versionAttribute   */
  public String getAnnotationOrigin();
  /**
   * This element identifies the origin of the annotation. It is an arbitrary string since it can be an individual's name as well as the name of a tool or even the name of a process step.
   * Attribute-Kind = versionAttribute   */
  public void setAnnotationOrigin(String newValue);
  // reference : annotationText generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ANNOTATION_TEXT = "annotationText";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: generalAnnotation_annotationText_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ANNOTATION_TEXT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ANNOTATION_TEXT,"ar3x.genericstructure.commonpatterns.annotation.GeneralAnnotation",128,null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemark.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemark.GENERAL_ANNOTATION_ANNOTATION_TEXT_OWNER_RELATION_INFO;}};
  /**
   * This is the text of the annotation.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemark getAnnotationText();
  /**
   * This is the text of the annotation.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setAnnotationText(com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIRemark newValue);
}
