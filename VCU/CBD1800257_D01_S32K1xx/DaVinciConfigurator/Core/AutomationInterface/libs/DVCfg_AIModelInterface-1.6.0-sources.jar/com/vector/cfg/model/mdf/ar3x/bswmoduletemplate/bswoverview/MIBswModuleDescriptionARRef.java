package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIBswModuleDescriptionARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "BswModuleDescriptionARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBswModuleDescriptionARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescriptionARRef",null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: bswModuleDescriptionARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescriptionARRef",3,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription.BSW_MODULE_DESCRIPTION_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription> getRefTargets();
  // reference : complexDeviceDriverComponentType_bswModuleDescription_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPLEX_DEVICE_DRIVER_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER = "complexDeviceDriverComponentType_bswModuleDescription_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: bswModuleDescription
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPLEX_DEVICE_DRIVER_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPLEX_DEVICE_DRIVER_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescriptionARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComplexDeviceDriverComponentType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComplexDeviceDriverComponentType.BSW_MODULE_DESCRIPTION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComplexDeviceDriverComponentType getComplexDeviceDriverComponentTypeBswModuleDescriptionOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComplexDeviceDriverComponentTypeBswModuleDescriptionOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComplexDeviceDriverComponentType newValue);
  // reference : ecuAbstractionComponentType_bswModuleDescription_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ECU_ABSTRACTION_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER = "ecuAbstractionComponentType_bswModuleDescription_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: bswModuleDescription
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ECU_ABSTRACTION_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ECU_ABSTRACTION_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescriptionARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIEcuAbstractionComponentType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIEcuAbstractionComponentType.BSW_MODULE_DESCRIPTION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIEcuAbstractionComponentType getEcuAbstractionComponentTypeBswModuleDescriptionOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEcuAbstractionComponentTypeBswModuleDescriptionOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIEcuAbstractionComponentType newValue);
  // reference : serviceComponentType_bswModuleDescription_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVICE_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER = "serviceComponentType_bswModuleDescription_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: bswModuleDescription
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescriptionARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentType.BSW_MODULE_DESCRIPTION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentType getServiceComponentTypeBswModuleDescriptionOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setServiceComponentTypeBswModuleDescriptionOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIServiceComponentType newValue);
  // reference : bswBehavior_bswModule_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_BEHAVIOR_BSW_MODULE_OWNER = "bswBehavior_bswModule_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: bswModule
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_BEHAVIOR_BSW_MODULE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_BEHAVIOR_BSW_MODULE_OWNER,"ar3x.bswmoduletemplate.bswoverview.BswModuleDescriptionARRef",64,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior.BSW_MODULE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior getBswBehaviorBswModuleOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswBehaviorBswModuleOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription newRefTarget);

}
