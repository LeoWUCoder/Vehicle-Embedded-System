package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Contains the value for the generic axis parameter.
 */
public interface MISwGenericAxisParamValue extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwGenericAxisParamValue";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwGenericAxisParamValue> mdfGetClass();
  // reference : swGenericAxisParam_swGenericAxisParamValue_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_GENERIC_AXIS_PARAM_SW_GENERIC_AXIS_PARAM_VALUE_OWNER = "swGenericAxisParam_swGenericAxisParamValue_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swGenericAxisParamValue
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_GENERIC_AXIS_PARAM_SW_GENERIC_AXIS_PARAM_VALUE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_GENERIC_AXIS_PARAM_SW_GENERIC_AXIS_PARAM_VALUE_OWNER,"ar3x.commonstructure.datadefproperties.SwGenericAxisParamValue",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam.SW_GENERIC_AXIS_PARAM_VALUE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam getSwGenericAxisParamSwGenericAxisParamValueOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwGenericAxisParamSwGenericAxisParamValueOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam newValue);
  // reference : swGenericAxisParamValueChildren generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_GENERIC_AXIS_PARAM_VALUE_CHILDREN = "swGenericAxisParamValueChildren";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swGenericAxisParamValue_swGenericAxisParamValueChildren_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_GENERIC_AXIS_PARAM_VALUE_CHILDREN_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_GENERIC_AXIS_PARAM_VALUE_CHILDREN,"ar3x.commonstructure.datadefproperties.SwGenericAxisParamValue",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValueChild.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValueChild.SW_GENERIC_AXIS_PARAM_VALUE_SW_GENERIC_AXIS_PARAM_VALUE_CHILDREN_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValueChild> getSwGenericAxisParamValueChildren();
}
