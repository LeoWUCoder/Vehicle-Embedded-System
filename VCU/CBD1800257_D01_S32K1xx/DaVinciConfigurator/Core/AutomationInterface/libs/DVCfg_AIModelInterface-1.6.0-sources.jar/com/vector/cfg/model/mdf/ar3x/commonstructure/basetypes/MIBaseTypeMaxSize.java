package com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This is the maximum size of a BaseType in case of a dynamic BaseType.
 */
public interface MIBaseTypeMaxSize extends com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeSizeDefinition
{
  public final static String CLASS_NAME = "BaseTypeMaxSize";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBaseTypeMaxSize> mdfGetClass();
  // attribute : maxBaseTypeSize generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_BASE_TYPE_SIZE = "maxBaseTypeSize";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_BASE_TYPE_SIZE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_BASE_TYPE_SIZE,"ar3x.commonstructure.basetypes.BaseTypeMaxSize",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describes the maximum length of the BaseType  in bits
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMaxBaseTypeSize();
  /**
   * Describes the maximum length of the BaseType  in bits
   * Attribute-Kind = versionAttribute   */
  public void setMaxBaseTypeSize(java.math.BigInteger newValue);
}
