package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.specializedswrecordlayoutv;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwRecordLayoutV extends com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutV, com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContentChild
{
  public final static String CLASS_NAME = "SwRecordLayoutV";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwRecordLayoutV> mdfGetClass();
}
