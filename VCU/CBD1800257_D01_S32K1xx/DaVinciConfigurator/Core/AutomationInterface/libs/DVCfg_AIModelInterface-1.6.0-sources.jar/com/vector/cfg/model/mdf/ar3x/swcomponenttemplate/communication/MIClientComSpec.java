package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Client specific communication attributes (R-Port and client-server interface).
 */
public interface MIClientComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIRPortComSpec
{
  public final static String CLASS_NAME = "ClientComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIClientComSpec> mdfGetClass();
  // reference : operation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OPERATION = "operation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: clientComSpec_operation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OPERATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OPERATION,"ar3x.swcomponenttemplate.communication.ClientComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIOperationPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIOperationPrototypeARRef.CLIENT_COM_SPEC_OPERATION_OWNER_RELATION_INFO;}};
  /**
   * Operation these attributes belong to.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIOperationPrototypeARRef getOperation();
  /**
   * Operation these attributes belong to.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setOperation(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIOperationPrototypeARRef newValue);
}
