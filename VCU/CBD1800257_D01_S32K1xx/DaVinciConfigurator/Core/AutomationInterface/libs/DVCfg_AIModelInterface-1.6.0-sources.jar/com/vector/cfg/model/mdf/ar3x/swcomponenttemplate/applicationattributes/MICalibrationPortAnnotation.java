package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Annotation to a port used for calibration regarding a certain CalprmElement. 
 */
public interface MICalibrationPortAnnotation extends com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIGeneralAnnotation
{
  public final static String CLASS_NAME = "CalibrationPortAnnotation";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICalibrationPortAnnotation> mdfGetClass();
  // reference : portPrototype_calibrationPortAnnotation_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_PROTOTYPE_CALIBRATION_PORT_ANNOTATION_OWNER = "portPrototype_calibrationPortAnnotation_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: calibrationPortAnnotation
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_PROTOTYPE_CALIBRATION_PORT_ANNOTATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_PROTOTYPE_CALIBRATION_PORT_ANNOTATION_OWNER,"ar3x.swcomponenttemplate.applicationattributes.CalibrationPortAnnotation",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.CALIBRATION_PORT_ANNOTATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype getPortPrototypeCalibrationPortAnnotationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortPrototypeCalibrationPortAnnotationOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype newValue);
  // reference : calprmElement generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CALPRM_ELEMENT = "calprmElement";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: calibrationPortAnnotation_calprmElement_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CALPRM_ELEMENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CALPRM_ELEMENT,"ar3x.swcomponenttemplate.applicationattributes.CalibrationPortAnnotation",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.MICalprmElementPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.MICalprmElementPrototypeARRef.CALIBRATION_PORT_ANNOTATION_CALPRM_ELEMENT_OWNER_RELATION_INFO;}};
  /**
   * The instance of calprm element annotated.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.MICalprmElementPrototypeARRef getCalprmElement();
  /**
   * The instance of calprm element annotated.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCalprmElement(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.MICalprmElementPrototypeARRef newValue);
}
