package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element is similar to <SW-INTERFACE-ACCESSED-ELEMENT-SET> but applies to <SW-SERVICE> . To some extent it is now possible to epress the access to interface elements  * within a software component represented by ( <swFeature> ), which is the mainly a functional view  * within a process represented by <SW-SERVICE>, which is more the dynamic view. These processes are part of compontents (represented by ownership and imports, which makes it possible to retrieve the functional view from the dynamic view (but ** vice versa).
 */
public interface MISwServiceAccessedElementSet extends com.vector.cfg.model.mdf.ar3x.commonstructure.systemconstant.MIIsSyscond
{
  public final static String CLASS_NAME = "SwServiceAccessedElementSet";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwServiceAccessedElementSet> mdfGetClass();
  // reference : swService_swServiceAccessedElementSet_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_SERVICE_SW_SERVICE_ACCESSED_ELEMENT_SET_OWNER = "swService_swServiceAccessedElementSet_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swServiceAccessedElementSet
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_SERVICE_SW_SERVICE_ACCESSED_ELEMENT_SET_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_SERVICE_SW_SERVICE_ACCESSED_ELEMENT_SET_OWNER,"ar3x.commonstructure.serviceprocesstask.SwServiceAccessedElementSet",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService.SW_SERVICE_ACCESSED_ELEMENT_SET_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService getSwServiceSwServiceAccessedElementSetOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwServiceSwServiceAccessedElementSetOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask.MISwService newValue);
}
