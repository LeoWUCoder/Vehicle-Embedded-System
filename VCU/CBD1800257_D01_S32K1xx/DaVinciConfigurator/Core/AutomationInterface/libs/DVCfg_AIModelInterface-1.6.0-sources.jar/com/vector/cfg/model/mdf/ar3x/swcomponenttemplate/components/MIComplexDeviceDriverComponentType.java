package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The ComplexDeviceDriver Component is a special AtomicSoftwareComponent that has direct access to hardware on an ECUand which is therefore linked to a specific ECU or specific hardware. The ComplexDeviceDriver ComponentType introduces the possibility to link from the software representation to its hardware description provided by the ECU Resource Template. 
 */
public interface MIComplexDeviceDriverComponentType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType
{
  public final static String CLASS_NAME = "ComplexDeviceDriverComponentType";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIComplexDeviceDriverComponentType> mdfGetClass();
  // reference : hardwareElement generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String HARDWARE_ELEMENT = "hardwareElement";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: complexDeviceDriverComponentType_hardwareElement_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HARDWARE_ELEMENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HARDWARE_ELEMENT,"ar3x.swcomponenttemplate.components.ComplexDeviceDriverComponentType",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef.COMPLEX_DEVICE_DRIVER_COMPONENT_TYPE_HARDWARE_ELEMENT_OWNER_RELATION_INFO;}};
  /**
   * Reference from the ComplexDeviceDriverComponentType to the description of the used HWElements.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementARRef> getHardwareElement();
  // reference : bswModuleDescription generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_DESCRIPTION = "bswModuleDescription";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: complexDeviceDriverComponentType_bswModuleDescription_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DESCRIPTION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DESCRIPTION,"ar3x.swcomponenttemplate.components.ComplexDeviceDriverComponentType",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef.COMPLEX_DEVICE_DRIVER_COMPONENT_TYPE_BSW_MODULE_DESCRIPTION_OWNER_RELATION_INFO;}};
  /**
   * Reference from the ComplexDeviceDriverComponentType to the Basic Software Module Description describing the BSW part of the Complex Device Driver Component.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef> getBswModuleDescription();
}
