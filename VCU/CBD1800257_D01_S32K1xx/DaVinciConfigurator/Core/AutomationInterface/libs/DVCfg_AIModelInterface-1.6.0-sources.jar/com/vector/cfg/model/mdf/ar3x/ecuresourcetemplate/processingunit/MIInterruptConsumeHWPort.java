package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This port represents the drain of an interrupt request, i.e. the HWElement (in the majority of cases this will be a ProcessingUnit) to which this HWPort is attached is capable of accepting interrupt requests.
 */
public interface MIInterruptConsumeHWPort extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptHWPort
{
  public final static String CLASS_NAME = "InterruptConsumeHWPort";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIInterruptConsumeHWPort> mdfGetClass();
  // attribute : priority generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PRIORITY = "priority";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PRIORITY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PRIORITY,"ar3x.ecuresourcetemplate.processingunit.InterruptConsumeHWPort",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Some processing units offer different interrupt levels. It describes the priority in which the incoming interrupts are handled.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getPriority();
  /**
   * Some processing units offer different interrupt levels. It describes the priority in which the incoming interrupts are handled.
   * Attribute-Kind = versionAttribute   */
  public void setPriority(java.math.BigInteger newValue);
  // attribute : latency generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String LATENCY = "latency";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo LATENCY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,LATENCY,"ar3x.ecuresourcetemplate.processingunit.InterruptConsumeHWPort",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Interrupt Latency: time passed from the occurrence of the interrupt request until the interrupt service routine is entered - HW: Register organisation; operations are necessary for context save. - SW: As SW can control the enabling/disabling of the interrupt SW determines a great part of the according time. - System: several constraints define the min/max times allowed for software to enable / disable interrupts.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getLatency();
  /**
   * Interrupt Latency: time passed from the occurrence of the interrupt request until the interrupt service routine is entered - HW: Register organisation; operations are necessary for context save. - SW: As SW can control the enabling/disabling of the interrupt SW determines a great part of the according time. - System: several constraints define the min/max times allowed for software to enable / disable interrupts.
   * Attribute-Kind = versionAttribute   */
  public void setLatency(java.math.BigDecimal newValue);
  // attribute : maskable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MASKABLE = "maskable";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MASKABLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MASKABLE,"ar3x.ecuresourcetemplate.processingunit.InterruptConsumeHWPort",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines if interrupts can be selected to be processed by the interrupt controller.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMaskable();
  /**
   * Defines if interrupts can be selected to be processed by the interrupt controller.
   * Attribute-Kind = versionAttribute   */
  public void setMaskable(Boolean newValue);
  // attribute : activationSource generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ACTIVATION_SOURCE = "activationSource";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ACTIVATION_SOURCE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ACTIVATION_SOURCE,"ar3x.ecuresourcetemplate.processingunit.InterruptConsumeHWPort",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines which hardware resource activate the interrupt. Typically any peripheral HW Element  can activate an interrupt.  E.g. CAN, SCI, SPI, Timer, ADC. Even simple digital I/O can activate an interrupt. Some microC have in this context dedicatated pins which act only as activation for interrupt. The connection from the according HW Element is made by the HW Port.
   * Attribute-Kind = versionAttribute   */
  public String getActivationSource();
  /**
   * Defines which hardware resource activate the interrupt. Typically any peripheral HW Element  can activate an interrupt.  E.g. CAN, SCI, SPI, Timer, ADC. Even simple digital I/O can activate an interrupt. Some microC have in this context dedicatated pins which act only as activation for interrupt. The connection from the according HW Element is made by the HW Port.
   * Attribute-Kind = versionAttribute   */
  public void setActivationSource(String newValue);
}
