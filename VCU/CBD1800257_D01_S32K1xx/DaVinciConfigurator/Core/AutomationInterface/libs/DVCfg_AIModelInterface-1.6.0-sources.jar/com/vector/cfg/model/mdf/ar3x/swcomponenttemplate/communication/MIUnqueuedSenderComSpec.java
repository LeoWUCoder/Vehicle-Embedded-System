package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes specific to distribution of data (P-Port, sender-receiver interface and data element carries "data" opposed to carrying an "event").
 */
public interface MIUnqueuedSenderComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MISenderComSpec
{
  public final static String CLASS_NAME = "UnqueuedSenderComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIUnqueuedSenderComSpec> mdfGetClass();
  // attribute : canInvalidate generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CAN_INVALIDATE = "canInvalidate";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CAN_INVALIDATE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CAN_INVALIDATE,"ar3x.swcomponenttemplate.communication.UnqueuedSenderComSpec",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Flag whether the component can actively invalidate data.
   * Attribute-Kind = versionAttribute   */
  public Boolean getCanInvalidate();
  /**
   * Flag whether the component can actively invalidate data.
   * Attribute-Kind = versionAttribute   */
  public void setCanInvalidate(Boolean newValue);
  // reference : initValue generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INIT_VALUE = "initValue";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: unqueuedSenderComSpec_initValue_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INIT_VALUE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INIT_VALUE,"ar3x.swcomponenttemplate.communication.UnqueuedSenderComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef.UNQUEUED_SENDER_COM_SPEC_INIT_VALUE_OWNER_RELATION_INFO;}};
  /**
   * Init value to be sent if sender component is not yet fully initialized, but receiver needs data already.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef getInitValue();
  /**
   * Init value to be sent if sender component is not yet fully initialized, but receiver needs data already.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setInitValue(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef newValue);
}
