package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIMemoryMappedHWPortARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "MemoryMappedHWPortARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIMemoryMappedHWPortARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.ecuresourcetemplate.memory.MemoryMappedHWPortARRef",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPortTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPortTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPortTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: memoryMappedHWPortARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.ecuresourcetemplate.memory.MemoryMappedHWPortARRef",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPort.MEMORY_MAPPED_HWPORT_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPort> getRefTargets();
  // reference : mPU_protectedMemoryHWPort_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String M_PU_PROTECTED_MEMORY_HWPORT_OWNER = "mPU_protectedMemoryHWPort_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: protectedMemoryHWPort
  public static final ru.novosoft.mdf.impl.MDFRelationInfo M_PU_PROTECTED_MEMORY_HWPORT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(M_PU_PROTECTED_MEMORY_HWPORT_OWNER,"ar3x.ecuresourcetemplate.memory.MemoryMappedHWPortARRef",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU.PROTECTED_MEMORY_HWPORT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU getMPUProtectedMemoryHWPortOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setMPUProtectedMemoryHWPortOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIMPU newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPort getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPort newRefTarget);

}
