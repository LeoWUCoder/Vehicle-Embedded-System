package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * <swClassAttrInstanceImpl> is used to create an instance from a model (Models are defined with SW-CLASS) where some specifications shall be changed / overwritten. This implementation will then be a instance specific implementation (Classes are usually only implemented under <swClassImpls>).
 */
public interface MISwClassAttrInstanceImpl extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwVariableImpl, com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MIHasSwCalprmImpl
{
  public final static String CLASS_NAME = "SwClassAttrInstanceImpl";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwClassAttrInstanceImpl> mdfGetClass();
  // reference : swClassInstance_swClassAttrInstanceImpl_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CLASS_INSTANCE_SW_CLASS_ATTR_INSTANCE_IMPL_OWNER = "swClassInstance_swClassAttrInstanceImpl_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swClassAttrInstanceImpl
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CLASS_INSTANCE_SW_CLASS_ATTR_INSTANCE_IMPL_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CLASS_INSTANCE_SW_CLASS_ATTR_INSTANCE_IMPL_OWNER,"ar3x.commonstructure.swclass.SwClassAttrInstanceImpl",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassInstance.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassInstance.SW_CLASS_ATTR_INSTANCE_IMPL_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassInstance getSwClassInstanceSwClassAttrInstanceImplOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwClassInstanceSwClassAttrInstanceImplOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassInstance newValue);
  // reference : swClassImpl generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CLASS_IMPL = "swClassImpl";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swClassAttrInstanceImpl_swClassImpl_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CLASS_IMPL_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CLASS_IMPL,"ar3x.commonstructure.swclass.SwClassAttrInstanceImpl",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassImpl.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassImpl.SW_CLASS_ATTR_INSTANCE_IMPL_SW_CLASS_IMPL_OWNER_RELATION_INFO;}};
  /**
   * This element describes the implementation details of a class attribute which manifests itself as a class.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassImpl> getSwClassImpl();
}
