package com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This is the absolute size of the basetype. In this case the BaseType is of fixed lenght.
 */
public interface MIBaseTypeAbsSize extends com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeSizeDefinition
{
  public final static String CLASS_NAME = "BaseTypeAbsSize";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBaseTypeAbsSize> mdfGetClass();
  // attribute : baseTypeSize generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BASE_TYPE_SIZE = "baseTypeSize";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BASE_TYPE_SIZE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BASE_TYPE_SIZE,"ar3x.commonstructure.basetypes.BaseTypeAbsSize",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describes the length of the data type specified in the container in bits.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getBaseTypeSize();
  /**
   * Describes the length of the data type specified in the container in bits.
   * Attribute-Kind = versionAttribute   */
  public void setBaseTypeSize(java.math.BigInteger newValue);
}
