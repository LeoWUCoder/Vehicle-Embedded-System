package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the abstract needs of a compoment or module on the configuration of OBD Services in relation to a particular PID (parameter identifier), which is supported by this component or module.
 */
public interface MIObdPidServiceNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "ObdPidServiceNeeds";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIObdPidServiceNeeds> mdfGetClass();
  // attribute : parameterId generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PARAMETER_ID = "parameterId";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PARAMETER_ID_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PARAMETER_ID,"ar3x.commonstructure.serviceneeds.ObdPidServiceNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Standardized parameter identifier (PID) according to the OBD standard specified in attribute "standard".
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getParameterId();
  /**
   * Standardized parameter identifier (PID) according to the OBD standard specified in attribute "standard".
   * Attribute-Kind = versionAttribute   */
  public void setParameterId(java.math.BigInteger newValue);
  // attribute : dataLength generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DATA_LENGTH = "dataLength";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DATA_LENGTH_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DATA_LENGTH,"ar3x.commonstructure.serviceneeds.ObdPidServiceNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Length of data (in bytes) provided for this particular PID.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getDataLength();
  /**
   * Length of data (in bytes) provided for this particular PID.
   * Attribute-Kind = versionAttribute   */
  public void setDataLength(java.math.BigInteger newValue);
  // attribute : standard generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String STANDARD = "standard";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo STANDARD_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,STANDARD,"ar3x.commonstructure.serviceneeds.ObdPidServiceNeeds",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Annotates the standard according to which the PID is given, e.g. "ISO15031-5" or "SAE J1979 Rev May 2007".
   * Attribute-Kind = versionAttribute   */
  public String getStandard();
  /**
   * Annotates the standard according to which the PID is given, e.g. "ISO15031-5" or "SAE J1979 Rev May 2007".
   * Attribute-Kind = versionAttribute   */
  public void setStandard(String newValue);
}
