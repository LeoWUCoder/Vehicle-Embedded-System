package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;
import javax.jmi.model.*;

public enum MIBswSporadicEventTypesEnum implements javax.jmi.reflect.RefEnum
{
  BSW_SPORADIC_EVENT("BSW-SPORADIC-EVENT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "bswbehavior" );
    temp.add( "BswSporadicEventTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIBswSporadicEventTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
