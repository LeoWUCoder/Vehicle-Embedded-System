package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes of an R-Port. This class will contain attributes that are valid for all kinds of require-ports, independent of client-server or sender-receiver communication patterns.
 */
public interface MIRPortComSpec extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "RPortComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIRPortComSpec> mdfGetClass();
  // reference : rPortPrototype_requiredComSpec_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String R_PORT_PROTOTYPE_REQUIRED_COM_SPEC_OWNER = "rPortPrototype_requiredComSpec_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: requiredComSpec
  public static final ru.novosoft.mdf.impl.MDFRelationInfo R_PORT_PROTOTYPE_REQUIRED_COM_SPEC_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(R_PORT_PROTOTYPE_REQUIRED_COM_SPEC_OWNER,"ar3x.swcomponenttemplate.communication.RPortComSpec",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototype.REQUIRED_COM_SPEC_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototype getRPortPrototypeRequiredComSpecOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRPortPrototypeRequiredComSpecOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototype newValue);
}
