package com.vector.cfg.model.mdf.ar3x.commonstructure.axis;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element describes a specific parameter of a generic axis. The name of the parameter is defined through a reference to a parameter type defined on a corresponding axis type.
 */
public interface MISwGenericAxisParam extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwGenericAxisParam";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwGenericAxisParam> mdfGetClass();
  // reference : swAxisGeneric_swGenericAxisParam_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_AXIS_GENERIC_SW_GENERIC_AXIS_PARAM_OWNER = "swAxisGeneric_swGenericAxisParam_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swGenericAxisParam
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_AXIS_GENERIC_SW_GENERIC_AXIS_PARAM_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_AXIS_GENERIC_SW_GENERIC_AXIS_PARAM_OWNER,"ar3x.commonstructure.axis.SwGenericAxisParam",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGeneric.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGeneric.SW_GENERIC_AXIS_PARAM_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGeneric getSwAxisGenericSwGenericAxisParamOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwAxisGenericSwGenericAxisParamOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGeneric newValue);
  // reference : swGenericAxisParamValue generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_GENERIC_AXIS_PARAM_VALUE = "swGenericAxisParamValue";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swGenericAxisParam_swGenericAxisParamValue_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_GENERIC_AXIS_PARAM_VALUE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_GENERIC_AXIS_PARAM_VALUE,"ar3x.commonstructure.axis.SwGenericAxisParam",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValue.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValue.SW_GENERIC_AXIS_PARAM_SW_GENERIC_AXIS_PARAM_VALUE_OWNER_RELATION_INFO;}};
  /**
   * The value of the parameter.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValue getSwGenericAxisParamValue();
  /**
   * The value of the parameter.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwGenericAxisParamValue(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValue newValue);
  // reference : swGenericAxisParamType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_GENERIC_AXIS_PARAM_TYPE = "swGenericAxisParamType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swGenericAxisParam_swGenericAxisParamType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_GENERIC_AXIS_PARAM_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_GENERIC_AXIS_PARAM_TYPE,"ar3x.commonstructure.axis.SwGenericAxisParam",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamTypeARRef.SW_GENERIC_AXIS_PARAM_SW_GENERIC_AXIS_PARAM_TYPE_OWNER_RELATION_INFO;}};
  /**
   * Parameter type defined on a corresponding axis type. References can only be made to axis parameters types which are defined within the referenced axis type.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamTypeARRef getSwGenericAxisParamType();
  /**
   * Parameter type defined on a corresponding axis type. References can only be made to axis parameters types which are defined within the referenced axis type.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwGenericAxisParamType(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamTypeARRef newValue);
}
