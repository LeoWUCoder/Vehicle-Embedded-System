package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The ApplicationSoftwareComponentType is used to represent the application software. 
 */
public interface MIApplicationSoftwareComponentType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType
{
  public final static String CLASS_NAME = "ApplicationSoftwareComponentType";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIApplicationSoftwareComponentType> mdfGetClass();
}
