package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Abstract class to specify the ability to connect HWPorts.
 */
public interface MIHWConnection extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "HWConnection";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIHWConnection> mdfGetClass();
  // reference : hWElementContainer_connection_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String H_WELEMENT_CONTAINER_CONNECTION_OWNER = "hWElementContainer_connection_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: connection
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WELEMENT_CONTAINER_CONNECTION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WELEMENT_CONTAINER_CONNECTION_OWNER,"ar3x.ecuresourcetemplate.HWConnection",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementContainer.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementContainer.CONNECTION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementContainer getHWElementContainerConnectionOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHWElementContainerConnectionOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementContainer newValue);
  // reference : connectedPin generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CONNECTED_PIN = "connectedPin";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hWConnection_connectedPin_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CONNECTED_PIN_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CONNECTED_PIN,"ar3x.ecuresourcetemplate.HWConnection",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIPinHWConnection.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIPinHWConnection.H_WCONNECTION_CONNECTED_PIN_OWNER_RELATION_INFO;}};
  /**
   * A set of connections between HWPins of the connected HWPorts.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIPinHWConnection> getConnectedPin();
}
