package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element describes the prototype declaration of a class attribute, which appears in the form of a class.
 */
public interface MISwClassPrototype extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable, com.vector.cfg.model.mdf.ar3x.commonstructure.systemconstant.MIIsSyscond
{
  public final static String CLASS_NAME = "SwClassPrototype";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwClassPrototype> mdfGetClass();
  // reference : swClassPrototypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_CLASS_PROTOTYPE_ARREF_REF_TARGETS_OWNER = "swClassPrototypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CLASS_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CLASS_PROTOTYPE_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.swclass.SwClassPrototype",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassPrototypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassPrototypeARRef> getSwClassPrototypeARRefRefTargetsOwner();
}
