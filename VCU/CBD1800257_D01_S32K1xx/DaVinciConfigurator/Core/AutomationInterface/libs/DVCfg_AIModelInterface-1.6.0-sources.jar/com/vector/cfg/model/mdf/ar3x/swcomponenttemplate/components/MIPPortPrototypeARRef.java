package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIPPortPrototypeARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "PPortPrototypeARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPPortPrototypeARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.swcomponenttemplate.components.PPortPrototypeARRef",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototypeTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototypeTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototypeTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: pPortPrototypeARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.swcomponenttemplate.components.PPortPrototypeARRef",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototype.P_PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototype> getRefTargets();
  // reference : roleBasedPPortAssignment_pPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ROLE_BASED_PPORT_ASSIGNMENT_P_PORT_PROTOTYPE_OWNER = "roleBasedPPortAssignment_pPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: pPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ROLE_BASED_PPORT_ASSIGNMENT_P_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ROLE_BASED_PPORT_ASSIGNMENT_P_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedPPortAssignment.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedPPortAssignment.P_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedPPortAssignment getRoleBasedPPortAssignmentPPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRoleBasedPPortAssignmentPPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedPPortAssignment newValue);
  // reference : assemblyConnectorPrototypeProvider_providerPPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_PROVIDER_PPORT_PROTOTYPE_OWNER = "assemblyConnectorPrototypeProvider_providerPPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: providerPPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_PROVIDER_PPORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_PROVIDER_PPORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider.PROVIDER_PPORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider getAssemblyConnectorPrototypeProviderProviderPPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setAssemblyConnectorPrototypeProviderProviderPPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider newValue);
  // reference : modeSwitchPointModeGroup_pPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MODE_SWITCH_POINT_MODE_GROUP_P_PORT_PROTOTYPE_OWNER = "modeSwitchPointModeGroup_pPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: pPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MODE_SWITCH_POINT_MODE_GROUP_P_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MODE_SWITCH_POINT_MODE_GROUP_P_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.modedeclarationgroup.instanceref.MIModeSwitchPointModeGroup.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.modedeclarationgroup.instanceref.MIModeSwitchPointModeGroup.P_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.modedeclarationgroup.instanceref.MIModeSwitchPointModeGroup getModeSwitchPointModeGroupPPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setModeSwitchPointModeGroupPPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.modedeclarationgroup.instanceref.MIModeSwitchPointModeGroup newValue);
  // reference : dataSendPointDataElement_pPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_SEND_POINT_DATA_ELEMENT_P_PORT_PROTOTYPE_OWNER = "dataSendPointDataElement_pPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: pPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_SEND_POINT_DATA_ELEMENT_P_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_SEND_POINT_DATA_ELEMENT_P_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataSendPointDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataSendPointDataElement.P_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataSendPointDataElement getDataSendPointDataElementPPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataSendPointDataElementPPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataSendPointDataElement newValue);
  // reference : dataWriteAccessDataElement_pPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_WRITE_ACCESS_DATA_ELEMENT_P_PORT_PROTOTYPE_OWNER = "dataWriteAccessDataElement_pPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: pPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_WRITE_ACCESS_DATA_ELEMENT_P_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_WRITE_ACCESS_DATA_ELEMENT_P_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataWriteAccessDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataWriteAccessDataElement.P_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataWriteAccessDataElement getDataWriteAccessDataElementPPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataWriteAccessDataElementPPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataWriteAccessDataElement newValue);
  // reference : operationInvokedEventOperation_pPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OPERATION_INVOKED_EVENT_OPERATION_P_PORT_PROTOTYPE_OWNER = "operationInvokedEventOperation_pPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: pPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OPERATION_INVOKED_EVENT_OPERATION_P_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OPERATION_INVOKED_EVENT_OPERATION_P_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.PPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIOperationInvokedEventOperation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIOperationInvokedEventOperation.P_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIOperationInvokedEventOperation getOperationInvokedEventOperationPPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setOperationInvokedEventOperationPPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIOperationInvokedEventOperation newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototype getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototype newRefTarget);

}
