package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Time information for ECU and PU startup.
 */
public interface MIBootTime extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "BootTime";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBootTime> mdfGetClass();
  // attribute : coldStartTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String COLD_START_TIME = "coldStartTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo COLD_START_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,COLD_START_TIME,"ar3x.ecuresourcetemplate.basicelements.BootTime",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Time it takes to come from a completely powered down state to the HWInit state in seconds.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getColdStartTime();
  /**
   * Time it takes to come from a completely powered down state to the HWInit state in seconds.
   * Attribute-Kind = versionAttribute   */
  public void setColdStartTime(java.math.BigDecimal newValue);
  // attribute : resetTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESET_TIME = "resetTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESET_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESET_TIME,"ar3x.ecuresourcetemplate.basicelements.BootTime",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Time it takes from the reset initiation to the HWInit state in seconds.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getResetTime();
  /**
   * Time it takes from the reset initiation to the HWInit state in seconds.
   * Attribute-Kind = versionAttribute   */
  public void setResetTime(java.math.BigDecimal newValue);
  // reference : processingUnit_bootTime_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROCESSING_UNIT_BOOT_TIME_OWNER = "processingUnit_bootTime_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: bootTime
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROCESSING_UNIT_BOOT_TIME_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROCESSING_UNIT_BOOT_TIME_OWNER,"ar3x.ecuresourcetemplate.basicelements.BootTime",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.BOOT_TIME_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit getProcessingUnitBootTimeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProcessingUnitBootTimeOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit newValue);
}
