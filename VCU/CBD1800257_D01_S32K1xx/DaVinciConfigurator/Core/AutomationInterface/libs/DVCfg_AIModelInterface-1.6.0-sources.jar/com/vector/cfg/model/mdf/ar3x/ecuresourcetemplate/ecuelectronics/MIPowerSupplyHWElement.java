package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The Power Supply HW Element provides information about the power source of the ECU. There can be multiple power supplies within one ECU.
 */
public interface MIPowerSupplyHWElement extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIECUElectronics
{
  public final static String CLASS_NAME = "PowerSupplyHWElement";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPowerSupplyHWElement> mdfGetClass();
  // attribute : backupCapacity generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BACKUP_CAPACITY = "backupCapacity";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BACKUP_CAPACITY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BACKUP_CAPACITY,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Define the capability assigned to the output of the Power Supply HW Element to maintain the output voltage stable for a certain time after the undervoltage status information is asserted. In the ECU Resource Template the Backup Capacity is described as time. The time is dependent from the current consumed by the HW Elements connected to the according output, the SW-functions controlling the ECU hardware and the implementation of the Power Supply HW Element itself. The time has to be calculated from the available capacitors or measured in the application. Example: For the energy storage for airbag applications capacitors stores energy for the airbag ignition for several seconds even the battery is completely disconnected. Example: A combined step up/step down DC/DC converter can deliver a stable 5V volt output even when the input has already dropped to 3V. The undervoltage status is already set at a Vbatt level of 6V. Unit: Ah
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getBackupCapacity();
  /**
   * Define the capability assigned to the output of the Power Supply HW Element to maintain the output voltage stable for a certain time after the undervoltage status information is asserted. In the ECU Resource Template the Backup Capacity is described as time. The time is dependent from the current consumed by the HW Elements connected to the according output, the SW-functions controlling the ECU hardware and the implementation of the Power Supply HW Element itself. The time has to be calculated from the available capacitors or measured in the application. Example: For the energy storage for airbag applications capacitors stores energy for the airbag ignition for several seconds even the battery is completely disconnected. Example: A combined step up/step down DC/DC converter can deliver a stable 5V volt output even when the input has already dropped to 3V. The undervoltage status is already set at a Vbatt level of 6V. Unit: Ah
   * Attribute-Kind = versionAttribute   */
  public void setBackupCapacity(java.math.BigDecimal newValue);
  // attribute : defaultVoltageOnReset generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEFAULT_VOLTAGE_ON_RESET = "defaultVoltageOnReset";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEFAULT_VOLTAGE_ON_RESET_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEFAULT_VOLTAGE_ON_RESET,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This value defines the nominal output voltage, which is supplied as default after a reset occured. This attribute is only applicable at power supplies with a programmable output voltage.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getDefaultVoltageOnReset();
  /**
   * This value defines the nominal output voltage, which is supplied as default after a reset occured. This attribute is only applicable at power supplies with a programmable output voltage.
   * Attribute-Kind = versionAttribute   */
  public void setDefaultVoltageOnReset(java.math.BigDecimal newValue);
  // attribute : maxVoltage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_VOLTAGE = "maxVoltage";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_VOLTAGE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_VOLTAGE,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The maximum voltage that can be supplied.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMaxVoltage();
  /**
   * The maximum voltage that can be supplied.
   * Attribute-Kind = versionAttribute   */
  public void setMaxVoltage(java.math.BigDecimal newValue);
  // attribute : minVoltage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_VOLTAGE = "minVoltage";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_VOLTAGE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_VOLTAGE,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The minimum voltage that can be supplied.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMinVoltage();
  /**
   * The minimum voltage that can be supplied.
   * Attribute-Kind = versionAttribute   */
  public void setMinVoltage(java.math.BigDecimal newValue);
  // attribute : notificationOverTemperature generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String NOTIFICATION_OVER_TEMPERATURE = "notificationOverTemperature";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo NOTIFICATION_OVER_TEMPERATURE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,NOTIFICATION_OVER_TEMPERATURE,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Status information that the on-chip temperature on the Power Supply Hardware Element exceed the maximal, defined limit.
   * Attribute-Kind = versionAttribute   */
  public Boolean getNotificationOverTemperature();
  /**
   * Status information that the on-chip temperature on the Power Supply Hardware Element exceed the maximal, defined limit.
   * Attribute-Kind = versionAttribute   */
  public void setNotificationOverTemperature(Boolean newValue);
  // attribute : notificationReset generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String NOTIFICATION_RESET = "notificationReset";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo NOTIFICATION_RESET_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,NOTIFICATION_RESET,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The power on reset is generated depending on the output voltage. Valid operation of the ECU and the connected HW Elements are only possible if the output voltage is stable and within the specified output voltage range. Therefore most of the Power Supply HW Elements contain a circuitry, which generate a output signal which indicates an instable or unspecified voltage at the output. Some Power Supply HW Elements offer the possibility to adjust the reset thresholds.
   * Attribute-Kind = versionAttribute   */
  public Boolean getNotificationReset();
  /**
   * The power on reset is generated depending on the output voltage. Valid operation of the ECU and the connected HW Elements are only possible if the output voltage is stable and within the specified output voltage range. Therefore most of the Power Supply HW Elements contain a circuitry, which generate a output signal which indicates an instable or unspecified voltage at the output. Some Power Supply HW Elements offer the possibility to adjust the reset thresholds.
   * Attribute-Kind = versionAttribute   */
  public void setNotificationReset(Boolean newValue);
  // attribute : resetDelay generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESET_DELAY = "resetDelay";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESET_DELAY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESET_DELAY,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The reset signal at the power-on reset is delayed by the Power Supply HW Element in order to enable the different ECU HW Elements to enter a stable and defined operation state when the reset signal is released. Unit: s
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getResetDelay();
  /**
   * The reset signal at the power-on reset is delayed by the Power Supply HW Element in order to enable the different ECU HW Elements to enter a stable and defined operation state when the reset signal is released. Unit: s
   * Attribute-Kind = versionAttribute   */
  public void setResetDelay(java.math.BigDecimal newValue);
  // attribute : resetOnFaultBehaviour generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESET_ON_FAULT_BEHAVIOUR = "resetOnFaultBehaviour";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESET_ON_FAULT_BEHAVIOUR_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESET_ON_FAULT_BEHAVIOUR,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementResetOnFaultBehaviourEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describe the way the element is reactivated after a self protection sequence was entered
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementResetOnFaultBehaviourEnum getResetOnFaultBehaviour();
  /**
   * Describe the way the element is reactivated after a self protection sequence was entered
   * Attribute-Kind = versionAttribute   */
  public void setResetOnFaultBehaviour(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementResetOnFaultBehaviourEnum newValue);
  // attribute : wakeupCapability generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String WAKEUP_CAPABILITY = "wakeupCapability";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo WAKEUP_CAPABILITY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,WAKEUP_CAPABILITY,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describes the feature of the power supply to turn on the output voltage by an external event. In some cases this feature is coupled with other ECU internal HW elements e.g. transceivers and is the main feature used by the car specific power management. Different to other HW elements with this feature the power supply is the receiver of the signal, as more ECU function is only possible if the power supply is activated. Example: Philips CAN Transceivers have an output called INH, which allow together with some Voltage regulators with wake up capability to wake up the ECU at the presence of a CAN bus telegram.  Example: The Wake up Capability is connected to the terminal KL15 (ignition), the ECU is waked up at the presence of KL15.
   * Attribute-Kind = versionAttribute   */
  public Boolean getWakeupCapability();
  /**
   * Describes the feature of the power supply to turn on the output voltage by an external event. In some cases this feature is coupled with other ECU internal HW elements e.g. transceivers and is the main feature used by the car specific power management. Different to other HW elements with this feature the power supply is the receiver of the signal, as more ECU function is only possible if the power supply is activated. Example: Philips CAN Transceivers have an output called INH, which allow together with some Voltage regulators with wake up capability to wake up the ECU at the presence of a CAN bus telegram.  Example: The Wake up Capability is connected to the terminal KL15 (ignition), the ECU is waked up at the presence of KL15.
   * Attribute-Kind = versionAttribute   */
  public void setWakeupCapability(Boolean newValue);
  // reference : overCurrentNotification generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OVER_CURRENT_NOTIFICATION = "overCurrentNotification";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: powerSupplyHWElement_overCurrentNotification_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OVER_CURRENT_NOTIFICATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OVER_CURRENT_NOTIFICATION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyCurrentNotification.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyCurrentNotification.POWER_SUPPLY_HWELEMENT_OVER_CURRENT_NOTIFICATION_OWNER_RELATION_INFO;}};
  /**
   * Status information that the output current exceeds the maximal, defined limit at the output of the Power Supply HW Element. A short circuit indication is a special form of the overcurrent status information.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyCurrentNotification getOverCurrentNotification();
  /**
   * Status information that the output current exceeds the maximal, defined limit at the output of the Power Supply HW Element. A short circuit indication is a special form of the overcurrent status information.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setOverCurrentNotification(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyCurrentNotification newValue);
  // reference : overVoltageNotification generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OVER_VOLTAGE_NOTIFICATION = "overVoltageNotification";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: powerSupplyHWElement_overVoltageNotification_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OVER_VOLTAGE_NOTIFICATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OVER_VOLTAGE_NOTIFICATION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyVoltageNotification.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyVoltageNotification.POWER_SUPPLY_HWELEMENT_OVER_VOLTAGE_NOTIFICATION_OWNER_RELATION_INFO;}};
  /**
   * Notification that the source voltage is too high for the power Supply HW Element to handle.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyVoltageNotification getOverVoltageNotification();
  /**
   * Notification that the source voltage is too high for the power Supply HW Element to handle.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setOverVoltageNotification(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyVoltageNotification newValue);
  // reference : underVoltageNotification generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String UNDER_VOLTAGE_NOTIFICATION = "underVoltageNotification";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: powerSupplyHWElement_underVoltageNotification_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo UNDER_VOLTAGE_NOTIFICATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(UNDER_VOLTAGE_NOTIFICATION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWElement",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyVoltageNotification.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyVoltageNotification.POWER_SUPPLY_HWELEMENT_UNDER_VOLTAGE_NOTIFICATION_OWNER_RELATION_INFO;}};
  /**
   * Status information that at the input of the Power Supply HW Element has dropped to a critical value. This can be used to switch off functions, which caused that voltage drop or start a power down function like storing important data to NV memory.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyVoltageNotification getUnderVoltageNotification();
  /**
   * Status information that at the input of the Power Supply HW Element has dropped to a critical value. This can be used to switch off functions, which caused that voltage drop or start a power down function like storing important data to NV memory.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setUnderVoltageNotification(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerSupplyVoltageNotification newValue);
}
