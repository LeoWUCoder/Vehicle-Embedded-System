package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MICompuConstNumericContent extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConstContent
{
  public final static String CLASS_NAME = "CompuConstNumericContent";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICompuConstNumericContent> mdfGetClass();
  // attribute : v generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String V = "v";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo V_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,V,"ar3x.swcomponenttemplate.datatype.computationmethod.CompuConstNumericContent",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Use <v> to enter a numerical value.
   * Attribute-Kind = versionAttribute   */
  public String getV();
  /**
   * Use <v> to enter a numerical value.
   * Attribute-Kind = versionAttribute   */
  public void setV(String newValue);
}
