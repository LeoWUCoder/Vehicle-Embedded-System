package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISensorActuatorHWARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "SensorActuatorHWARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISensorActuatorHWARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.ecuresourcetemplate.sensoractuator.SensorActuatorHWARRef",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHWTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHWTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHWTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: sensorActuatorHWARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.ecuresourcetemplate.sensoractuator.SensorActuatorHWARRef",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW.SENSOR_ACTUATOR_HWARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW> getRefTargets();
  // reference : sensorActuatorSoftwareComponentType_sensorActuator_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SENSOR_ACTUATOR_SOFTWARE_COMPONENT_TYPE_SENSOR_ACTUATOR_OWNER = "sensorActuatorSoftwareComponentType_sensorActuator_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: sensorActuator
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SENSOR_ACTUATOR_SOFTWARE_COMPONENT_TYPE_SENSOR_ACTUATOR_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SENSOR_ACTUATOR_SOFTWARE_COMPONENT_TYPE_SENSOR_ACTUATOR_OWNER,"ar3x.ecuresourcetemplate.sensoractuator.SensorActuatorHWARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MISensorActuatorSoftwareComponentType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MISensorActuatorSoftwareComponentType.SENSOR_ACTUATOR_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MISensorActuatorSoftwareComponentType getSensorActuatorSoftwareComponentTypeSensorActuatorOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSensorActuatorSoftwareComponentTypeSensorActuatorOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MISensorActuatorSoftwareComponentType newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW newRefTarget);

}
