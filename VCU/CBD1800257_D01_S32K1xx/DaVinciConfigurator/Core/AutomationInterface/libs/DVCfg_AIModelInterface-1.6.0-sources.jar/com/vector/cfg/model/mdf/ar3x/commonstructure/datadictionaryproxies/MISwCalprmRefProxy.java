package com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Parent class for several kinds of references to a calibration parameter.
 */
public interface MISwCalprmRefProxy extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwCalprmRefProxy";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwCalprmRefProxy> mdfGetClass();
  // reference : swAxisGrouped_swCalprm_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_AXIS_GROUPED_SW_CALPRM_OWNER = "swAxisGrouped_swCalprm_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swCalprm
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_AXIS_GROUPED_SW_CALPRM_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_AXIS_GROUPED_SW_CALPRM_OWNER,"ar3x.commonstructure.datadictionaryproxies.SwCalprmRefProxy",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGrouped.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGrouped.SW_CALPRM_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGrouped getSwAxisGroupedSwCalprmOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwAxisGroupedSwCalprmOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisGrouped newValue);
}
