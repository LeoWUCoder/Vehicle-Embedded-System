package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The abstract class ECU Electronics HW Element contains all elements and attributes common for all kind of ECU Electronics.
 */
public interface MIECUElectronics extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement
{
  public final static String CLASS_NAME = "ECUElectronics";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIECUElectronics> mdfGetClass();
  // attribute : canBeDisabled generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CAN_BE_DISABLED = "canBeDisabled";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CAN_BE_DISABLED_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CAN_BE_DISABLED,"ar3x.ecuresourcetemplate.ecuelectronics.ECUElectronics",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines if the ECU Electronic can be enabled and disabled.
   * Attribute-Kind = versionAttribute   */
  public Boolean getCanBeDisabled();
  /**
   * Defines if the ECU Electronic can be enabled and disabled.
   * Attribute-Kind = versionAttribute   */
  public void setCanBeDisabled(Boolean newValue);
}
