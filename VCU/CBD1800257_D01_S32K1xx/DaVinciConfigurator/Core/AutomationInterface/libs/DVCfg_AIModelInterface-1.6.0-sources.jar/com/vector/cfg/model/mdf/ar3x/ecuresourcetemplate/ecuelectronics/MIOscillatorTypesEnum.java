package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;
import javax.jmi.model.*;

public enum MIOscillatorTypesEnum implements javax.jmi.reflect.RefEnum
{
  OSCILLATOR("OSCILLATOR");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "ecuelectronics" );
    temp.add( "OscillatorTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIOscillatorTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
