package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;
import javax.jmi.model.*;

public enum MIHwElementResetOnFaultBehaviourEnum implements javax.jmi.reflect.RefEnum
{
  AUTO("AUTO"),
  RE_TRIGGER("RE-TRIGGER"),
  FOLD_BACK("FOLD-BACK");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "ecuelectronics" );
    temp.add( "HwElementResetOnFaultBehaviourEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIHwElementResetOnFaultBehaviourEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
