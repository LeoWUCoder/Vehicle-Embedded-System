package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

public enum MIOscillatorModeEnum implements javax.jmi.reflect.RefEnum
{
  FUNDAMENTAL("FUNDAMENTAL"),
  OVERTONE("OVERTONE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "OscillatorModeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIOscillatorModeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
