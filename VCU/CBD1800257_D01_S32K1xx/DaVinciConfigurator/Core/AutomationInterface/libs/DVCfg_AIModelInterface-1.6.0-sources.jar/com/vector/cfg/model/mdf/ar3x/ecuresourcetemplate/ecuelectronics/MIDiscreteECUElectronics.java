package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIDiscreteECUElectronics extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIECUElectronics
{
  public final static String CLASS_NAME = "DiscreteECUElectronics";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDiscreteECUElectronics> mdfGetClass();
}
