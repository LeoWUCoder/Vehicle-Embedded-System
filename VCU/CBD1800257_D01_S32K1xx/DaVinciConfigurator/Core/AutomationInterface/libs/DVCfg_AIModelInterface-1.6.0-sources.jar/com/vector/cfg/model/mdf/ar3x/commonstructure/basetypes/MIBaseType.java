package com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIBaseType extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement
{
  public final static String CLASS_NAME = "BaseType";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBaseType> mdfGetClass();
  // reference : baseTypeDefinitionType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BASE_TYPE_DEFINITION_TYPE = "baseTypeDefinitionType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: baseType_baseTypeDefinitionType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BASE_TYPE_DEFINITION_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BASE_TYPE_DEFINITION_TYPE,"ar3x.commonstructure.basetypes.BaseType",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDefinition.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDefinition.BASE_TYPE_BASE_TYPE_DEFINITION_TYPE_OWNER_RELATION_INFO;}};
  /**
   * This is the actual definition of the base type.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDefinition getBaseTypeDefinitionType();
  /**
   * This is the actual definition of the base type.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBaseTypeDefinitionType(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeDefinition newValue);
}
