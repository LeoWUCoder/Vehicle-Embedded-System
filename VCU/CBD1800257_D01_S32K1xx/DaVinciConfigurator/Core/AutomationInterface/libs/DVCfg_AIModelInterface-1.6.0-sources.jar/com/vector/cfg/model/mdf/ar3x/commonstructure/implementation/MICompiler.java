package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the compiler attributes. In case of source code this specifies requirements how the compiler shall be invoked. In case of object code this documents the used compiler settings.
 */
public interface MICompiler extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "Compiler";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICompiler> mdfGetClass();
  // attribute : compilerName generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String COMPILER_NAME = "compilerName";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo COMPILER_NAME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,COMPILER_NAME,"ar3x.commonstructure.implementation.Compiler",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Compiler name (like gcc).
   * Attribute-Kind = versionAttribute   */
  public String getCompilerName();
  /**
   * Compiler name (like gcc).
   * Attribute-Kind = versionAttribute   */
  public void setCompilerName(String newValue);
  // attribute : vendor generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VENDOR = "vendor";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VENDOR_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VENDOR,"ar3x.commonstructure.implementation.Compiler",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Vendor of compiler.
   * Attribute-Kind = versionAttribute   */
  public String getVendor();
  /**
   * Vendor of compiler.
   * Attribute-Kind = versionAttribute   */
  public void setVendor(String newValue);
  // attribute : version generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VERSION = "version";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VERSION,"ar3x.commonstructure.implementation.Compiler",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Exact version of compiler executable.
   * Attribute-Kind = versionAttribute   */
  public String getVersion();
  /**
   * Exact version of compiler executable.
   * Attribute-Kind = versionAttribute   */
  public void setVersion(String newValue);
  // attribute : options generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OPTIONS = "options";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OPTIONS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OPTIONS,"ar3x.commonstructure.implementation.Compiler",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies the compiler options.
   * Attribute-Kind = versionAttribute   */
  public String getOptions();
  /**
   * Specifies the compiler options.
   * Attribute-Kind = versionAttribute   */
  public void setOptions(String newValue);
  // reference : implementation_compiler_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IMPLEMENTATION_COMPILER_OWNER = "implementation_compiler_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: compiler
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IMPLEMENTATION_COMPILER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IMPLEMENTATION_COMPILER_OWNER,"ar3x.commonstructure.implementation.Compiler",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation.COMPILER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation getImplementationCompilerOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setImplementationCompilerOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementation newValue);
}
