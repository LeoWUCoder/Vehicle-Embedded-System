package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasSwCalprmImpl extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasSwCalprmImpl";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIHasSwCalprmImpl> mdfGetClass();
  // reference : swCalprmImpl generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_CALPRM_IMPL = "swCalprmImpl";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasSwCalprmImpl_swCalprmImpl_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_IMPL_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM_IMPL,"ar3x.commonstructure.swclass.HasSwCalprmImpl",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwCalprmImpl.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwCalprmImpl.HAS_SW_CALPRM_IMPL_SW_CALPRM_IMPL_OWNER_RELATION_INFO;}};
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwCalprmImpl> getSwCalprmImpl();
}
