package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;
import javax.jmi.model.*;

public enum MIProcessingUnitArchitectureKindEnum implements javax.jmi.reflect.RefEnum
{
  HARVARD("HARVARD"),
  NEUMANN("NEUMANN");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "processingunit" );
    temp.add( "ProcessingUnitArchitectureKindEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIProcessingUnitArchitectureKindEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
