package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIRPortPrototypeARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "RPortPrototypeARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIRPortPrototypeARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototypeTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototypeTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototypeTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: rPortPrototypeARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototype.R_PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototype> getRefTargets();
  // reference : roleBasedRPortAssignment_rPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ROLE_BASED_RPORT_ASSIGNMENT_R_PORT_PROTOTYPE_OWNER = "roleBasedRPortAssignment_rPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: rPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ROLE_BASED_RPORT_ASSIGNMENT_R_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ROLE_BASED_RPORT_ASSIGNMENT_R_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedRPortAssignment.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedRPortAssignment.R_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedRPortAssignment getRoleBasedRPortAssignmentRPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRoleBasedRPortAssignmentRPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servicemapping.MIRoleBasedRPortAssignment newValue);
  // reference : assemblyConnectorPrototypeRequester_requesterRPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_REQUESTER_RPORT_PROTOTYPE_OWNER = "assemblyConnectorPrototypeRequester_requesterRPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: requesterRPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_REQUESTER_RPORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_REQUESTER_RPORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester.REQUESTER_RPORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester getAssemblyConnectorPrototypeRequesterRequesterRPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setAssemblyConnectorPrototypeRequesterRequesterRPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester newValue);
  // reference : dataReceivePointDataElement_rPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_RECEIVE_POINT_DATA_ELEMENT_R_PORT_PROTOTYPE_OWNER = "dataReceivePointDataElement_rPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: rPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_RECEIVE_POINT_DATA_ELEMENT_R_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_RECEIVE_POINT_DATA_ELEMENT_R_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataReceivePointDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataReceivePointDataElement.R_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataReceivePointDataElement getDataReceivePointDataElementRPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataReceivePointDataElementRPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataReceivePointDataElement newValue);
  // reference : dataReadAccessDataElement_rPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_READ_ACCESS_DATA_ELEMENT_R_PORT_PROTOTYPE_OWNER = "dataReadAccessDataElement_rPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: rPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_READ_ACCESS_DATA_ELEMENT_R_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_READ_ACCESS_DATA_ELEMENT_R_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataReadAccessDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataReadAccessDataElement.R_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataReadAccessDataElement getDataReadAccessDataElementRPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataReadAccessDataElementRPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.dataelements.instanceref.MIDataReadAccessDataElement newValue);
  // reference : serverCallPointOperation_rPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVER_CALL_POINT_OPERATION_R_PORT_PROTOTYPE_OWNER = "serverCallPointOperation_rPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: rPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVER_CALL_POINT_OPERATION_R_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVER_CALL_POINT_OPERATION_R_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servercall.instanceref.MIServerCallPointOperation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servercall.instanceref.MIServerCallPointOperation.R_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servercall.instanceref.MIServerCallPointOperation getServerCallPointOperationRPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setServerCallPointOperationRPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.servercall.instanceref.MIServerCallPointOperation newValue);
  // reference : dataReceiveErrorEventData_rPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_RECEIVE_ERROR_EVENT_DATA_R_PORT_PROTOTYPE_OWNER = "dataReceiveErrorEventData_rPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: rPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_RECEIVE_ERROR_EVENT_DATA_R_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_RECEIVE_ERROR_EVENT_DATA_R_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIDataReceiveErrorEventData.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIDataReceiveErrorEventData.R_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIDataReceiveErrorEventData getDataReceiveErrorEventDataRPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataReceiveErrorEventDataRPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIDataReceiveErrorEventData newValue);
  // reference : dataReceivedEventData_rPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_RECEIVED_EVENT_DATA_R_PORT_PROTOTYPE_OWNER = "dataReceivedEventData_rPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: rPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_RECEIVED_EVENT_DATA_R_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_RECEIVED_EVENT_DATA_R_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIDataReceivedEventData.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIDataReceivedEventData.R_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIDataReceivedEventData getDataReceivedEventDataRPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataReceivedEventDataRPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIDataReceivedEventData newValue);
  // reference : modeSwitchEventMode_rPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MODE_SWITCH_EVENT_MODE_R_PORT_PROTOTYPE_OWNER = "modeSwitchEventMode_rPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: rPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MODE_SWITCH_EVENT_MODE_R_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MODE_SWITCH_EVENT_MODE_R_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIModeSwitchEventMode.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIModeSwitchEventMode.R_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIModeSwitchEventMode getModeSwitchEventModeRPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setModeSwitchEventModeRPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.rteevents.instanceref.MIModeSwitchEventMode newValue);
  // reference : modeDisablingDependencyDependentOnMode_rPortPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MODE_DISABLING_DEPENDENCY_DEPENDENT_ON_MODE_R_PORT_PROTOTYPE_OWNER = "modeDisablingDependencyDependentOnMode_rPortPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: rPortPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MODE_DISABLING_DEPENDENCY_DEPENDENT_ON_MODE_R_PORT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MODE_DISABLING_DEPENDENCY_DEPENDENT_ON_MODE_R_PORT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.components.RPortPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.modedeclaration.instanceref.MIModeDisablingDependencyDependentOnMode.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.modedeclaration.instanceref.MIModeDisablingDependencyDependentOnMode.R_PORT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.modedeclaration.instanceref.MIModeDisablingDependencyDependentOnMode getModeDisablingDependencyDependentOnModeRPortPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setModeDisablingDependencyDependentOnModeRPortPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.modedeclaration.instanceref.MIModeDisablingDependencyDependentOnMode newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototype getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIRPortPrototype newRefTarget);

}
