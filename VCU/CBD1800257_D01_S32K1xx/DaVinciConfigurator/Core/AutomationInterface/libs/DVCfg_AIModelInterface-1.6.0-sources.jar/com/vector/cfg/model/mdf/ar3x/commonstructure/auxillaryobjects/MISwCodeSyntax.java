package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * SwCodeSyntax objects fix the representation of data objects, e.g. variables and parameters, in the program source file. These code syntax objects are defined centrally in SwCodeSyntaxes and are connected to data objects by means of SwCodeSyntaxRef.  The principle role of this element is the declaration of keywords (in the subelement ShortName) for the code generation procedure. The process itself is given a verbal description (in SwCodeSyntaxDesc) rather than a formal one. This approach was adopted as the number of possible code syntax schematics is relatively small. A complete formal description would create unnecessary work.
 */
public interface MISwCodeSyntax extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement
{
  public final static String CLASS_NAME = "SwCodeSyntax";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwCodeSyntax> mdfGetClass();
  // reference : swCodeSyntaxARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_CODE_SYNTAX_ARREF_REF_TARGETS_OWNER = "swCodeSyntaxARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CODE_SYNTAX_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CODE_SYNTAX_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.auxillaryobjects.SwCodeSyntax",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwCodeSyntaxARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwCodeSyntaxARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwCodeSyntaxARRef> getSwCodeSyntaxARRefRefTargetsOwner();
}
