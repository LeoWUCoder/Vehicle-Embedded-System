package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;
import javax.jmi.model.*;

public enum MISignalFanEnum implements javax.jmi.reflect.RefEnum
{
  NFOLD("NFOLD"),
  SINGLE("SINGLE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "applicationattributes" );
    temp.add( "SignalFanEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISignalFanEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
