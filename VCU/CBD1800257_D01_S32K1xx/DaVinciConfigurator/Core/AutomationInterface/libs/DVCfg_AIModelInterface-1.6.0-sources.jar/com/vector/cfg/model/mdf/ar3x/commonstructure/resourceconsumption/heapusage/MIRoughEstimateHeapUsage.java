package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Rough estimation of the heap usage.
 */
public interface MIRoughEstimateHeapUsage extends com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage.MIHeapUsage
{
  public final static String CLASS_NAME = "RoughEstimateHeapUsage";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIRoughEstimateHeapUsage> mdfGetClass();
  // attribute : memoryConsumption generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MEMORY_CONSUMPTION = "memoryConsumption";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MEMORY_CONSUMPTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MEMORY_CONSUMPTION,"ar3x.commonstructure.resourceconsumption.heapusage.RoughEstimateHeapUsage",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Rough estimate of the heap usage.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMemoryConsumption();
  /**
   * Rough estimate of the heap usage.
   * Attribute-Kind = versionAttribute   */
  public void setMemoryConsumption(java.math.BigInteger newValue);
}
