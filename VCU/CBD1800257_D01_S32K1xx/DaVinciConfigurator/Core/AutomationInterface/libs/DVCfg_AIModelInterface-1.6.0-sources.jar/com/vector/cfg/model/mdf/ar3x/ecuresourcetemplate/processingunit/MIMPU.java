package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A MPU provides means where the memory access within a defined program flow of a PU is controlled. In case of a failure an exception routine e.g. interrupt is activated. A MPU is implemented as an independent hardware block in a device separate to the processing unit. A MPU does not perform any data manipulation, only in case of an error a change in the processor control flow is forced. The number of individual checked memory ranges is limited to the registers available for specifying the memory ranges. One individual memory range is in the following referenced as MPU Channel. In most cases the MPU consists of a set of registers, which do range checking of the addresses asserted by the program on the address bus as well as the access type to the according address. The checking of the address ranges is also coupled to the address range of the program, which runs under the control of the MPU. The MPU also can be coupled with one of the different processing elements of a device like the PU itself, a DMA or a Coprocessor. In order to have a broad usage of a MPU a specification of filter values is often allowed, so very user specific selection methods are possible. Typical use case for a MPU: A 3rd party software routine is allowed only to access a defined memory-area. Any access outside the defined memory area will be denied and control will be transferred to the supervising operating system. A error handling routine will be started.
 */
public interface MIMPU extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "MPU";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIMPU> mdfGetClass();
  // attribute : channelCount generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CHANNEL_COUNT = "channelCount";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CHANNEL_COUNT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CHANNEL_COUNT,"ar3x.ecuresourcetemplate.processingunit.MPU",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the number of individual MPU channels are available.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getChannelCount();
  /**
   * Defines the number of individual MPU channels are available.
   * Attribute-Kind = versionAttribute   */
  public void setChannelCount(java.math.BigInteger newValue);
  // reference : processingUnit_mpu_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROCESSING_UNIT_MPU_OWNER = "processingUnit_mpu_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: mpu
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROCESSING_UNIT_MPU_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROCESSING_UNIT_MPU_OWNER,"ar3x.ecuresourcetemplate.processingunit.MPU",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.MPU_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit getProcessingUnitMpuOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProcessingUnitMpuOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit newValue);
  // reference : protectedMemoryHWPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROTECTED_MEMORY_HWPORT = "protectedMemoryHWPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: mPU_protectedMemoryHWPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROTECTED_MEMORY_HWPORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROTECTED_MEMORY_HWPORT,"ar3x.ecuresourcetemplate.processingunit.MPU",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPortARRef.M_PU_PROTECTED_MEMORY_HWPORT_OWNER_RELATION_INFO;}};
  /**
   * Describes which Memory Mapped HW Ports are obserable by this MPU. The actual configuration will be done by SW.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedHWPortARRef> getProtectedMemoryHWPort();
  // reference : raisedInterrupt generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RAISED_INTERRUPT = "raisedInterrupt";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: mPU_raisedInterrupt_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RAISED_INTERRUPT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RAISED_INTERRUPT,"ar3x.ecuresourcetemplate.processingunit.MPU",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPort.M_PU_RAISED_INTERRUPT_OWNER_RELATION_INFO;}};
  /**
   * Defines the interrupts this MPU can raise to indicate the violation of memory access.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPort> getRaisedInterrupt();
}
