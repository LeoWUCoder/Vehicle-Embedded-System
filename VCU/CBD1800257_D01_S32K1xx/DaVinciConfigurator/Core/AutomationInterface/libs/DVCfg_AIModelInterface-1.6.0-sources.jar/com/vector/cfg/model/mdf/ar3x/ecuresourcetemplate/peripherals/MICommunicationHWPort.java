package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MICommunicationHWPort extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheralHWPort
{
  public final static String CLASS_NAME = "CommunicationHWPort";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICommunicationHWPort> mdfGetClass();
  // reference : speed generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SPEED = "speed";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: communicationHWPort_speed_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SPEED_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SPEED,"ar3x.ecuresourcetemplate.peripherals.CommunicationHWPort",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationSpeed.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationSpeed.COMMUNICATION_HWPORT_SPEED_OWNER_RELATION_INFO;}};
  /**
   * The Communication speed can be provided either as a fixed value if it can not be changed by software. Or there can be a range in which software can configure the communication speed. Also a list of possible speed values can be provided from which the software can choose. If the communication speed is not fixed with one value the System Constraint Description has the freedom to choose from the given range or list of communication speed. In the end only HW Ports with the same communication speed can be connected to a bus system.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationSpeed getSpeed();
  /**
   * The Communication speed can be provided either as a fixed value if it can not be changed by software. Or there can be a range in which software can configure the communication speed. Also a list of possible speed values can be provided from which the software can choose. If the communication speed is not fixed with one value the System Constraint Description has the freedom to choose from the given range or list of communication speed. In the end only HW Ports with the same communication speed can be connected to a bus system.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSpeed(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationSpeed newValue);
  // reference : physicalLayer generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PHYSICAL_LAYER = "physicalLayer";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: communicationHWPort_physicalLayer_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PHYSICAL_LAYER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PHYSICAL_LAYER,"ar3x.ecuresourcetemplate.peripherals.CommunicationHWPort",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPhysicalMedium.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPhysicalMedium.COMMUNICATION_HWPORT_PHYSICAL_LAYER_OWNER_RELATION_INFO;}};
  /**
   * Describes the physical medium the bus is working on. In most cases it is not relevant for the SW to know about it.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPhysicalMedium getPhysicalLayer();
  /**
   * Describes the physical medium the bus is working on. In most cases it is not relevant for the SW to know about it.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPhysicalLayer(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPhysicalMedium newValue);
  // reference : communicationPeripheral_hwPort_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMMUNICATION_PERIPHERAL_HW_PORT_OWNER = "communicationPeripheral_hwPort_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: hwPort
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMMUNICATION_PERIPHERAL_HW_PORT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMMUNICATION_PERIPHERAL_HW_PORT_OWNER,"ar3x.ecuresourcetemplate.peripherals.CommunicationHWPort",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral.HW_PORT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral getCommunicationPeripheralHwPortOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCommunicationPeripheralHwPortOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationPeripheral newValue);
}
