package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This class collects the dependencies of a BSW module or cluster on a certain other BSW module in an abstract way.
 */
public interface MIBswModuleDependency extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "BswModuleDependency";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBswModuleDependency> mdfGetClass();
  // attribute : targetModuleId generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TARGET_MODULE_ID = "targetModuleId";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TARGET_MODULE_ID_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TARGET_MODULE_ID,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleDependency",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * AUTOSAR identifier of the target module of which the dependencies are defined.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getTargetModuleId();
  /**
   * AUTOSAR identifier of the target module of which the dependencies are defined.
   * Attribute-Kind = versionAttribute   */
  public void setTargetModuleId(java.math.BigInteger newValue);
  // reference : bswModuleDescription_bswModuleDependency_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE_DESCRIPTION_BSW_MODULE_DEPENDENCY_OWNER = "bswModuleDescription_bswModuleDependency_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: bswModuleDependency
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_DESCRIPTION_BSW_MODULE_DEPENDENCY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_DESCRIPTION_BSW_MODULE_DEPENDENCY_OWNER,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleDependency",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription.BSW_MODULE_DEPENDENCY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription getBswModuleDescriptionBswModuleDependencyOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswModuleDescriptionBswModuleDependencyOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescription newValue);
  // reference : serviceItem generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVICE_ITEM = "serviceItem";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleDependency_serviceItem_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_ITEM_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_ITEM,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleDependency",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds.BSW_MODULE_DEPENDENCY_SERVICE_ITEM_OWNER_RELATION_INFO;}};
  /**
   *  A single item (example: Nv block) for which the quality of a service is defined.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds> getServiceItem();
  // reference : expectedCallback generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String EXPECTED_CALLBACK = "expectedCallback";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleDependency_expectedCallback_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXPECTED_CALLBACK_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXPECTED_CALLBACK,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleDependency",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.BSW_MODULE_DEPENDENCY_EXPECTED_CALLBACK_OWNER_RELATION_INFO;}};
  /**
   * Indicates a callback expected to be called from another module and implemented by this module.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef> getExpectedCallback();
  // reference : requiredEntry generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String REQUIRED_ENTRY = "requiredEntry";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleDependency_requiredEntry_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REQUIRED_ENTRY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REQUIRED_ENTRY,"ar3x.bswmoduletemplate.bswinterfaces.BswModuleDependency",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.BSW_MODULE_DEPENDENCY_REQUIRED_ENTRY_OWNER_RELATION_INFO;}};
  /**
   * Indicates an entry into another modules which is required by this module.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef> getRequiredEntry();
}
