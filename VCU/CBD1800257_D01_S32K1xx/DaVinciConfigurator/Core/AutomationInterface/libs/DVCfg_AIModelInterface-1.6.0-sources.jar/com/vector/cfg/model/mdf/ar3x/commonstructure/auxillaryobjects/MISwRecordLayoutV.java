package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element specifies which values are stored for the current SwRecordLayoutGroup. If no baseType is present, the SwBaseType referenced initially in the father element SwRecordLayoutGroup is valid. The specification of swRecordLayoutVAxis gives the axis of the values to be stored in accordance with the current record layout SwRecordLayoutGroup. In swRecordLayoutVProp you are able to specify the type of values that are to be stored, e.g. number or value. Under swRecordLayoutVIndex, the symbolic values of the axes can be given, for which the value given under swRecordLayoutVProp is iterated. These symbolic values relate to the values given in swRecordLayoutGroupIndex.
 */
public interface MISwRecordLayoutV extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwRecordLayoutV";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwRecordLayoutV> mdfGetClass();
  // attribute : swRecordLayoutVAxis generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_VAXIS = "swRecordLayoutVAxis";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_RECORD_LAYOUT_VAXIS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_RECORD_LAYOUT_VAXIS,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutV",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This attribute specifies the axis from which the value properties are used.  This attribute has been set to "String" because in the generated XML-Schema it is already a string (see RfC#53652).
   * Attribute-Kind = versionAttribute   */
  public String getSwRecordLayoutVAxis();
  /**
   * This attribute specifies the axis from which the value properties are used.  This attribute has been set to "String" because in the generated XML-Schema it is already a string (see RfC#53652).
   * Attribute-Kind = versionAttribute   */
  public void setSwRecordLayoutVAxis(String newValue);
  // attribute : swRecordLayoutVFixValue generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_VFIX_VALUE = "swRecordLayoutVFixValue";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_RECORD_LAYOUT_VFIX_VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_RECORD_LAYOUT_VFIX_VALUE,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutV",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This attribute specifies the filler character for the current record layout, in the form of hex digits. The element present parallel to this in swRecordLayoutVProp must therefore have the contents FILL.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSwRecordLayoutVFixValue();
  /**
   * This attribute specifies the filler character for the current record layout, in the form of hex digits. The element present parallel to this in swRecordLayoutVProp must therefore have the contents FILL.
   * Attribute-Kind = versionAttribute   */
  public void setSwRecordLayoutVFixValue(java.math.BigInteger newValue);
  // attribute : swRecordLayoutVIndex generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_VINDEX = "swRecordLayoutVIndex";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_RECORD_LAYOUT_VINDEX_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_RECORD_LAYOUT_VINDEX,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutV",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The symbolic value for iteration, or the symbolic values separated by white-spaces, refer to the symbolic values given in swRecordLayoutGroupIndex . The iterators are processed from left to right, in such a manner that they symbolize the loop index from the outside to the inside.  An error has occurred if a parameter references a record layout which contains an swRecordLayoutVIndex with more components than the number of parameter axes.
   * Attribute-Kind = versionAttribute   */
  public String getSwRecordLayoutVIndex();
  /**
   * The symbolic value for iteration, or the symbolic values separated by white-spaces, refer to the symbolic values given in swRecordLayoutGroupIndex . The iterators are processed from left to right, in such a manner that they symbolize the loop index from the outside to the inside.  An error has occurred if a parameter references a record layout which contains an swRecordLayoutVIndex with more components than the number of parameter axes.
   * Attribute-Kind = versionAttribute   */
  public void setSwRecordLayoutVIndex(String newValue);
  // attribute : swRecordLayoutVProp generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_VPROP = "swRecordLayoutVProp";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_RECORD_LAYOUT_VPROP_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_RECORD_LAYOUT_VPROP,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutV",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The contents of this attribute describes the type of values to be stored in the record.
   * Attribute-Kind = versionAttribute   */
  public String getSwRecordLayoutVProp();
  /**
   * The contents of this attribute describes the type of values to be stored in the record.
   * Attribute-Kind = versionAttribute   */
  public void setSwRecordLayoutVProp(String newValue);
  // reference : swRecordLayout generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_RECORD_LAYOUT = "swRecordLayout";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swRecordLayoutV_swRecordLayout_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_RECORD_LAYOUT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_RECORD_LAYOUT,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutV",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef.SW_RECORD_LAYOUT_V_SW_RECORD_LAYOUT_OWNER_RELATION_INFO;}};
  /**
   * tbd: I (bernhard Weichel) ar not sure if this association is superfluous ...
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef getSwRecordLayout();
  /**
   * tbd: I (bernhard Weichel) ar not sure if this association is superfluous ...
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwRecordLayout(com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutARRef newValue);
  // reference : baseType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BASE_TYPE = "baseType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swRecordLayoutV_baseType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BASE_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BASE_TYPE,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutV",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef.SW_RECORD_LAYOUT_V_BASE_TYPE_OWNER_RELATION_INFO;}};
  /**
   * SwBaseType to be used for the values within this SwRecordLayoutV.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef getBaseType();
  /**
   * SwBaseType to be used for the values within this SwRecordLayoutV.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBaseType(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef newValue);
}
