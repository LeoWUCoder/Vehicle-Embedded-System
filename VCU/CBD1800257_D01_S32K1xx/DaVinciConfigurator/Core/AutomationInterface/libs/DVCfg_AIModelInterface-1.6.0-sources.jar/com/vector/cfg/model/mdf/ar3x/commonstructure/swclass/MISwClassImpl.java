package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element describes the implementation details of a class attribute which manifests itself as a class.
 */
public interface MISwClassImpl extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps
{
  public final static String CLASS_NAME = "SwClassImpl";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwClassImpl> mdfGetClass();
  // reference : swClassAttrInstanceImpl_swClassImpl_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CLASS_ATTR_INSTANCE_IMPL_SW_CLASS_IMPL_OWNER = "swClassAttrInstanceImpl_swClassImpl_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swClassImpl
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CLASS_ATTR_INSTANCE_IMPL_SW_CLASS_IMPL_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CLASS_ATTR_INSTANCE_IMPL_SW_CLASS_IMPL_OWNER,"ar3x.commonstructure.swclass.SwClassImpl",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttrInstanceImpl.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttrInstanceImpl.SW_CLASS_IMPL_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttrInstanceImpl getSwClassAttrInstanceImplSwClassImplOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwClassAttrInstanceImplSwClassImplOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttrInstanceImpl newValue);
  // reference : swClassPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CLASS_PROTOTYPE = "swClassPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swClassImpl_swClassPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CLASS_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CLASS_PROTOTYPE,"ar3x.commonstructure.swclass.SwClassImpl",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassPrototypeARRef.SW_CLASS_IMPL_SW_CLASS_PROTOTYPE_OWNER_RELATION_INFO;}};
  /**
   * This element describes the prototype declaration of a class attribute, which appears in the form of a class.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassPrototypeARRef getSwClassPrototype();
  /**
   * This element describes the prototype declaration of a class attribute, which appears in the form of a class.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwClassPrototype(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassPrototypeARRef newValue);
}
