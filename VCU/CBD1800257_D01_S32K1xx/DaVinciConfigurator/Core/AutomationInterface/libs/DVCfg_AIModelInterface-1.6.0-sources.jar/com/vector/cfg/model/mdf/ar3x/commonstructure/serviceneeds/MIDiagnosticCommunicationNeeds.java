package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the abstract needs on the configuration of the  Diagnostic Communication Manager for one "user".  Details are an expert task for AUTOSAR Release 4.0. 
 */
public interface MIDiagnosticCommunicationNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "DiagnosticCommunicationNeeds";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDiagnosticCommunicationNeeds> mdfGetClass();
}
