package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Common attributes shared by all timer peripherals
 */
public interface MIGeneralPurposeTimer extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheral, com.vector.cfg.model.mdf.commoncore.basetypes.MIHasThresholdValueIntegerItem
{
  public final static String CLASS_NAME = "GeneralPurposeTimer";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIGeneralPurposeTimer> mdfGetClass();
  // attribute : resolution generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESOLUTION = "resolution";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESOLUTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESOLUTION,"ar3x.ecuresourcetemplate.peripherals.GeneralPurposeTimer",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * For a timer the resolution defines the data width of the counter. Unit: Bits
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getResolution();
  /**
   * For a timer the resolution defines the data width of the counter. Unit: Bits
   * Attribute-Kind = versionAttribute   */
  public void setResolution(java.math.BigInteger newValue);
  // attribute : phaseDetection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PHASE_DETECTION = "phaseDetection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PHASE_DETECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PHASE_DETECTION,"ar3x.ecuresourcetemplate.peripherals.GeneralPurposeTimer",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Some timers have the possibility to detect signals from a quadrature rotating switch. There are two outputs signal from such a switch; the signals are 90 degrees phase shifted from each other. The rotation of the switch can then automatically be detected by a special function in a timer.
   * Attribute-Kind = versionAttribute   */
  public Boolean getPhaseDetection();
  /**
   * Some timers have the possibility to detect signals from a quadrature rotating switch. There are two outputs signal from such a switch; the signals are 90 degrees phase shifted from each other. The rotation of the switch can then automatically be detected by a special function in a timer.
   * Attribute-Kind = versionAttribute   */
  public void setPhaseDetection(Boolean newValue);
  // reference : clockSource generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CLOCK_SOURCE = "clockSource";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: generalPurposeTimer_clockSource_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CLOCK_SOURCE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CLOCK_SOURCE,"ar3x.ecuresourcetemplate.peripherals.GeneralPurposeTimer",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef.GENERAL_PURPOSE_TIMER_CLOCK_SOURCE_OWNER_RELATION_INFO;}};
  /**
   * The clock input to a timer can have different sources like the internal system clock or an external clock. If the clock is pre-scaled this information should be entered in the table.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef getClockSource();
  /**
   * The clock input to a timer can have different sources like the internal system clock or an external clock. If the clock is pre-scaled this information should be entered in the table.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setClockSource(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef newValue);
}
