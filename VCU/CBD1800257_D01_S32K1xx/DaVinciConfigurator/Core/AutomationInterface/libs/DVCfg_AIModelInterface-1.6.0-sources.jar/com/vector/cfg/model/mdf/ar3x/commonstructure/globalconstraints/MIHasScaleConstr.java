package com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasScaleConstr extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasScaleConstr";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIHasScaleConstr> mdfGetClass();
  // reference : scaleConstr generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SCALE_CONSTR = "scaleConstr";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasScaleConstr_scaleConstr_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SCALE_CONSTR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SCALE_CONSTR,"ar3x.commonstructure.globalconstraints.HasScaleConstr",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIScaleConstr.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIScaleConstr.HAS_SCALE_CONSTR_SCALE_CONSTR_OWNER_RELATION_INFO;}};
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIScaleConstr> getScaleConstr();
}
