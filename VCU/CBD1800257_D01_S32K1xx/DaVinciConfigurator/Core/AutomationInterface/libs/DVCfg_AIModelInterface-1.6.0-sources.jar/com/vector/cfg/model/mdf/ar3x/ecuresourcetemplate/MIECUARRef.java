package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIECUARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "ECUARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIECUARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.ecuresourcetemplate.ECUARRef",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: eCUARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.ecuresourcetemplate.ECUARRef",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECU.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECU.E_CUARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECU> getRefTargets();
  // reference : stackUsage_ecu_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String STACK_USAGE_ECU_OWNER = "stackUsage_ecu_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: ecu
  public static final ru.novosoft.mdf.impl.MDFRelationInfo STACK_USAGE_ECU_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(STACK_USAGE_ECU_OWNER,"ar3x.ecuresourcetemplate.ECUARRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage.MIStackUsage.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage.MIStackUsage.ECU_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage.MIStackUsage getStackUsageEcuOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setStackUsageEcuOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage.MIStackUsage newValue);
  // reference : heapUsage_ecu_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String HEAP_USAGE_ECU_OWNER = "heapUsage_ecu_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: ecu
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HEAP_USAGE_ECU_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HEAP_USAGE_ECU_OWNER,"ar3x.ecuresourcetemplate.ECUARRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage.MIHeapUsage.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage.MIHeapUsage.ECU_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage.MIHeapUsage getHeapUsageEcuOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHeapUsageEcuOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage.MIHeapUsage newValue);
  // reference : eCUPrototype_eCU_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String E_CUPROTOTYPE_E_CU_OWNER = "eCUPrototype_eCU_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: eCU
  public static final ru.novosoft.mdf.impl.MDFRelationInfo E_CUPROTOTYPE_E_CU_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(E_CUPROTOTYPE_E_CU_OWNER,"ar3x.ecuresourcetemplate.ECUARRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIECUPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIECUPrototype.E_CU_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIECUPrototype getECUPrototypeECUOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setECUPrototypeECUOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIECUPrototype newValue);
  // reference : eCUMapping_ecu_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String E_CUMAPPING_ECU_OWNER = "eCUMapping_ecu_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: ecu
  public static final ru.novosoft.mdf.impl.MDFRelationInfo E_CUMAPPING_ECU_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(E_CUMAPPING_ECU_OWNER,"ar3x.ecuresourcetemplate.ECUARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.ecuresourcemapping.MIECUMapping.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.ecuresourcemapping.MIECUMapping.ECU_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.ecuresourcemapping.MIECUMapping getECUMappingEcuOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setECUMappingEcuOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.ecuresourcemapping.MIECUMapping newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECU getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECU newRefTarget);

}
