package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Defines an event which is used to trigger a schedulable entity of this BSW module or cluster. The event is local to the BSW module or cluster. The short name of the class instance is intended as an input to configure the required API of the BSW Scheduler.
 */
public interface MIBswEvent extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "BswEvent";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBswEvent> mdfGetClass();
  // reference : bswBehavior_event_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_BEHAVIOR_EVENT_OWNER = "bswBehavior_event_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: event
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_BEHAVIOR_EVENT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_BEHAVIOR_EVENT_OWNER,"ar3x.bswmoduletemplate.bswbehavior.BswEvent",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior.EVENT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior getBswBehaviorEventOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswBehaviorEventOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior newValue);
  // reference : startsOnEvent generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String STARTS_ON_EVENT = "startsOnEvent";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswEvent_startsOnEvent_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo STARTS_ON_EVENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(STARTS_ON_EVENT,"ar3x.bswmoduletemplate.bswbehavior.BswEvent",128,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntityARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntityARRef.BSW_EVENT_STARTS_ON_EVENT_OWNER_RELATION_INFO;}};
  /**
   * This entity is started by the event.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntityARRef getStartsOnEvent();
  /**
   * This entity is started by the event.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setStartsOnEvent(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntityARRef newValue);
}
