package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Use <ft> , to create a footnote.
 */
public interface MIFt extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "Ft";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIFt> mdfGetClass();
  // reference : ftChildren generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String FT_CHILDREN = "ftChildren";
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: ft_ftChildren_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo FT_CHILDREN_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(FT_CHILDREN,"ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines.Ft",133,null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines.MIFtChild.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines.MIFtChild.FT_FT_CHILDREN_OWNER_RELATION_INFO;}};
  public java.util.List<com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.inlinetextmodel.inlines.MIFtChild> getFtChildren();
}
