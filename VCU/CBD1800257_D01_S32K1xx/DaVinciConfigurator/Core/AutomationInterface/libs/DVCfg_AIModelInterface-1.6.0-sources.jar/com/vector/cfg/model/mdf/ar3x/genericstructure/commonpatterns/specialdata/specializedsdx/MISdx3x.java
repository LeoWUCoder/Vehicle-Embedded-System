package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.specializedsdx;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISdx3x extends com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.specialdata.MISdx, com.vector.cfg.model.mdf.model.autosar.commonpatterns.specialdata.MISdgContentsChild
{
  public final static String CLASS_NAME = "Sdx3x";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISdx3x> mdfGetClass();
}
