package com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIScaleConstrs extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject, com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIHasScaleConstr
{
  public final static String CLASS_NAME = "ScaleConstrs";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIScaleConstrs> mdfGetClass();
}
