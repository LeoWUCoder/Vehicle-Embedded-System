package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

public enum MIAnalogueIoModeEnum implements javax.jmi.reflect.RefEnum
{
  CONTINUOUS("CONTINUOUS"),
  SINGLE("SINGLE"),
  SEQUENTIAL("SEQUENTIAL");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "AnalogueIoModeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIAnalogueIoModeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
