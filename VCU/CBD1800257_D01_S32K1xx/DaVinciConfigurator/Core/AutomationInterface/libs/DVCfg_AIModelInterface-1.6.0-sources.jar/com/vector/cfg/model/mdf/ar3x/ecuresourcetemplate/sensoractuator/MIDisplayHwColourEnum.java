package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;
import javax.jmi.model.*;

public enum MIDisplayHwColourEnum implements javax.jmi.reflect.RefEnum
{
  COLOUR("COLOUR"),
  GREY("GREY"),
  MONO("MONO");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "sensoractuator" );
    temp.add( "DisplayHwColourEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIDisplayHwColourEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
