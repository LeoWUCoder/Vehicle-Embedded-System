package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * BSW module entity, which is designed to be triggered by an interrupt.
 */
public interface MIBswInterruptEntity extends com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity
{
  public final static String CLASS_NAME = "BswInterruptEntity";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBswInterruptEntity> mdfGetClass();
  // attribute : interruptCategory generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String INTERRUPT_CATEGORY = "interruptCategory";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo INTERRUPT_CATEGORY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,INTERRUPT_CATEGORY,"ar3x.bswmoduletemplate.bswbehavior.BswInterruptEntity",null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswInterruptCategory.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Category of the interrupt
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswInterruptCategory getInterruptCategory();
  /**
   * Category of the interrupt
   * Attribute-Kind = versionAttribute   */
  public void setInterruptCategory(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswInterruptCategory newValue);
  // attribute : interruptSource generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String INTERRUPT_SOURCE = "interruptSource";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo INTERRUPT_SOURCE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,INTERRUPT_SOURCE,"ar3x.bswmoduletemplate.bswbehavior.BswInterruptEntity",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Allows a textual documentation of the intended interrupt source.
   * Attribute-Kind = versionAttribute   */
  public String getInterruptSource();
  /**
   * Allows a textual documentation of the intended interrupt source.
   * Attribute-Kind = versionAttribute   */
  public void setInterruptSource(String newValue);
}
