package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes the heap memory usage of a SW-Component.
 */
public interface MIHeapUsage extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable, com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasHardwareConfiguration, com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasSoftwareContext
{
  public final static String CLASS_NAME = "HeapUsage";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIHeapUsage> mdfGetClass();
  // reference : resourceConsumption_heapUsage_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RESOURCE_CONSUMPTION_HEAP_USAGE_OWNER = "resourceConsumption_heapUsage_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: heapUsage
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RESOURCE_CONSUMPTION_HEAP_USAGE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RESOURCE_CONSUMPTION_HEAP_USAGE_OWNER,"ar3x.commonstructure.resourceconsumption.heapusage.HeapUsage",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption.HEAP_USAGE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption getResourceConsumptionHeapUsageOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setResourceConsumptionHeapUsageOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption newValue);
  // reference : ecu generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ECU = "ecu";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: heapUsage_ecu_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ECU_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ECU,"ar3x.commonstructure.resourceconsumption.heapusage.HeapUsage",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef.HEAP_USAGE_ECU_OWNER_RELATION_INFO;}};
  /**
   * Reference to the ECU description this implementation is provided for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef getEcu();
  /**
   * Reference to the ECU description this implementation is provided for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEcu(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef newValue);
}
