package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIActuatorHwDefaultPositioinTypeEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "ActuatorHwDefaultPositioinTypeEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIActuatorHwDefaultPositioinTypeEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.ecuresourcetemplate.sensoractuator.ActuatorHwDefaultPositioinTypeEnumItem",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwDefaultPositioinTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwDefaultPositioinTypeEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIActuatorHwDefaultPositioinTypeEnum newValue);
}
