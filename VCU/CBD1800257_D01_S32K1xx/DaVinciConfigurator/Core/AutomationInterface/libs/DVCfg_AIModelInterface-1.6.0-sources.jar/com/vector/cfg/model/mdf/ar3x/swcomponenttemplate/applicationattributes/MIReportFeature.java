package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This feature is used for input signals only. Each time the level of the associated data-element changes a dedicated  GET operation has to be invoked by the sensor software component, i.e. an appropriate runnable has to be started. 
 */
public interface MIReportFeature extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "ReportFeature";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIReportFeature> mdfGetClass();
  // reference : ioHwAbstractionServerAnnotation_supportsReportRunnable_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IO_HW_ABSTRACTION_SERVER_ANNOTATION_SUPPORTS_REPORT_RUNNABLE_OWNER = "ioHwAbstractionServerAnnotation_supportsReportRunnable_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: supportsReportRunnable
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IO_HW_ABSTRACTION_SERVER_ANNOTATION_SUPPORTS_REPORT_RUNNABLE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IO_HW_ABSTRACTION_SERVER_ANNOTATION_SUPPORTS_REPORT_RUNNABLE_OWNER,"ar3x.swcomponenttemplate.applicationattributes.ReportFeature",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation.SUPPORTS_REPORT_RUNNABLE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation getIoHwAbstractionServerAnnotationSupportsReportRunnableOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setIoHwAbstractionServerAnnotationSupportsReportRunnableOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation newValue);
}
