package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;
import javax.jmi.model.*;

public enum MISensorActuatorHWTypesEnum implements javax.jmi.reflect.RefEnum
{
  ACTUATOR_HW("ACTUATOR-HW"),
  DISPLAY_HW("DISPLAY-HW"),
  SENSOR_ACTUATOR_HW("SENSOR-ACTUATOR-HW"),
  SENSOR_HW("SENSOR-HW");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "sensoractuator" );
    temp.add( "SensorActuatorHWTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISensorActuatorHWTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
