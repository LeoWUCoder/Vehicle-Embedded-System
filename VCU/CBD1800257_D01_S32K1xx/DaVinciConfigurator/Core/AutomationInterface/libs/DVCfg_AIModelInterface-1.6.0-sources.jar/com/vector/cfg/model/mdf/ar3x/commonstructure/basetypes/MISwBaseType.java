package com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwBaseType extends com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseType
{
  public final static String CLASS_NAME = "SwBaseType";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwBaseType> mdfGetClass();
  // reference : swBaseTypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_BASE_TYPE_ARREF_REF_TARGETS_OWNER = "swBaseTypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_BASE_TYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_BASE_TYPE_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.basetypes.SwBaseType",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeARRef> getSwBaseTypeARRefRefTargetsOwner();
}
