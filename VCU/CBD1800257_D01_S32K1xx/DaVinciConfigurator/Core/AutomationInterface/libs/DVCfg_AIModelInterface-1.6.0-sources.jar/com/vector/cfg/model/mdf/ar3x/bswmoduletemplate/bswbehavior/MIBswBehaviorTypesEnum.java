package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;
import javax.jmi.model.*;

public enum MIBswBehaviorTypesEnum implements javax.jmi.reflect.RefEnum
{
  BSW_BEHAVIOR("BSW-BEHAVIOR");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "bswbehavior" );
    temp.add( "BswBehaviorTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIBswBehaviorTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
