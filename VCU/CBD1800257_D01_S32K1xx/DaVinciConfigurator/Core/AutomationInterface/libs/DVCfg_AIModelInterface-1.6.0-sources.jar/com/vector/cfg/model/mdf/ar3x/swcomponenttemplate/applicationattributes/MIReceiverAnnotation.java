package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Annotation of a receiver port, specifying properties of data elements that don't affect communication or generation of the RTE. The given attributes are requirements on the required data.
 */
public interface MIReceiverAnnotation extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISenderReceiverAnnotation
{
  public final static String CLASS_NAME = "ReceiverAnnotation";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIReceiverAnnotation> mdfGetClass();
  // attribute : signalAge generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SIGNAL_AGE = "signalAge";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SIGNAL_AGE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SIGNAL_AGE,"ar3x.swcomponenttemplate.applicationattributes.ReceiverAnnotation",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The maximum allowed age of the signal since it was originally read by a sensor. This is a requirement specified on the receiver side.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getSignalAge();
  /**
   * The maximum allowed age of the signal since it was originally read by a sensor. This is a requirement specified on the receiver side.
   * Attribute-Kind = versionAttribute   */
  public void setSignalAge(java.math.BigDecimal newValue);
}
