package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;
import javax.jmi.model.*;

public enum MIHwElementPowerDriverTypeEnum implements javax.jmi.reflect.RefEnum
{
  HS("HS"),
  LS("LS"),
  HB("HB"),
  FB("FB"),
  OTHER("OTHER");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "ecuelectronics" );
    temp.add( "HwElementPowerDriverTypeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIHwElementPowerDriverTypeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
