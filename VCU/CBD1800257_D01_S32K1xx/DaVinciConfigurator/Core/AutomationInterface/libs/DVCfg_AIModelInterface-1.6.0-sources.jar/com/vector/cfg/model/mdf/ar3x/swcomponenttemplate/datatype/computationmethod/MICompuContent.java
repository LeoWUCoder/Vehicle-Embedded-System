package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MICompuContent extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "CompuContent";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICompuContent> mdfGetClass();
  // reference : compu_compuContentType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPU_COMPU_CONTENT_TYPE_OWNER = "compu_compuContentType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: compuContentType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPU_COMPU_CONTENT_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPU_COMPU_CONTENT_TYPE_OWNER,"ar3x.swcomponenttemplate.datatype.computationmethod.CompuContent",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompu.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompu.COMPU_CONTENT_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompu getCompuCompuContentTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompuCompuContentTypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompu newValue);
}
