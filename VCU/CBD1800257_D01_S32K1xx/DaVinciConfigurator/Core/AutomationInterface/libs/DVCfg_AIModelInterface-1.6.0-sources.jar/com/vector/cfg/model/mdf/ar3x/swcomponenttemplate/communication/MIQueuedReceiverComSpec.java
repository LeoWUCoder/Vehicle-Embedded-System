package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes specific to queued receiving.
 */
public interface MIQueuedReceiverComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIReceiverComSpec
{
  public final static String CLASS_NAME = "QueuedReceiverComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIQueuedReceiverComSpec> mdfGetClass();
  // attribute : queueLength generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String QUEUE_LENGTH = "queueLength";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo QUEUE_LENGTH_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,QUEUE_LENGTH,"ar3x.swcomponenttemplate.communication.QueuedReceiverComSpec",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Length of queue for received events.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getQueueLength();
  /**
   * Length of queue for received events.
   * Attribute-Kind = versionAttribute   */
  public void setQueueLength(java.math.BigInteger newValue);
}
