package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIMemorySegmentUsageEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "MemorySegmentUsageEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIMemorySegmentUsageEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.ecuresourcetemplate.memory.MemorySegmentUsageEnumItem",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemorySegmentUsageEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemorySegmentUsageEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemorySegmentUsageEnum newValue);
  // reference : memoryMappedAssemblyHWConnection_segmentUsage_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MEMORY_MAPPED_ASSEMBLY_HWCONNECTION_SEGMENT_USAGE_OWNER = "memoryMappedAssemblyHWConnection_segmentUsage_Owner";
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: segmentUsage
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MEMORY_MAPPED_ASSEMBLY_HWCONNECTION_SEGMENT_USAGE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MEMORY_MAPPED_ASSEMBLY_HWCONNECTION_SEGMENT_USAGE_OWNER,"ar3x.ecuresourcetemplate.memory.MemorySegmentUsageEnumItem",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedAssemblyHWConnection.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedAssemblyHWConnection.SEGMENT_USAGE_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedAssemblyHWConnection getMemoryMappedAssemblyHWConnectionSegmentUsageOwner();
  public void setMemoryMappedAssemblyHWConnectionSegmentUsageOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIMemoryMappedAssemblyHWConnection newValue);
}
