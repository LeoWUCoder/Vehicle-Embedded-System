package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A HW Container is a group of HW Elements on the same hierarchical level and is an abstraction of composite HW Elements. The HW Container is a specialisation of a HW Element and therefore the HW Container has all elements of a HW Element. The values of elements of the HW Elements grouped in a HW Container may differ from the values of the elements of the HW Container. 
 */
public interface MIHWContainer extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementContainer
{
  public final static String CLASS_NAME = "HWContainer";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIHWContainer> mdfGetClass();
}
