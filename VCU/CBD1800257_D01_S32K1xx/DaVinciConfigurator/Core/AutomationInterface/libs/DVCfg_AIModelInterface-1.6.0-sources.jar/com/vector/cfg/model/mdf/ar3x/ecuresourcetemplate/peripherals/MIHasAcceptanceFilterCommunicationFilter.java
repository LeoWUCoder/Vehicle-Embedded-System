package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasAcceptanceFilterCommunicationFilter extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasAcceptanceFilterCommunicationFilter";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIHasAcceptanceFilterCommunicationFilter> mdfGetClass();
  // reference : acceptanceFilter generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ACCEPTANCE_FILTER = "acceptanceFilter";
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasAcceptanceFilterCommunicationFilter_acceptanceFilter_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ACCEPTANCE_FILTER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ACCEPTANCE_FILTER,"ar3x.ecuresourcetemplate.peripherals.HasAcceptanceFilterCommunicationFilter",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationFilter.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationFilter.HAS_ACCEPTANCE_FILTER_COMMUNICATION_FILTER_ACCEPTANCE_FILTER_OWNER_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationFilter getAcceptanceFilter();
  public void setAcceptanceFilter(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationFilter newValue);
}
