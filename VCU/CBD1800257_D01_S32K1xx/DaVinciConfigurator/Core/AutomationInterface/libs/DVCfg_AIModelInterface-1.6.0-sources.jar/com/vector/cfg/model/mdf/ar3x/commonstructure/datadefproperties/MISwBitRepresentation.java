package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Description of the structure of a bit variable: Comprises of the bitPosition in a memory object (e.g. swHostVariable, which stands parallel to swBitRepresentation) and the numberOfBits . In this way, interrelated memory areas can be described. Non-related memory areas are not supported.
 */
public interface MISwBitRepresentation extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwBitRepresentation";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwBitRepresentation> mdfGetClass();
  // attribute : bitPosition generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BIT_POSITION = "bitPosition";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BIT_POSITION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BIT_POSITION,"ar3x.commonstructure.datadefproperties.SwBitRepresentation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * If the "bit data object" is hosted witin another data object (e.g. if the memory can be accessed via byte as well as bit adress), this attribute specifies the position of the data object. The count starts at zero (0).
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getBitPosition();
  /**
   * If the "bit data object" is hosted witin another data object (e.g. if the memory can be accessed via byte as well as bit adress), this attribute specifies the position of the data object. The count starts at zero (0).
   * Attribute-Kind = versionAttribute   */
  public void setBitPosition(java.math.BigInteger newValue);
  // attribute : numberOfBits generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String NUMBER_OF_BITS = "numberOfBits";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo NUMBER_OF_BITS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,NUMBER_OF_BITS,"ar3x.commonstructure.datadefproperties.SwBitRepresentation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Number of bits allocated by a "bit data object" within its host data object.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getNumberOfBits();
  /**
   * Number of bits allocated by a "bit data object" within its host data object.
   * Attribute-Kind = versionAttribute   */
  public void setNumberOfBits(java.math.BigInteger newValue);
  // reference : swDataDefProps_swBitRepresentation_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_DATA_DEF_PROPS_SW_BIT_REPRESENTATION_OWNER = "swDataDefProps_swBitRepresentation_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swBitRepresentation
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEF_PROPS_SW_BIT_REPRESENTATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEF_PROPS_SW_BIT_REPRESENTATION_OWNER,"ar3x.commonstructure.datadefproperties.SwBitRepresentation",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.SW_BIT_REPRESENTATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps getSwDataDefPropsSwBitRepresentationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwDataDefPropsSwBitRepresentationOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps newValue);
}
