package com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.specializedswvariablerefproxy;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwVariableRef extends com.vector.cfg.model.mdf.ar3x.commonstructure.datadictionaryproxies.MISwVariableRefProxy, com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependencyArgsChild
{
  public final static String CLASS_NAME = "SwVariableRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwVariableRef> mdfGetClass();
}
