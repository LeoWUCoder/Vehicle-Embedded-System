package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the abstract needs of a compoment or module on the configuration of OBD Services in relation to a particular on-board monitoring test supported by this component or module. (OBD Service 06).
 */
public interface MIObdMonitorServiceNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "ObdMonitorServiceNeeds";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIObdMonitorServiceNeeds> mdfGetClass();
  // attribute : testId generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TEST_ID = "testId";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TEST_ID_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TEST_ID,"ar3x.commonstructure.serviceneeds.ObdMonitorServiceNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Test Identifier (TID) according to ISO 15031-5.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getTestId();
  /**
   * Test Identifier (TID) according to ISO 15031-5.
   * Attribute-Kind = versionAttribute   */
  public void setTestId(java.math.BigInteger newValue);
  // attribute : unitAndScalingId generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String UNIT_AND_SCALING_ID = "unitAndScalingId";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo UNIT_AND_SCALING_ID_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,UNIT_AND_SCALING_ID,"ar3x.commonstructure.serviceneeds.ObdMonitorServiceNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Unit and scaling ID according to ISO 15031-5.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getUnitAndScalingId();
  /**
   * Unit and scaling ID according to ISO 15031-5.
   * Attribute-Kind = versionAttribute   */
  public void setUnitAndScalingId(java.math.BigInteger newValue);
  // attribute : onBoardMonitorId generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ON_BOARD_MONITOR_ID = "onBoardMonitorId";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ON_BOARD_MONITOR_ID_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ON_BOARD_MONITOR_ID,"ar3x.commonstructure.serviceneeds.ObdMonitorServiceNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * On-board monitor ID according to ISO 15031-5.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getOnBoardMonitorId();
  /**
   * On-board monitor ID according to ISO 15031-5.
   * Attribute-Kind = versionAttribute   */
  public void setOnBoardMonitorId(java.math.BigInteger newValue);
}
