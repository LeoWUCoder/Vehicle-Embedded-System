package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

public enum MICommunicationArchitectureEnum implements javax.jmi.reflect.RefEnum
{
  MASTER("MASTER"),
  SLAVE("SLAVE"),
  MULTI_MASTER("MULTI-MASTER");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "CommunicationArchitectureEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MICommunicationArchitectureEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
