package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This is the contents of a RecordLaoyut which is inserted for every iteration. Note that since this is atpMixed, multiple properties can be inserted for each iteration.
 */
public interface MISwRecordLayoutGroupContent extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwRecordLayoutGroupContent";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwRecordLayoutGroupContent> mdfGetClass();
  // reference : swRecordLayoutGroup_swRecordLayoutGroupContentType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_RECORD_LAYOUT_GROUP_SW_RECORD_LAYOUT_GROUP_CONTENT_TYPE_OWNER = "swRecordLayoutGroup_swRecordLayoutGroupContentType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swRecordLayoutGroupContentType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_RECORD_LAYOUT_GROUP_SW_RECORD_LAYOUT_GROUP_CONTENT_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_RECORD_LAYOUT_GROUP_SW_RECORD_LAYOUT_GROUP_CONTENT_TYPE_OWNER,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroupContent",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroup.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroup.SW_RECORD_LAYOUT_GROUP_CONTENT_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroup getSwRecordLayoutGroupSwRecordLayoutGroupContentTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwRecordLayoutGroupSwRecordLayoutGroupContentTypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroup newValue);
  // reference : swRecordLayoutGroupContentChildren generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_RECORD_LAYOUT_GROUP_CONTENT_CHILDREN = "swRecordLayoutGroupContentChildren";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swRecordLayoutGroupContent_swRecordLayoutGroupContentChildren_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_RECORD_LAYOUT_GROUP_CONTENT_CHILDREN_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_RECORD_LAYOUT_GROUP_CONTENT_CHILDREN,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroupContent",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContentChild.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContentChild.SW_RECORD_LAYOUT_GROUP_CONTENT_SW_RECORD_LAYOUT_GROUP_CONTENT_CHILDREN_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContentChild> getSwRecordLayoutGroupContentChildren();
}
