package com.vector.cfg.model.mdf.ar3x.commonstructure.axis;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element defines an axis for the base points calculated in the ECU. The ECU is equipped with a fixed calculation algorithm. Parameters for the algorithm can be stored in the data component of the ECU.
 */
public interface MISwAxisGeneric extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwAxisGeneric";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwAxisGeneric> mdfGetClass();
  // reference : swAxisIndividual_swAxisGeneric_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_AXIS_INDIVIDUAL_SW_AXIS_GENERIC_OWNER = "swAxisIndividual_swAxisGeneric_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swAxisGeneric
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_AXIS_INDIVIDUAL_SW_AXIS_GENERIC_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_AXIS_INDIVIDUAL_SW_AXIS_GENERIC_OWNER,"ar3x.commonstructure.axis.SwAxisGeneric",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisIndividual.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisIndividual.SW_AXIS_GENERIC_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisIndividual getSwAxisIndividualSwAxisGenericOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwAxisIndividualSwAxisGenericOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisIndividual newValue);
  // reference : swGenericAxisParam generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_GENERIC_AXIS_PARAM = "swGenericAxisParam";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swAxisGeneric_swGenericAxisParam_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_GENERIC_AXIS_PARAM_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_GENERIC_AXIS_PARAM,"ar3x.commonstructure.axis.SwAxisGeneric",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam.SW_AXIS_GENERIC_SW_GENERIC_AXIS_PARAM_OWNER_RELATION_INFO;}};
  /**
   * Specific parameter of a generic axis.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam> getSwGenericAxisParam();
  // reference : swAxisType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_AXIS_TYPE = "swAxisType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swAxisGeneric_swAxisType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_AXIS_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_AXIS_TYPE,"ar3x.commonstructure.axis.SwAxisGeneric",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisTypeARRef.SW_AXIS_GENERIC_SW_AXIS_TYPE_OWNER_RELATION_INFO;}};
  /**
   * Associated axis calculation strategy.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisTypeARRef getSwAxisType();
  /**
   * Associated axis calculation strategy.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwAxisType(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisTypeARRef newValue);
}
