package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Description of a  buffer. It is used to describe input and output buffers. Buffers can also be configurable direction.
 */
public interface MIBuffer extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "Buffer";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBuffer> mdfGetClass();
  // attribute : number generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String NUMBER = "number";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo NUMBER_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,NUMBER,"ar3x.ecuresourcetemplate.peripherals.Buffer",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The amount of buffers with the attributes size and type.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getNumber();
  /**
   * The amount of buffers with the attributes size and type.
   * Attribute-Kind = versionAttribute   */
  public void setNumber(java.math.BigInteger newValue);
  // attribute : size generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SIZE = "size";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SIZE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SIZE,"ar3x.ecuresourcetemplate.peripherals.Buffer",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The size of the Buffer. Unit: Byte
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSize();
  /**
   * The size of the Buffer. Unit: Byte
   * Attribute-Kind = versionAttribute   */
  public void setSize(java.math.BigInteger newValue);
  // attribute : type generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TYPE = "type";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TYPE,"ar3x.ecuresourcetemplate.peripherals.Buffer",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationDirectionEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Either input, output or configurable buffer.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationDirectionEnum getType();
  /**
   * Either input, output or configurable buffer.
   * Attribute-Kind = versionAttribute   */
  public void setType(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationDirectionEnum newValue);
  // reference : peripheralHWPort_buffer_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PERIPHERAL_HWPORT_BUFFER_OWNER = "peripheralHWPort_buffer_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: buffer
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PERIPHERAL_HWPORT_BUFFER_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PERIPHERAL_HWPORT_BUFFER_OWNER,"ar3x.ecuresourcetemplate.peripherals.Buffer",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheralHWPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheralHWPort.BUFFER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheralHWPort getPeripheralHWPortBufferOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPeripheralHWPortBufferOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheralHWPort newValue);
}
