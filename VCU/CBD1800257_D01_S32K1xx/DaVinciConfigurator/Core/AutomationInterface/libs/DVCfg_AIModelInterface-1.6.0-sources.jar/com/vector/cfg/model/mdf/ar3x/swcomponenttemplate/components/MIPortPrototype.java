package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Base class for the ports of an AUTOSAR software component.
 */
public interface MIPortPrototype extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "PortPrototype";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPortPrototype> mdfGetClass();
  // reference : portPrototypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER = "portPrototypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER,"ar3x.swcomponenttemplate.components.PortPrototype",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef> getPortPrototypeARRefRefTargetsOwner();
  // reference : componentType_port_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_TYPE_PORT_OWNER = "componentType_port_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: port
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_TYPE_PORT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_TYPE_PORT_OWNER,"ar3x.swcomponenttemplate.components.PortPrototype",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType.PORT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType getComponentTypePortOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComponentTypePortOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType newValue);
  // reference : nvDataPortAnnotation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String NV_DATA_PORT_ANNOTATION = "nvDataPortAnnotation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: portPrototype_nvDataPortAnnotation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo NV_DATA_PORT_ANNOTATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(NV_DATA_PORT_ANNOTATION,"ar3x.swcomponenttemplate.components.PortPrototype",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MINvDataPortAnnotation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MINvDataPortAnnotation.PORT_PROTOTYPE_NV_DATA_PORT_ANNOTATION_OWNER_RELATION_INFO;}};
  /**
   * Annotations on this non voilatile data port.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MINvDataPortAnnotation> getNvDataPortAnnotation();
  // reference : senderReceiverAnnotation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SENDER_RECEIVER_ANNOTATION = "senderReceiverAnnotation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: portPrototype_senderReceiverAnnotation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SENDER_RECEIVER_ANNOTATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SENDER_RECEIVER_ANNOTATION,"ar3x.swcomponenttemplate.components.PortPrototype",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISenderReceiverAnnotation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISenderReceiverAnnotation.PORT_PROTOTYPE_SENDER_RECEIVER_ANNOTATION_OWNER_RELATION_INFO;}};
  /**
   * Collection of annotations of this ports sender/receiver communication.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MISenderReceiverAnnotation> getSenderReceiverAnnotation();
  // reference : ioHwAbstractionServerAnnotation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IO_HW_ABSTRACTION_SERVER_ANNOTATION = "ioHwAbstractionServerAnnotation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: portPrototype_ioHwAbstractionServerAnnotation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IO_HW_ABSTRACTION_SERVER_ANNOTATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IO_HW_ABSTRACTION_SERVER_ANNOTATION,"ar3x.swcomponenttemplate.components.PortPrototype",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation.PORT_PROTOTYPE_IO_HW_ABSTRACTION_SERVER_ANNOTATION_OWNER_RELATION_INFO;}};
  /**
   * Annotations on this IoHwAbstraction port.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation> getIoHwAbstractionServerAnnotation();
  // reference : delegatedPortAnnotation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DELEGATED_PORT_ANNOTATION = "delegatedPortAnnotation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: portPrototype_delegatedPortAnnotation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DELEGATED_PORT_ANNOTATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DELEGATED_PORT_ANNOTATION,"ar3x.swcomponenttemplate.components.PortPrototype",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIDelegatedPortAnnotation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIDelegatedPortAnnotation.PORT_PROTOTYPE_DELEGATED_PORT_ANNOTATION_OWNER_RELATION_INFO;}};
  /**
   * Annotations on this delegated port.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIDelegatedPortAnnotation getDelegatedPortAnnotation();
  /**
   * Annotations on this delegated port.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDelegatedPortAnnotation(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIDelegatedPortAnnotation newValue);
  // reference : calibrationPortAnnotation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CALIBRATION_PORT_ANNOTATION = "calibrationPortAnnotation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: portPrototype_calibrationPortAnnotation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CALIBRATION_PORT_ANNOTATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CALIBRATION_PORT_ANNOTATION,"ar3x.swcomponenttemplate.components.PortPrototype",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MICalibrationPortAnnotation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MICalibrationPortAnnotation.PORT_PROTOTYPE_CALIBRATION_PORT_ANNOTATION_OWNER_RELATION_INFO;}};
  /**
   * Annotations on this CalibrationPort.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MICalibrationPortAnnotation> getCalibrationPortAnnotation();
}
