package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceprocesstask;
import javax.jmi.model.*;

public enum MISwServiceReentranceEnum implements javax.jmi.reflect.RefEnum
{
  REENTRANCE("REENTRANCE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "serviceprocesstask" );
    temp.add( "SwServiceReentranceEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwServiceReentranceEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
