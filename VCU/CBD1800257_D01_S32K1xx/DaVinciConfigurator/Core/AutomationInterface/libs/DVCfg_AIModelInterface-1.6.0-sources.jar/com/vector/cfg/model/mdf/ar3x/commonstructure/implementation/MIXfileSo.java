package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This meta class represents the ability to refer to an external file in a standalone context. Note that Xfile does the same but embedded in a documentation block paragraph.  This meta class maintains backward compatibility of xml schema wrt. to Code.xfile and Dependency.xfile.  
 */
public interface MIXfileSo extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable, com.vector.cfg.model.mdf.model.autosar.commonpatterns.blockelements.MIHasUrl
{
  public final static String CLASS_NAME = "XfileSo";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIXfileSo> mdfGetClass();
  // attribute : tool generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TOOL = "tool";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TOOL_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TOOL,"ar3x.commonstructure.implementation.XfileSo",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element describes the tool which was used to generate the corresponding <xfile> . Kept as a string.
   * Attribute-Kind = versionAttribute   */
  public String getTool();
  /**
   * This element describes the tool which was used to generate the corresponding <xfile> . Kept as a string.
   * Attribute-Kind = versionAttribute   */
  public void setTool(String newValue);
  // attribute : toolVersion generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TOOL_VERSION = "toolVersion";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TOOL_VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TOOL_VERSION,"ar3x.commonstructure.implementation.XfileSo",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element describes the tool version which was used to generate the corresponding <xfile> . Kept as a string.
   * Attribute-Kind = versionAttribute   */
  public String getToolVersion();
  /**
   * This element describes the tool version which was used to generate the corresponding <xfile> . Kept as a string.
   * Attribute-Kind = versionAttribute   */
  public void setToolVersion(String newValue);
  // reference : code_codeXfile_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CODE_CODE_XFILE_OWNER = "code_codeXfile_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: codeXfile
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CODE_CODE_XFILE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CODE_CODE_XFILE_OWNER,"ar3x.commonstructure.implementation.XfileSo",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICode.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICode.CODE_XFILE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICode getCodeCodeXfileOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCodeCodeXfileOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICode newValue);
  // reference : dependencyOnFile_dependencyOnFileXfile_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DEPENDENCY_ON_FILE_DEPENDENCY_ON_FILE_XFILE_OWNER = "dependencyOnFile_dependencyOnFileXfile_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: dependencyOnFileXfile
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DEPENDENCY_ON_FILE_DEPENDENCY_ON_FILE_XFILE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DEPENDENCY_ON_FILE_DEPENDENCY_ON_FILE_XFILE_OWNER,"ar3x.commonstructure.implementation.XfileSo",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnFile.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnFile.DEPENDENCY_ON_FILE_XFILE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnFile getDependencyOnFileDependencyOnFileXfileOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDependencyOnFileDependencyOnFileXfileOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnFile newValue);
}
