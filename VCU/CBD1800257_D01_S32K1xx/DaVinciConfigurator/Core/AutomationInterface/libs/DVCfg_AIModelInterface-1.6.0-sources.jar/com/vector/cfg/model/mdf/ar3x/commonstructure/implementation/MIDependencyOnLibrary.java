package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A specific file dependency: without the library that implementation cannot be used (compiled, linked, executed, ...).
 */
public interface MIDependencyOnLibrary extends com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnFile
{
  public final static String CLASS_NAME = "DependencyOnLibrary";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDependencyOnLibrary> mdfGetClass();
  // attribute : minVersion generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_VERSION = "minVersion";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_VERSION,"ar3x.commonstructure.implementation.DependencyOnLibrary",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minimum version compatible with implementation.
   * Attribute-Kind = versionAttribute   */
  public String getMinVersion();
  /**
   * Minimum version compatible with implementation.
   * Attribute-Kind = versionAttribute   */
  public void setMinVersion(String newValue);
  // attribute : maxVersion generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_VERSION = "maxVersion";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_VERSION,"ar3x.commonstructure.implementation.DependencyOnLibrary",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximum version compatible with implementation. If not set, there is limitation on the upper version.
   * Attribute-Kind = versionAttribute   */
  public String getMaxVersion();
  /**
   * Maximum version compatible with implementation. If not set, there is limitation on the upper version.
   * Attribute-Kind = versionAttribute   */
  public void setMaxVersion(String newValue);
  // reference : dependencyOnLibraryARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEPENDENCY_ON_LIBRARY_ARREF_REF_TARGETS_OWNER = "dependencyOnLibraryARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DEPENDENCY_ON_LIBRARY_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DEPENDENCY_ON_LIBRARY_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.implementation.DependencyOnLibrary",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnLibraryARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnLibraryARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnLibraryARRef> getDependencyOnLibraryARRefRefTargetsOwner();
}
