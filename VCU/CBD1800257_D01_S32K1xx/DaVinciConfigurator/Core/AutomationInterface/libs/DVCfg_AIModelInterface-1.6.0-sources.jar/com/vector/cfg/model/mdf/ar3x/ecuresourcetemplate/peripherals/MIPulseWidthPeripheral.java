package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Common elements for PWM, PWD and CCU.
 */
public interface MIPulseWidthPeripheral extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheral
{
  public final static String CLASS_NAME = "PulseWidthPeripheral";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPulseWidthPeripheral> mdfGetClass();
  // attribute : resolution generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESOLUTION = "resolution";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESOLUTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESOLUTION,"ar3x.ecuresourcetemplate.peripherals.PulseWidthPeripheral",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the data width of the counter. Unit: Bits
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getResolution();
  /**
   * Defines the data width of the counter. Unit: Bits
   * Attribute-Kind = versionAttribute   */
  public void setResolution(java.math.BigInteger newValue);
}
