package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasSwDataDefProps extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasSwDataDefProps";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIHasSwDataDefProps> mdfGetClass();
  // reference : swDataDefProps generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_DATA_DEF_PROPS = "swDataDefProps";
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasSwDataDefProps_swDataDefProps_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEF_PROPS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEF_PROPS,"ar3x.commonstructure.datadefproperties.HasSwDataDefProps",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.HAS_SW_DATA_DEF_PROPS_SW_DATA_DEF_PROPS_OWNER_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps getSwDataDefProps();
  public void setSwDataDefProps(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps newValue);
}
