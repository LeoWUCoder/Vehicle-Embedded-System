package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;
import javax.jmi.model.*;

public enum MIHWPortTypesEnum implements javax.jmi.reflect.RefEnum
{
  COMMUNICATION_HW_PORT("COMMUNICATION-HW-PORT"),
  ECU_COMMUNICATION_PORT("ECU-COMMUNICATION-PORT"),
  HW_PORT("HW-PORT"),
  INTERRUPT_CONSUME_HW_PORT("INTERRUPT-CONSUME-HW-PORT"),
  INTERRUPT_HW_PORT("INTERRUPT-HW-PORT"),
  INTERRUPT_PRODUCE_HW_PORT("INTERRUPT-PRODUCE-HW-PORT"),
  MEMORY_MAPPED_HW_PORT("MEMORY-MAPPED-HW-PORT"),
  PERIPHERAL_HW_PORT("PERIPHERAL-HW-PORT"),
  POWER_DRIVER_HW_PORT("POWER-DRIVER-HW-PORT"),
  POWER_SUPPLY_HW_PORT("POWER-SUPPLY-HW-PORT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "ecuresourcetemplate" );
    temp.add( "HWPortTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIHWPortTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
