package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces;
import javax.jmi.model.*;

public enum MIBswCallType implements javax.jmi.reflect.RefEnum
{
  REGULAR("REGULAR"),
  CALLBACK("CALLBACK"),
  INTERRUPT("INTERRUPT"),
  SCHEDULED("SCHEDULED");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "bswinterfaces" );
    temp.add( "BswCallType" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIBswCallType(String literalName)
  {
    this.literalName = literalName;
  }
}
