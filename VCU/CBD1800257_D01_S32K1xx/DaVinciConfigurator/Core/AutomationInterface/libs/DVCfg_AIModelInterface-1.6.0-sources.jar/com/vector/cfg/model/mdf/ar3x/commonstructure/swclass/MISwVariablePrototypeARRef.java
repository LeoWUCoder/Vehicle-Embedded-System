package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwVariablePrototypeARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "SwVariablePrototypeARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwVariablePrototypeARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.commonstructure.swclass.SwVariablePrototypeARRef",null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototypeTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototypeTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototypeTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: swVariablePrototypeARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.commonstructure.swclass.SwVariablePrototypeARRef",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototype.SW_VARIABLE_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototype> getRefTargets();
  // reference : swVariableImpl_swVariablePrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_VARIABLE_IMPL_SW_VARIABLE_PROTOTYPE_OWNER = "swVariableImpl_swVariablePrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swVariablePrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_VARIABLE_IMPL_SW_VARIABLE_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_VARIABLE_IMPL_SW_VARIABLE_PROTOTYPE_OWNER,"ar3x.commonstructure.swclass.SwVariablePrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariableImpl.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariableImpl.SW_VARIABLE_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariableImpl getSwVariableImplSwVariablePrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwVariableImplSwVariablePrototypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariableImpl newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototype getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwVariablePrototype newRefTarget);

}
