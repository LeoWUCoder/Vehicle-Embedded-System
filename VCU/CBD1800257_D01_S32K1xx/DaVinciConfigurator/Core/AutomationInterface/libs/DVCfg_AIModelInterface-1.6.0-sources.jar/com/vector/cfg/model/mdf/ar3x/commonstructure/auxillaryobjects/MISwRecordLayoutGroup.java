package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies how a record layout is set up. Using SwRecordLayoutGroup it recursively models iterations through axis values. The subelement swRecordLayoutGroupContentType may reference other SwRecordLayouts, SwRecordLayoutVs and SwRecordLayoutGroups for the modeled record layout.
 */
public interface MISwRecordLayoutGroup extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwRecordLayoutGroup";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwRecordLayoutGroup> mdfGetClass();
  // attribute : swRecordLayoutComponent generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_COMPONENT = "swRecordLayoutComponent";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_RECORD_LAYOUT_COMPONENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_RECORD_LAYOUT_COMPONENT,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroup",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element is used to denote the component to which the group in question applies. Thus, the record layout supports structured objects. This secures independence from the sequence of components, because they can be referred to via name.
   * Attribute-Kind = versionAttribute   */
  public String getSwRecordLayoutComponent();
  /**
   * This element is used to denote the component to which the group in question applies. Thus, the record layout supports structured objects. This secures independence from the sequence of components, because they can be referred to via name.
   * Attribute-Kind = versionAttribute   */
  public void setSwRecordLayoutComponent(String newValue);
  // attribute : swRecordLayoutGroupAxis generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_GROUP_AXIS = "swRecordLayoutGroupAxis";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_RECORD_LAYOUT_GROUP_AXIS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_RECORD_LAYOUT_GROUP_AXIS,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroup",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The contents of this element specifies the axis number within a record layout group.  This attribute has been set to "String" because in the generated XML-Schema it is already a string (see RfC#53652).
   * Attribute-Kind = versionAttribute   */
  public String getSwRecordLayoutGroupAxis();
  /**
   * The contents of this element specifies the axis number within a record layout group.  This attribute has been set to "String" because in the generated XML-Schema it is already a string (see RfC#53652).
   * Attribute-Kind = versionAttribute   */
  public void setSwRecordLayoutGroupAxis(String newValue);
  // attribute : swRecordLayoutGroupFrom generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_GROUP_FROM = "swRecordLayoutGroupFrom";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_RECORD_LAYOUT_GROUP_FROM_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_RECORD_LAYOUT_GROUP_FROM,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroup",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element specifies the iterator index for the point in the axis from which a record layout group is commenced. Negative values are also possible, i.e. the value -4 counts from the fourth value from the end.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSwRecordLayoutGroupFrom();
  /**
   * This element specifies the iterator index for the point in the axis from which a record layout group is commenced. Negative values are also possible, i.e. the value -4 counts from the fourth value from the end.
   * Attribute-Kind = versionAttribute   */
  public void setSwRecordLayoutGroupFrom(java.math.BigInteger newValue);
  // attribute : swRecordLayoutGroupIndex generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_GROUP_INDEX = "swRecordLayoutGroupIndex";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_RECORD_LAYOUT_GROUP_INDEX_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_RECORD_LAYOUT_GROUP_INDEX,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroup",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element attributes a symbolic name to the iterator of the superimposed record layout group. This can be referenced as a loop index beneath superimposed or subsequent SwRecordLayoutV elements.
   * Attribute-Kind = versionAttribute   */
  public String getSwRecordLayoutGroupIndex();
  /**
   * This element attributes a symbolic name to the iterator of the superimposed record layout group. This can be referenced as a loop index beneath superimposed or subsequent SwRecordLayoutV elements.
   * Attribute-Kind = versionAttribute   */
  public void setSwRecordLayoutGroupIndex(String newValue);
  // attribute : swRecordLayoutGroupStep generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_GROUP_STEP = "swRecordLayoutGroupStep";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_RECORD_LAYOUT_GROUP_STEP_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_RECORD_LAYOUT_GROUP_STEP,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroup",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element specifies the step width for the iterator index, which is used for a record layout group .
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSwRecordLayoutGroupStep();
  /**
   * This element specifies the step width for the iterator index, which is used for a record layout group .
   * Attribute-Kind = versionAttribute   */
  public void setSwRecordLayoutGroupStep(java.math.BigInteger newValue);
  // attribute : swRecordLayoutGroupTo generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_RECORD_LAYOUT_GROUP_TO = "swRecordLayoutGroupTo";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_RECORD_LAYOUT_GROUP_TO_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_RECORD_LAYOUT_GROUP_TO,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroup",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This element specifies the iterator index for a point in the axis up to which iteration for a record layout group takes place. Negative values are also possible, i.e. the value -4 counts up to the fourth value from the end.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSwRecordLayoutGroupTo();
  /**
   * This element specifies the iterator index for a point in the axis up to which iteration for a record layout group takes place. Negative values are also possible, i.e. the value -4 counts up to the fourth value from the end.
   * Attribute-Kind = versionAttribute   */
  public void setSwRecordLayoutGroupTo(java.math.BigInteger newValue);
  // reference : swRecordLayout_swRecordLayoutGroup_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_RECORD_LAYOUT_SW_RECORD_LAYOUT_GROUP_OWNER = "swRecordLayout_swRecordLayoutGroup_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swRecordLayoutGroup
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_RECORD_LAYOUT_SW_RECORD_LAYOUT_GROUP_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_RECORD_LAYOUT_SW_RECORD_LAYOUT_GROUP_OWNER,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroup",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayout.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayout.SW_RECORD_LAYOUT_GROUP_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayout getSwRecordLayoutSwRecordLayoutGroupOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwRecordLayoutSwRecordLayoutGroupOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayout newValue);
  // reference : swRecordLayoutGroupContentType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_RECORD_LAYOUT_GROUP_CONTENT_TYPE = "swRecordLayoutGroupContentType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swRecordLayoutGroup_swRecordLayoutGroupContentType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_RECORD_LAYOUT_GROUP_CONTENT_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_RECORD_LAYOUT_GROUP_CONTENT_TYPE,"ar3x.commonstructure.auxillaryobjects.SwRecordLayoutGroup",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContent.SW_RECORD_LAYOUT_GROUP_SW_RECORD_LAYOUT_GROUP_CONTENT_TYPE_OWNER_RELATION_INFO;}};
  /**
   * this is the contents of the recordLayout which is produces for every step of iteration.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContent getSwRecordLayoutGroupContentType();
  /**
   * this is the contents of the recordLayout which is produces for every step of iteration.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwRecordLayoutGroupContentType(com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContent newValue);
}
