package com.vector.cfg.model.mdf;

import ru.novosoft.mdf.ext.MDFObject;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

//@CHECKSTYLE:OFF
//@NEWLINE_CONVERSION:OFF
/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation"> The {@link MIObject} is the base interface for all AUTOSAR model
 * objects in the DaVinci Configurator data model. It extends {@link MDFObject} which is the base interface of all model objects. Your client code shall always use
 * {@link MIObject}, when AUTOSAR model objects are used, instead of {@link MDFObject}.
 *
 * <p>
 * The figure <!--LaTeX:\vref{fig:MIObjectClassHierarchy}--> describes the class hierarchy of the {@link MIObject}.<br/>
 *
 * <img src="{@docRoot} /../_doc/UML/MIObject/MIObjectClassHierarchy.png" alt= "MIObject class hierarchy and base interfaces" id="fig:MIObjectClassHierarchy" data-latex-style=
 * "scale=0.7" />
 *
 * <pre>
 * <!--PlantUML: MIObjectClassHierarchy
 * interface {@link MDFObject}
 * interface {@link IModelObject}
 * interface {@link IConsistencyObject}
 * interface {@link MIObject}
 *
 *  {@link MDFObject} <|.. {@link IModelObject}
 *  {@link IModelObject} <|.. {@link MIObject}
 *  {@link IModelObject} <|.. {@link IConsistencyObject}
 *  {@link IConsistencyObject} <|.. {@link MIObject}
 *  note right of {@link MIObject} : Base interface for all \nAUTOSAR model objects
 * -->
 * </pre>
 *
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface MIObject extends MDFObject, IModelObject, IConsistencyObject {

    /**
     * Returns the immediate parent object.
     *
     * @return the immediate parent object.
     */
    @PublishedMethod
    MIObject miImmediateComposite();
}
