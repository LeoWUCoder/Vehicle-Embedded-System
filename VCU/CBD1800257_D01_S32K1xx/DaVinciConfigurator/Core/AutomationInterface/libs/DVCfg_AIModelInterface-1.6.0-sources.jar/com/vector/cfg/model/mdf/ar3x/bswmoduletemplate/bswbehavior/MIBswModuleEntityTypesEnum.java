package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;
import javax.jmi.model.*;

public enum MIBswModuleEntityTypesEnum implements javax.jmi.reflect.RefEnum
{
  BSW_INTERRUPT_ENTITY("BSW-INTERRUPT-ENTITY"),
  BSW_MODULE_ENTITY("BSW-MODULE-ENTITY"),
  BSW_SCHEDULABLE_ENTITY("BSW-SCHEDULABLE-ENTITY");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "bswbehavior" );
    temp.add( "BswModuleEntityTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIBswModuleEntityTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
