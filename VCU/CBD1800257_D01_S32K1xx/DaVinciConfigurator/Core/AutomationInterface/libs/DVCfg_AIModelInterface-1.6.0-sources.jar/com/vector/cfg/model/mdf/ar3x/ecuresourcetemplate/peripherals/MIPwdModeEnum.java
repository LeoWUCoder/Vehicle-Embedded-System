package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

public enum MIPwdModeEnum implements javax.jmi.reflect.RefEnum
{
  TWO_PHASE_INPUT("TWO-PHASE-INPUT"),
  THREE_PHASE_INPUT("THREE-PHASE-INPUT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "PwdModeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIPwdModeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
