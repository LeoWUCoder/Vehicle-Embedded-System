package com.vector.cfg.model.mdf.ar3x.commonstructure.filter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The filter removes all messages.
 */
public interface MINever extends com.vector.cfg.model.mdf.ar3x.commonstructure.filter.MIDataFilter
{
  public final static String CLASS_NAME = "Never";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MINever> mdfGetClass();
}
