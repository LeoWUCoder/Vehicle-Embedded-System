package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The heap usage has been measured.
 */
public interface MIMeasuredHeapUsage extends com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.heapusage.MIHeapUsage
{
  public final static String CLASS_NAME = "MeasuredHeapUsage";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIMeasuredHeapUsage> mdfGetClass();
  // attribute : minimumMemoryConsumption generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MINIMUM_MEMORY_CONSUMPTION = "minimumMemoryConsumption";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MINIMUM_MEMORY_CONSUMPTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MINIMUM_MEMORY_CONSUMPTION,"ar3x.commonstructure.resourceconsumption.heapusage.MeasuredHeapUsage",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The minimum heap usage measured.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMinimumMemoryConsumption();
  /**
   * The minimum heap usage measured.
   * Attribute-Kind = versionAttribute   */
  public void setMinimumMemoryConsumption(java.math.BigInteger newValue);
  // attribute : maximumMemoryConsumption generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAXIMUM_MEMORY_CONSUMPTION = "maximumMemoryConsumption";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAXIMUM_MEMORY_CONSUMPTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAXIMUM_MEMORY_CONSUMPTION,"ar3x.commonstructure.resourceconsumption.heapusage.MeasuredHeapUsage",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The maximum heap usage measured.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMaximumMemoryConsumption();
  /**
   * The maximum heap usage measured.
   * Attribute-Kind = versionAttribute   */
  public void setMaximumMemoryConsumption(java.math.BigInteger newValue);
  // attribute : averageMemoryConsumption generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String AVERAGE_MEMORY_CONSUMPTION = "averageMemoryConsumption";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo AVERAGE_MEMORY_CONSUMPTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,AVERAGE_MEMORY_CONSUMPTION,"ar3x.commonstructure.resourceconsumption.heapusage.MeasuredHeapUsage",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The average heap usage measured.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getAverageMemoryConsumption();
  /**
   * The average heap usage measured.
   * Attribute-Kind = versionAttribute   */
  public void setAverageMemoryConsumption(java.math.BigInteger newValue);
  // attribute : testPattern generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TEST_PATTERN = "testPattern";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TEST_PATTERN_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TEST_PATTERN,"ar3x.commonstructure.resourceconsumption.heapusage.MeasuredHeapUsage",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Description of the test pattern used to aquire the measured values.
   * Attribute-Kind = versionAttribute   */
  public String getTestPattern();
  /**
   * Description of the test pattern used to aquire the measured values.
   * Attribute-Kind = versionAttribute   */
  public void setTestPattern(String newValue);
}
