package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The Power Supply HW Port is used to model the power distribution within the ECU. If the direction is "in" the port is used to describe the power consumption of an HW Element. If the direction is "out" the port is used to describe a power source. The HW Connection between these two HW Ports can only be established between the Power Supply HW Port of the HW Element with direction "out" and a Power Supply HW Port of the Power Supply HW Element with direction "in".
 */
public interface MIPowerSupplyHWPort extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort
{
  public final static String CLASS_NAME = "PowerSupplyHWPort";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPowerSupplyHWPort> mdfGetClass();
  // attribute : canBeSwitchedOff generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CAN_BE_SWITCHED_OFF = "canBeSwitchedOff";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CAN_BE_SWITCHED_OFF_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CAN_BE_SWITCHED_OFF,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWPort",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines if the Power Supply HW Port can be switched off and therefore the supplied HW Element is switched off as well. This feature allows to describe which parts of an ECU are able be disconnected from their power supply based on software interaction.  If the Power Supply HW Port has the direction 'in' the supplied HW Element can be switched off.  If the Power Supply HW Port has the direction 'out' the power supply can be switched off and therefore all supplied HW Elements are switched off as well (This is used to describe groups of HW Elements that can only be switched off together).  When however the whole ECU is disconnected from power the switchable power supply is of course not valid anymore.
   * Attribute-Kind = versionAttribute   */
  public Boolean getCanBeSwitchedOff();
  /**
   * Defines if the Power Supply HW Port can be switched off and therefore the supplied HW Element is switched off as well. This feature allows to describe which parts of an ECU are able be disconnected from their power supply based on software interaction.  If the Power Supply HW Port has the direction 'in' the supplied HW Element can be switched off.  If the Power Supply HW Port has the direction 'out' the power supply can be switched off and therefore all supplied HW Elements are switched off as well (This is used to describe groups of HW Elements that can only be switched off together).  When however the whole ECU is disconnected from power the switchable power supply is of course not valid anymore.
   * Attribute-Kind = versionAttribute   */
  public void setCanBeSwitchedOff(Boolean newValue);
  // reference : supplied generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SUPPLIED = "supplied";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: powerSupplyHWPort_supplied_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SUPPLIED_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SUPPLIED,"ar3x.ecuresourcetemplate.ecuelectronics.PowerSupplyHWPort",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIElectricalRange.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIElectricalRange.POWER_SUPPLY_HWPORT_SUPPLIED_OWNER_RELATION_INFO;}};
  /**
   * For power source: provided electrical specification. For power consumer: required electrical specification.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIElectricalRange getSupplied();
  /**
   * For power source: provided electrical specification. For power consumer: required electrical specification.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSupplied(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIElectricalRange newValue);
}
