package com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwBaseTypeARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "SwBaseTypeARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwBaseTypeARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.commonstructure.basetypes.SwBaseTypeARRef",null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseTypeTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: swBaseTypeARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.commonstructure.basetypes.SwBaseTypeARRef",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseType.SW_BASE_TYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseType> getRefTargets();
  // reference : swDataDefProps_baseType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_DATA_DEF_PROPS_BASE_TYPE_OWNER = "swDataDefProps_baseType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: baseType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEF_PROPS_BASE_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEF_PROPS_BASE_TYPE_OWNER,"ar3x.commonstructure.basetypes.SwBaseTypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.BASE_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps getSwDataDefPropsBaseTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwDataDefPropsBaseTypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps newValue);
  // reference : swRecordLayoutV_baseType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_RECORD_LAYOUT_V_BASE_TYPE_OWNER = "swRecordLayoutV_baseType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: baseType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_RECORD_LAYOUT_V_BASE_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_RECORD_LAYOUT_V_BASE_TYPE_OWNER,"ar3x.commonstructure.basetypes.SwBaseTypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutV.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutV.BASE_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutV getSwRecordLayoutVBaseTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwRecordLayoutVBaseTypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutV newValue);
  // reference : baseTypeIndirectDefinition_baseType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BASE_TYPE_INDIRECT_DEFINITION_BASE_TYPE_OWNER = "baseTypeIndirectDefinition_baseType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: baseType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BASE_TYPE_INDIRECT_DEFINITION_BASE_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BASE_TYPE_INDIRECT_DEFINITION_BASE_TYPE_OWNER,"ar3x.commonstructure.basetypes.SwBaseTypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeIndirectDefinition.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeIndirectDefinition.BASE_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeIndirectDefinition getBaseTypeIndirectDefinitionBaseTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBaseTypeIndirectDefinitionBaseTypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseTypeIndirectDefinition newValue);
  // reference : swCalprmAxis_baseType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CALPRM_AXIS_BASE_TYPE_OWNER = "swCalprmAxis_baseType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: baseType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CALPRM_AXIS_BASE_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CALPRM_AXIS_BASE_TYPE_OWNER,"ar3x.commonstructure.basetypes.SwBaseTypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxis.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxis.BASE_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxis getSwCalprmAxisBaseTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCalprmAxisBaseTypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter.MISwCalprmAxis newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseType getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MISwBaseType newRefTarget);

}
