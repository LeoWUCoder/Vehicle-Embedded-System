package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The CCU is a special kind of a timer, which has the capability of counting and comparing external signals. The timer is equipped with some extra registers and comparators in order to measure time or frequency.
 */
public interface MICCU extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIGeneralPurposeTimer
{
  public final static String CLASS_NAME = "CCU";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICCU> mdfGetClass();
  // attribute : mode generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MODE = "mode";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MODE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MODE,"ar3x.ecuresourcetemplate.peripherals.CCU",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICcuModeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * A Capture and Compare peripheral can be configured to operate either in capture or compare mode.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICcuModeEnum getMode();
  /**
   * A Capture and Compare peripheral can be configured to operate either in capture or compare mode.
   * Attribute-Kind = versionAttribute   */
  public void setMode(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICcuModeEnum newValue);
}
