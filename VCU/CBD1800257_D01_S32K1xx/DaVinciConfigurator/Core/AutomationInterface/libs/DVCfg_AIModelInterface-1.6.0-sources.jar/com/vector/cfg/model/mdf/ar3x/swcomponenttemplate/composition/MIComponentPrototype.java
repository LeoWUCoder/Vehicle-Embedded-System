package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Role of a software component within a composition.
 */
public interface MIComponentPrototype extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "ComponentPrototype";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIComponentPrototype> mdfGetClass();
  // reference : componentPrototypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String COMPONENT_PROTOTYPE_ARREF_REF_TARGETS_OWNER = "componentPrototypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_PROTOTYPE_ARREF_REF_TARGETS_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototype",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef> getComponentPrototypeARRefRefTargetsOwner();
  // reference : type generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String TYPE = "type";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: componentPrototype_type_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(TYPE,"ar3x.swcomponenttemplate.composition.ComponentPrototype",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentTypeARRef.COMPONENT_PROTOTYPE_TYPE_OWNER_RELATION_INFO;}};
  /**
   * Type of the instance.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentTypeARRef getType();
  /**
   * Type of the instance.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setType(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentTypeARRef newValue);
  // reference : compositionType_component_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPOSITION_TYPE_COMPONENT_OWNER = "compositionType_component_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: component
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPOSITION_TYPE_COMPONENT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPOSITION_TYPE_COMPONENT_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototype",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionType.COMPONENT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionType getCompositionTypeComponentOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompositionTypeComponentOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionType newValue);
}
