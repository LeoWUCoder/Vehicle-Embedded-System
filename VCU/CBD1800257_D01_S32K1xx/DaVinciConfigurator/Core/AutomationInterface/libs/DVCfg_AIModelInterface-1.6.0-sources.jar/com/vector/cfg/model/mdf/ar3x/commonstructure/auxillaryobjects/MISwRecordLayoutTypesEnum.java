package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;
import javax.jmi.model.*;

public enum MISwRecordLayoutTypesEnum implements javax.jmi.reflect.RefEnum
{
  SW_RECORD_LAYOUT("SW-RECORD-LAYOUT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "auxillaryobjects" );
    temp.add( "SwRecordLayoutTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwRecordLayoutTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
