package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MICompuConst extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "CompuConst";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICompuConst> mdfGetClass();
  // reference : compu_compuDefaultValue_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPU_COMPU_DEFAULT_VALUE_OWNER = "compu_compuDefaultValue_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: compuDefaultValue
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPU_COMPU_DEFAULT_VALUE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPU_COMPU_DEFAULT_VALUE_OWNER,"ar3x.swcomponenttemplate.datatype.computationmethod.CompuConst",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompu.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompu.COMPU_DEFAULT_VALUE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompu getCompuCompuDefaultValueOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompuCompuDefaultValueOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompu newValue);
  // reference : compuScaleConstantContents_compuConst_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPU_SCALE_CONSTANT_CONTENTS_COMPU_CONST_OWNER = "compuScaleConstantContents_compuConst_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: compuConst
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPU_SCALE_CONSTANT_CONTENTS_COMPU_CONST_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPU_SCALE_CONSTANT_CONTENTS_COMPU_CONST_OWNER,"ar3x.swcomponenttemplate.datatype.computationmethod.CompuConst",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuScaleConstantContents.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuScaleConstantContents.COMPU_CONST_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuScaleConstantContents getCompuScaleConstantContentsCompuConstOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompuScaleConstantContentsCompuConstOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuScaleConstantContents newValue);
  // reference : compuConstContentType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPU_CONST_CONTENT_TYPE = "compuConstContentType";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: compuConst_compuConstContentType_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPU_CONST_CONTENT_TYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPU_CONST_CONTENT_TYPE,"ar3x.swcomponenttemplate.datatype.computationmethod.CompuConst",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConstContent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConstContent.COMPU_CONST_COMPU_CONST_CONTENT_TYPE_OWNER_RELATION_INFO;}};
  /**
   * This is the actual content of the constant compu method scale.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConstContent getCompuConstContentType();
  /**
   * This is the actual content of the constant compu method scale.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompuConstContentType(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConstContent newValue);
}
