package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;
import javax.jmi.model.*;

public enum MIMaxCommModeEnum implements javax.jmi.reflect.RefEnum
{
  NONE("NONE"),
  SILENT("SILENT"),
  FULL("FULL");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "serviceneeds" );
    temp.add( "MaxCommModeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIMaxCommModeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
