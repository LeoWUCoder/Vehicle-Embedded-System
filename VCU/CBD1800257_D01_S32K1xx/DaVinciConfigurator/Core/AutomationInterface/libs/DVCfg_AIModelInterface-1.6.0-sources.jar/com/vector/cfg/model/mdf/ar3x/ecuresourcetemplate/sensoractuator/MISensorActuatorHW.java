package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The common attributes for sensors and actuators. The sensor and actuators can be connected via a Peripheral HW Port, a Communication HW Port or a Power Driver HW Port.
 */
public interface MISensorActuatorHW extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement
{
  public final static String CLASS_NAME = "SensorActuatorHW";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISensorActuatorHW> mdfGetClass();
  // attribute : type generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TYPE = "type";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TYPE,"ar3x.ecuresourcetemplate.sensoractuator.SensorActuatorHW",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the general type of the sensor/actuator type is a most common naming for a sensor/actuator and is an open list and is not restricted to the following items. Several sets of types exist. Type is mandatory for the usage of the template - Sensor: Temperature, Pressure, Distance, Hall - Actuator: DC Motor, Valve, Relay, Display
   * Attribute-Kind = versionAttribute   */
  public String getType();
  /**
   * Defines the general type of the sensor/actuator type is a most common naming for a sensor/actuator and is an open list and is not restricted to the following items. Several sets of types exist. Type is mandatory for the usage of the template - Sensor: Temperature, Pressure, Distance, Hall - Actuator: DC Motor, Valve, Relay, Display
   * Attribute-Kind = versionAttribute   */
  public void setType(String newValue);
  // attribute : accuracy generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ACCURACY = "accuracy";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ACCURACY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ACCURACY,"ar3x.ecuresourcetemplate.sensoractuator.SensorActuatorHW",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the error in the representation of the Technical Signal in the data format This applies only if the Technical Signal is encoded before it is transferred to the ECU Electronics (e.g. via Communication Transceiver HW Port).
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getAccuracy();
  /**
   * Defines the error in the representation of the Technical Signal in the data format This applies only if the Technical Signal is encoded before it is transferred to the ECU Electronics (e.g. via Communication Transceiver HW Port).
   * Attribute-Kind = versionAttribute   */
  public void setAccuracy(java.math.BigDecimal newValue);
  // attribute : resolution generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESOLUTION = "resolution";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESOLUTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESOLUTION,"ar3x.ecuresourcetemplate.sensoractuator.SensorActuatorHW",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the granularity of the representation of the Technical Signal in the data format. This applies only if the Technical Signal is encoded before it is transferred to the ECU Electronics (e.g. via Communication Transceiver HW Port).
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getResolution();
  /**
   * Defines the granularity of the representation of the Technical Signal in the data format. This applies only if the Technical Signal is encoded before it is transferred to the ECU Electronics (e.g. via Communication Transceiver HW Port).
   * Attribute-Kind = versionAttribute   */
  public void setResolution(java.math.BigDecimal newValue);
  // reference : sensorActuatorHWARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SENSOR_ACTUATOR_HWARREF_REF_TARGETS_OWNER = "sensorActuatorHWARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SENSOR_ACTUATOR_HWARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SENSOR_ACTUATOR_HWARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.sensoractuator.SensorActuatorHW",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHWARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHWARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHWARRef> getSensorActuatorHWARRefRefTargetsOwner();
  // reference : cycleTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CYCLE_TIME = "cycleTime";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: sensorActuatorHW_cycleTime_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CYCLE_TIME_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CYCLE_TIME,"ar3x.ecuresourcetemplate.sensoractuator.SensorActuatorHW",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITimeRange.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITimeRange.SENSOR_ACTUATOR_HW_CYCLE_TIME_OWNER_RELATION_INFO;}};
  /**
   * The time the sensor/actuator must be accessed for correct information. It is possible to give a minimum, a maximum and a typical cycle time.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITimeRange getCycleTime();
  /**
   * The time the sensor/actuator must be accessed for correct information. It is possible to give a minimum, a maximum and a typical cycle time.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCycleTime(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MITimeRange newValue);
}
