package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A specialization of a Communication HW Port that is availabe for the inter ECU communication.
 */
public interface MIECUCommunicationPort extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationHWPort
{
  public final static String CLASS_NAME = "ECUCommunicationPort";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIECUCommunicationPort> mdfGetClass();
  // reference : eCUCommunicationPortARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String E_CUCOMMUNICATION_PORT_ARREF_REF_TARGETS_OWNER = "eCUCommunicationPortARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo E_CUCOMMUNICATION_PORT_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(E_CUCOMMUNICATION_PORT_ARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.peripherals.ECUCommunicationPort",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPortARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIECUCommunicationPortARRef> getECUCommunicationPortARRefRefTargetsOwner();
}
