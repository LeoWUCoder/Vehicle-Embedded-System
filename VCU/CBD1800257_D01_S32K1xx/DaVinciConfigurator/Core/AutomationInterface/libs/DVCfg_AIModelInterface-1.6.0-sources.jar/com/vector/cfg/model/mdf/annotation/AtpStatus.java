package com.vector.cfg.model.mdf.annotation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.TYPE;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

//CHECKSTYLE:OFF because we directly use the AUTOSAR names
/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@Retention(RetentionPolicy.CLASS)
@Target({ TYPE, FIELD, METHOD })
public @interface AtpStatus {
    enum AtpStatusEnum {
        valid,
        draft,
        obsolete,
        preliminary,
        removed,
        shallBecomeMandatory
    }

    AtpStatusEnum value() default AtpStatusEnum.valid;
}
