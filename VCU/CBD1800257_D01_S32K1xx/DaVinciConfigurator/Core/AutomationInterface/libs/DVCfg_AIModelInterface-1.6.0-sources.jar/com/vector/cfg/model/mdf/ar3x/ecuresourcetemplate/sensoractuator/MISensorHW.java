package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * HW Element Sensor definition.
 */
public interface MISensorHW extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW
{
  public final static String CLASS_NAME = "SensorHW";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISensorHW> mdfGetClass();
  // attribute : signalQuality generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SIGNAL_QUALITY = "signalQuality";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SIGNAL_QUALITY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SIGNAL_QUALITY,"ar3x.ecuresourcetemplate.sensoractuator.SensorHW",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorHwSignalQualityEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the quality of the data received from a sensor. Depending on this information later processing on the signal has to be done in HW or SW.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorHwSignalQualityEnum getSignalQuality();
  /**
   * Defines the quality of the data received from a sensor. Depending on this information later processing on the signal has to be done in HW or SW.
   * Attribute-Kind = versionAttribute   */
  public void setSignalQuality(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorHwSignalQualityEnum newValue);
}
