package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIProgramminglanguageEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "ProgramminglanguageEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIProgramminglanguageEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.commonstructure.implementation.ProgramminglanguageEnumItem",null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIProgramminglanguageEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIProgramminglanguageEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIProgramminglanguageEnum newValue);
}
