package com.vector.cfg.model.mdf.ar3x.commonstructure.axis;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element describes a generic axis parameter type, namely:  * Plausibility checks can be specified via dataConstr.  * Textual description (desc), as a formal description is not of any use, due to the large variety of possibilities.  * If this parameter contains structures, these can be simulated through the recursive use of swGenericAxisParamTypes.
 */
public interface MISwGenericAxisParamType extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "SwGenericAxisParamType";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwGenericAxisParamType> mdfGetClass();
  // reference : swGenericAxisParamTypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_GENERIC_AXIS_PARAM_TYPE_ARREF_REF_TARGETS_OWNER = "swGenericAxisParamTypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_GENERIC_AXIS_PARAM_TYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_GENERIC_AXIS_PARAM_TYPE_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.axis.SwGenericAxisParamType",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamTypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamTypeARRef> getSwGenericAxisParamTypeARRefRefTargetsOwner();
  // reference : swAxisType_swGenericAxisParamType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_AXIS_TYPE_SW_GENERIC_AXIS_PARAM_TYPE_OWNER = "swAxisType_swGenericAxisParamType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swGenericAxisParamType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_AXIS_TYPE_SW_GENERIC_AXIS_PARAM_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_AXIS_TYPE_SW_GENERIC_AXIS_PARAM_TYPE_OWNER,"ar3x.commonstructure.axis.SwGenericAxisParamType",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisType.SW_GENERIC_AXIS_PARAM_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisType getSwAxisTypeSwGenericAxisParamTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwAxisTypeSwGenericAxisParamTypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwAxisType newValue);
}
