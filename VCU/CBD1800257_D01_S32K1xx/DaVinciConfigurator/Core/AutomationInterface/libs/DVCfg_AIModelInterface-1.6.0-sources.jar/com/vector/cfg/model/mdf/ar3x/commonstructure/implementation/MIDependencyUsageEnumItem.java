package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIDependencyUsageEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "DependencyUsageEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDependencyUsageEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.commonstructure.implementation.DependencyUsageEnumItem",null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyUsageEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyUsageEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyUsageEnum newValue);
  // reference : dependency_usage_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEPENDENCY_USAGE_OWNER = "dependency_usage_Owner";
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: usage
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DEPENDENCY_USAGE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DEPENDENCY_USAGE_OWNER,"ar3x.commonstructure.implementation.DependencyUsageEnumItem",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependency.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependency.USAGE_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependency getDependencyUsageOwner();
  public void setDependencyUsageOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependency newValue);
}
