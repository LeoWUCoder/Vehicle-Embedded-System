package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;
import javax.jmi.model.*;

public enum MIActuatorHwMovementEnum implements javax.jmi.reflect.RefEnum
{
  UNIDIRECTIONAL("UNIDIRECTIONAL"),
  BIDIRECTIONAL("BIDIRECTIONAL"),
  UNIDIRECTIONAL_WITH_AUTO_RESET("UNIDIRECTIONAL-WITH-AUTO-RESET");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "sensoractuator" );
    temp.add( "ActuatorHwMovementEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIActuatorHwMovementEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
