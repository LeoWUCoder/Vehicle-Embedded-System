package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;
import javax.jmi.model.*;

public enum MIHWPinTypesEnum implements javax.jmi.reflect.RefEnum
{
  HW_PIN("HW-PIN");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "ecuresourcetemplate" );
    temp.add( "HWPinTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIHWPinTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
