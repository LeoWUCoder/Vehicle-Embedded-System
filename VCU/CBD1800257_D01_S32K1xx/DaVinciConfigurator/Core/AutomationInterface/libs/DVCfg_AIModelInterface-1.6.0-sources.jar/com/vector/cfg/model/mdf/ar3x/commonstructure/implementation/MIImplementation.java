package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIImplementation extends com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIImplementation, com.vector.cfg.model.mdf.model.autosar.base.MIARElement
{
  public final static String CLASS_NAME = "Implementation";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIImplementation> mdfGetClass();
  // attribute : codeGenerator generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CODE_GENERATOR = "codeGenerator";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CODE_GENERATOR_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CODE_GENERATOR,"ar3x.commonstructure.implementation.Implementation",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Optional: code generator used.
   * Attribute-Kind = versionAttribute   */
  public String getCodeGenerator();
  /**
   * Optional: code generator used.
   * Attribute-Kind = versionAttribute   */
  public void setCodeGenerator(String newValue);
  // attribute : programmingLanguage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PROGRAMMING_LANGUAGE = "programmingLanguage";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PROGRAMMING_LANGUAGE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PROGRAMMING_LANGUAGE,"ar3x.commonstructure.implementation.Implementation",null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIProgramminglanguageEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Programming language the implementation was created in.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIProgramminglanguageEnum getProgrammingLanguage();
  /**
   * Programming language the implementation was created in.
   * Attribute-Kind = versionAttribute   */
  public void setProgrammingLanguage(com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIProgramminglanguageEnum newValue);
  // attribute : swMajorVersion generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_MAJOR_VERSION = "swMajorVersion";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_MAJOR_VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_MAJOR_VERSION,"ar3x.commonstructure.implementation.Implementation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Major version number of this implementation. The numbering is vendor specific.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSwMajorVersion();
  /**
   * Major version number of this implementation. The numbering is vendor specific.
   * Attribute-Kind = versionAttribute   */
  public void setSwMajorVersion(java.math.BigInteger newValue);
  // attribute : swMinorVersion generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_MINOR_VERSION = "swMinorVersion";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_MINOR_VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_MINOR_VERSION,"ar3x.commonstructure.implementation.Implementation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minor version number of this implementation. The numbering is vendor specific.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSwMinorVersion();
  /**
   * Minor version number of this implementation. The numbering is vendor specific.
   * Attribute-Kind = versionAttribute   */
  public void setSwMinorVersion(java.math.BigInteger newValue);
  // attribute : swPatchVersion generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_PATCH_VERSION = "swPatchVersion";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_PATCH_VERSION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_PATCH_VERSION,"ar3x.commonstructure.implementation.Implementation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Patch version number of this implementation. The numbering is vendor specific.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSwPatchVersion();
  /**
   * Patch version number of this implementation. The numbering is vendor specific.
   * Attribute-Kind = versionAttribute   */
  public void setSwPatchVersion(java.math.BigInteger newValue);
  // reference : codeDescriptor generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CODE_DESCRIPTOR = "codeDescriptor";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: implementation_codeDescriptor_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CODE_DESCRIPTOR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CODE_DESCRIPTOR,"ar3x.commonstructure.implementation.Implementation",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICode.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICode.IMPLEMENTATION_CODE_DESCRIPTOR_OWNER_RELATION_INFO;}};
  /**
   * Specifies the provided implementation code.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICode> getCodeDescriptor();
  // reference : compiler generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPILER = "compiler";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: implementation_compiler_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPILER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPILER,"ar3x.commonstructure.implementation.Implementation",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICompiler.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICompiler.IMPLEMENTATION_COMPILER_OWNER_RELATION_INFO;}};
  /**
   * Specifies the compiler for which this implementation has been released
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MICompiler> getCompiler();
  // reference : implementationDependency generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IMPLEMENTATION_DEPENDENCY = "implementationDependency";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: implementation_implementationDependency_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IMPLEMENTATION_DEPENDENCY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IMPLEMENTATION_DEPENDENCY,"ar3x.commonstructure.implementation.Implementation",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependency.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependency.IMPLEMENTATION_IMPLEMENTATION_DEPENDENCY_OWNER_RELATION_INFO;}};
  /**
   * Specifies details on dependent software, modules or libraries.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependency> getImplementationDependency();
  // reference : processor generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROCESSOR = "processor";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: implementation_processor_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROCESSOR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROCESSOR,"ar3x.commonstructure.implementation.Implementation",133,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitARRef.IMPLEMENTATION_PROCESSOR_OWNER_RELATION_INFO;}};
  /**
   * The processor the implementation is compatible with.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitARRef> getProcessor();
  // reference : linker generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String LINKER = "linker";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: implementation_linker_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo LINKER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(LINKER,"ar3x.commonstructure.implementation.Implementation",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MILinker.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MILinker.IMPLEMENTATION_LINKER_OWNER_RELATION_INFO;}};
  /**
   * Specifies the linker for which this implementation has been released.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MILinker> getLinker();
  // reference : resourceConsumption generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RESOURCE_CONSUMPTION = "resourceConsumption";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: implementation_resourceConsumption_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RESOURCE_CONSUMPTION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RESOURCE_CONSUMPTION,"ar3x.commonstructure.implementation.Implementation",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption.IMPLEMENTATION_RESOURCE_CONSUMPTION_OWNER_RELATION_INFO;}};
  /**
   * All static and dynamic resources for each implementation are described  within the ResourceConsumption class.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption getResourceConsumption();
  /**
   * All static and dynamic resources for each implementation are described  within the ResourceConsumption class.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setResourceConsumption(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption newValue);
}
