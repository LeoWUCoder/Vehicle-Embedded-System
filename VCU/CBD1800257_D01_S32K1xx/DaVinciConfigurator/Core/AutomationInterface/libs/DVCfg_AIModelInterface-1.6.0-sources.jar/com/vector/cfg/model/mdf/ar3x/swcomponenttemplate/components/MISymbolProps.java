package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISymbolProps extends com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIImplementationProps
{
  public final static String CLASS_NAME = "SymbolProps";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISymbolProps> mdfGetClass();
  // reference : atomicSoftwareComponentType_symbolProps_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ATOMIC_SOFTWARE_COMPONENT_TYPE_SYMBOL_PROPS_OWNER = "atomicSoftwareComponentType_symbolProps_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: symbolProps
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ATOMIC_SOFTWARE_COMPONENT_TYPE_SYMBOL_PROPS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ATOMIC_SOFTWARE_COMPONENT_TYPE_SYMBOL_PROPS_OWNER,"ar3x.swcomponenttemplate.components.SymbolProps",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType.SYMBOL_PROPS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType getAtomicSoftwareComponentTypeSymbolPropsOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setAtomicSoftwareComponentTypeSymbolPropsOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIAtomicSoftwareComponentType newValue);
}
