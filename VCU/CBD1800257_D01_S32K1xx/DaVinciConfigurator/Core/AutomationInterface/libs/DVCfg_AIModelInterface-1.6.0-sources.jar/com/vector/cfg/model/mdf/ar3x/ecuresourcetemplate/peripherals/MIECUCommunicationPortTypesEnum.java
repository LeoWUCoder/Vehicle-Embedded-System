package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

public enum MIECUCommunicationPortTypesEnum implements javax.jmi.reflect.RefEnum
{
  ECU_COMMUNICATION_PORT("ECU-COMMUNICATION-PORT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "ECUCommunicationPortTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIECUCommunicationPortTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
