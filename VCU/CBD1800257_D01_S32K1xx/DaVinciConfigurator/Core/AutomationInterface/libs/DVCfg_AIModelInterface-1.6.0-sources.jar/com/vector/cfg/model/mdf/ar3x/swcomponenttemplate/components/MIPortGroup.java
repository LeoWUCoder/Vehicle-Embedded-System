package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Group of ports which share a common functionality, e.g. need specific network resources. This information shall be available on the VFB level in order to delegate it properly via compositions. When propagated into the ECU extract, this information is used as input for the configuration of Services like the Communication Manager. A PortGroup is defined locally in a component (which can be a composition) and refers to the "outer" ports belonging to the group as well as to the "inner" groups which propagate this group into the components which are part of a composition. A PortGroup within an atomic SWC cannot be linked to inner groups.
 */
public interface MIPortGroup extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "PortGroup";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPortGroup> mdfGetClass();
  // reference : portGroupARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PORT_GROUP_ARREF_REF_TARGETS_OWNER = "portGroupARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_GROUP_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_GROUP_ARREF_REF_TARGETS_OWNER,"ar3x.swcomponenttemplate.components.PortGroup",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroupARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroupARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroupARRef> getPortGroupARRefRefTargetsOwner();
  // reference : componentType_portGroup_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_TYPE_PORT_GROUP_OWNER = "componentType_portGroup_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: portGroup
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_TYPE_PORT_GROUP_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_TYPE_PORT_GROUP_OWNER,"ar3x.swcomponenttemplate.components.PortGroup",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType.PORT_GROUP_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType getComponentTypePortGroupOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComponentTypePortGroupOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType newValue);
  // reference : innerGroup generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INNER_GROUP = "innerGroup";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: portGroup_innerGroup_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INNER_GROUP_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INNER_GROUP,"ar3x.swcomponenttemplate.components.PortGroup",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup.PORT_GROUP_INNER_GROUP_OWNER_RELATION_INFO;}};
  /**
   * Links a PortGroup in a composition to another PortGroup, that is defined in a component which is part of this CompositionType. 
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup> getInnerGroup();
  // reference : portGroupOuterPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_GROUP_OUTER_PORT = "portGroupOuterPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: portGroup_portGroupOuterPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_GROUP_OUTER_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_GROUP_OUTER_PORT,"ar3x.swcomponenttemplate.components.PortGroup",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.PORT_GROUP_PORT_GROUP_OUTER_PORT_OWNER_RELATION_INFO;}};
  /**
   * Outer port of this component which belongs to the group. A port can belong to several groups or to no group at all.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef> getPortGroupOuterPort();
}
