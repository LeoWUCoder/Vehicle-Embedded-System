package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Provides a description of a rough estimate on the ExecutionTime.
 */
public interface MIRoughEstimateOfExecutionTime extends com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime
{
  public final static String CLASS_NAME = "RoughEstimateOfExecutionTime";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIRoughEstimateOfExecutionTime> mdfGetClass();
  // attribute : estimationDescription generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ESTIMATION_DESCRIPTION = "estimationDescription";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ESTIMATION_DESCRIPTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ESTIMATION_DESCRIPTION,"ar3x.commonstructure.resourceconsumption.executiontime.RoughEstimateOfExecutionTime",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Provides description on the rough estimate of the ExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public String getEstimationDescription();
  /**
   * Provides description on the rough estimate of the ExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public void setEstimationDescription(String newValue);
}
