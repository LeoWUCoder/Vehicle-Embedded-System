package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The properties specific for a textual calibration parameter / variable.
 */
public interface MISwTextProps extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwTextProps";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwTextProps> mdfGetClass();
  // attribute : swFillCharacter generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SW_FILL_CHARACTER = "swFillCharacter";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SW_FILL_CHARACTER_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SW_FILL_CHARACTER,"ar3x.commonstructure.datadefproperties.SwTextProps",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Filler character for text parameter to pad up to the maximum length <SwMaxTextSize>. The filler character for texts which are shorter than the maximum permitted text length. The value will be interpreted according to the encoding specified in the associated base type of the data object., e.g. 0x30 (hex) represents the ASCII character zero as filler character and 0 (dez) represents an end of string as filler character.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSwFillCharacter();
  /**
   * Filler character for text parameter to pad up to the maximum length <SwMaxTextSize>. The filler character for texts which are shorter than the maximum permitted text length. The value will be interpreted according to the encoding specified in the associated base type of the data object., e.g. 0x30 (hex) represents the ASCII character zero as filler character and 0 (dez) represents an end of string as filler character.
   * Attribute-Kind = versionAttribute   */
  public void setSwFillCharacter(java.math.BigInteger newValue);
  // reference : swDataDefProps_swTextProps_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_DATA_DEF_PROPS_SW_TEXT_PROPS_OWNER = "swDataDefProps_swTextProps_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swTextProps
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEF_PROPS_SW_TEXT_PROPS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEF_PROPS_SW_TEXT_PROPS_OWNER,"ar3x.commonstructure.datadefproperties.SwTextProps",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps.SW_TEXT_PROPS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps getSwDataDefPropsSwTextPropsOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwDataDefPropsSwTextPropsOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDefProps newValue);
  // reference : swMaxTextSize generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_MAX_TEXT_SIZE = "swMaxTextSize";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swTextProps_swMaxTextSize_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_MAX_TEXT_SIZE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_MAX_TEXT_SIZE,"ar3x.commonstructure.datadefproperties.SwTextProps",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf.SW_TEXT_PROPS_SW_MAX_TEXT_SIZE_OWNER_RELATION_INFO;}};
  /**
   * Specifies the maximum text size in characters. Note the the size in bytes depends on the encoding in the corresponding baseType.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf getSwMaxTextSize();
  /**
   * Specifies the maximum text size in characters. Note the the size in bytes depends on the encoding in the corresponding baseType.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwMaxTextSize(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf newValue);
}
