package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes specific to distribution of  events (P-Port, sender-receiver interface and data element carries an "event").
 */
public interface MIQueuedSenderComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MISenderComSpec
{
  public final static String CLASS_NAME = "QueuedSenderComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIQueuedSenderComSpec> mdfGetClass();
}
