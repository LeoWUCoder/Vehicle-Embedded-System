package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;
import javax.jmi.model.*;

public enum MIProvidedMemorySegmentTypesEnum implements javax.jmi.reflect.RefEnum
{
  PROVIDED_MEMORY_SEGMENT("PROVIDED-MEMORY-SEGMENT"),
  PROVIDED_NV_MEMORY_SEGMENT("PROVIDED-NV-MEMORY-SEGMENT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "memory" );
    temp.add( "ProvidedMemorySegmentTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIProvidedMemorySegmentTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
