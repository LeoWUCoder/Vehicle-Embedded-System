package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;
import javax.jmi.model.*;

public enum MISwVariableAccessImplPolicyEnum implements javax.jmi.reflect.RefEnum
{
  OPTIMIZED("OPTIMIZED"),
  SELECTABLE("SELECTABLE"),
  DIRECT("DIRECT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "datadefproperties" );
    temp.add( "SwVariableAccessImplPolicyEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwVariableAccessImplPolicyEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
