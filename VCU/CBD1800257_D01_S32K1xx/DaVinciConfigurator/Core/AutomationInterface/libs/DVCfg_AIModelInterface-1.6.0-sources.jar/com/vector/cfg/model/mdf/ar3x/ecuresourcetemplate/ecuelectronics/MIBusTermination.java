package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * In order to avoid signal reflection and oscillation of the Technical Signal represen-tation the impedance on communication lines have to be defined and matched at the signal destination and the signal source. Some examples: A High-speed CAN network with a twisted pair cable works optimal with an overall impedance of 60 Ohms represented by a 120 Ohm resistor in the ECU at the begin-ning of the network and 120 Ohm in the ECU at the end of a linear network topology. For Low-speed CAN networks in many cases termination resistors of 820 Ohm each are distributed on several ECUs to get good balance between system scalability and signal integrity in real networks without a fixed network topology. The lower bandwidth can tolerate some impedance mismatch. For LIN networks recessive termination is used: The inactive bus signal level is defined by resistors tied to a defined voltage level. An important attribute for communication lines is the presence of a termination resistor and the value of this resistor.
 */
public interface MIBusTermination extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "BusTermination";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBusTermination> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.ecuresourcetemplate.ecuelectronics.BusTermination",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describe the nominal Value of the termination resistor at the ECU as seen from the communication network.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getValue();
  /**
   * Describe the nominal Value of the termination resistor at the ECU as seen from the communication network.
   * Attribute-Kind = versionAttribute   */
  public void setValue(java.math.BigInteger newValue);
  // attribute : split generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SPLIT = "split";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SPLIT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SPLIT,"ar3x.ecuresourcetemplate.ecuelectronics.BusTermination",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describe a technology were the termination is split in to individual resistors with a  capacitive coupling to ground. This technology improves the signal quality.
   * Attribute-Kind = versionAttribute   */
  public Boolean getSplit();
  /**
   * Describe a technology were the termination is split in to individual resistors with a  capacitive coupling to ground. This technology improves the signal quality.
   * Attribute-Kind = versionAttribute   */
  public void setSplit(Boolean newValue);
  // attribute : activeSwitchable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ACTIVE_SWITCHABLE = "activeSwitchable";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ACTIVE_SWITCHABLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ACTIVE_SWITCHABLE,"ar3x.ecuresourcetemplate.ecuelectronics.BusTermination",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Switchable termination describes a technology were the termination resistors can be switched or changed by extra hardware and therefore is under control of software. Main scope of a switchable termination is to adopt the termination of an individual ECU to the network topology of a specific car, e. g modules for extra car options can use this method to be incorporated in a wide range of different car types. The active termination is described by the values for each termination value. E.g. 120, 820, 12k. No termination is represented by values greater than 100 k. The attributes value and switchable are exclusive to each other.
   * Attribute-Kind = versionAttribute   */
  public Boolean getActiveSwitchable();
  /**
   * Switchable termination describes a technology were the termination resistors can be switched or changed by extra hardware and therefore is under control of software. Main scope of a switchable termination is to adopt the termination of an individual ECU to the network topology of a specific car, e. g modules for extra car options can use this method to be incorporated in a wide range of different car types. The active termination is described by the values for each termination value. E.g. 120, 820, 12k. No termination is represented by values greater than 100 k. The attributes value and switchable are exclusive to each other.
   * Attribute-Kind = versionAttribute   */
  public void setActiveSwitchable(Boolean newValue);
  // attribute : choke generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CHOKE = "choke";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CHOKE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CHOKE,"ar3x.ecuresourcetemplate.ecuelectronics.BusTermination",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * To improve the signal integrity on communication busses with a differential electrical signal representation on the physical layer, common mode chokes are used. They suppress common mode DC noise on CAN, FlexRay and Ethernet networks. Depending on the network topology common mode chokes of an ECU have to be taken in to account when adding ECUs to a network during design phase. Typically chokes are used on CAN, FlexRay, LVDS.
   * Attribute-Kind = versionAttribute   */
  public Boolean getChoke();
  /**
   * To improve the signal integrity on communication busses with a differential electrical signal representation on the physical layer, common mode chokes are used. They suppress common mode DC noise on CAN, FlexRay and Ethernet networks. Depending on the network topology common mode chokes of an ECU have to be taken in to account when adding ECUs to a network during design phase. Typically chokes are used on CAN, FlexRay, LVDS.
   * Attribute-Kind = versionAttribute   */
  public void setChoke(Boolean newValue);
  // attribute : emcFilter generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String EMC_FILTER = "emcFilter";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo EMC_FILTER_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,EMC_FILTER,"ar3x.ecuresourcetemplate.ecuelectronics.BusTermination",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * To improve the EMC behaviour of communication busses common dedicated EMC Filters are used. They suppress frequencies outside the range, which is needed for the communication of the specific bus E.g. some small capacitors in parallel to ground, resistors and inductivities in series are added to the bus lines in order to prevent the higher harmonics stimulated by the communication on the network The information about the termination is used with in the system configuration process, where the placement of an ECU within a car architecture is generated.
   * Attribute-Kind = versionAttribute   */
  public Boolean getEmcFilter();
  /**
   * To improve the EMC behaviour of communication busses common dedicated EMC Filters are used. They suppress frequencies outside the range, which is needed for the communication of the specific bus E.g. some small capacitors in parallel to ground, resistors and inductivities in series are added to the bus lines in order to prevent the higher harmonics stimulated by the communication on the network The information about the termination is used with in the system configuration process, where the placement of an ECU within a car architecture is generated.
   * Attribute-Kind = versionAttribute   */
  public void setEmcFilter(Boolean newValue);
  // reference : communicationTransceiver_termination_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMMUNICATION_TRANSCEIVER_TERMINATION_OWNER = "communicationTransceiver_termination_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: termination
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMMUNICATION_TRANSCEIVER_TERMINATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMMUNICATION_TRANSCEIVER_TERMINATION_OWNER,"ar3x.ecuresourcetemplate.ecuelectronics.BusTermination",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MICommunicationTransceiver.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MICommunicationTransceiver.TERMINATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MICommunicationTransceiver getCommunicationTransceiverTerminationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCommunicationTransceiverTerminationOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MICommunicationTransceiver newValue);
}
