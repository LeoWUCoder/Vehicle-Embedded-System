package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIProcessingUnitSpecialOpcodesEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "ProcessingUnitSpecialOpcodesEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIProcessingUnitSpecialOpcodesEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnitSpecialOpcodesEnumItem",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitSpecialOpcodesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitSpecialOpcodesEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnitSpecialOpcodesEnum newValue);
  // reference : processingUnit_specialOpcodes_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PROCESSING_UNIT_SPECIAL_OPCODES_OWNER = "processingUnit_specialOpcodes_Owner";
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: specialOpcodes
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROCESSING_UNIT_SPECIAL_OPCODES_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROCESSING_UNIT_SPECIAL_OPCODES_OWNER,"ar3x.ecuresourcetemplate.processingunit.ProcessingUnitSpecialOpcodesEnumItem",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.SPECIAL_OPCODES_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit getProcessingUnitSpecialOpcodesOwner();
  public void setProcessingUnitSpecialOpcodesOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit newValue);
}
