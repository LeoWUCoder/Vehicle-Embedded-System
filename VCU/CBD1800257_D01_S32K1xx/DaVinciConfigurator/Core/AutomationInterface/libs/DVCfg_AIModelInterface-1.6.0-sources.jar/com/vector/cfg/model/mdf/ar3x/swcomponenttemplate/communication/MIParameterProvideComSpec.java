package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This meta-class represents the ability to provide an initial value for a calibration parameter. 
 */
public interface MIParameterProvideComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.componentlocalcalprm.MIInitValueAssignment, com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIPPortComSpec
{
  public final static String CLASS_NAME = "ParameterProvideComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIParameterProvideComSpec> mdfGetClass();
}
