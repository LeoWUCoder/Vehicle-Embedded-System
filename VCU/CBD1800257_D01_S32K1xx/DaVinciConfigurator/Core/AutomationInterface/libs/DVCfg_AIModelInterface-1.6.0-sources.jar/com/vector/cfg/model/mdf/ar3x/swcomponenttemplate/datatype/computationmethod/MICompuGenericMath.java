package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This class represents a calculation formula as a simple arithmetical expression.  string f(x): function to calculate the physical value from the binary, control unit internal value. The interpretation proceeds from left to right for operations of the same operation preferences. Operator preferences, such as power before product/quotient before sum/difference before shift left before shift right before logical AND before logical OR are taken into account. Brackets are allowed and should be used in order to exclude interpretation doubt.   For more details refer to ASAM Harmonized Data Objects v1.1 Chapter 9.3.11.  Note that this element is a mixed string since a future variant mechanism  might use placeholdes to represent references to other objects of the metamodel.  As of August 2007 within ASAM there are slightly different syntaxes. One from ASAM-HDO (GenericMath) and the one from SwDataDependency: The difference is mainly between available functions and operators. Nevertheless we use the same class for now.  numeric_expression ::= ( "-"expression ) | ( expression ( "+" | "-" | "*" | "/" | "^") expression )                 expression ::= ( number | variable | numeric_expression | ( "(" expression ")" ) | sinus_statement | cosinus_statement | sqrt_statement ) | expression {white-space}                 sinus_statement ::= "sin" "(" expression ")"                 cosinus_statement ::= "cos" "(" expression ")"                 sqrt_statement ::= "sqrt" "(" expression ")"                 number ::= integer_literal | float_literal                 variable ::= Any valid Object in question                 integer_literal ::= ( "1..9" { "0..9" } ) | ( "0" "x" "0..9a..f" { "0..9a..f" } )                 float_literal ::= ( decimal_digits "."  decimal_digits   exponent_part  ) | ( "." decimal_digits  exponent_part  ) | ( decimal_digits  exponent_part  )                 decimal_digits ::= "0..9" { "0..9" }                 exponent_part ::= "e"  "+" | "-"  decimal_digits                 white-space ::= tabulator | blank | newline | carriage_return | {tabulator | blank | newline | carriage_return }                 tabulator ::= \t                 blank ::= " "                 newline ::= \n                 carriage_return ::= \c
 */
public interface MICompuGenericMath extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIValueByFormula
{
  public final static String CLASS_NAME = "CompuGenericMath";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICompuGenericMath> mdfGetClass();
  // attribute : level generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String LEVEL = "level";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo LEVEL_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,LEVEL,"ar3x.swcomponenttemplate.datatype.computationmethod.CompuGenericMath",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Placeholder to describe an indicator of a language level for the mathematics e.g. INFORMAL, ASAMHDO. May be refined by particular usecases.
   * Attribute-Kind = versionAttribute   */
  public String getLevel();
  /**
   * Placeholder to describe an indicator of a language level for the mathematics e.g. INFORMAL, ASAMHDO. May be refined by particular usecases.
   * Attribute-Kind = versionAttribute   */
  public void setLevel(String newValue);
  // reference : swDataDependency_swDataDependencyFormula_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_DATA_DEPENDENCY_SW_DATA_DEPENDENCY_FORMULA_OWNER = "swDataDependency_swDataDependencyFormula_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swDataDependencyFormula
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_DATA_DEPENDENCY_SW_DATA_DEPENDENCY_FORMULA_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_DATA_DEPENDENCY_SW_DATA_DEPENDENCY_FORMULA_OWNER,"ar3x.swcomponenttemplate.datatype.computationmethod.CompuGenericMath",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency.SW_DATA_DEPENDENCY_FORMULA_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency getSwDataDependencySwDataDependencyFormulaOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwDataDependencySwDataDependencyFormulaOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwDataDependency newValue);
}
