package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * A delegation connector delegates one inner PortPrototype  (a port of a component that is used inside the composition) to a outer PortPrototype of compatible type that belongs directly to the composition (a port that is owned by the composition).
 */
public interface MIDelegationConnectorPrototype extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIConnectorPrototype
{
  public final static String CLASS_NAME = "DelegationConnectorPrototype";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDelegationConnectorPrototype> mdfGetClass();
  // reference : outerPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OUTER_PORT = "outerPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: delegationConnectorPrototype_outerPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OUTER_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OUTER_PORT,"ar3x.swcomponenttemplate.composition.DelegationConnectorPrototype",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.DELEGATION_CONNECTOR_PROTOTYPE_OUTER_PORT_OWNER_RELATION_INFO;}};
  /**
   * The port that is located on the outside of the CompositionType
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef getOuterPort();
  /**
   * The port that is located on the outside of the CompositionType
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setOuterPort(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef newValue);
  // reference : innerPort generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INNER_PORT = "innerPort";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: delegationConnectorPrototype_innerPort_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INNER_PORT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INNER_PORT,"ar3x.swcomponenttemplate.composition.DelegationConnectorPrototype",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort.DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_OWNER_RELATION_INFO;}};
  /**
   * The port that belongs to the ComponentPrototype in the composition 
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort getInnerPort();
  /**
   * The port that belongs to the ComponentPrototype in the composition 
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setInnerPort(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort newValue);
}
