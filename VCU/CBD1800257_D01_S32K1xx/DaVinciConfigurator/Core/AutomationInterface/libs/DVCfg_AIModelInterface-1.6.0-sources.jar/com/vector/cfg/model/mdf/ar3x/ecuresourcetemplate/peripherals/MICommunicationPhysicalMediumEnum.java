package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;
import javax.jmi.model.*;

public enum MICommunicationPhysicalMediumEnum implements javax.jmi.reflect.RefEnum
{
  ELECTRICAL("ELECTRICAL"),
  OPTICAL("OPTICAL"),
  WIRELESS("WIRELESS");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "peripherals" );
    temp.add( "CommunicationPhysicalMediumEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MICommunicationPhysicalMediumEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
