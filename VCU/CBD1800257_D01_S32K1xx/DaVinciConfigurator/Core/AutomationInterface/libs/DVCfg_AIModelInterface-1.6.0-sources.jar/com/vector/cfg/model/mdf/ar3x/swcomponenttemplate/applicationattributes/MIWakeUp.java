package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This attribut indicates wheter the software component reading this value provides dedicated runnables to handle a wake-up call by the IoHwAbstraction layer.
 */
public interface MIWakeUp extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "WakeUp";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIWakeUp> mdfGetClass();
  // reference : ioHwAbstractionServerAnnotation_supportsWakeUpRunnable_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IO_HW_ABSTRACTION_SERVER_ANNOTATION_SUPPORTS_WAKE_UP_RUNNABLE_OWNER = "ioHwAbstractionServerAnnotation_supportsWakeUpRunnable_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: supportsWakeUpRunnable
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IO_HW_ABSTRACTION_SERVER_ANNOTATION_SUPPORTS_WAKE_UP_RUNNABLE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IO_HW_ABSTRACTION_SERVER_ANNOTATION_SUPPORTS_WAKE_UP_RUNNABLE_OWNER,"ar3x.swcomponenttemplate.applicationattributes.WakeUp",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation.SUPPORTS_WAKE_UP_RUNNABLE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation getIoHwAbstractionServerAnnotationSupportsWakeUpRunnableOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setIoHwAbstractionServerAnnotationSupportsWakeUpRunnableOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIIoHwAbstractionServerAnnotation newValue);
}
