package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.specializedswrecordlayoutgroup;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwRecordLayoutGroup extends com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroup, com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects.MISwRecordLayoutGroupContentChild
{
  public final static String CLASS_NAME = "SwRecordLayoutGroup";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwRecordLayoutGroup> mdfGetClass();
}
