package com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIDataConstrRule extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "DataConstrRule";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDataConstrRule> mdfGetClass();
  // reference : dataConstr_dataConstrRule_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_CONSTR_DATA_CONSTR_RULE_OWNER = "dataConstr_dataConstrRule_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: dataConstrRule
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_CONSTR_DATA_CONSTR_RULE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_CONSTR_DATA_CONSTR_RULE_OWNER,"ar3x.commonstructure.globalconstraints.DataConstrRule",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstr.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstr.DATA_CONSTR_RULE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstr getDataConstrDataConstrRuleOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataConstrDataConstrRuleOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIDataConstr newValue);
  // reference : internalConstrs generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INTERNAL_CONSTRS = "internalConstrs";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: dataConstrRule_internalConstrs_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INTERNAL_CONSTRS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INTERNAL_CONSTRS,"ar3x.commonstructure.globalconstraints.DataConstrRule",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIInternalConstrs.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIInternalConstrs.DATA_CONSTR_RULE_INTERNAL_CONSTRS_OWNER_RELATION_INFO;}};
  /**
   * Describes the limitiations applicapble on the internal domain (as opposed to the physical domain).
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIInternalConstrs getInternalConstrs();
  /**
   * Describes the limitiations applicapble on the internal domain (as opposed to the physical domain).
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setInternalConstrs(com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIInternalConstrs newValue);
  // reference : physConstrs generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PHYS_CONSTRS = "physConstrs";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: dataConstrRule_physConstrs_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PHYS_CONSTRS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PHYS_CONSTRS,"ar3x.commonstructure.globalconstraints.DataConstrRule",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIPhysConstrs.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIPhysConstrs.DATA_CONSTR_RULE_PHYS_CONSTRS_OWNER_RELATION_INFO;}};
  /**
   * Describes the limitiations applicapble on the physical domain (as opposed to the internal domain).
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIPhysConstrs getPhysConstrs();
  /**
   * Describes the limitiations applicapble on the physical domain (as opposed to the internal domain).
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPhysConstrs(com.vector.cfg.model.mdf.ar3x.commonstructure.globalconstraints.MIPhysConstrs newValue);
}
