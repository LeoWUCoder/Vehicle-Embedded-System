package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The ECU provides information about an ECU and its internal hardware elements. The described hardware elements are related to some extent to basic software configuration and the AUTOSAR generation process.
 */
public interface MIECU extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElementContainer
{
  public final static String CLASS_NAME = "ECU";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIECU> mdfGetClass();
  // reference : eCUARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String E_CUARREF_REF_TARGETS_OWNER = "eCUARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo E_CUARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(E_CUARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.ECU",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIECUARRef> getECUARRefRefTargetsOwner();
  // reference : ecuAbstraction generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ECU_ABSTRACTION = "ecuAbstraction";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: eCU_ecuAbstraction_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ECU_ABSTRACTION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ECU_ABSTRACTION,"ar3x.ecuresourcetemplate.ECU",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentTypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentTypeARRef.E_CU_ECU_ABSTRACTION_OWNER_RELATION_INFO;}};
  /**
   * Reference to the software component describing the ECU Abstraction software module for this ECU.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentTypeARRef getEcuAbstraction();
  /**
   * Reference to the software component describing the ECU Abstraction software module for this ECU.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEcuAbstraction(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentTypeARRef newValue);
}
