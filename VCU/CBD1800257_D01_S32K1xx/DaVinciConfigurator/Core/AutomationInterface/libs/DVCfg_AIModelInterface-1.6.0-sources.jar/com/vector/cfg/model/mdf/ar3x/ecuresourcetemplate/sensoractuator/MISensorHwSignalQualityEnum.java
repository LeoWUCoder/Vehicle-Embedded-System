package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;
import javax.jmi.model.*;

public enum MISensorHwSignalQualityEnum implements javax.jmi.reflect.RefEnum
{
  RAW("RAW"),
  FILTERED("FILTERED"),
  DEBOUNCED("DEBOUNCED"),
  CODED("CODED");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "sensoractuator" );
    temp.add( "SensorHwSignalQualityEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISensorHwSignalQualityEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
