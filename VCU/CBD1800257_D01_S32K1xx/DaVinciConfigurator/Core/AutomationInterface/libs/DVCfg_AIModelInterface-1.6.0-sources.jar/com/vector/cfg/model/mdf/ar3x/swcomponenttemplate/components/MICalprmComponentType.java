package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MICalprmComponentType extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIComponentType
{
  public final static String CLASS_NAME = "CalprmComponentType";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICalprmComponentType> mdfGetClass();
}
