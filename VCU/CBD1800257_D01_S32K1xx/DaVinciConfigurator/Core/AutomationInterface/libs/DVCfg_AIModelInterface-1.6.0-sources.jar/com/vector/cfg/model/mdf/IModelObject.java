package com.vector.cfg.model.mdf;

import ru.novosoft.mdf.ext.MDFObject;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.IProjectContext;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IModelObject extends MDFObject {

    /**
     * Returns <code>true</code>, if the object was removed from repository, or is invisible in the current active {@link IModelView}.
     *
     * <p>
     * Note: The return value is dependent on the current active thread and the current active <code>IModelView</code> in this thread!
     * </p>
     *
     * @return true, if object were removed or is currently invisible.
     */
    @PublishedMethod
    boolean moIsRemoved();

    /**
     * Returns the immediate parent object.
     *
     * @return the immediate parent object.
     */
    @PublishedMethod
    IModelObject moImmediateComposite();

    /**
     * Returns the corresponding {@link IProjectContext} of this model object.
     * 
     * @return the project context
     */
    @PublishedMethod
    IProjectContext getProjectContext();
}
