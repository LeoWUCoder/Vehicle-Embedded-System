package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The ECU Resource Template provides the element SupportsSecurity storing the information about the supported security mechanism. In the current version of the ECU Resource Template the element SupportsSecurity is optional. A HW Element uses this element if it provides a security mechanism otherwise this element is missing in the description of the HW Element. 
 */
public interface MISupportsSecurity extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SupportsSecurity";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISupportsSecurity> mdfGetClass();
  // reference : hWElement_supportsSecurity_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String H_WELEMENT_SUPPORTS_SECURITY_OWNER = "hWElement_supportsSecurity_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: supportsSecurity
  public static final ru.novosoft.mdf.impl.MDFRelationInfo H_WELEMENT_SUPPORTS_SECURITY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(H_WELEMENT_SUPPORTS_SECURITY_OWNER,"ar3x.ecuresourcetemplate.basicelements.SupportsSecurity",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement.SUPPORTS_SECURITY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement getHWElementSupportsSecurityOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setHWElementSupportsSecurityOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement newValue);
}
