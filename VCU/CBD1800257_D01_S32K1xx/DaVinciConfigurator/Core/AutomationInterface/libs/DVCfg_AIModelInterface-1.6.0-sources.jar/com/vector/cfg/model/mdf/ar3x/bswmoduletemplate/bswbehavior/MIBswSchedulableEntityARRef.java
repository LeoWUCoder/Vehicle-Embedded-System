package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIBswSchedulableEntityARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "BswSchedulableEntityARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBswSchedulableEntityARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.bswmoduletemplate.bswbehavior.BswSchedulableEntityARRef",null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntityTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntityTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntityTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: bswSchedulableEntityARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.bswmoduletemplate.bswbehavior.BswSchedulableEntityARRef",3,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntity.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntity.BSW_SCHEDULABLE_ENTITY_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntity> getRefTargets();
  // reference : bswEvent_startsOnEvent_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_EVENT_STARTS_ON_EVENT_OWNER = "bswEvent_startsOnEvent_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: startsOnEvent
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_EVENT_STARTS_ON_EVENT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_EVENT_STARTS_ON_EVENT_OWNER,"ar3x.bswmoduletemplate.bswbehavior.BswSchedulableEntityARRef",64,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswEvent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswEvent.STARTS_ON_EVENT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswEvent getBswEventStartsOnEventOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswEventStartsOnEventOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswEvent newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntity getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSchedulableEntity newRefTarget);

}
