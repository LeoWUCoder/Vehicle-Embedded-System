package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifes the context the software is whose ExecutionTime is provided.
 */
public interface MISoftwareContext extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SoftwareContext";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISoftwareContext> mdfGetClass();
  // attribute : input generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String INPUT = "input";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo INPUT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,INPUT,"ar3x.commonstructure.resourceconsumption.SoftwareContext",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies the input vector which is used to provide the ExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public String getInput();
  /**
   * Specifies the input vector which is used to provide the ExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public void setInput(String newValue);
  // attribute : state generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String STATE = "state";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo STATE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,STATE,"ar3x.commonstructure.resourceconsumption.SoftwareContext",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies the state the software is in when the ExecutionTime is provided.
   * Attribute-Kind = versionAttribute   */
  public String getState();
  /**
   * Specifies the state the software is in when the ExecutionTime is provided.
   * Attribute-Kind = versionAttribute   */
  public void setState(String newValue);
  // reference : hasSoftwareContext_softwareContext_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String HAS_SOFTWARE_CONTEXT_SOFTWARE_CONTEXT_OWNER = "hasSoftwareContext_softwareContext_Owner";
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: softwareContext
  public static final ru.novosoft.mdf.impl.MDFRelationInfo HAS_SOFTWARE_CONTEXT_SOFTWARE_CONTEXT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(HAS_SOFTWARE_CONTEXT_SOFTWARE_CONTEXT_OWNER,"ar3x.commonstructure.resourceconsumption.SoftwareContext",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasSoftwareContext.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasSoftwareContext.SOFTWARE_CONTEXT_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasSoftwareContext getHasSoftwareContextSoftwareContextOwner();
  public void setHasSoftwareContextSoftwareContextOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasSoftwareContext newValue);
}
