package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview;
import javax.jmi.model.*;

public enum MIBswModuleDescriptionTypesEnum implements javax.jmi.reflect.RefEnum
{
  BSW_MODULE_DESCRIPTION("BSW-MODULE-DESCRIPTION");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "bswoverview" );
    temp.add( "BswModuleDescriptionTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIBswModuleDescriptionTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
