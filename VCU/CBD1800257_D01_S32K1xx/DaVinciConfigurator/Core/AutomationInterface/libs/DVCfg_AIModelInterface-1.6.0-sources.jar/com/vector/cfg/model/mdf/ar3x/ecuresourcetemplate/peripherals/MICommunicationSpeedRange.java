package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Range of communication speed.
 */
public interface MICommunicationSpeedRange extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MICommunicationSpeed
{
  public final static String CLASS_NAME = "CommunicationSpeedRange";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICommunicationSpeedRange> mdfGetClass();
  // attribute : minSpeed generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_SPEED = "minSpeed";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_SPEED_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_SPEED,"ar3x.ecuresourcetemplate.peripherals.CommunicationSpeedRange",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Unit: bits per second
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMinSpeed();
  /**
   * Unit: bits per second
   * Attribute-Kind = versionAttribute   */
  public void setMinSpeed(java.math.BigInteger newValue);
  // attribute : maxSpeed generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_SPEED = "maxSpeed";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_SPEED_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_SPEED,"ar3x.ecuresourcetemplate.peripherals.CommunicationSpeedRange",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Unit: bits per second
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMaxSpeed();
  /**
   * Unit: bits per second
   * Attribute-Kind = versionAttribute   */
  public void setMaxSpeed(java.math.BigInteger newValue);
}
