package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the ExecutionTime which has been gathered using measurement means.
 */
public interface MIMeasuredExecutionTime extends com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime
{
  public final static String CLASS_NAME = "MeasuredExecutionTime";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIMeasuredExecutionTime> mdfGetClass();
  // attribute : averageExecutionTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String AVERAGE_EXECUTION_TIME = "averageExecutionTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo AVERAGE_EXECUTION_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,AVERAGE_EXECUTION_TIME,"ar3x.commonstructure.resourceconsumption.executiontime.MeasuredExecutionTime",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Average MeasuredExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getAverageExecutionTime();
  /**
   * Average MeasuredExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public void setAverageExecutionTime(java.math.BigDecimal newValue);
  // attribute : maximalExecutionTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAXIMAL_EXECUTION_TIME = "maximalExecutionTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAXIMAL_EXECUTION_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAXIMAL_EXECUTION_TIME,"ar3x.commonstructure.resourceconsumption.executiontime.MeasuredExecutionTime",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximum MeasuredExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMaximalExecutionTime();
  /**
   * Maximum MeasuredExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public void setMaximalExecutionTime(java.math.BigDecimal newValue);
  // attribute : minimalExecutionTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MINIMAL_EXECUTION_TIME = "minimalExecutionTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MINIMAL_EXECUTION_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MINIMAL_EXECUTION_TIME,"ar3x.commonstructure.resourceconsumption.executiontime.MeasuredExecutionTime",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minumum MeasuredExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMinimalExecutionTime();
  /**
   * Minumum MeasuredExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public void setMinimalExecutionTime(java.math.BigDecimal newValue);
}
