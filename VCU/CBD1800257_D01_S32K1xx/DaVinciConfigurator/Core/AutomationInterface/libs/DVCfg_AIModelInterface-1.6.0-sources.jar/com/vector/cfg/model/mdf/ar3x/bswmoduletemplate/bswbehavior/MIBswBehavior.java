package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the behavior of a BSW module or a BSW cluster w.r.t. the code entities visible by the BSW Scheduler. It is possible to have several different BswBehaviors referring to the same BswModuleDescription.
 */
public interface MIBswBehavior extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement, com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIHasExclusiveArea
{
  public final static String CLASS_NAME = "BswBehavior";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBswBehavior> mdfGetClass();
  // reference : bswBehaviorARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BSW_BEHAVIOR_ARREF_REF_TARGETS_OWNER = "bswBehaviorARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_BEHAVIOR_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_BEHAVIOR_ARREF_REF_TARGETS_OWNER,"ar3x.bswmoduletemplate.bswbehavior.BswBehavior",3,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehaviorARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehaviorARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehaviorARRef> getBswBehaviorARRefRefTargetsOwner();
  // reference : bswModule generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_MODULE = "bswModule";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswBehavior_bswModule_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE,"ar3x.bswmoduletemplate.bswbehavior.BswBehavior",128,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef.BSW_BEHAVIOR_BSW_MODULE_OWNER_RELATION_INFO;}};
  /**
   * The module specification fulfilled by this behavior.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef getBswModule();
  /**
   * The module specification fulfilled by this behavior.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswModule(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswoverview.MIBswModuleDescriptionARRef newValue);
  // reference : event generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String EVENT = "event";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswBehavior_event_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EVENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EVENT,"ar3x.bswmoduletemplate.bswbehavior.BswBehavior",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswEvent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswEvent.BSW_BEHAVIOR_EVENT_OWNER_RELATION_INFO;}};
  /**
   * An event required by this module behavior.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswEvent> getEvent();
  // reference : entity generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ENTITY = "entity";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswBehavior_entity_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ENTITY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ENTITY,"ar3x.bswmoduletemplate.bswbehavior.BswBehavior",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity.BSW_BEHAVIOR_ENTITY_OWNER_RELATION_INFO;}};
  /**
   * A code entity for which the behavior is described
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntity> getEntity();
}
