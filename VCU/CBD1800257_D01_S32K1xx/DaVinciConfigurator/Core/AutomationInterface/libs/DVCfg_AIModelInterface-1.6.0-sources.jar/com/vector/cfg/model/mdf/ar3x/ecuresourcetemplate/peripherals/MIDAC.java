package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The processing unit writes a digital value to a register of the DAC and the value is converted to an analogue value at a given pin.
 */
public interface MIDAC extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIAnalogueIO
{
  public final static String CLASS_NAME = "DAC";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDAC> mdfGetClass();
}
