package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIComponentPrototypeARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "ComponentPrototypeARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIComponentPrototypeARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: componentPrototypeARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototype.COMPONENT_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototype> getRefTargets();
  // reference : arCalprmRefCalprmElementPrototype_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String AR_CALPRM_REF_CALPRM_ELEMENT_PROTOTYPE_COMPONENT_PROTOTYPE_OWNER = "arCalprmRefCalprmElementPrototype_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo AR_CALPRM_REF_CALPRM_ELEMENT_PROTOTYPE_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(AR_CALPRM_REF_CALPRM_ELEMENT_PROTOTYPE_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MIArCalprmRefCalprmElementPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MIArCalprmRefCalprmElementPrototype.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MIArCalprmRefCalprmElementPrototype getArCalprmRefCalprmElementPrototypeComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setArCalprmRefCalprmElementPrototypeComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MIArCalprmRefCalprmElementPrototype newValue);
  // reference : dataPrototypeRefDataPrototype_compositionComponentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_PROTOTYPE_REF_DATA_PROTOTYPE_COMPOSITION_COMPONENT_PROTOTYPE_OWNER = "dataPrototypeRefDataPrototype_compositionComponentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: compositionComponentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_PROTOTYPE_REF_DATA_PROTOTYPE_COMPOSITION_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_PROTOTYPE_REF_DATA_PROTOTYPE_COMPOSITION_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype.COMPOSITION_COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype getDataPrototypeRefDataPrototypeCompositionComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataPrototypeRefDataPrototypeCompositionComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype newValue);
  // reference : dataPrototypeRefDataPrototype_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DATA_PROTOTYPE_REF_DATA_PROTOTYPE_COMPONENT_PROTOTYPE_OWNER = "dataPrototypeRefDataPrototype_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DATA_PROTOTYPE_REF_DATA_PROTOTYPE_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DATA_PROTOTYPE_REF_DATA_PROTOTYPE_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype getDataPrototypeRefDataPrototypeComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDataPrototypeRefDataPrototypeComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIDataPrototypeRefDataPrototype newValue);
  // reference : recordElementRefRecordElement_compositionComponentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RECORD_ELEMENT_REF_RECORD_ELEMENT_COMPOSITION_COMPONENT_PROTOTYPE_OWNER = "recordElementRefRecordElement_compositionComponentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: compositionComponentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RECORD_ELEMENT_REF_RECORD_ELEMENT_COMPOSITION_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RECORD_ELEMENT_REF_RECORD_ELEMENT_COMPOSITION_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement.COMPOSITION_COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement getRecordElementRefRecordElementCompositionComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRecordElementRefRecordElementCompositionComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement newValue);
  // reference : recordElementRefRecordElement_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RECORD_ELEMENT_REF_RECORD_ELEMENT_COMPONENT_PROTOTYPE_OWNER = "recordElementRefRecordElement_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RECORD_ELEMENT_REF_RECORD_ELEMENT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RECORD_ELEMENT_REF_RECORD_ELEMENT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement getRecordElementRefRecordElementComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRecordElementRefRecordElementComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.measurementproperty.instanceref.MIRecordElementRefRecordElement newValue);
  // reference : assemblyConnectorPrototypeProvider_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_COMPONENT_PROTOTYPE_OWNER = "assemblyConnectorPrototypeProvider_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ASSEMBLY_CONNECTOR_PROTOTYPE_PROVIDER_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider getAssemblyConnectorPrototypeProviderComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setAssemblyConnectorPrototypeProviderComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeProvider newValue);
  // reference : assemblyConnectorPrototypeRequester_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_COMPONENT_PROTOTYPE_OWNER = "assemblyConnectorPrototypeRequester_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ASSEMBLY_CONNECTOR_PROTOTYPE_REQUESTER_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester getAssemblyConnectorPrototypeRequesterComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setAssemblyConnectorPrototypeRequesterComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIAssemblyConnectorPrototypeRequester newValue);
  // reference : delegationConnectorPrototypeInnerPort_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_COMPONENT_PROTOTYPE_OWNER = "delegationConnectorPrototypeInnerPort_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DELEGATION_CONNECTOR_PROTOTYPE_INNER_PORT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort getDelegationConnectorPrototypeInnerPortComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setDelegationConnectorPrototypeInnerPortComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIDelegationConnectorPrototypeInnerPort newValue);
  // reference : serviceConnectorPrototypeApplicationPort_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_COMPONENT_PROTOTYPE_OWNER = "serviceConnectorPrototypeApplicationPort_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort getServiceConnectorPrototypeApplicationPortComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setServiceConnectorPrototypeApplicationPortComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref.MIServiceConnectorPrototypeApplicationPort newValue);
  // reference : portGroupInnerGroup_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_GROUP_INNER_GROUP_COMPONENT_PROTOTYPE_OWNER = "portGroupInnerGroup_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_GROUP_INNER_GROUP_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_GROUP_INNER_GROUP_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup getPortGroupInnerGroupComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortGroupInnerGroupComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup newValue);
  // reference : calprmAccessCalprmElementPrototype_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CALPRM_ACCESS_CALPRM_ELEMENT_PROTOTYPE_COMPONENT_PROTOTYPE_OWNER = "calprmAccessCalprmElementPrototype_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CALPRM_ACCESS_CALPRM_ELEMENT_PROTOTYPE_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CALPRM_ACCESS_CALPRM_ELEMENT_PROTOTYPE_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MICalprmAccessCalprmElementPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MICalprmAccessCalprmElementPrototype.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MICalprmAccessCalprmElementPrototype getCalprmAccessCalprmElementPrototypeComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCalprmAccessCalprmElementPrototypeComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.measurementandcalibration.characteristic.instanceref.MICalprmAccessCalprmElementPrototype newValue);
  // reference : clientServerToSignalGroupMappingMappedOperation_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CLIENT_SERVER_TO_SIGNAL_GROUP_MAPPING_MAPPED_OPERATION_COMPONENT_PROTOTYPE_OWNER = "clientServerToSignalGroupMappingMappedOperation_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CLIENT_SERVER_TO_SIGNAL_GROUP_MAPPING_MAPPED_OPERATION_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CLIENT_SERVER_TO_SIGNAL_GROUP_MAPPING_MAPPED_OPERATION_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MIClientServerToSignalGroupMappingMappedOperation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MIClientServerToSignalGroupMappingMappedOperation.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MIClientServerToSignalGroupMappingMappedOperation getClientServerToSignalGroupMappingMappedOperationComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setClientServerToSignalGroupMappingMappedOperationComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MIClientServerToSignalGroupMappingMappedOperation newValue);
  // reference : senderReceiverToSignalGroupMappingDataElement_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SENDER_RECEIVER_TO_SIGNAL_GROUP_MAPPING_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER = "senderReceiverToSignalGroupMappingDataElement_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SENDER_RECEIVER_TO_SIGNAL_GROUP_MAPPING_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SENDER_RECEIVER_TO_SIGNAL_GROUP_MAPPING_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalGroupMappingDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalGroupMappingDataElement.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalGroupMappingDataElement getSenderReceiverToSignalGroupMappingDataElementComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSenderReceiverToSignalGroupMappingDataElementComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalGroupMappingDataElement newValue);
  // reference : senderReceiverToSignalMappingDataElement_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SENDER_RECEIVER_TO_SIGNAL_MAPPING_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER = "senderReceiverToSignalMappingDataElement_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SENDER_RECEIVER_TO_SIGNAL_MAPPING_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SENDER_RECEIVER_TO_SIGNAL_MAPPING_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalMappingDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalMappingDataElement.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalMappingDataElement getSenderReceiverToSignalMappingDataElementComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSenderReceiverToSignalMappingDataElementComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.datamapping.instanceref.MISenderReceiverToSignalMappingDataElement newValue);
  // reference : swcToSwcSignalDataElement_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SWC_TO_SWC_SIGNAL_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER = "swcToSwcSignalDataElement_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SWC_TO_SWC_SIGNAL_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SWC_TO_SWC_SIGNAL_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcSignalDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcSignalDataElement.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcSignalDataElement getSwcToSwcSignalDataElementComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwcToSwcSignalDataElementComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcSignalDataElement newValue);
  // reference : swcToSwcOperationArgumentsOperation_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SWC_TO_SWC_OPERATION_ARGUMENTS_OPERATION_COMPONENT_PROTOTYPE_OWNER = "swcToSwcOperationArgumentsOperation_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SWC_TO_SWC_OPERATION_ARGUMENTS_OPERATION_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SWC_TO_SWC_OPERATION_ARGUMENTS_OPERATION_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcOperationArgumentsOperation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcOperationArgumentsOperation.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcOperationArgumentsOperation getSwcToSwcOperationArgumentsOperationComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwcToSwcOperationArgumentsOperationComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.signalpaths.instanceref.MISwcToSwcOperationArgumentsOperation newValue);
  // reference : swCompToEcuMappingComponent_targetComponentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_COMP_TO_ECU_MAPPING_COMPONENT_TARGET_COMPONENT_PROTOTYPE_OWNER = "swCompToEcuMappingComponent_targetComponentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: targetComponentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_COMP_TO_ECU_MAPPING_COMPONENT_TARGET_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_COMP_TO_ECU_MAPPING_COMPONENT_TARGET_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToEcuMappingComponent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToEcuMappingComponent.TARGET_COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToEcuMappingComponent getSwCompToEcuMappingComponentTargetComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCompToEcuMappingComponentTargetComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToEcuMappingComponent newValue);
  // reference : swCompToEcuMappingComponent_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_COMP_TO_ECU_MAPPING_COMPONENT_COMPONENT_PROTOTYPE_OWNER = "swCompToEcuMappingComponent_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_COMP_TO_ECU_MAPPING_COMPONENT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_COMP_TO_ECU_MAPPING_COMPONENT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToEcuMappingComponent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToEcuMappingComponent.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToEcuMappingComponent getSwCompToEcuMappingComponentComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCompToEcuMappingComponentComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToEcuMappingComponent newValue);
  // reference : componentClusteringClusteredComponent_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_CLUSTERING_CLUSTERED_COMPONENT_COMPONENT_PROTOTYPE_OWNER = "componentClusteringClusteredComponent_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_CLUSTERING_CLUSTERED_COMPONENT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_CLUSTERING_CLUSTERED_COMPONENT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentClusteringClusteredComponent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentClusteringClusteredComponent.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentClusteringClusteredComponent getComponentClusteringClusteredComponentComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComponentClusteringClusteredComponentComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentClusteringClusteredComponent newValue);
  // reference : componentClusteringClusteredComponent_clusteredComponent_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_CLUSTERING_CLUSTERED_COMPONENT_CLUSTERED_COMPONENT_OWNER = "componentClusteringClusteredComponent_clusteredComponent_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: clusteredComponent
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_CLUSTERING_CLUSTERED_COMPONENT_CLUSTERED_COMPONENT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_CLUSTERING_CLUSTERED_COMPONENT_CLUSTERED_COMPONENT_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentClusteringClusteredComponent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentClusteringClusteredComponent.CLUSTERED_COMPONENT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentClusteringClusteredComponent getComponentClusteringClusteredComponentClusteredComponentOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComponentClusteringClusteredComponentClusteredComponentOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentClusteringClusteredComponent newValue);
  // reference : componentSeparationSeparatedComponent_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_SEPARATION_SEPARATED_COMPONENT_COMPONENT_PROTOTYPE_OWNER = "componentSeparationSeparatedComponent_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_SEPARATION_SEPARATED_COMPONENT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_SEPARATION_SEPARATED_COMPONENT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentSeparationSeparatedComponent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentSeparationSeparatedComponent.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentSeparationSeparatedComponent getComponentSeparationSeparatedComponentComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComponentSeparationSeparatedComponentComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentSeparationSeparatedComponent newValue);
  // reference : componentSeparationSeparatedComponent_separatedComponent_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_SEPARATION_SEPARATED_COMPONENT_SEPARATED_COMPONENT_OWNER = "componentSeparationSeparatedComponent_separatedComponent_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: separatedComponent
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_SEPARATION_SEPARATED_COMPONENT_SEPARATED_COMPONENT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_SEPARATION_SEPARATED_COMPONENT_SEPARATED_COMPONENT_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentSeparationSeparatedComponent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentSeparationSeparatedComponent.SEPARATED_COMPONENT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentSeparationSeparatedComponent getComponentSeparationSeparatedComponentSeparatedComponentOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setComponentSeparationSeparatedComponentSeparatedComponentOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIComponentSeparationSeparatedComponent newValue);
  // reference : swcToEcuMappingConstraintComponent_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SWC_TO_ECU_MAPPING_CONSTRAINT_COMPONENT_COMPONENT_PROTOTYPE_OWNER = "swcToEcuMappingConstraintComponent_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SWC_TO_ECU_MAPPING_CONSTRAINT_COMPONENT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SWC_TO_ECU_MAPPING_CONSTRAINT_COMPONENT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwcToEcuMappingConstraintComponent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwcToEcuMappingConstraintComponent.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwcToEcuMappingConstraintComponent getSwcToEcuMappingConstraintComponentComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwcToEcuMappingConstraintComponentComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwcToEcuMappingConstraintComponent newValue);
  // reference : swcToEcuMappingConstraintComponent_targetComponentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SWC_TO_ECU_MAPPING_CONSTRAINT_COMPONENT_TARGET_COMPONENT_PROTOTYPE_OWNER = "swcToEcuMappingConstraintComponent_targetComponentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: targetComponentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SWC_TO_ECU_MAPPING_CONSTRAINT_COMPONENT_TARGET_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SWC_TO_ECU_MAPPING_CONSTRAINT_COMPONENT_TARGET_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwcToEcuMappingConstraintComponent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwcToEcuMappingConstraintComponent.TARGET_COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwcToEcuMappingConstraintComponent getSwcToEcuMappingConstraintComponentTargetComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwcToEcuMappingConstraintComponentTargetComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwcToEcuMappingConstraintComponent newValue);
  // reference : pncMappingVfc_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PNC_MAPPING_VFC_COMPONENT_PROTOTYPE_OWNER = "pncMappingVfc_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PNC_MAPPING_VFC_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PNC_MAPPING_VFC_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIPncMappingVfc.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIPncMappingVfc.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIPncMappingVfc getPncMappingVfcComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPncMappingVfcComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIPncMappingVfc newValue);
  // reference : swCompToImplMappingComponent_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_COMP_TO_IMPL_MAPPING_COMPONENT_COMPONENT_PROTOTYPE_OWNER = "swCompToImplMappingComponent_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_COMP_TO_IMPL_MAPPING_COMPONENT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_COMP_TO_IMPL_MAPPING_COMPONENT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToImplMappingComponent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToImplMappingComponent.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToImplMappingComponent getSwCompToImplMappingComponentComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCompToImplMappingComponentComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToImplMappingComponent newValue);
  // reference : swCompToImplMappingComponent_targetComponentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_COMP_TO_IMPL_MAPPING_COMPONENT_TARGET_COMPONENT_PROTOTYPE_OWNER = "swCompToImplMappingComponent_targetComponentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: targetComponentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_COMP_TO_IMPL_MAPPING_COMPONENT_TARGET_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_COMP_TO_IMPL_MAPPING_COMPONENT_TARGET_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToImplMappingComponent.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToImplMappingComponent.TARGET_COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToImplMappingComponent getSwCompToImplMappingComponentTargetComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwCompToImplMappingComponentTargetComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MISwCompToImplMappingComponent newValue);
  // reference : endToEndProtectionDataElementPrototypeDataElement_componentPrototype_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String END_TO_END_PROTECTION_DATA_ELEMENT_PROTOTYPE_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER = "endToEndProtectionDataElementPrototypeDataElement_componentPrototype_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: componentPrototype
  public static final ru.novosoft.mdf.impl.MDFRelationInfo END_TO_END_PROTECTION_DATA_ELEMENT_PROTOTYPE_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(END_TO_END_PROTECTION_DATA_ELEMENT_PROTOTYPE_DATA_ELEMENT_COMPONENT_PROTOTYPE_OWNER,"ar3x.swcomponenttemplate.composition.ComponentPrototypeARRef",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.endtoendprotection.MIEndToEndProtectionDataElementPrototypeDataElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.endtoendprotection.MIEndToEndProtectionDataElementPrototypeDataElement.COMPONENT_PROTOTYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.endtoendprotection.MIEndToEndProtectionDataElementPrototypeDataElement getEndToEndProtectionDataElementPrototypeDataElementComponentPrototypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEndToEndProtectionDataElementPrototypeDataElementComponentPrototypeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.endtoendprotection.MIEndToEndProtectionDataElementPrototypeDataElement newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototype getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototype newRefTarget);

}
