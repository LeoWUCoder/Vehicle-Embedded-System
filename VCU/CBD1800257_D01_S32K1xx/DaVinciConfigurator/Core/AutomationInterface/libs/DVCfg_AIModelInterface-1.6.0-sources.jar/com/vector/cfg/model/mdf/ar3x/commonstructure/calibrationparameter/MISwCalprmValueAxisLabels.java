package com.vector.cfg.model.mdf.ar3x.commonstructure.calibrationparameter;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This element is used to record textual descriptions of axis values and is contained in ASAP1.4, for reasons of backward compatibility.  In new systems, the application should be implemented via conversion formulae.
 */
public interface MISwCalprmValueAxisLabels extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "SwCalprmValueAxisLabels";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwCalprmValueAxisLabels> mdfGetClass();
}
