package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;
import javax.jmi.model.*;

public enum MIComponentTypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  APPLICATION_SOFTWARE_COMPONENT_TYPE("APPLICATION-SOFTWARE-COMPONENT-TYPE"),
  ATOMIC_SOFTWARE_COMPONENT_TYPE("ATOMIC-SOFTWARE-COMPONENT-TYPE"),
  CALPRM_COMPONENT_TYPE("CALPRM-COMPONENT-TYPE"),
  COMPLEX_DEVICE_DRIVER_COMPONENT_TYPE("COMPLEX-DEVICE-DRIVER-COMPONENT-TYPE"),
  COMPONENT_TYPE("COMPONENT-TYPE"),
  COMPOSITION_TYPE("COMPOSITION-TYPE"),
  ECU_ABSTRACTION_COMPONENT_TYPE("ECU-ABSTRACTION-COMPONENT-TYPE"),
  NV_BLOCK_SW_COMPONENT_TYPE("NV-BLOCK-SW-COMPONENT-TYPE"),
  SENSOR_ACTUATOR_SOFTWARE_COMPONENT_TYPE("SENSOR-ACTUATOR-SOFTWARE-COMPONENT-TYPE"),
  SERVICE_COMPONENT_TYPE("SERVICE-COMPONENT-TYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "components" );
    temp.add( "ComponentTypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIComponentTypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
