package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * This meta-class represents the ability to define an initial value for a calibration parameter. 
 */
public interface MIParameterRequireComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIRPortComSpec, com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.swcinternalbehavior.componentlocalcalprm.MIInitValueAssignment
{
  public final static String CLASS_NAME = "ParameterRequireComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIParameterRequireComSpec> mdfGetClass();
}
