package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes one non-volatile memory segment.
 */
public interface MIProvidedNVMemorySegment extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegment
{
  public final static String CLASS_NAME = "ProvidedNVMemorySegment";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIProvidedNVMemorySegment> mdfGetClass();
  // attribute : segmentSizeWrite generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SEGMENT_SIZE_WRITE = "segmentSizeWrite";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SEGMENT_SIZE_WRITE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SEGMENT_SIZE_WRITE,"ar3x.ecuresourcetemplate.memory.ProvidedNVMemorySegment",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Some memory types have not the same segment size as in the case when data is written to the memory. For example, a specific flash memory you must write 128 bytes once even if the segment size is 16 kBytes. Unit: Byte
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSegmentSizeWrite();
  /**
   * Some memory types have not the same segment size as in the case when data is written to the memory. For example, a specific flash memory you must write 128 bytes once even if the segment size is 16 kBytes. Unit: Byte
   * Attribute-Kind = versionAttribute   */
  public void setSegmentSizeWrite(java.math.BigInteger newValue);
  // attribute : segmentSizeErase generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SEGMENT_SIZE_ERASE = "segmentSizeErase";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SEGMENT_SIZE_ERASE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SEGMENT_SIZE_ERASE,"ar3x.ecuresourcetemplate.memory.ProvidedNVMemorySegment",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * For an erasable memory it's usually the same size of the segment as for the segment size which can be erased at a time. If the size of an erasable segment is different shall the size of the erasable segment be entered in the table. Unit: Byte
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSegmentSizeErase();
  /**
   * For an erasable memory it's usually the same size of the segment as for the segment size which can be erased at a time. If the size of an erasable segment is different shall the size of the erasable segment be entered in the table. Unit: Byte
   * Attribute-Kind = versionAttribute   */
  public void setSegmentSizeErase(java.math.BigInteger newValue);
  // attribute : dataRetention generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DATA_RETENTION = "dataRetention";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DATA_RETENTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DATA_RETENTION,"ar3x.ecuresourcetemplate.memory.ProvidedNVMemorySegment",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Data retention time is the time between programming a sample of non-volatile memory and the observation of a prescribed failure rate when verifying the programmed pattern. The time is dependent on the chosen technology for the integrated memory cell. Unit: Years
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getDataRetention();
  /**
   * Data retention time is the time between programming a sample of non-volatile memory and the observation of a prescribed failure rate when verifying the programmed pattern. The time is dependent on the chosen technology for the integrated memory cell. Unit: Years
   * Attribute-Kind = versionAttribute   */
  public void setDataRetention(java.math.BigDecimal newValue);
  // attribute : dataEndurance generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DATA_ENDURANCE = "dataEndurance";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DATA_ENDURANCE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DATA_ENDURANCE,"ar3x.ecuresourcetemplate.memory.ProvidedNVMemorySegment",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Program and erase cycles are a stress to the memory cell, therefore endurance is characterised by the number of erase/program cycles the memory can survive exceeding the prescribed failure rate. Unit: No of cycles.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getDataEndurance();
  /**
   * Program and erase cycles are a stress to the memory cell, therefore endurance is characterised by the number of erase/program cycles the memory can survive exceeding the prescribed failure rate. Unit: No of cycles.
   * Attribute-Kind = versionAttribute   */
  public void setDataEndurance(java.math.BigInteger newValue);
  // attribute : marginReadAvailable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MARGIN_READ_AVAILABLE = "marginReadAvailable";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MARGIN_READ_AVAILABLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MARGIN_READ_AVAILABLE,"ar3x.ecuresourcetemplate.memory.ProvidedNVMemorySegment",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Additional to verify, all data are read back with a different set-up of the threshold of the sense amplifier of the programmed cell. With this method besides the logical correctness, the sufficient amount of electrical charges, which represents the stored data is checked. Furthermore the content of the memory and the correctness and the quality of the programming tools can be verified. Performing the margin read allow the prediction of the data retention. The feature of margin read is a characteristic of a memory, which is not available at all devices. Margin read is available for flash technology only.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMarginReadAvailable();
  /**
   * Additional to verify, all data are read back with a different set-up of the threshold of the sense amplifier of the programmed cell. With this method besides the logical correctness, the sufficient amount of electrical charges, which represents the stored data is checked. Furthermore the content of the memory and the correctness and the quality of the programming tools can be verified. Performing the margin read allow the prediction of the data retention. The feature of margin read is a characteristic of a memory, which is not available at all devices. Margin read is available for flash technology only.
   * Attribute-Kind = versionAttribute   */
  public void setMarginReadAvailable(Boolean newValue);
}
