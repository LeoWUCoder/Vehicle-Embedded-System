package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Defines the particular instantiation of a referenced <swClass> .
 */
public interface MISwClassInstance extends com.vector.cfg.model.mdf.model.autosar.base.MIARElement, com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MIHasSwDataDefProps
{
  public final static String CLASS_NAME = "SwClassInstance";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwClassInstance> mdfGetClass();
  // reference : swClassAttrInstanceImpl generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_CLASS_ATTR_INSTANCE_IMPL = "swClassAttrInstanceImpl";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: swClassInstance_swClassAttrInstanceImpl_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_CLASS_ATTR_INSTANCE_IMPL_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_CLASS_ATTR_INSTANCE_IMPL,"ar3x.commonstructure.swclass.SwClassInstance",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttrInstanceImpl.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttrInstanceImpl.SW_CLASS_INSTANCE_SW_CLASS_ATTR_INSTANCE_IMPL_OWNER_RELATION_INFO;}};
  /**
   * <swClassAttrInstanceImpl> is used to create an instance from a model (Models are defined with SW-CLASS) where some specifications shall be changed / overwritten. This implementation will then be a instance specific implementation (Classes are usually only implemented under <swClassImpls>).
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttrInstanceImpl getSwClassAttrInstanceImpl();
  /**
   * <swClassAttrInstanceImpl> is used to create an instance from a model (Models are defined with SW-CLASS) where some specifications shall be changed / overwritten. This implementation will then be a instance specific implementation (Classes are usually only implemented under <swClassImpls>).
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwClassAttrInstanceImpl(com.vector.cfg.model.mdf.ar3x.commonstructure.swclass.MISwClassAttrInstanceImpl newValue);
}
