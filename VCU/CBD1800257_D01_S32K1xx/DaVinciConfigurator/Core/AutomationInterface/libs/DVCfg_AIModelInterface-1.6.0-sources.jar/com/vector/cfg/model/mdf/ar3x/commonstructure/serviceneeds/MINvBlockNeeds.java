package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the abstract needs on the configuration of a single Nv block or a PortPrototype typed by a NvDataInterface. 
 */
public interface MINvBlockNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "NvBlockNeeds";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MINvBlockNeeds> mdfGetClass();
  // attribute : nDataSets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String N_DATA_SETS = "nDataSets";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo N_DATA_SETS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,N_DATA_SETS,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * number of data sets to be provided by the NVRAM manager for this block
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getNDataSets();
  /**
   * number of data sets to be provided by the NVRAM manager for this block
   * Attribute-Kind = versionAttribute   */
  public void setNDataSets(java.math.BigInteger newValue);
  // attribute : ramBlockStatusControl generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RAM_BLOCK_STATUS_CONTROL = "ramBlockStatusControl";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RAM_BLOCK_STATUS_CONTROL_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RAM_BLOCK_STATUS_CONTROL,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.nvblockcomponent.MIRamBlockStatusControlEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This attribute defines how the management of the ramBlock status is controlled. 
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.nvblockcomponent.MIRamBlockStatusControlEnum getRamBlockStatusControl();
  /**
   * This attribute defines how the management of the ramBlock status is controlled. 
   * Attribute-Kind = versionAttribute   */
  public void setRamBlockStatusControl(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.nvblockcomponent.MIRamBlockStatusControlEnum newValue);
  // attribute : readonly generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String READONLY = "readonly";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo READONLY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,READONLY,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * true: data of this block are write protected for normal operation (but protection can be disabled) false: no restriction
   * Attribute-Kind = versionAttribute   */
  public Boolean getReadonly();
  /**
   * true: data of this block are write protected for normal operation (but protection can be disabled) false: no restriction
   * Attribute-Kind = versionAttribute   */
  public void setReadonly(Boolean newValue);
  // attribute : reliability generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RELIABILITY = "reliability";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RELIABILITY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RELIABILITY,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MINvBlockNeedsReliabilityEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Reliability against data loss on the non-volatile medium.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MINvBlockNeedsReliabilityEnum getReliability();
  /**
   * Reliability against data loss on the non-volatile medium.
   * Attribute-Kind = versionAttribute   */
  public void setReliability(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MINvBlockNeedsReliabilityEnum newValue);
  // attribute : resistantToChangedSw generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESISTANT_TO_CHANGED_SW = "resistantToChangedSw";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESISTANT_TO_CHANGED_SW_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESISTANT_TO_CHANGED_SW,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines whether an Nv block shall be treated resistant to configuration changes (true) or not (false). For details how to handle initialization in the latter case, refer to the NVRAM specification.
   * Attribute-Kind = versionAttribute   */
  public Boolean getResistantToChangedSw();
  /**
   * Defines whether an Nv block shall be treated resistant to configuration changes (true) or not (false). For details how to handle initialization in the latter case, refer to the NVRAM specification.
   * Attribute-Kind = versionAttribute   */
  public void setResistantToChangedSw(Boolean newValue);
  // attribute : restoreAtStart generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESTORE_AT_START = "restoreAtStart";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESTORE_AT_START_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESTORE_AT_START,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines whether the associated RAM mirror block shall be implictly restored during startup by the basic SW or not. Only relevant if a RAM mirror block (PerInstanceMemory) is associated with this port.
   * Attribute-Kind = versionAttribute   */
  public Boolean getRestoreAtStart();
  /**
   * Defines whether the associated RAM mirror block shall be implictly restored during startup by the basic SW or not. Only relevant if a RAM mirror block (PerInstanceMemory) is associated with this port.
   * Attribute-Kind = versionAttribute   */
  public void setRestoreAtStart(Boolean newValue);
  // attribute : writeOnlyOnce generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String WRITE_ONLY_ONCE = "writeOnlyOnce";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo WRITE_ONLY_ONCE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,WRITE_ONLY_ONCE,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines write protection after first write: true: This block is prevented from being changed/erased or being replaced with the default ROM data after first initialization by the SWC. false: No such restriction.
   * Attribute-Kind = versionAttribute   */
  public Boolean getWriteOnlyOnce();
  /**
   * Defines write protection after first write: true: This block is prevented from being changed/erased or being replaced with the default ROM data after first initialization by the SWC. false: No such restriction.
   * Attribute-Kind = versionAttribute   */
  public void setWriteOnlyOnce(Boolean newValue);
  // attribute : writingFrequency generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String WRITING_FREQUENCY = "writingFrequency";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo WRITING_FREQUENCY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,WRITING_FREQUENCY,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Provides the amount of updates to this block from the application point of view. It has to be provided in "number of write access per year".
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getWritingFrequency();
  /**
   * Provides the amount of updates to this block from the application point of view. It has to be provided in "number of write access per year".
   * Attribute-Kind = versionAttribute   */
  public void setWritingFrequency(java.math.BigInteger newValue);
  // attribute : writingPriority generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String WRITING_PRIORITY = "writingPriority";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo WRITING_PRIORITY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,WRITING_PRIORITY,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MINvBlockNeedsWritingPriorityEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Requires the priority of writing this block in case of concurrent requests to write other blocks.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MINvBlockNeedsWritingPriorityEnum getWritingPriority();
  /**
   * Requires the priority of writing this block in case of concurrent requests to write other blocks.
   * Attribute-Kind = versionAttribute   */
  public void setWritingPriority(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MINvBlockNeedsWritingPriorityEnum newValue);
  // attribute : storeAtShutdown generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String STORE_AT_SHUTDOWN = "storeAtShutdown";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo STORE_AT_SHUTDOWN_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,STORE_AT_SHUTDOWN,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines whether or not the associated RAM mirror block shall be implicitly stored during shutdown by the basic SW. 
   * Attribute-Kind = versionAttribute   */
  public Boolean getStoreAtShutdown();
  /**
   * Defines whether or not the associated RAM mirror block shall be implicitly stored during shutdown by the basic SW. 
   * Attribute-Kind = versionAttribute   */
  public void setStoreAtShutdown(Boolean newValue);
  // reference : nvBlockDescriptor_nvBlockNeeds_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String NV_BLOCK_DESCRIPTOR_NV_BLOCK_NEEDS_OWNER = "nvBlockDescriptor_nvBlockNeeds_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: nvBlockNeeds
  public static final ru.novosoft.mdf.impl.MDFRelationInfo NV_BLOCK_DESCRIPTOR_NV_BLOCK_NEEDS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(NV_BLOCK_DESCRIPTOR_NV_BLOCK_NEEDS_OWNER,"ar3x.commonstructure.serviceneeds.NvBlockNeeds",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.nvblockcomponent.MINvBlockDescriptor.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.nvblockcomponent.MINvBlockDescriptor.NV_BLOCK_NEEDS_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.nvblockcomponent.MINvBlockDescriptor getNvBlockDescriptorNvBlockNeedsOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setNvBlockDescriptorNvBlockNeedsOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.nvblockcomponent.MINvBlockDescriptor newValue);
}
