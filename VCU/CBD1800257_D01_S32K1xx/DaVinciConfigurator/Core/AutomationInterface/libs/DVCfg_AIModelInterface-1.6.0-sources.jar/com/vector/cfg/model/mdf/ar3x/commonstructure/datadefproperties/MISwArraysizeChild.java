package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwArraysizeChild extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "SwArraysizeChild";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwArraysizeChild> mdfGetClass();
  // reference : swArraysize_swArraysizeChildren_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_ARRAYSIZE_SW_ARRAYSIZE_CHILDREN_OWNER = "swArraysize_swArraysizeChildren_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swArraysizeChildren
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_ARRAYSIZE_SW_ARRAYSIZE_CHILDREN_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_ARRAYSIZE_SW_ARRAYSIZE_CHILDREN_OWNER,"ar3x.commonstructure.datadefproperties.SwArraysizeChild",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize.SW_ARRAYSIZE_CHILDREN_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize getSwArraysizeSwArraysizeChildrenOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwArraysizeSwArraysizeChildrenOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwArraysize newValue);
}
