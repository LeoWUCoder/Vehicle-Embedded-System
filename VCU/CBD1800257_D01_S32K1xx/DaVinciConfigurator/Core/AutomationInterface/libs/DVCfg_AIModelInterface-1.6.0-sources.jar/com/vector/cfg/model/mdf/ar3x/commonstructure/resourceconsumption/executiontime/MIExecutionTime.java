package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Base class for several means how to describe the ExecutionTime of software. The required context information is provided through this class.
 */
public interface MIExecutionTime extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable, com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasHardwareConfiguration, com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIHasSoftwareContext
{
  public final static String CLASS_NAME = "ExecutionTime";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIExecutionTime> mdfGetClass();
  // reference : resourceConsumption_executionTime_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RESOURCE_CONSUMPTION_EXECUTION_TIME_OWNER = "resourceConsumption_executionTime_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: executionTime
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RESOURCE_CONSUMPTION_EXECUTION_TIME_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RESOURCE_CONSUMPTION_EXECUTION_TIME_OWNER,"ar3x.commonstructure.resourceconsumption.executiontime.ExecutionTime",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption.EXECUTION_TIME_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption getResourceConsumptionExecutionTimeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setResourceConsumptionExecutionTimeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MIResourceConsumption newValue);
  // reference : exclusiveArea generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String EXCLUSIVE_AREA = "exclusiveArea";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: executionTime_exclusiveArea_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXCLUSIVE_AREA_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXCLUSIVE_AREA,"ar3x.commonstructure.resourceconsumption.executiontime.ExecutionTime",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaARRef.EXECUTION_TIME_EXCLUSIVE_AREA_OWNER_RELATION_INFO;}};
  /**
   * Reference to the ExclusiveArea this execution time is provided for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaARRef getExclusiveArea();
  /**
   * Reference to the ExclusiveArea this execution time is provided for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setExclusiveArea(com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaARRef newValue);
  // reference : runnable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String RUNNABLE = "runnable";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: executionTime_runnable_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo RUNNABLE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(RUNNABLE,"ar3x.commonstructure.resourceconsumption.executiontime.ExecutionTime",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef.EXECUTION_TIME_RUNNABLE_OWNER_RELATION_INFO;}};
  /**
   * Reference to the runnable this execution time is provided for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef getRunnable();
  /**
   * Reference to the runnable this execution time is provided for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setRunnable(com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntityARRef newValue);
  // reference : externalLibrary generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String EXTERNAL_LIBRARY = "externalLibrary";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: executionTime_externalLibrary_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo EXTERNAL_LIBRARY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(EXTERNAL_LIBRARY,"ar3x.commonstructure.resourceconsumption.executiontime.ExecutionTime",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnLibraryARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnLibraryARRef.EXECUTION_TIME_EXTERNAL_LIBRARY_OWNER_RELATION_INFO;}};
  /**
   * If this dependency is specified, the execution time of the library code is included in the execution time data for the runnable.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.implementation.MIDependencyOnLibraryARRef> getExternalLibrary();
  // reference : ecu generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ECU = "ecu";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: executionTime_ecu_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ECU_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ECU,"ar3x.commonstructure.resourceconsumption.executiontime.ExecutionTime",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIECUPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIECUPrototype.EXECUTION_TIME_ECU_OWNER_RELATION_INFO;}};
  /**
   * Provides information on a ECUPrototype based on one ECU type.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIECUPrototype getEcu();
  /**
   * Provides information on a ECUPrototype based on one ECU type.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setEcu(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIECUPrototype newValue);
  // reference : memorySectionLocation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String MEMORY_SECTION_LOCATION = "memorySectionLocation";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: executionTime_memorySectionLocation_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo MEMORY_SECTION_LOCATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(MEMORY_SECTION_LOCATION,"ar3x.commonstructure.resourceconsumption.executiontime.ExecutionTime",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIMemorySectionLocation.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIMemorySectionLocation.EXECUTION_TIME_MEMORY_SECTION_LOCATION_OWNER_RELATION_INFO;}};
  /**
   * Provides information on the MemorySectionLocation which is involved in the ExecutionTime description.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIMemorySectionLocation> getMemorySectionLocation();
}
