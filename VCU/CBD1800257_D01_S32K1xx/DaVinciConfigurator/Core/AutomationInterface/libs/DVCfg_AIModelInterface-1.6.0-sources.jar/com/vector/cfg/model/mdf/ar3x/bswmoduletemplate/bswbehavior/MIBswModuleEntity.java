package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the smallest code fragment which can be described for a BSW module or cluster within AUTOSAR.
 */
public interface MIBswModuleEntity extends com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExecutableEntity
{
  public final static String CLASS_NAME = "BswModuleEntity";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBswModuleEntity> mdfGetClass();
  // reference : bswModuleEntityARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BSW_MODULE_ENTITY_ARREF_REF_TARGETS_OWNER = "bswModuleEntityARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_MODULE_ENTITY_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_MODULE_ENTITY_ARREF_REF_TARGETS_OWNER,"ar3x.bswmoduletemplate.bswbehavior.BswModuleEntity",3,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntityARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntityARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswModuleEntityARRef> getBswModuleEntityARRefRefTargetsOwner();
  // reference : bswBehavior_entity_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BSW_BEHAVIOR_ENTITY_OWNER = "bswBehavior_entity_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: entity
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BSW_BEHAVIOR_ENTITY_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BSW_BEHAVIOR_ENTITY_OWNER,"ar3x.bswmoduletemplate.bswbehavior.BswModuleEntity",74,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior.ENTITY_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior getBswBehaviorEntityOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBswBehaviorEntityOwner(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswBehavior newValue);
  // reference : canEnterExclusiveArea generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CAN_ENTER_EXCLUSIVE_AREA = "canEnterExclusiveArea";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleEntity_canEnterExclusiveArea_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CAN_ENTER_EXCLUSIVE_AREA_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CAN_ENTER_EXCLUSIVE_AREA,"ar3x.bswmoduletemplate.bswbehavior.BswModuleEntity",133,null,com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaARRef.BSW_MODULE_ENTITY_CAN_ENTER_EXCLUSIVE_AREA_OWNER_RELATION_INFO;}};
  /**
   * The BswModuleEntity can enter/leave the referenced exclusive area through explicit API calls.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.commonstructure.internalbehavior.MIExclusiveAreaARRef> getCanEnterExclusiveArea();
  // reference : activationPoint generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ACTIVATION_POINT = "activationPoint";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleEntity_activationPoint_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ACTIVATION_POINT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ACTIVATION_POINT,"ar3x.bswmoduletemplate.bswbehavior.BswModuleEntity",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSporadicEventARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSporadicEventARRef.BSW_MODULE_ENTITY_ACTIVATION_POINT_OWNER_RELATION_INFO;}};
  /**
   * The module entity can activate this event.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSporadicEventARRef> getActivationPoint();
  // reference : implementedEntry generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IMPLEMENTED_ENTRY = "implementedEntry";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleEntity_implementedEntry_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IMPLEMENTED_ENTRY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IMPLEMENTED_ENTRY,"ar3x.bswmoduletemplate.bswbehavior.BswModuleEntity",128,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.BSW_MODULE_ENTITY_IMPLEMENTED_ENTRY_OWNER_RELATION_INFO;}};
  /**
   * The entry which is implemented by this module entity.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef getImplementedEntry();
  /**
   * The entry which is implemented by this module entity.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setImplementedEntry(com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef newValue);
  // reference : calledEntry generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CALLED_ENTRY = "calledEntry";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleEntity_calledEntry_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CALLED_ENTRY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CALLED_ENTRY,"ar3x.bswmoduletemplate.bswbehavior.BswModuleEntity",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef.BSW_MODULE_ENTITY_CALLED_ENTRY_OWNER_RELATION_INFO;}};
  /**
   * The entry of another (or the same) BSW module which is called by this entry (usually via C function call). This information allows to set up a model of call chains.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswinterfaces.MIBswModuleEntryARRef> getCalledEntry();
  // reference : cancellationPoint generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String CANCELLATION_POINT = "cancellationPoint";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: bswModuleEntity_cancellationPoint_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo CANCELLATION_POINT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(CANCELLATION_POINT,"ar3x.bswmoduletemplate.bswbehavior.BswModuleEntity",133,null,com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSporadicEventARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSporadicEventARRef.BSW_MODULE_ENTITY_CANCELLATION_POINT_OWNER_RELATION_INFO;}};
  /**
   * The module entity can cancel the activation of the event (this only makes sense, if the event has a non-zero delay time).
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior.MIBswSporadicEventARRef> getCancellationPoint();
}
