package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;
import javax.jmi.model.*;

public enum MIPortPrototypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  P_PORT_PROTOTYPE("P-PORT-PROTOTYPE"),
  PORT_PROTOTYPE("PORT-PROTOTYPE"),
  R_PORT_PROTOTYPE("R-PORT-PROTOTYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "components" );
    temp.add( "PortPrototypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIPortPrototypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
