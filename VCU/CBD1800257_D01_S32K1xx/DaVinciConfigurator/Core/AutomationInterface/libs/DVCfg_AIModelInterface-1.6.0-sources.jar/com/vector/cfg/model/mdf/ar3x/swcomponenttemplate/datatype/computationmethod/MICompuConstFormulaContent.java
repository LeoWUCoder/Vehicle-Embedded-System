package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MICompuConstFormulaContent extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConstContent
{
  public final static String CLASS_NAME = "CompuConstFormulaContent";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICompuConstFormulaContent> mdfGetClass();
  // reference : vf generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String VF = "vf";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: compuConstFormulaContent_vf_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo VF_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(VF,"ar3x.swcomponenttemplate.datatype.computationmethod.CompuConstFormulaContent",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf.COMPU_CONST_FORMULA_CONTENT_VF_OWNER_RELATION_INFO;}};
  /**
   * Value calculated via a system constant. This element is included in every case, where parameters should be generated from numerical values during compile time (not runtime!). Thus for example, the influence of the cylinder number on conversion formulae, can be introduced in a repeatable manner.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf getVf();
  /**
   * Value calculated via a system constant. This element is included in every case, where parameters should be generated from numerical values during compile time (not runtime!). Thus for example, the influence of the cylinder number on conversion formulae, can be introduced in a repeatable manner.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setVf(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVf newValue);
}
