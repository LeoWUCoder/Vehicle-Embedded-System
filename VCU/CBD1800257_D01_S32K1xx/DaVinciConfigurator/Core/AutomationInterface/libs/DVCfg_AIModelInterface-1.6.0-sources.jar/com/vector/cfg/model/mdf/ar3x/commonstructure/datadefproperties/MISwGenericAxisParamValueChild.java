package com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwGenericAxisParamValueChild extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "SwGenericAxisParamValueChild";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwGenericAxisParamValueChild> mdfGetClass();
  // reference : swGenericAxisParamValue_swGenericAxisParamValueChildren_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_GENERIC_AXIS_PARAM_VALUE_SW_GENERIC_AXIS_PARAM_VALUE_CHILDREN_OWNER = "swGenericAxisParamValue_swGenericAxisParamValueChildren_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: swGenericAxisParamValueChildren
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_GENERIC_AXIS_PARAM_VALUE_SW_GENERIC_AXIS_PARAM_VALUE_CHILDREN_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_GENERIC_AXIS_PARAM_VALUE_SW_GENERIC_AXIS_PARAM_VALUE_CHILDREN_OWNER,"ar3x.commonstructure.datadefproperties.SwGenericAxisParamValueChild",74,null,com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValue.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValue.SW_GENERIC_AXIS_PARAM_VALUE_CHILDREN_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValue getSwGenericAxisParamValueSwGenericAxisParamValueChildrenOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwGenericAxisParamValueSwGenericAxisParamValueChildrenOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.datadefproperties.MISwGenericAxisParamValue newValue);
}
