package com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIBaseTypeDefinition extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "BaseTypeDefinition";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIBaseTypeDefinition> mdfGetClass();
  // reference : baseType_baseTypeDefinitionType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BASE_TYPE_BASE_TYPE_DEFINITION_TYPE_OWNER = "baseType_baseTypeDefinitionType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: baseTypeDefinitionType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BASE_TYPE_BASE_TYPE_DEFINITION_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BASE_TYPE_BASE_TYPE_DEFINITION_TYPE_OWNER,"ar3x.commonstructure.basetypes.BaseTypeDefinition",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseType.BASE_TYPE_DEFINITION_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseType getBaseTypeBaseTypeDefinitionTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBaseTypeBaseTypeDefinitionTypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.basetypes.MIBaseType newValue);
}
