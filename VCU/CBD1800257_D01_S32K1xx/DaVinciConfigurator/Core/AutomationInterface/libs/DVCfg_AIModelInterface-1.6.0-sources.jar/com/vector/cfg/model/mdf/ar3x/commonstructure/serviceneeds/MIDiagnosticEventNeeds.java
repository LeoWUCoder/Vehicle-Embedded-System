package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the abstract needs on the configuration of the Diagnostic Event Manager for one diagnostic event. Its name can be regarded as a symbol identifying the diagnostic event from the viewpoint of the component or module which owns this class.
 */
public interface MIDiagnosticEventNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "DiagnosticEventNeeds";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDiagnosticEventNeeds> mdfGetClass();
  // reference : diagnosticEventNeedsARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DIAGNOSTIC_EVENT_NEEDS_ARREF_REF_TARGETS_OWNER = "diagnosticEventNeedsARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo DIAGNOSTIC_EVENT_NEEDS_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(DIAGNOSTIC_EVENT_NEEDS_ARREF_REF_TARGETS_OWNER,"ar3x.commonstructure.serviceneeds.DiagnosticEventNeeds",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIDiagnosticEventNeedsARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIDiagnosticEventNeedsARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIDiagnosticEventNeedsARRef> getDiagnosticEventNeedsARRefRefTargetsOwner();
}
