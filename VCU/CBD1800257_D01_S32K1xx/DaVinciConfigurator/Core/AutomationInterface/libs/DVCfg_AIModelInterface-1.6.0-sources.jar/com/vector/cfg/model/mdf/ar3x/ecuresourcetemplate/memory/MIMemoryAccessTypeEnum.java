package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;
import javax.jmi.model.*;

public enum MIMemoryAccessTypeEnum implements javax.jmi.reflect.RefEnum
{
  READ("READ"),
  WRITE("WRITE"),
  ERASE("ERASE"),
  PROGRAM("PROGRAM"),
  RANDOM("RANDOM"),
  SEQUENCE("SEQUENCE"),
  BURST("BURST");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "memory" );
    temp.add( "MemoryAccessTypeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIMemoryAccessTypeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
