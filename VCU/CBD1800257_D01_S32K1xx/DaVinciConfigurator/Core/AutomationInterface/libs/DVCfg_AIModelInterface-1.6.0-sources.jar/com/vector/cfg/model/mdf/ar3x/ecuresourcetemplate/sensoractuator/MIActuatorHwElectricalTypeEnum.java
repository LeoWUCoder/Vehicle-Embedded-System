package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;
import javax.jmi.model.*;

public enum MIActuatorHwElectricalTypeEnum implements javax.jmi.reflect.RefEnum
{
  RESISTIVE("RESISTIVE"),
  CAPACITIVE("CAPACITIVE"),
  INDUCTIVE("INDUCTIVE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "sensoractuator" );
    temp.add( "ActuatorHwElectricalTypeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIActuatorHwElectricalTypeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
