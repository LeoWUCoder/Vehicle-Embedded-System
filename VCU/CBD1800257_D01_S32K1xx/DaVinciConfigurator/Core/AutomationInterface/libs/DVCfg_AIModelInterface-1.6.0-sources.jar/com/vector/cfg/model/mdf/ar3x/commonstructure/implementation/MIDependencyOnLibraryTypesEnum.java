package com.vector.cfg.model.mdf.ar3x.commonstructure.implementation;
import javax.jmi.model.*;

public enum MIDependencyOnLibraryTypesEnum implements javax.jmi.reflect.RefEnum
{
  DEPENDENCY_ON_LIBRARY("DEPENDENCY-ON-LIBRARY");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "implementation" );
    temp.add( "DependencyOnLibraryTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIDependencyOnLibraryTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
