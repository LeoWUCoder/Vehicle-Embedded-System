package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIByteOrderEnumItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "ByteOrderEnumItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIByteOrderEnumItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.genericstructure.commonpatterns.enumerations.ByteOrderEnumItem",null,com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIByteOrderEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIByteOrderEnum getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations.MIByteOrderEnum newValue);
}
