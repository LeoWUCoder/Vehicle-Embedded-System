package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The user available registers are a part of the programming model that consists of: Memory organisation and segmentation, Data types, Registers, Instruction format, Operand selection, Interrupts and exceptions. Basically the register model contains the registers that are interest to the applications programmer; these registers can be grouped into three basic categories: - General registers: These general-purpose registers are used primarily to contain operands for arithmetic and logical operations. - Segment registers: These special-purpose registers permit software designers to choose either a flat or segmented model of memory organisation. These registers determine, at any given time, which segments of memory are currently addressable. - Status and instruction registers: These special-purpose registers are used to record and alter certain aspects of the processor state.  The register model is only valuable data for low level programming, e.g assembler programming. The register model, along with the available OP codes takes influence on the performance of the PU. The most general impact of the register model to software is number of registers which have to be handled during interrupts or function calls.
 */
public interface MIRegister extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "Register";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIRegister> mdfGetClass();
  // attribute : count generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String COUNT = "count";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo COUNT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,COUNT,"ar3x.ecuresourcetemplate.processingunit.Register",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describes how many registers are available of the specified type.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getCount();
  /**
   * Describes how many registers are available of the specified type.
   * Attribute-Kind = versionAttribute   */
  public void setCount(java.math.BigInteger newValue);
  // attribute : type generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TYPE = "type";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TYPE,"ar3x.ecuresourcetemplate.processingunit.Register",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIRegisterTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describes the kind of register.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIRegisterTypeEnum getType();
  /**
   * Describes the kind of register.
   * Attribute-Kind = versionAttribute   */
  public void setType(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIRegisterTypeEnum newValue);
  // reference : processingUnit_registerModel_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROCESSING_UNIT_REGISTER_MODEL_OWNER = "processingUnit_registerModel_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: registerModel
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROCESSING_UNIT_REGISTER_MODEL_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROCESSING_UNIT_REGISTER_MODEL_OWNER,"ar3x.ecuresourcetemplate.processingunit.Register",74,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit.REGISTER_MODEL_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit getProcessingUnitRegisterModelOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProcessingUnitRegisterModelOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIProcessingUnit newValue);
}
