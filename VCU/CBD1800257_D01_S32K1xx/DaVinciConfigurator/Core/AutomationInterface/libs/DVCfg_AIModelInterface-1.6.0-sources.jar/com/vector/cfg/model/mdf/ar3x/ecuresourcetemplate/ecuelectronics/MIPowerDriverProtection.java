package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The Power Driver HW Element / ASIC turns off by internal means in order to protect the device against severe damages.
 */
public interface MIPowerDriverProtection extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "PowerDriverProtection";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPowerDriverProtection> mdfGetClass();
  // attribute : minCurrentProtection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_CURRENT_PROTECTION = "minCurrentProtection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_CURRENT_PROTECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_CURRENT_PROTECTION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverProtection",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minimal current limits are exceeded.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMinCurrentProtection();
  /**
   * Minimal current limits are exceeded.
   * Attribute-Kind = versionAttribute   */
  public void setMinCurrentProtection(Boolean newValue);
  // attribute : maxCurrentProtection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_CURRENT_PROTECTION = "maxCurrentProtection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_CURRENT_PROTECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_CURRENT_PROTECTION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverProtection",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximal current limits are exceeded.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMaxCurrentProtection();
  /**
   * Maximal current limits are exceeded.
   * Attribute-Kind = versionAttribute   */
  public void setMaxCurrentProtection(Boolean newValue);
  // attribute : minVoltageProtection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_VOLTAGE_PROTECTION = "minVoltageProtection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_VOLTAGE_PROTECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_VOLTAGE_PROTECTION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverProtection",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minimal voltage limits are exceeded.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMinVoltageProtection();
  /**
   * Minimal voltage limits are exceeded.
   * Attribute-Kind = versionAttribute   */
  public void setMinVoltageProtection(Boolean newValue);
  // attribute : maxVoltageProtection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_VOLTAGE_PROTECTION = "maxVoltageProtection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_VOLTAGE_PROTECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_VOLTAGE_PROTECTION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverProtection",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximal voltage limits are exceeded.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMaxVoltageProtection();
  /**
   * Maximal voltage limits are exceeded.
   * Attribute-Kind = versionAttribute   */
  public void setMaxVoltageProtection(Boolean newValue);
  // attribute : reverseBatteryProtection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REVERSE_BATTERY_PROTECTION = "reverseBatteryProtection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo REVERSE_BATTERY_PROTECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,REVERSE_BATTERY_PROTECTION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverProtection",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Is protected against reverse battery voltage.
   * Attribute-Kind = versionAttribute   */
  public Boolean getReverseBatteryProtection();
  /**
   * Is protected against reverse battery voltage.
   * Attribute-Kind = versionAttribute   */
  public void setReverseBatteryProtection(Boolean newValue);
  // attribute : lossOfGroundProtection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String LOSS_OF_GROUND_PROTECTION = "lossOfGroundProtection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo LOSS_OF_GROUND_PROTECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,LOSS_OF_GROUND_PROTECTION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverProtection",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Is protected against loss of ground.
   * Attribute-Kind = versionAttribute   */
  public Boolean getLossOfGroundProtection();
  /**
   * Is protected against loss of ground.
   * Attribute-Kind = versionAttribute   */
  public void setLossOfGroundProtection(Boolean newValue);
  // attribute : overTemperatureProtection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OVER_TEMPERATURE_PROTECTION = "overTemperatureProtection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OVER_TEMPERATURE_PROTECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OVER_TEMPERATURE_PROTECTION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverProtection",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Is protected against over-temperature.
   * Attribute-Kind = versionAttribute   */
  public Boolean getOverTemperatureProtection();
  /**
   * Is protected against over-temperature.
   * Attribute-Kind = versionAttribute   */
  public void setOverTemperatureProtection(Boolean newValue);
  // reference : powerDriverHWElement_protection_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String POWER_DRIVER_HWELEMENT_PROTECTION_OWNER = "powerDriverHWElement_protection_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: protection
  public static final ru.novosoft.mdf.impl.MDFRelationInfo POWER_DRIVER_HWELEMENT_PROTECTION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(POWER_DRIVER_HWELEMENT_PROTECTION_OWNER,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverProtection",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverHWElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverHWElement.PROTECTION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverHWElement getPowerDriverHWElementProtectionOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPowerDriverHWElementProtectionOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverHWElement newValue);
}
