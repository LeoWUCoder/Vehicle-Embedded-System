package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHandleInvalidTypeItem extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HandleInvalidTypeItem";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIHandleInvalidTypeItem> mdfGetClass();
  // attribute : value generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VALUE = "value";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VALUE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VALUE,"ar3x.swcomponenttemplate.communication.HandleInvalidTypeItem",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIHandleInvalidType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIHandleInvalidType getValue();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setValue(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIHandleInvalidType newValue);
}
