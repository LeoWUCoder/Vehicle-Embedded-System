package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the abstract needs of a compoment or module on the configuration of OBD Services in relation to a given InfoType (OBD Service 09), which is supported by this component or module.
 */
public interface MIObdInfoServiceNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "ObdInfoServiceNeeds";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIObdInfoServiceNeeds> mdfGetClass();
  // attribute : infoType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String INFO_TYPE = "infoType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo INFO_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,INFO_TYPE,"ar3x.commonstructure.serviceneeds.ObdInfoServiceNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The InfoType according to ISO 15031-5
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getInfoType();
  /**
   * The InfoType according to ISO 15031-5
   * Attribute-Kind = versionAttribute   */
  public void setInfoType(java.math.BigInteger newValue);
  // attribute : dataLength generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DATA_LENGTH = "dataLength";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DATA_LENGTH_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DATA_LENGTH,"ar3x.commonstructure.serviceneeds.ObdInfoServiceNeeds",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Length of date (in bytes) provided for this InfoType.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getDataLength();
  /**
   * Length of date (in bytes) provided for this InfoType.
   * Attribute-Kind = versionAttribute   */
  public void setDataLength(java.math.BigInteger newValue);
}
