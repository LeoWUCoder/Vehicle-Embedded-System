package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MICompuGenericMathChild extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIValueByFormulaChild
{
  public final static String CLASS_NAME = "CompuGenericMathChild";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICompuGenericMathChild> mdfGetClass();
}
