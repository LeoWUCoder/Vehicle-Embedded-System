package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describe the status which cause a notification to the controlling devices of an ECU, e.g. to the PU.
 */
public interface MIPowerDriverNotification extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "PowerDriverNotification";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPowerDriverNotification> mdfGetClass();
  // attribute : minCurrent generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_CURRENT = "minCurrent";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_CURRENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_CURRENT,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The device detected a too low curent.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMinCurrent();
  /**
   * The device detected a too low curent.
   * Attribute-Kind = versionAttribute   */
  public void setMinCurrent(Boolean newValue);
  // attribute : maxCurrent generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_CURRENT = "maxCurrent";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_CURRENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_CURRENT,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The device detected a too high current.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMaxCurrent();
  /**
   * The device detected a too high current.
   * Attribute-Kind = versionAttribute   */
  public void setMaxCurrent(Boolean newValue);
  // attribute : minVoltage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MIN_VOLTAGE = "minVoltage";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MIN_VOLTAGE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MIN_VOLTAGE,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The device detected a too low supply voltage.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMinVoltage();
  /**
   * The device detected a too low supply voltage.
   * Attribute-Kind = versionAttribute   */
  public void setMinVoltage(Boolean newValue);
  // attribute : maxVoltage generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_VOLTAGE = "maxVoltage";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_VOLTAGE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_VOLTAGE,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The device detected a too high supply voltage.
   * Attribute-Kind = versionAttribute   */
  public Boolean getMaxVoltage();
  /**
   * The device detected a too high supply voltage.
   * Attribute-Kind = versionAttribute   */
  public void setMaxVoltage(Boolean newValue);
  // attribute : shortToGround generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SHORT_TO_GROUND = "shortToGround";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SHORT_TO_GROUND_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SHORT_TO_GROUND,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The device detected a short to ground situation. The device was forced off, in order to avoid damages by excessive currents.
   * Attribute-Kind = versionAttribute   */
  public Boolean getShortToGround();
  /**
   * The device detected a short to ground situation. The device was forced off, in order to avoid damages by excessive currents.
   * Attribute-Kind = versionAttribute   */
  public void setShortToGround(Boolean newValue);
  // attribute : lossOfGround generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String LOSS_OF_GROUND = "lossOfGround";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo LOSS_OF_GROUND_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,LOSS_OF_GROUND,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The device detected a loss of ground situation. The device was forced off, in order to avoid damages by excessive currents.
   * Attribute-Kind = versionAttribute   */
  public Boolean getLossOfGround();
  /**
   * The device detected a loss of ground situation. The device was forced off, in order to avoid damages by excessive currents.
   * Attribute-Kind = versionAttribute   */
  public void setLossOfGround(Boolean newValue);
  // attribute : shortToBatt generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SHORT_TO_BATT = "shortToBatt";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SHORT_TO_BATT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SHORT_TO_BATT,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The device detected a short to battery situation. The device was forced off, in order to avoid damages by excessive currents.
   * Attribute-Kind = versionAttribute   */
  public Boolean getShortToBatt();
  /**
   * The device detected a short to battery situation. The device was forced off, in order to avoid damages by excessive currents.
   * Attribute-Kind = versionAttribute   */
  public void setShortToBatt(Boolean newValue);
  // attribute : openLoad generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OPEN_LOAD = "openLoad";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OPEN_LOAD_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OPEN_LOAD,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The device detected open loads. This situation is reported to the controlling portion of an ECU, e.g. to the PU.
   * Attribute-Kind = versionAttribute   */
  public Boolean getOpenLoad();
  /**
   * The device detected open loads. This situation is reported to the controlling portion of an ECU, e.g. to the PU.
   * Attribute-Kind = versionAttribute   */
  public void setOpenLoad(Boolean newValue);
  // attribute : shortLoad generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SHORT_LOAD = "shortLoad";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SHORT_LOAD_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SHORT_LOAD,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The device was forced off, in order to avoid damages by excessive currents.
   * Attribute-Kind = versionAttribute   */
  public Boolean getShortLoad();
  /**
   * The device was forced off, in order to avoid damages by excessive currents.
   * Attribute-Kind = versionAttribute   */
  public void setShortLoad(Boolean newValue);
  // attribute : overTemperature generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OVER_TEMPERATURE = "overTemperature";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OVER_TEMPERATURE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OVER_TEMPERATURE,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The maximum allowed temperature was detected in the device. A protecting hardware has forced the device off.
   * Attribute-Kind = versionAttribute   */
  public Boolean getOverTemperature();
  /**
   * The maximum allowed temperature was detected in the device. A protecting hardware has forced the device off.
   * Attribute-Kind = versionAttribute   */
  public void setOverTemperature(Boolean newValue);
  // reference : powerDriverHWElement_notification_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String POWER_DRIVER_HWELEMENT_NOTIFICATION_OWNER = "powerDriverHWElement_notification_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: notification
  public static final ru.novosoft.mdf.impl.MDFRelationInfo POWER_DRIVER_HWELEMENT_NOTIFICATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(POWER_DRIVER_HWELEMENT_NOTIFICATION_OWNER,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverHWElement.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverHWElement.NOTIFICATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverHWElement getPowerDriverHWElementNotificationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPowerDriverHWElementNotificationOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverHWElement newValue);
  // reference : issuedInterruptSource generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ISSUED_INTERRUPT_SOURCE = "issuedInterruptSource";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: powerDriverNotification_issuedInterruptSource_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ISSUED_INTERRUPT_SOURCE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ISSUED_INTERRUPT_SOURCE,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverNotification",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPortARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPortARRef.POWER_DRIVER_NOTIFICATION_ISSUED_INTERRUPT_SOURCE_OWNER_RELATION_INFO;}};
  /**
   * If a notification is issued, in which Interrupt will it result.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPortARRef getIssuedInterruptSource();
  /**
   * If a notification is issued, in which Interrupt will it result.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setIssuedInterruptSource(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit.MIInterruptProduceHWPortARRef newValue);
}
