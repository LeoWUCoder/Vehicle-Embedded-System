package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Communication attributes of RPortPrototypes with respect to Nv data communication on the required side. 
 */
public interface MINvRequireComSpec extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIRPortComSpec
{
  public final static String CLASS_NAME = "NvRequireComSpec";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MINvRequireComSpec> mdfGetClass();
  // reference : initValue generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String INIT_VALUE = "initValue";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: nvRequireComSpec_initValue_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo INIT_VALUE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(INIT_VALUE,"ar3x.swcomponenttemplate.communication.NvRequireComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef.NV_REQUIRE_COM_SPEC_INIT_VALUE_OWNER_RELATION_INFO;}};
  /**
   * The initial value to be applied by the NvComSpec.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef getInitValue();
  /**
   * The initial value to be applied by the NvComSpec.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setInitValue(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.constants.MIValueSpecificationARRef newValue);
  // reference : nvDataElement generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String NV_DATA_ELEMENT = "nvDataElement";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: nvRequireComSpec_nvDataElement_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo NV_DATA_ELEMENT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(NV_DATA_ELEMENT,"ar3x.swcomponenttemplate.communication.NvRequireComSpec",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.NV_REQUIRE_COM_SPEC_NV_DATA_ELEMENT_OWNER_RELATION_INFO;}};
  /**
   * The DataElementPrototype the ComSpec applies for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef getNvDataElement();
  /**
   * The DataElementPrototype the ComSpec applies for.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setNvDataElement(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef newValue);
}
