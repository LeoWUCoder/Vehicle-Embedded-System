package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The basic source for time in the ECU. Based on the oscillator the PU clock is generated, but also the communication and other peripherals need timing information (ADC, PWM, timer).
 */
public interface MIOscillator extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIECUElectronics
{
  public final static String CLASS_NAME = "Oscillator";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIOscillator> mdfGetClass();
  // attribute : adjustible generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ADJUSTIBLE = "adjustible";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ADJUSTIBLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ADJUSTIBLE,"ar3x.ecuresourcetemplate.ecuelectronics.Oscillator",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines if the oscillator is adjustable from software.
   * Attribute-Kind = versionAttribute   */
  public Boolean getAdjustible();
  /**
   * Defines if the oscillator is adjustable from software.
   * Attribute-Kind = versionAttribute   */
  public void setAdjustible(Boolean newValue);
  // attribute : oscillatorJitter generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OSCILLATOR_JITTER = "oscillatorJitter";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OSCILLATOR_JITTER_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OSCILLATOR_JITTER,"ar3x.ecuresourcetemplate.ecuelectronics.Oscillator",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The short-term deviation of the nominal frequency to the real frequency. Jitter is influenced by the circuitry itself, voltage spikes etc. Jitter is critical for communication elements.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getOscillatorJitter();
  /**
   * The short-term deviation of the nominal frequency to the real frequency. Jitter is influenced by the circuitry itself, voltage spikes etc. Jitter is critical for communication elements.
   * Attribute-Kind = versionAttribute   */
  public void setOscillatorJitter(java.math.BigDecimal newValue);
  // attribute : oscillatorMode generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OSCILLATOR_MODE = "oscillatorMode";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OSCILLATOR_MODE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OSCILLATOR_MODE,"ar3x.ecuresourcetemplate.ecuelectronics.Oscillator",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIOscillatorModeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Crystals and other oscillating elements have more than one resonant frequencies, which are usually odd harmonics to the basic, fundamental frequencies. For Automotive a basic requirement should be to use only fundamental mode only. Using overtone modes there is a risk, that the oscillator circuitry starts at the fundamental mode after a error in the start up routine. In order to reach an overtone mode the frequency of the fundamental mode, or lower overtones has to be passed during start up. There is a risk that the oscillator locks to this, lower frequency. Therefore Fundamental modes oscillatorts are not so critical for this issue. Fundamental quartz/crystals can reach up to 40 MHz today, above this frequency all quartz/crystals are running in the 3rd, 5th or higher overtone mode.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIOscillatorModeEnum getOscillatorMode();
  /**
   * Crystals and other oscillating elements have more than one resonant frequencies, which are usually odd harmonics to the basic, fundamental frequencies. For Automotive a basic requirement should be to use only fundamental mode only. Using overtone modes there is a risk, that the oscillator circuitry starts at the fundamental mode after a error in the start up routine. In order to reach an overtone mode the frequency of the fundamental mode, or lower overtones has to be passed during start up. There is a risk that the oscillator locks to this, lower frequency. Therefore Fundamental modes oscillatorts are not so critical for this issue. Fundamental quartz/crystals can reach up to 40 MHz today, above this frequency all quartz/crystals are running in the 3rd, 5th or higher overtone mode.
   * Attribute-Kind = versionAttribute   */
  public void setOscillatorMode(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIOscillatorModeEnum newValue);
  // attribute : oscillatorStartupTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OSCILLATOR_STARTUP_TIME = "oscillatorStartupTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OSCILLATOR_STARTUP_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OSCILLATOR_STARTUP_TIME,"ar3x.ecuresourcetemplate.ecuelectronics.Oscillator",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The time the oscillator needs to deliver a stable and valid signal.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getOscillatorStartupTime();
  /**
   * The time the oscillator needs to deliver a stable and valid signal.
   * Attribute-Kind = versionAttribute   */
  public void setOscillatorStartupTime(java.math.BigDecimal newValue);
  // attribute : oscillatorTolerance generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OSCILLATOR_TOLERANCE = "oscillatorTolerance";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo OSCILLATOR_TOLERANCE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,OSCILLATOR_TOLERANCE,"ar3x.ecuresourcetemplate.ecuelectronics.Oscillator",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The long-term deviation of the nominal frequency to the real frequency. Influenced by manufacturing, layout, temperature, external components and voltage. Tolerances are critical for timer application and time synchronisation.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getOscillatorTolerance();
  /**
   * The long-term deviation of the nominal frequency to the real frequency. Influenced by manufacturing, layout, temperature, external components and voltage. Tolerances are critical for timer application and time synchronisation.
   * Attribute-Kind = versionAttribute   */
  public void setOscillatorTolerance(java.math.BigDecimal newValue);
  // reference : oscillatorARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String OSCILLATOR_ARREF_REF_TARGETS_OWNER = "oscillatorARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OSCILLATOR_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OSCILLATOR_ARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.ecuelectronics.Oscillator",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillatorARRef> getOscillatorARRefRefTargetsOwner();
  // reference : oscillatorFrequencyRange generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OSCILLATOR_FREQUENCY_RANGE = "oscillatorFrequencyRange";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: oscillator_oscillatorFrequencyRange_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OSCILLATOR_FREQUENCY_RANGE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OSCILLATOR_FREQUENCY_RANGE,"ar3x.ecuresourcetemplate.ecuelectronics.Oscillator",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIFrequencyRange.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIFrequencyRange.OSCILLATOR_OSCILLATOR_FREQUENCY_RANGE_OWNER_RELATION_INFO;}};
  /**
   * The frequency range the oscillator is able to provide.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIFrequencyRange getOscillatorFrequencyRange();
  /**
   * The frequency range the oscillator is able to provide.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setOscillatorFrequencyRange(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIFrequencyRange newValue);
  // reference : backupOscillator generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String BACKUP_OSCILLATOR = "backupOscillator";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: oscillator_backupOscillator_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo BACKUP_OSCILLATOR_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(BACKUP_OSCILLATOR,"ar3x.ecuresourcetemplate.ecuelectronics.Oscillator",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator.OSCILLATOR_BACKUP_OSCILLATOR_OWNER_RELATION_INFO;}};
  /**
   * An internal, very inaccurate RC-oscillator, which provide the PU with a clock source when the external oscillator is not available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator getBackupOscillator();
  /**
   * An internal, very inaccurate RC-oscillator, which provide the PU with a clock source when the external oscillator is not available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setBackupOscillator(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator newValue);
  // reference : oscillator_backupOscillator_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String OSCILLATOR_BACKUP_OSCILLATOR_OWNER = "oscillator_backupOscillator_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: backupOscillator
  public static final ru.novosoft.mdf.impl.MDFRelationInfo OSCILLATOR_BACKUP_OSCILLATOR_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(OSCILLATOR_BACKUP_OSCILLATOR_OWNER,"ar3x.ecuresourcetemplate.ecuelectronics.Oscillator",64,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator.BACKUP_OSCILLATOR_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator getOscillatorBackupOscillatorOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setOscillatorBackupOscillatorOwner(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIOscillator newValue);
}
