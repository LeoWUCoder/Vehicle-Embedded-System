package com.vector.cfg.model.mdf.ar3x.commonstructure.axis;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MISwGenericAxisParamTypeARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "SwGenericAxisParamTypeARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MISwGenericAxisParamTypeARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.commonstructure.axis.SwGenericAxisParamTypeARRef",null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamTypeTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamTypeTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamTypeTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: swGenericAxisParamTypeARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.commonstructure.axis.SwGenericAxisParamTypeARRef",3,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamType.SW_GENERIC_AXIS_PARAM_TYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamType> getRefTargets();
  // reference : swGenericAxisParam_swGenericAxisParamType_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SW_GENERIC_AXIS_PARAM_SW_GENERIC_AXIS_PARAM_TYPE_OWNER = "swGenericAxisParam_swGenericAxisParamType_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: swGenericAxisParamType
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SW_GENERIC_AXIS_PARAM_SW_GENERIC_AXIS_PARAM_TYPE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SW_GENERIC_AXIS_PARAM_SW_GENERIC_AXIS_PARAM_TYPE_OWNER,"ar3x.commonstructure.axis.SwGenericAxisParamTypeARRef",64,null,com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam.SW_GENERIC_AXIS_PARAM_TYPE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam getSwGenericAxisParamSwGenericAxisParamTypeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSwGenericAxisParamSwGenericAxisParamTypeOwner(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParam newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamType getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.commonstructure.axis.MISwGenericAxisParamType newRefTarget);

}
