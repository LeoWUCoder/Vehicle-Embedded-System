package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;
import javax.jmi.model.*;

public enum MIDiagnosticEventNeedsTypesEnum implements javax.jmi.reflect.RefEnum
{
  DIAGNOSTIC_EVENT_NEEDS("DIAGNOSTIC-EVENT-NEEDS"),
  SWC_DIAGNOSTIC_EVENT_NEEDS("SWC-DIAGNOSTIC-EVENT-NEEDS");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "serviceneeds" );
    temp.add( "DiagnosticEventNeedsTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIDiagnosticEventNeedsTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
