package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition;
import javax.jmi.model.*;

public enum MICompositionTypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  COMPOSITION_TYPE("COMPOSITION-TYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "composition" );
    temp.add( "CompositionTypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MICompositionTypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
