package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Component port providing a certain port interface.
 */
public interface MIPPortPrototype extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype
{
  public final static String CLASS_NAME = "PPortPrototype";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPPortPrototype> mdfGetClass();
  // reference : pPortPrototypeARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String P_PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER = "pPortPrototypeARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo P_PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(P_PORT_PROTOTYPE_ARREF_REF_TARGETS_OWNER,"ar3x.swcomponenttemplate.components.PPortPrototype",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototypeARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPPortPrototypeARRef> getPPortPrototypeARRefRefTargetsOwner();
  // reference : providedComSpec generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROVIDED_COM_SPEC = "providedComSpec";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: pPortPrototype_providedComSpec_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROVIDED_COM_SPEC_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROVIDED_COM_SPEC,"ar3x.swcomponenttemplate.components.PPortPrototype",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIPPortComSpec.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIPPortComSpec.P_PORT_PROTOTYPE_PROVIDED_COM_SPEC_OWNER_RELATION_INFO;}};
  /**
   * Provided communication attributes per interface element (data element or operation).
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MIPPortComSpec> getProvidedComSpec();
  // reference : providedInterface generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROVIDED_INTERFACE = "providedInterface";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: pPortPrototype_providedInterface_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROVIDED_INTERFACE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROVIDED_INTERFACE,"ar3x.swcomponenttemplate.components.PPortPrototype",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIPortInterfaceARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIPortInterfaceARRef.P_PORT_PROTOTYPE_PROVIDED_INTERFACE_OWNER_RELATION_INFO;}};
  /**
   * The interface that this port provides.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIPortInterfaceARRef getProvidedInterface();
  /**
   * The interface that this port provides.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProvidedInterface(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIPortInterfaceARRef newValue);
}
