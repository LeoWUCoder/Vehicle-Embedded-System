package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The IoHwAbstractionPort Annotation will only be used from a sensor- or an actuator component while interacting with the IoHwAbstraction layer 
 */
public interface MIIoHwAbstractionServerAnnotation extends com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIGeneralAnnotation
{
  public final static String CLASS_NAME = "IoHwAbstractionServerAnnotation";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIIoHwAbstractionServerAnnotation> mdfGetClass();
  // attribute : age generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String AGE = "age";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo AGE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,AGE,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * In case of a SET operation, the age will be interpreted as Delay while in a GET operation (input) it specifies the Lifetime of the signal within the IoHwAbstraction Layer 
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getAge();
  /**
   * In case of a SET operation, the age will be interpreted as Delay while in a GET operation (input) it specifies the Lifetime of the signal within the IoHwAbstraction Layer 
   * Attribute-Kind = versionAttribute   */
  public void setAge(java.math.BigInteger newValue);
  // attribute : bswRangeMax generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BSW_RANGE_MAX = "bswRangeMax";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BSW_RANGE_MAX_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BSW_RANGE_MAX,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies the maximum value of the Range the ECU-Signal is supposed to have
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getBswRangeMax();
  /**
   * Specifies the maximum value of the Range the ECU-Signal is supposed to have
   * Attribute-Kind = versionAttribute   */
  public void setBswRangeMax(java.math.BigInteger newValue);
  // attribute : bswRangeMin generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BSW_RANGE_MIN = "bswRangeMin";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BSW_RANGE_MIN_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BSW_RANGE_MIN,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Specifies the maximum value of the Range the ECU-Signal is supposed to have.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getBswRangeMin();
  /**
   * Specifies the maximum value of the Range the ECU-Signal is supposed to have.
   * Attribute-Kind = versionAttribute   */
  public void setBswRangeMin(java.math.BigInteger newValue);
  // attribute : bswResolution generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BSW_RESOLUTION = "bswResolution";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BSW_RESOLUTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BSW_RESOLUTION,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This value is determined by an appropriate combination of the range, the unit as well as the data-elements type, i.e. (BswRangeMax-BswRangeMin) / (2^datatypelength - 1)
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getBswResolution();
  /**
   * This value is determined by an appropriate combination of the range, the unit as well as the data-elements type, i.e. (BswRangeMax-BswRangeMin) / (2^datatypelength - 1)
   * Attribute-Kind = versionAttribute   */
  public void setBswResolution(java.math.BigDecimal newValue);
  // attribute : filteringDebouncing generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String FILTERING_DEBOUNCING = "filteringDebouncing";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo FILTERING_DEBOUNCING_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,FILTERING_DEBOUNCING,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIFilterDebouncingEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This attribute is used to indicate what kind of filtering/debouncing has been put to the signal in the IoHwAbstraction layer.   rawData means that no modification of the signal has been applied.This is the default value debounceData means that the signal is a mean value waitTimeData means that the signal is delivered by a GET operation after a certain amount of time 
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIFilterDebouncingEnum getFilteringDebouncing();
  /**
   * This attribute is used to indicate what kind of filtering/debouncing has been put to the signal in the IoHwAbstraction layer.   rawData means that no modification of the signal has been applied.This is the default value debounceData means that the signal is a mean value waitTimeData means that the signal is delivered by a GET operation after a certain amount of time 
   * Attribute-Kind = versionAttribute   */
  public void setFilteringDebouncing(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIFilterDebouncingEnum newValue);
  // attribute : pulseTest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PULSE_TEST = "pulseTest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo PULSE_TEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,PULSE_TEST,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIPulseTestEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * This attribute indicates to the connected SensorActuatorSoftwareComponentType whether the DataElementPrototype can be used to generate pulse test sequences using the IoHwAbstraction layer
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIPulseTestEnum getPulseTest();
  /**
   * This attribute indicates to the connected SensorActuatorSoftwareComponentType whether the DataElementPrototype can be used to generate pulse test sequences using the IoHwAbstraction layer
   * Attribute-Kind = versionAttribute   */
  public void setPulseTest(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIPulseTestEnum newValue);
  // attribute : unit generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String UNIT = "unit";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo UNIT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,UNIT,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * These are either electrical units like Volts (V) or time units like milliseconds (ms). The unit is set according to the ECU Input signal class which is either analogue or modulation
   * Attribute-Kind = versionAttribute   */
  public String getUnit();
  /**
   * These are either electrical units like Volts (V) or time units like milliseconds (ms). The unit is set according to the ECU Input signal class which is either analogue or modulation
   * Attribute-Kind = versionAttribute   */
  public void setUnit(String newValue);
  // reference : portPrototype_ioHwAbstractionServerAnnotation_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_PROTOTYPE_IO_HW_ABSTRACTION_SERVER_ANNOTATION_OWNER = "portPrototype_ioHwAbstractionServerAnnotation_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: ioHwAbstractionServerAnnotation
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_PROTOTYPE_IO_HW_ABSTRACTION_SERVER_ANNOTATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_PROTOTYPE_IO_HW_ABSTRACTION_SERVER_ANNOTATION_OWNER,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.IO_HW_ABSTRACTION_SERVER_ANNOTATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype getPortPrototypeIoHwAbstractionServerAnnotationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortPrototypeIoHwAbstractionServerAnnotationOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype newValue);
  // reference : failureMonitoring generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String FAILURE_MONITORING = "failureMonitoring";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: ioHwAbstractionServerAnnotation_failureMonitoring_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo FAILURE_MONITORING_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(FAILURE_MONITORING,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.IO_HW_ABSTRACTION_SERVER_ANNOTATION_FAILURE_MONITORING_OWNER_RELATION_INFO;}};
  /**
   * This is only applicable in SET operations. If it is enabled, the IoHwAbstraction layer will monitor the result of the operation and issue an diagnostic signal. This means especially, that an additional client-server port has to be created. Tools can use this information to cross-check whether for each data-element in a SET operation with FailureMonitoring enabled an additional port is created  The referenced port monitors a failure in the to be monitored data-element of the IoHwAbstraction layer. The referenced port has to be another port of the same Actuator or Sensor Component.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef getFailureMonitoring();
  /**
   * This is only applicable in SET operations. If it is enabled, the IoHwAbstraction layer will monitor the result of the operation and issue an diagnostic signal. This means especially, that an additional client-server port has to be created. Tools can use this information to cross-check whether for each data-element in a SET operation with FailureMonitoring enabled an additional port is created  The referenced port monitors a failure in the to be monitored data-element of the IoHwAbstraction layer. The referenced port has to be another port of the same Actuator or Sensor Component.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setFailureMonitoring(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef newValue);
  // reference : ioDataElementPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String IO_DATA_ELEMENT_PROTOTYPE = "ioDataElementPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: ioHwAbstractionServerAnnotation_ioDataElementPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo IO_DATA_ELEMENT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(IO_DATA_ELEMENT_PROTOTYPE,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.IO_HW_ABSTRACTION_SERVER_ANNOTATION_IO_DATA_ELEMENT_PROTOTYPE_OWNER_RELATION_INFO;}};
  /**
   * Reference to the corresponding DataElementPrototype. The IoHwAbstractionServerAnnotation can be applied either to sender-receiver or to client-server communication. This association only applies in the former case
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef getIoDataElementPrototype();
  /**
   * Reference to the corresponding DataElementPrototype. The IoHwAbstractionServerAnnotation can be applied either to sender-receiver or to client-server communication. This association only applies in the former case
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setIoDataElementPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef newValue);
  // reference : argumentPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ARGUMENT_PROTOTYPE = "argumentPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: ioHwAbstractionServerAnnotation_argumentPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ARGUMENT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ARGUMENT_PROTOTYPE,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIArgumentPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIArgumentPrototypeARRef.IO_HW_ABSTRACTION_SERVER_ANNOTATION_ARGUMENT_PROTOTYPE_OWNER_RELATION_INFO;}};
  /**
   * Reference to the corresponding ArgumentPrototype. The IoHwAbstractionServerAnnotation can be applied either to sender-receiver or to client-server communication. This association only applies in the latter case
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIArgumentPrototypeARRef getArgumentPrototype();
  /**
   * Reference to the corresponding ArgumentPrototype. The IoHwAbstractionServerAnnotation can be applied either to sender-receiver or to client-server communication. This association only applies in the latter case
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setArgumentPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIArgumentPrototypeARRef newValue);
  // reference : supportsReportRunnable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SUPPORTS_REPORT_RUNNABLE = "supportsReportRunnable";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: ioHwAbstractionServerAnnotation_supportsReportRunnable_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SUPPORTS_REPORT_RUNNABLE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SUPPORTS_REPORT_RUNNABLE,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIReportFeature.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIReportFeature.IO_HW_ABSTRACTION_SERVER_ANNOTATION_SUPPORTS_REPORT_RUNNABLE_OWNER_RELATION_INFO;}};
  /**
   * Calrifies whether a report RunnableEntity is supported,
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIReportFeature getSupportsReportRunnable();
  /**
   * Calrifies whether a report RunnableEntity is supported,
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSupportsReportRunnable(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIReportFeature newValue);
  // reference : supportsWakeUpRunnable generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SUPPORTS_WAKE_UP_RUNNABLE = "supportsWakeUpRunnable";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: ioHwAbstractionServerAnnotation_supportsWakeUpRunnable_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SUPPORTS_WAKE_UP_RUNNABLE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SUPPORTS_WAKE_UP_RUNNABLE,"ar3x.swcomponenttemplate.applicationattributes.IoHwAbstractionServerAnnotation",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIWakeUp.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIWakeUp.IO_HW_ABSTRACTION_SERVER_ANNOTATION_SUPPORTS_WAKE_UP_RUNNABLE_OWNER_RELATION_INFO;}};
  /**
   * Clarifies whether a wake-up RunnableEntity is supported.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIWakeUp getSupportsWakeUpRunnable();
  /**
   * Clarifies whether a wake-up RunnableEntity is supported.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSupportsWakeUpRunnable(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes.MIWakeUp newValue);
}
