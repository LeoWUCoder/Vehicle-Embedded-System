package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIPortGroupARRef extends com.vector.cfg.model.mdf.commoncore.autosar.MIARRef
{
  public final static String CLASS_NAME = "PortGroupARRef";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPortGroupARRef> mdfGetClass();
  // attribute : dest generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEST = "dest";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEST_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEST,"ar3x.swcomponenttemplate.components.PortGroupARRef",null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroupTypesEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroupTypesEnum getDest();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDest(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroupTypesEnum newValue);
  // reference : refTargets generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String REF_TARGETS = "refTargets";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: portGroupARRef_refTargets_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo REF_TARGETS_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(REF_TARGETS,"ar3x.swcomponenttemplate.components.PortGroupARRef",3,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup.PORT_GROUP_ARREF_REF_TARGETS_OWNER_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup> getRefTargets();
  // reference : portGroupInnerGroup_portGroup_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_GROUP_INNER_GROUP_PORT_GROUP_OWNER = "portGroupInnerGroup_portGroup_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: portGroup
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_GROUP_INNER_GROUP_PORT_GROUP_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_GROUP_INNER_GROUP_PORT_GROUP_OWNER,"ar3x.swcomponenttemplate.components.PortGroupARRef",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup.PORT_GROUP_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup getPortGroupInnerGroupPortGroupOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortGroupInnerGroupPortGroupOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.instanceref.MIPortGroupInnerGroup newValue);
  // reference : pncMappingVfc_vfc_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PNC_MAPPING_VFC_VFC_OWNER = "pncMappingVfc_vfc_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: vfc
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PNC_MAPPING_VFC_VFC_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PNC_MAPPING_VFC_VFC_OWNER,"ar3x.swcomponenttemplate.components.PortGroupARRef",64,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIPncMappingVfc.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIPncMappingVfc.VFC_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIPncMappingVfc getPncMappingVfcVfcOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPncMappingVfcVfcOwner(com.vector.cfg.model.mdf.ar3x.systemtemplate.swmapping.instanceref.MIPncMappingVfc newValue);

  // ------------------------------------------
  // Added business hooks

  /**
   * This method returns the references target object as long as only one target is being referenced. In case of multiple targets an
   * {@link com.vector.cfg.model.exceptions.MultipleVariantObjectsException} exception is being thrown.
   * 
   * When no target is available this method returns <code>null</code>.
   * 
   * @return
   * @throws com.vector.cfg.model.exceptions.MultipleVariantObjectsException
   */
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup getRefTarget();

  /**
   * This method sets the reference value path to the AUTOSAR path of the specified target object. All currently referenced target objects will be replaced by
   * all target objects referenced by the new path.
   * 
   * When the specified target object doesn't have an AUTOSAR path this method returns without any change.
   * 
   * This method doesn't throw an exception.
   * 
   * @param newRefTarget
   */
  public void setRefTarget(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortGroup newRefTarget);

}
