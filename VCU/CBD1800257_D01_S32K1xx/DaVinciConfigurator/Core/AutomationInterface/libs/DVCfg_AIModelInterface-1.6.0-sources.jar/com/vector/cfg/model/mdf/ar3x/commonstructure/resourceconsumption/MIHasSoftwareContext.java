package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIHasSoftwareContext extends com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact
{
  public final static String CLASS_NAME = "HasSoftwareContext";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIHasSoftwareContext> mdfGetClass();
  // reference : softwareContext generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SOFTWARE_CONTEXT = "softwareContext";
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: hasSoftwareContext_softwareContext_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SOFTWARE_CONTEXT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SOFTWARE_CONTEXT,"ar3x.commonstructure.resourceconsumption.HasSoftwareContext",128,null,com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MISoftwareContext.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MISoftwareContext.HAS_SOFTWARE_CONTEXT_SOFTWARE_CONTEXT_OWNER_RELATION_INFO;}};
  public com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MISoftwareContext getSoftwareContext();
  public void setSoftwareContext(com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.MISoftwareContext newValue);
}
