package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.instanceref;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIServiceConnectorPrototypeApplicationPort extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "ServiceConnectorPrototypeApplicationPort";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIServiceConnectorPrototypeApplicationPort> mdfGetClass();
  // reference : serviceConnectorPrototype_applicationPort_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_OWNER = "serviceConnectorPrototype_applicationPort_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: applicationPort
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_OWNER,"ar3x.swcomponenttemplate.composition.instanceref.ServiceConnectorPrototypeApplicationPort",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIServiceConnectorPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIServiceConnectorPrototype.APPLICATION_PORT_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIServiceConnectorPrototype getServiceConnectorPrototypeApplicationPortOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setServiceConnectorPrototypeApplicationPortOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIServiceConnectorPrototype newValue);
  // reference : portPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_PROTOTYPE = "portPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: serviceConnectorPrototypeApplicationPort_portPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_PROTOTYPE,"ar3x.swcomponenttemplate.composition.instanceref.ServiceConnectorPrototypeApplicationPort",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef.SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_PORT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef getPortPrototype();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototypeARRef newValue);
  // reference : componentPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPONENT_PROTOTYPE = "componentPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_MULTIPLE; TO_TARGET_IS_ORDERED; TO_SOURCE_IS_COMPOSITE; OppositeRoleName: serviceConnectorPrototypeApplicationPort_componentPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPONENT_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPONENT_PROTOTYPE,"ar3x.swcomponenttemplate.composition.instanceref.ServiceConnectorPrototypeApplicationPort",133,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef.SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_COMPONENT_PROTOTYPE_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public java.util.List<com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MIComponentPrototypeARRef> getComponentPrototype();
  // reference : softwareComposition generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SOFTWARE_COMPOSITION = "softwareComposition";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: serviceConnectorPrototypeApplicationPort_softwareComposition_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SOFTWARE_COMPOSITION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SOFTWARE_COMPOSITION,"ar3x.swcomponenttemplate.composition.instanceref.ServiceConnectorPrototypeApplicationPort",128,null,com.vector.cfg.model.mdf.ar3x.systemtemplate.MISoftwareCompositionARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.systemtemplate.MISoftwareCompositionARRef.SERVICE_CONNECTOR_PROTOTYPE_APPLICATION_PORT_SOFTWARE_COMPOSITION_OWNER_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.systemtemplate.MISoftwareCompositionARRef getSoftwareComposition();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSoftwareComposition(com.vector.cfg.model.mdf.ar3x.systemtemplate.MISoftwareCompositionARRef newValue);
}
