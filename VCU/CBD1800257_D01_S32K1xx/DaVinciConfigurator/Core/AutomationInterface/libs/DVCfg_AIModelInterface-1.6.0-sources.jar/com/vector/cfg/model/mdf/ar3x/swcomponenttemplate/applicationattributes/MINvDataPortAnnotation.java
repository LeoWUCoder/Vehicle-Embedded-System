package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Annotation to a port regarding a certain DataElementPrototype. 
 */
public interface MINvDataPortAnnotation extends com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.annotation.MIGeneralAnnotation
{
  public final static String CLASS_NAME = "NvDataPortAnnotation";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MINvDataPortAnnotation> mdfGetClass();
  // reference : portPrototype_nvDataPortAnnotation_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PORT_PROTOTYPE_NV_DATA_PORT_ANNOTATION_OWNER = "portPrototype_nvDataPortAnnotation_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: nvDataPortAnnotation
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PORT_PROTOTYPE_NV_DATA_PORT_ANNOTATION_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PORT_PROTOTYPE_NV_DATA_PORT_ANNOTATION_OWNER,"ar3x.swcomponenttemplate.applicationattributes.NvDataPortAnnotation",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype.NV_DATA_PORT_ANNOTATION_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype getPortPrototypeNvDataPortAnnotationOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setPortPrototypeNvDataPortAnnotationOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.components.MIPortPrototype newValue);
  // reference : nvDataPrototype generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String NV_DATA_PROTOTYPE = "nvDataPrototype";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: nvDataPortAnnotation_nvDataPrototype_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo NV_DATA_PROTOTYPE_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(NV_DATA_PROTOTYPE,"ar3x.swcomponenttemplate.applicationattributes.NvDataPortAnnotation",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef.NV_DATA_PORT_ANNOTATION_NV_DATA_PROTOTYPE_OWNER_RELATION_INFO;}};
  /**
   * The instance of nvData annotated.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef getNvDataPrototype();
  /**
   * The instance of nvData annotated.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setNvDataPrototype(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.portinterface.MIDataElementPrototypeARRef newValue);
}
