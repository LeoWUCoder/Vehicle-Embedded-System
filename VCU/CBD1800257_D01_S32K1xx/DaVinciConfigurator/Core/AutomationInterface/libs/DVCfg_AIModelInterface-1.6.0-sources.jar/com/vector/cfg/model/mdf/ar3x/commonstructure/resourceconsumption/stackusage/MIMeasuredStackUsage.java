package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The stack usage has been measured.
 */
public interface MIMeasuredStackUsage extends com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.stackusage.MIStackUsage
{
  public final static String CLASS_NAME = "MeasuredStackUsage";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIMeasuredStackUsage> mdfGetClass();
  // attribute : minimumMemoryConsumption generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MINIMUM_MEMORY_CONSUMPTION = "minimumMemoryConsumption";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MINIMUM_MEMORY_CONSUMPTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MINIMUM_MEMORY_CONSUMPTION,"ar3x.commonstructure.resourceconsumption.stackusage.MeasuredStackUsage",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The minimum stack usage measured.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMinimumMemoryConsumption();
  /**
   * The minimum stack usage measured.
   * Attribute-Kind = versionAttribute   */
  public void setMinimumMemoryConsumption(java.math.BigInteger newValue);
  // attribute : maximumMemoryConsumption generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAXIMUM_MEMORY_CONSUMPTION = "maximumMemoryConsumption";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAXIMUM_MEMORY_CONSUMPTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAXIMUM_MEMORY_CONSUMPTION,"ar3x.commonstructure.resourceconsumption.stackusage.MeasuredStackUsage",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The maximum stack usage measured.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getMaximumMemoryConsumption();
  /**
   * The maximum stack usage measured.
   * Attribute-Kind = versionAttribute   */
  public void setMaximumMemoryConsumption(java.math.BigInteger newValue);
  // attribute : averageMemoryConsumption generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String AVERAGE_MEMORY_CONSUMPTION = "averageMemoryConsumption";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo AVERAGE_MEMORY_CONSUMPTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,AVERAGE_MEMORY_CONSUMPTION,"ar3x.commonstructure.resourceconsumption.stackusage.MeasuredStackUsage",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The average stack usage measured.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getAverageMemoryConsumption();
  /**
   * The average stack usage measured.
   * Attribute-Kind = versionAttribute   */
  public void setAverageMemoryConsumption(java.math.BigInteger newValue);
  // attribute : testPattern generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TEST_PATTERN = "testPattern";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TEST_PATTERN_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TEST_PATTERN,"ar3x.commonstructure.resourceconsumption.stackusage.MeasuredStackUsage",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Description of the test pattern used to aquire the measured values.
   * Attribute-Kind = versionAttribute   */
  public String getTestPattern();
  /**
   * Description of the test pattern used to aquire the measured values.
   * Attribute-Kind = versionAttribute   */
  public void setTestPattern(String newValue);
}
