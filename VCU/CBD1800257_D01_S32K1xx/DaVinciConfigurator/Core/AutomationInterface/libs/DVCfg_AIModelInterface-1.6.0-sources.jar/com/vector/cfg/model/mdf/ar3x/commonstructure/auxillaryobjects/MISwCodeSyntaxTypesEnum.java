package com.vector.cfg.model.mdf.ar3x.commonstructure.auxillaryobjects;
import javax.jmi.model.*;

public enum MISwCodeSyntaxTypesEnum implements javax.jmi.reflect.RefEnum
{
  SW_CODE_SYNTAX("SW-CODE-SYNTAX");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "auxillaryobjects" );
    temp.add( "SwCodeSyntaxTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwCodeSyntaxTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
