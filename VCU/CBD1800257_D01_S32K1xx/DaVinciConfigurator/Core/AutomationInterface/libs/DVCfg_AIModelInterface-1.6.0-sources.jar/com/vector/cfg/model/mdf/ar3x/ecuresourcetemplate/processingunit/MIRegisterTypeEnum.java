package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;
import javax.jmi.model.*;

public enum MIRegisterTypeEnum implements javax.jmi.reflect.RefEnum
{
  DATA("DATA"),
  ADDRESS("ADDRESS"),
  CONTROL("CONTROL"),
  STATUS("STATUS"),
  STACK_POINTER("STACK-POINTER"),
  SPECIAL("SPECIAL");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "processingunit" );
    temp.add( "RegisterTypeEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIRegisterTypeEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
