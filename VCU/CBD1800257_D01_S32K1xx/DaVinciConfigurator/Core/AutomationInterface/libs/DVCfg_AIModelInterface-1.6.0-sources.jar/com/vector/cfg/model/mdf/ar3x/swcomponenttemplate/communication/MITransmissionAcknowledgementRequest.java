package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Requests transmission acknowledgement that data has been sent successfully. Success/failure is reported via a SendPoint of a Runnable.
 */
public interface MITransmissionAcknowledgementRequest extends com.vector.cfg.model.mdf.commoncore.autosar.MIARObject
{
  public final static String CLASS_NAME = "TransmissionAcknowledgementRequest";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MITransmissionAcknowledgementRequest> mdfGetClass();
  // attribute : timeout generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String TIMEOUT = "timeout";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo TIMEOUT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,TIMEOUT,"ar3x.swcomponenttemplate.communication.TransmissionAcknowledgementRequest",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Number of seconds before an error is reported or in case of allowed redundancy, the value is sent again.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getTimeout();
  /**
   * Number of seconds before an error is reported or in case of allowed redundancy, the value is sent again.
   * Attribute-Kind = versionAttribute   */
  public void setTimeout(java.math.BigDecimal newValue);
  // reference : senderComSpec_transmissionAcknowledge_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String SENDER_COM_SPEC_TRANSMISSION_ACKNOWLEDGE_OWNER = "senderComSpec_transmissionAcknowledge_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; OppositeRoleName: transmissionAcknowledge
  public static final ru.novosoft.mdf.impl.MDFRelationInfo SENDER_COM_SPEC_TRANSMISSION_ACKNOWLEDGE_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(SENDER_COM_SPEC_TRANSMISSION_ACKNOWLEDGE_OWNER,"ar3x.swcomponenttemplate.communication.TransmissionAcknowledgementRequest",64,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MISenderComSpec.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MISenderComSpec.TRANSMISSION_ACKNOWLEDGE_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MISenderComSpec getSenderComSpecTransmissionAcknowledgeOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setSenderComSpecTransmissionAcknowledgeOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.communication.MISenderComSpec newValue);
}
