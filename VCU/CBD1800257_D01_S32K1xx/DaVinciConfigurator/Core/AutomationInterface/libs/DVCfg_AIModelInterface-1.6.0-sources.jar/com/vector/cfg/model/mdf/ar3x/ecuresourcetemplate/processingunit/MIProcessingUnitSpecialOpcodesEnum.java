package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;
import javax.jmi.model.*;

public enum MIProcessingUnitSpecialOpcodesEnum implements javax.jmi.reflect.RefEnum
{
  BIT_MANIPULATION("BIT-MANIPULATION"),
  MUL("MUL"),
  DIV("DIV"),
  MAC("MAC"),
  FLOAT("FLOAT");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "processingunit" );
    temp.add( "ProcessingUnitSpecialOpcodesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIProcessingUnitSpecialOpcodesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
