package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Describes one volatile memory segment.
 */
public interface MIProvidedMemorySegment extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWElement
{
  public final static String CLASS_NAME = "ProvidedMemorySegment";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIProvidedMemorySegment> mdfGetClass();
  // attribute : segmentSize generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SEGMENT_SIZE = "segmentSize";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SEGMENT_SIZE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SEGMENT_SIZE,"ar3x.ecuresourcetemplate.memory.ProvidedMemorySegment",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * A value that determines the amount of bytes within the memory segment. An ECU for AUTOSAR always contains at least one memory segment. Within a single ECU different memory types and access types can be used simultaneously. An ECU may consist of different parts that carry one or more memories. Segment size is defined in the terms of Bytes.  The overall amount of memory is the sum of all available memory segments. For different types of memory only the sum of the same type gives a useful overall sum. Unit: Byte
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getSegmentSize();
  /**
   * A value that determines the amount of bytes within the memory segment. An ECU for AUTOSAR always contains at least one memory segment. Within a single ECU different memory types and access types can be used simultaneously. An ECU may consist of different parts that carry one or more memories. Segment size is defined in the terms of Bytes.  The overall amount of memory is the sum of all available memory segments. For different types of memory only the sum of the same type gives a useful overall sum. Unit: Byte
   * Attribute-Kind = versionAttribute   */
  public void setSegmentSize(java.math.BigInteger newValue);
  // attribute : alignment generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ALIGNMENT = "alignment";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ALIGNMENT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ALIGNMENT,"ar3x.ecuresourcetemplate.memory.ProvidedMemorySegment",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Some memory architectures are organised for bigger natural data size than accessed by the PU. In this case memory might not be used completely and some memory locations are left blank due to misalignment. The overall memory size is not used by code or data. Misalignment may be recovered by special mechanisms provided by hardware or software. In this case the access time will be increased. Certain PU architectures do not allow misalignment in code or data generally. Unit: Byte
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getAlignment();
  /**
   * Some memory architectures are organised for bigger natural data size than accessed by the PU. In this case memory might not be used completely and some memory locations are left blank due to misalignment. The overall memory size is not used by code or data. Misalignment may be recovered by special mechanisms provided by hardware or software. In this case the access time will be increased. Certain PU architectures do not allow misalignment in code or data generally. Unit: Byte
   * Attribute-Kind = versionAttribute   */
  public void setAlignment(java.math.BigInteger newValue);
  // attribute : separate generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String SEPARATE = "separate";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo SEPARATE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,SEPARATE,"ar3x.ecuresourcetemplate.memory.ProvidedMemorySegment",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Separate memories are required for safety-relevant functions and redundancy requirements.
   * Attribute-Kind = versionAttribute   */
  public Boolean getSeparate();
  /**
   * Separate memories are required for safety-relevant functions and redundancy requirements.
   * Attribute-Kind = versionAttribute   */
  public void setSeparate(Boolean newValue);
  // attribute : manufacturingQuality generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MANUFACTURING_QUALITY = "manufacturingQuality";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MANUFACTURING_QUALITY_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MANUFACTURING_QUALITY,"ar3x.ecuresourcetemplate.memory.ProvidedMemorySegment",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * As memory holds the executable program as well as the according data, memory needs a level of quality and reliability according to the purpose of the ECU. In most applications today memory is the biggest homogeneous hardware block; therefore quality and reliability of memory have the biggest impact on ECU performance and availability. With the introduction of non-volatile memory and the use of huge DRAM memories the aspect of quality and reliability gains more importance. Despite all Zero-defect programs of the semiconductor suppliers a defect rate in the range of 1 to 5 ppm must be considered as given even for critical applications. Separate quality data for Endurance and Data retention can be available also. The biggest value for ppm rates is used as a quality factor. Unit: ppm
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getManufacturingQuality();
  /**
   * As memory holds the executable program as well as the according data, memory needs a level of quality and reliability according to the purpose of the ECU. In most applications today memory is the biggest homogeneous hardware block; therefore quality and reliability of memory have the biggest impact on ECU performance and availability. With the introduction of non-volatile memory and the use of huge DRAM memories the aspect of quality and reliability gains more importance. Despite all Zero-defect programs of the semiconductor suppliers a defect rate in the range of 1 to 5 ppm must be considered as given even for critical applications. Separate quality data for Endurance and Data retention can be available also. The biggest value for ppm rates is used as a quality factor. Unit: ppm
   * Attribute-Kind = versionAttribute   */
  public void setManufacturingQuality(java.math.BigDecimal newValue);
  // reference : providedMemorySegmentARRef_refTargets_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String PROVIDED_MEMORY_SEGMENT_ARREF_REF_TARGETS_OWNER = "providedMemorySegmentARRef_refTargets_Owner";
  //TO_TARGET_IS_MULTIPLE; TO_SOURCE_IS_MULTIPLE; OppositeRoleName: refTargets
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROVIDED_MEMORY_SEGMENT_ARREF_REF_TARGETS_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROVIDED_MEMORY_SEGMENT_ARREF_REF_TARGETS_OWNER,"ar3x.ecuresourcetemplate.memory.ProvidedMemorySegment",3,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegmentARRef.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegmentARRef.REF_TARGETS_RELATION_INFO;}};
  public java.util.Collection<com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.memory.MIProvidedMemorySegmentARRef> getProvidedMemorySegmentARRefRefTargetsOwner();
  // reference : architecturalQuality generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String ARCHITECTURAL_QUALITY = "architecturalQuality";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: providedMemorySegment_architecturalQuality_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo ARCHITECTURAL_QUALITY_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(ARCHITECTURAL_QUALITY,"ar3x.ecuresourcetemplate.memory.ProvidedMemorySegment",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIErrorDetectionCorrection.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIErrorDetectionCorrection.PROVIDED_MEMORY_SEGMENT_ARCHITECTURAL_QUALITY_OWNER_RELATION_INFO;}};
  /**
   * The error detection and error correction facilities provided by the memory segment itself.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIErrorDetectionCorrection getArchitecturalQuality();
  /**
   * The error detection and error correction facilities provided by the memory segment itself.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setArchitecturalQuality(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.basicelements.MIErrorDetectionCorrection newValue);
}
