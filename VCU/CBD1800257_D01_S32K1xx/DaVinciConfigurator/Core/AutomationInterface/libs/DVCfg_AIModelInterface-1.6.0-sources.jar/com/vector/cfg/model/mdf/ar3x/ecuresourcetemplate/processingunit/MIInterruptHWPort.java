package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.processingunit;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MIInterruptHWPort extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.MIHWPort
{
  public final static String CLASS_NAME = "InterruptHWPort";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIInterruptHWPort> mdfGetClass();
}
