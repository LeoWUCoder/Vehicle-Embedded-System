package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.applicationattributes;
import javax.jmi.model.*;

public enum MIFilterDebouncingEnum implements javax.jmi.reflect.RefEnum
{
  RAW_DATA("RAW-DATA"),
  DEBOUNCE_DATA("DEBOUNCE-DATA"),
  WAIT_TIME_DATE("WAIT-TIME-DATE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "applicationattributes" );
    temp.add( "FilterDebouncingEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIFilterDebouncingEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
