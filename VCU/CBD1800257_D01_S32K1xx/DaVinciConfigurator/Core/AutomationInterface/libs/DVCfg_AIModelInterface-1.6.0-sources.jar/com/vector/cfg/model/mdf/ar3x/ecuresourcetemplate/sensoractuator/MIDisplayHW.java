package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The Display HW element derives from HW Sensor Actuator and can be connected to a PU via a serial or parallel interface. For the parallel mode the display can be connected to the data bus and address bus of a PU or to a peripheral. The most common serial interface for displays are: - I2C - SPI The most common physical interface for high resolution displays are the LVDS interface (Low Voltage Differential Signalling). This interface has three different lines for colours (RGB) and additional lines for control signals.
 */
public interface MIDisplayHW extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MISensorActuatorHW
{
  public final static String CLASS_NAME = "DisplayHW";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDisplayHW> mdfGetClass();
  // attribute : backlight generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BACKLIGHT = "backlight";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BACKLIGHT_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BACKLIGHT,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines whether the display has a background lighting. This eases the readability of the displays during bad daylight conditions.
   * Attribute-Kind = versionAttribute   */
  public Boolean getBacklight();
  /**
   * Defines whether the display has a background lighting. This eases the readability of the displays during bad daylight conditions.
   * Attribute-Kind = versionAttribute   */
  public void setBacklight(Boolean newValue);
  // attribute : brightness generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BRIGHTNESS = "brightness";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BRIGHTNESS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BRIGHTNESS,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the visibility of the display.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getBrightness();
  /**
   * Defines the visibility of the display.
   * Attribute-Kind = versionAttribute   */
  public void setBrightness(java.math.BigDecimal newValue);
  // attribute : characterGenerator generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CHARACTER_GENERATOR = "characterGenerator";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CHARACTER_GENERATOR_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CHARACTER_GENERATOR,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,Boolean.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * If the display has an in-built character generator.
   * Attribute-Kind = versionAttribute   */
  public Boolean getCharacterGenerator();
  /**
   * If the display has an in-built character generator.
   * Attribute-Kind = versionAttribute   */
  public void setCharacterGenerator(Boolean newValue);
  // attribute : characterSet generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CHARACTER_SET = "characterSet";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CHARACTER_SET_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CHARACTER_SET,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,String.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines which character set that can be handled by the display. There is a number of standardised character sets like ISO-8859-1 or Unicode.
   * Attribute-Kind = versionAttribute   */
  public String getCharacterSet();
  /**
   * Defines which character set that can be handled by the display. There is a number of standardised character sets like ISO-8859-1 or Unicode.
   * Attribute-Kind = versionAttribute   */
  public void setCharacterSet(String newValue);
  // attribute : colour generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String COLOUR = "colour";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo COLOUR_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,COLOUR,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIDisplayHwColourEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * If the display can show objects in monochrome, grey scale or in colour.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIDisplayHwColourEnum getColour();
  /**
   * If the display can show objects in monochrome, grey scale or in colour.
   * Attribute-Kind = versionAttribute   */
  public void setColour(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIDisplayHwColourEnum newValue);
  // attribute : resolutionRation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESOLUTION_RATION = "resolutionRation";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESOLUTION_RATION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESOLUTION_RATION,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the ratio of the display resolution in horizontal versus vertical direction (e.g. 16 to 9).
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getResolutionRation();
  /**
   * Defines the ratio of the display resolution in horizontal versus vertical direction (e.g. 16 to 9).
   * Attribute-Kind = versionAttribute   */
  public void setResolutionRation(java.math.BigDecimal newValue);
  // attribute : resolutionX generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESOLUTION_X = "resolutionX";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESOLUTION_X_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESOLUTION_X,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the number of the smallest graphical elements which can be displayed in horizontal direction.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getResolutionX();
  /**
   * Defines the number of the smallest graphical elements which can be displayed in horizontal direction.
   * Attribute-Kind = versionAttribute   */
  public void setResolutionX(java.math.BigInteger newValue);
  // attribute : resolutionY generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESOLUTION_Y = "resolutionY";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESOLUTION_Y_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESOLUTION_Y,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the number of the smallest graphical elements which can be displayed in vertical direction.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getResolutionY();
  /**
   * Defines the number of the smallest graphical elements which can be displayed in vertical direction.
   * Attribute-Kind = versionAttribute   */
  public void setResolutionY(java.math.BigInteger newValue);
  // attribute : responseTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESPONSE_TIME = "responseTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESPONSE_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESPONSE_TIME,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines how long it takes for the display to show a changed element at -20 degree C.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getResponseTime();
  /**
   * Defines how long it takes for the display to show a changed element at -20 degree C.
   * Attribute-Kind = versionAttribute   */
  public void setResponseTime(java.math.BigDecimal newValue);
  // attribute : btypeOfCharacters generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String BTYPE_OF_CHARACTERS = "btypeOfCharacters";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo BTYPE_OF_CHARACTERS_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,BTYPE_OF_CHARACTERS,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIDisplayHwTypeOfCharactersEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * If the display can present numerical, alpha-numerical, semi-graphical or graphical objects.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIDisplayHwTypeOfCharactersEnum getBtypeOfCharacters();
  /**
   * If the display can present numerical, alpha-numerical, semi-graphical or graphical objects.
   * Attribute-Kind = versionAttribute   */
  public void setBtypeOfCharacters(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.sensoractuator.MIDisplayHwTypeOfCharactersEnum newValue);
  // attribute : viewingAngle generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String VIEWING_ANGLE = "viewingAngle";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo VIEWING_ANGLE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,VIEWING_ANGLE,"ar3x.ecuresourcetemplate.sensoractuator.DisplayHW",null,java.math.BigInteger.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the angle range where the display can be observed.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigInteger getViewingAngle();
  /**
   * Defines the angle range where the display can be observed.
   * Attribute-Kind = versionAttribute   */
  public void setViewingAngle(java.math.BigInteger newValue);
}
