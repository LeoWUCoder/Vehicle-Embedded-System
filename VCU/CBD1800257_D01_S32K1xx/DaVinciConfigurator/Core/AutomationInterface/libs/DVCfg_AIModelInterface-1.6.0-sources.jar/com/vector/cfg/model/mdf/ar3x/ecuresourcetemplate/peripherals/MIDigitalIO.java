package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Digital Input/Output peripherals provide the capability to send/receive data in a digital manner. Each digital input has an electrical range. When the voltage is less than a specified level, the input is represents logical low '0'. On the opposite when the voltage is higher than a specified value the input represents logical high '1'. A digital I/O can usually be programmed to be either an input or output. It can also be programmed to logically invert the input or output. The maximum frequency of a digital input or output is related to how fast the PU can read or write to the digital I/O register. It's very common for a digital I/O to have different functionality. One example is when a timer has an external clock signal associated with a digital I/O. In this case the maximum frequency is defined by the performance of the timer counter and can be found in the electrical characteristic of the peripheral datasheet.
 */
public interface MIDigitalIO extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIPeripheral
{
  public final static String CLASS_NAME = "DigitalIO";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIDigitalIO> mdfGetClass();
  // attribute : edgeDetection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String EDGE_DETECTION = "edgeDetection";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo EDGE_DETECTION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,EDGE_DETECTION,"ar3x.ecuresourcetemplate.peripherals.DigitalIO",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIDigitalIoEdgeDetectionEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * A general digital input can be enabled to trigger an interrupt on a falling, rising or both edges of an input signal. A clock, compare or count input on a timer can be programmed to increase, decrease or store the timer value if a change on the input pin has occurred. The condition for this change can be programmed to trigger an event  in the same manner as for a digital input.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIDigitalIoEdgeDetectionEnum getEdgeDetection();
  /**
   * A general digital input can be enabled to trigger an interrupt on a falling, rising or both edges of an input signal. A clock, compare or count input on a timer can be programmed to increase, decrease or store the timer value if a change on the input pin has occurred. The condition for this change can be programmed to trigger an event  in the same manner as for a digital input.
   * Attribute-Kind = versionAttribute   */
  public void setEdgeDetection(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.peripherals.MIDigitalIoEdgeDetectionEnum newValue);
}
