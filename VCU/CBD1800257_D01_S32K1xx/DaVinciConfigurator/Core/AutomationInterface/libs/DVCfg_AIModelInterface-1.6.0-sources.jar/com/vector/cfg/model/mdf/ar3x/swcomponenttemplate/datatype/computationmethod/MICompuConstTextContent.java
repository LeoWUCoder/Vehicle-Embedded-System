package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

public interface MICompuConstTextContent extends com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.computationmethod.MICompuConstContent
{
  public final static String CLASS_NAME = "CompuConstTextContent";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MICompuConstTextContent> mdfGetClass();
  // reference : vt generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String VT = "vt";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: compuConstTextContent_vt_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo VT_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(VT,"ar3x.swcomponenttemplate.datatype.computationmethod.CompuConstTextContent",128,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVt.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVt.COMPU_CONST_TEXT_CONTENT_VT_OWNER_RELATION_INFO;}};
  /**
   * <vt> represents one particular textual value of the calibration item.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVt getVt();
  /**
   * <vt> represents one particular textual value of the calibration item.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setVt(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.datatype.valuemodel.MIVt newValue);
}
