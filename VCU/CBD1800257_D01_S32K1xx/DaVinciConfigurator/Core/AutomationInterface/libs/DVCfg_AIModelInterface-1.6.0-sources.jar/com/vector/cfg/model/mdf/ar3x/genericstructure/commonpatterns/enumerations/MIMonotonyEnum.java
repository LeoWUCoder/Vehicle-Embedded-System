package com.vector.cfg.model.mdf.ar3x.genericstructure.commonpatterns.enumerations;
import javax.jmi.model.*;

public enum MIMonotonyEnum implements javax.jmi.reflect.RefEnum
{
  INCREASING("INCREASING"),
  DECREASING("DECREASING"),
  STRICTLY_INCREASING("STRICTLY-INCREASING"),
  STRICTLY_DECREASING("STRICTLY-DECREASING"),
  NO_MONOTONY("NO-MONOTONY");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "enumerations" );
    temp.add( "MonotonyEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIMonotonyEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
