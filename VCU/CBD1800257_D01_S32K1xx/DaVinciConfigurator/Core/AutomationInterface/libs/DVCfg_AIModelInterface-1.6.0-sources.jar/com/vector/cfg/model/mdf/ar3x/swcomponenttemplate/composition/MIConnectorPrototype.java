package com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * The base class for connectors between ports. Connectors have to be identifiable to allow references from the system constraint template.
 */
public interface MIConnectorPrototype extends com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable
{
  public final static String CLASS_NAME = "ConnectorPrototype";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIConnectorPrototype> mdfGetClass();
  // reference : compositionType_compositionTypeConnector_Owner generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String COMPOSITION_TYPE_COMPOSITION_TYPE_CONNECTOR_OWNER = "compositionType_compositionTypeConnector_Owner";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_TARGET_IS_COMPOSITE; TO_SOURCE_IS_MULTIPLE; TO_SOURCE_IS_ORDERED; OppositeRoleName: compositionTypeConnector
  public static final ru.novosoft.mdf.impl.MDFRelationInfo COMPOSITION_TYPE_COMPOSITION_TYPE_CONNECTOR_OWNER_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(COMPOSITION_TYPE_COMPOSITION_TYPE_CONNECTOR_OWNER,"ar3x.swcomponenttemplate.composition.ConnectorPrototype",74,null,com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionType.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionType.COMPOSITION_TYPE_CONNECTOR_RELATION_INFO;}};
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionType getCompositionTypeCompositionTypeConnectorOwner();
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setCompositionTypeCompositionTypeConnectorOwner(com.vector.cfg.model.mdf.ar3x.swcomponenttemplate.composition.MICompositionType newValue);
}
