package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Specifies the abstract needs on the configuration of the Communication Manager for one "user".
 */
public interface MIComMgrUserNeeds extends com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIServiceNeeds
{
  public final static String CLASS_NAME = "ComMgrUserNeeds";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIComMgrUserNeeds> mdfGetClass();
  // attribute : maxCommMode generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAX_COMM_MODE = "maxCommMode";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAX_COMM_MODE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAX_COMM_MODE,"ar3x.commonstructure.serviceneeds.ComMgrUserNeeds",null,com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIMaxCommModeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximum communication mode requested by this ComM user
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIMaxCommModeEnum getMaxCommMode();
  /**
   * Maximum communication mode requested by this ComM user
   * Attribute-Kind = versionAttribute   */
  public void setMaxCommMode(com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds.MIMaxCommModeEnum newValue);
}
