package com.vector.cfg.model.mdf.ar3x.commonstructure.swclass;
import javax.jmi.model.*;

public enum MISwClassPrototypeTypesEnum implements javax.jmi.reflect.RefEnum
{
  SW_CLASS_PROTOTYPE("SW-CLASS-PROTOTYPE");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "swclass" );
    temp.add( "SwClassPrototypeTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MISwClassPrototypeTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
