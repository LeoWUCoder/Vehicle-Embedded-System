package com.vector.cfg.model.mdf.ar3x.commonstructure.serviceneeds;
import javax.jmi.model.*;

public enum MIFunctionInhibitionNeedsTypesEnum implements javax.jmi.reflect.RefEnum
{
  FUNCTION_INHIBITION_NEEDS("FUNCTION-INHIBITION-NEEDS"),
  SWC_FUNCTION_INHIBITION_NEEDS("SWC-FUNCTION-INHIBITION-NEEDS");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "serviceneeds" );
    temp.add( "FunctionInhibitionNeedsTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIFunctionInhibitionNeedsTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
