package com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * Power Driver HW Element describes a group of electronic devices, which perform signal transformations with hardware devices. The main focus of the ECU Resource Template is the logical description of these elements, necessary for the system generation and relevant for the SW development.
 */
public interface MIPowerDriverHWElement extends com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIECUElectronics
{
  public final static String CLASS_NAME = "PowerDriverHWElement";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIPowerDriverHWElement> mdfGetClass();
  // attribute : currentLimitation generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String CURRENT_LIMITATION = "currentLimitation";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo CURRENT_LIMITATION_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,CURRENT_LIMITATION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverHWElement",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The device limits the maximum current conduction. The limit has to be specified. If this element does not occur the HW Element does not provide current limitation. Unit: Ampere
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getCurrentLimitation();
  /**
   * The device limits the maximum current conduction. The limit has to be specified. If this element does not occur the HW Element does not provide current limitation. Unit: Ampere
   * Attribute-Kind = versionAttribute   */
  public void setCurrentLimitation(java.math.BigDecimal newValue);
  // attribute : defaultResetBehaviuor generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String DEFAULT_RESET_BEHAVIUOR = "defaultResetBehaviuor";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo DEFAULT_RESET_BEHAVIUOR_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,DEFAULT_RESET_BEHAVIUOR,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverHWElement",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementDefaultResetBehaviorEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementDefaultResetBehaviorEnum getDefaultResetBehaviuor();
  /**
   * Attribute-Kind = versionAttribute   */
  public void setDefaultResetBehaviuor(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementDefaultResetBehaviorEnum newValue);
  // attribute : onStateResistance generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String ON_STATE_RESISTANCE = "onStateResistance";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo ON_STATE_RESISTANCE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,ON_STATE_RESISTANCE,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverHWElement",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * The resistance in ON state can be used together with the current through this element to determine the static thermal power dissipation of the element itself and the ECU completely by summing up each element with power dissipation. As the heating up of an power element follows with an exponential delay, the ratio of on and off times is later needed in the system generation process. This information can give the first hint on critical issues of thermal design, but does not replace a complete static and dynamic verification of the thermal layout. Unit: Ohm
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getOnStateResistance();
  /**
   * The resistance in ON state can be used together with the current through this element to determine the static thermal power dissipation of the element itself and the ECU completely by summing up each element with power dissipation. As the heating up of an power element follows with an exponential delay, the ratio of on and off times is later needed in the system generation process. This information can give the first hint on critical issues of thermal design, but does not replace a complete static and dynamic verification of the thermal layout. Unit: Ohm
   * Attribute-Kind = versionAttribute   */
  public void setOnStateResistance(java.math.BigDecimal newValue);
  // attribute : powerDriverType generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String POWER_DRIVER_TYPE = "powerDriverType";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo POWER_DRIVER_TYPE_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,POWER_DRIVER_TYPE,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverHWElement",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementPowerDriverTypeEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Defines the general type of the element. Type is a most common naming for an element. Several sets of types exist. Type is mandatory for the usage of the ECU Resource Template.
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementPowerDriverTypeEnum getPowerDriverType();
  /**
   * Defines the general type of the element. Type is a most common naming for an element. Several sets of types exist. Type is mandatory for the usage of the ECU Resource Template.
   * Attribute-Kind = versionAttribute   */
  public void setPowerDriverType(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementPowerDriverTypeEnum newValue);
  // attribute : resetOnFaultBehaviour generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String RESET_ON_FAULT_BEHAVIOUR = "resetOnFaultBehaviour";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo RESET_ON_FAULT_BEHAVIOUR_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,RESET_ON_FAULT_BEHAVIOUR,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverHWElement",null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementResetOnFaultBehaviourEnum.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Describe the way the element is reactivated after a self protection sequence was entered
   * Attribute-Kind = versionAttribute   */
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementResetOnFaultBehaviourEnum getResetOnFaultBehaviour();
  /**
   * Describe the way the element is reactivated after a self protection sequence was entered
   * Attribute-Kind = versionAttribute   */
  public void setResetOnFaultBehaviour(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIHwElementResetOnFaultBehaviourEnum newValue);
  // reference : protection generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String PROTECTION = "protection";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: powerDriverHWElement_protection_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo PROTECTION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(PROTECTION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverHWElement",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverProtection.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverProtection.POWER_DRIVER_HWELEMENT_PROTECTION_OWNER_RELATION_INFO;}};
  /**
   * Which kind of protection is available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverProtection getProtection();
  /**
   * Which kind of protection is available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setProtection(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverProtection newValue);
  // reference : notification generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public static final String NOTIFICATION = "notification";
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  //TO_SOURCE_IS_COMPOSITE; OppositeRoleName: powerDriverHWElement_notification_Owner
  public static final ru.novosoft.mdf.impl.MDFRelationInfo NOTIFICATION_RELATION_INFO = new ru.novosoft.mdf.impl.MDFRelationInfo(NOTIFICATION,"ar3x.ecuresourcetemplate.ecuelectronics.PowerDriverHWElement",128,null,com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverNotification.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class), java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class)) {public ru.novosoft.mdf.impl.MDFRelationInfo getOppositeRelationInfo() {return com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverNotification.POWER_DRIVER_HWELEMENT_NOTIFICATION_OWNER_RELATION_INFO;}};
  /**
   * Which kind of notification to the PU is available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverNotification getNotification();
  /**
   * Which kind of notification to the PU is available.
   */
  @com.vector.cfg.model.mdf.annotation.AtpStatus(com.vector.cfg.model.mdf.annotation.AtpStatus.AtpStatusEnum.valid)
  public void setNotification(com.vector.cfg.model.mdf.ar3x.ecuresourcetemplate.ecuelectronics.MIPowerDriverNotification newValue);
}
