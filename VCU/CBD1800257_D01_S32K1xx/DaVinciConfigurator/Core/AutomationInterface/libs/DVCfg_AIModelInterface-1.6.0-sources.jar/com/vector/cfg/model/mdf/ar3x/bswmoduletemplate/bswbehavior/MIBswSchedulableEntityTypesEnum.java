package com.vector.cfg.model.mdf.ar3x.bswmoduletemplate.bswbehavior;
import javax.jmi.model.*;

public enum MIBswSchedulableEntityTypesEnum implements javax.jmi.reflect.RefEnum
{
  BSW_SCHEDULABLE_ENTITY("BSW-SCHEDULABLE-ENTITY");

  private final java.lang.String literalName;
  private static final java.util.List typeName;
  static
  {
    java.util.ArrayList temp = new java.util.ArrayList();
    temp.add( "bswbehavior" );
    temp.add( "BswSchedulableEntityTypesEnum" );
    typeName = java.util.Collections.unmodifiableList(temp);
  }
  public java.util.List refTypeName()
  {
    return typeName;
  }
  public String toString()
  {
    return literalName;
  }
  private MIBswSchedulableEntityTypesEnum(String literalName)
  {
    this.literalName = literalName;
  }
}
