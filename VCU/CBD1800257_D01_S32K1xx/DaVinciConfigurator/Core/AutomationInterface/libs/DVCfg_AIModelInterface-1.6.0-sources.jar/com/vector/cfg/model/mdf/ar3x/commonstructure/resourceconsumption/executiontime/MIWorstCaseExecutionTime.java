package com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime;

//Suppress warnings because it is generated code
//CHECKSTYLE:OFF

/**
 * WorstCaseExecutionTime provides an analytic method for specifying the minimum and maximum execution time.
 */
public interface MIWorstCaseExecutionTime extends com.vector.cfg.model.mdf.ar3x.commonstructure.resourceconsumption.executiontime.MIExecutionTime
{
  public final static String CLASS_NAME = "WorstCaseExecutionTime";
  
  ru.novosoft.mdf.ext.MDFClass<? extends MIWorstCaseExecutionTime> mdfGetClass();
  // attribute : maximalExecutionTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MAXIMAL_EXECUTION_TIME = "maximalExecutionTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MAXIMAL_EXECUTION_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MAXIMAL_EXECUTION_TIME,"ar3x.commonstructure.resourceconsumption.executiontime.WorstCaseExecutionTime",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Maximum WorstCaseExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMaximalExecutionTime();
  /**
   * Maximum WorstCaseExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public void setMaximalExecutionTime(java.math.BigDecimal newValue);
  // attribute : minimalExecutionTime generated in ru.novosoft.mdf.generator.jmi.GenMMObject#generateMethods
  public static final String MINIMAL_EXECUTION_TIME = "minimalExecutionTime";
  //VERSION_ATTRIBUTE; NO_INITIAL_VALUE_DEFINED
  public static final ru.novosoft.mdf.impl.MDFAttributeInfo MINIMAL_EXECUTION_TIME_ATTRIBUTE_INFO = new ru.novosoft.mdf.impl.MDFAttributeInfo(64,MINIMAL_EXECUTION_TIME,"ar3x.commonstructure.resourceconsumption.executiontime.WorstCaseExecutionTime",null,java.math.BigDecimal.class, java.util.EnumSet.noneOf(ru.novosoft.mdf.ext.MDFTag.class));
  /**
   * Minimum WorstCaseExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public java.math.BigDecimal getMinimalExecutionTime();
  /**
   * Minimum WorstCaseExecutionTime.
   * Attribute-Kind = versionAttribute   */
  public void setMinimalExecutionTime(java.math.BigDecimal newValue);
}
