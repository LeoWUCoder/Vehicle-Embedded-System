package com.vector.cfg.core.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class InvalidSipLicenseException extends RuntimeException {

    private static final long serialVersionUID = 6906907630440716111L;

    /**
     * Constructor.
     *
     * @param buildMessage
     */
    @PublishedMethod
    public InvalidSipLicenseException(final String message) {
        super(message);
    }

}
