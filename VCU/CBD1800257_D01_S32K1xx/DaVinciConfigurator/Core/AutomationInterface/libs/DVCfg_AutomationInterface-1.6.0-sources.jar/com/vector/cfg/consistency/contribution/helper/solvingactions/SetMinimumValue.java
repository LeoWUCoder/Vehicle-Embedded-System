package com.vector.cfg.consistency.contribution.helper.solvingactions;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.internal.contribution.helper.solvingactions.SetValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFloatParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIIntegerParamDef;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class SetMinimumValue extends SetValue<MINumericalValue> {

    /**
     * Constructor for SetDefaultValue.
     *
     * @param parameter
     * @param defaultValue
     */
    @PublishedMethod
    public SetMinimumValue(MINumericalValue parameter, Object defaultValue) {
        super(parameter, defaultValue);
        setTargetValueInfo(MixedText.newBuilder().append("minimum value").flushResult());
    }

    @PublishedMethod
    public static SetMinimumValue create(MIParameterValue parameter) {
        SetMinimumValue ret = null;
        try {
            final MIConfigParameter configParameter = parameter.getDefinitionRef().getRefTarget();
            if (configParameter instanceof MIFloatParamDef) {
                final BigDecimal val = getAsFloat(((MIFloatParamDef) configParameter).getMin());
                if (val != null) {
                    ret = new SetMinimumValue((MINumericalValue) parameter, val);
                }
            } else if (configParameter instanceof MIIntegerParamDef) {
                final BigInteger val = getAsInteger(((MIIntegerParamDef) configParameter).getMin());
                if (val != null) {
                    ret = new SetMinimumValue((MINumericalValue) parameter, val);
                }
            }
        } catch (final Throwable e) {
            ret = null;
        }
        return ret;
    }
}
