package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class NoRelatedModuleConfigurationException extends ModelInconsistencyException {

    private static final long serialVersionUID = -8478089445617480759L;

    private final String objectLink;

    /**
     * Constructor.
     *
     * The specified object has no related module configuration.
     */
    @PublishedMethod
    public NoRelatedModuleConfigurationException(String objectLink) {
        super("The model object '" + objectLink + "' has no related module configuration");
        this.objectLink = objectLink;
    }

    @PublishedMethod
    public String getObj() {
        return objectLink;
    }

}
