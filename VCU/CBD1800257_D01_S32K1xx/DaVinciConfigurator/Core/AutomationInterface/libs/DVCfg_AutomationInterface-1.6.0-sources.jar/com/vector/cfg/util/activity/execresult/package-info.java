/**
 * Activity execution result interfaces and base types.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.activity.execresult;