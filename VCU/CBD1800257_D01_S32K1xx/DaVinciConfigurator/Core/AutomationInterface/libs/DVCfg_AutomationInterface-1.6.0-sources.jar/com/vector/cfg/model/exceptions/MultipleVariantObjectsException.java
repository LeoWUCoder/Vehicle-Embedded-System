package com.vector.cfg.model.exceptions;

import static com.vector.davinci.util.base.VUtil.NL;
import static com.google.common.base.Preconditions.checkArgument;

import java.util.Collection;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.util.text.format.FormattingService;

/**
 * This exception is being thrown in contexts were only one reference target is being expected but several are available.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class MultipleVariantObjectsException extends ModelVariantException {

    private static final long serialVersionUID = 2275917416662737460L;

    private final Collection<? extends MIObject> affectedObjects;

    @KeepSecretFromPublishedApi
    public MultipleVariantObjectsException(String message, MIObject source, Collection<? extends MIObject> affectedObjects) {
        this(message, source, affectedObjects, null);

    }

    @KeepSecretFromPublishedApi
    public MultipleVariantObjectsException(String message, Collection<? extends MIObject> affectedObjects) {
        this(message, null, affectedObjects, null);

    }

    @KeepSecretFromPublishedApi
    public MultipleVariantObjectsException(String message, MIObject source, Collection<? extends MIObject> affectedObjects, Throwable innerEx) {
        super(message, getSourceByAffectedObjects(source, affectedObjects), innerEx);

        this.affectedObjects = ImmutableList.copyOf(affectedObjects);

    }

    /**
     * Gets the source by affected objects.
     *
     * <p>
     * If passed source is not <code>null</code> the passed source is used, otherwise the first element of affectedObjectsLoc is used.
     * </p>
     *
     * @param source the source
     * @param affectedObjectsLoc the affected objects loc
     * @return the source by affected objects
     */
    private static MIObject getSourceByAffectedObjects(MIObject source, Collection<? extends MIObject> affectedObjectsLoc) {
        if (source == null) {
            checkArgument(affectedObjectsLoc.size() > 0);
            return affectedObjectsLoc.iterator().next();
        }
        return source;
    }

    @KeepSecretFromPublishedApi
    public MultipleVariantObjectsException(String message, Collection<? extends MIObject> affectedObjects, Throwable innerEx) {
        this(message, null, affectedObjects, innerEx);

    }

    @Override
    @PublishedMethod
    public String getMessage() {
        final StringBuilder builder = new StringBuilder();
        builder.append(super.getMessage());

        if (affectedObjects != null && !affectedObjects.isEmpty()) {
            builder.append(" " + NL + "Affected MDFObjects: " + NL + "\t");
            builder.append(FormattingService.INSTANCE.formatCollection(affectedObjects, NL + "\t"));
        }
        return builder.toString();
    }

    @PublishedMethod
    public Collection<? extends MIObject> getAffectedObjects() {
        return affectedObjects;
    }

}
