package com.vector.cfg.gen.core.gencore.generationsteps;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * ExecutionType (E.g. SERIAL, PARALLEL)
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum EGenStepExecutionType {
    SERIAL("Serial"),
    PARALLEL("Parallel");

    private final String descriptiveName;

    EGenStepExecutionType(final String descriptiveName) {
        this.descriptiveName = descriptiveName;

    }

    @PublishedMethod
    public static EGenStepExecutionType parseDescriptiveName(final String name) {
        if ("Serial".equals(name)) {
            return SERIAL;
        }
        if ("Parallel".equals(name)) {
            return PARALLEL;
        }

        return null;
    }

    @PublishedMethod
    public String getDescriptiveName() {
        return descriptiveName;
    }

    @KeepSecretFromPublishedApi
    public static String[] getLiterals() {
        final EGenStepExecutionType[] values = values();
        final String[] result = new String[values.length];
        for (int i = 0; i < values.length; ++i) {
            result[i] = values[i].getDescriptiveName();
        }
        return result;
    }
}
