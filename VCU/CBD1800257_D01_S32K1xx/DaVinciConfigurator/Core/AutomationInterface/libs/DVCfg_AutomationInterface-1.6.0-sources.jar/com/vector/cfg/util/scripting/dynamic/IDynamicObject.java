package com.vector.cfg.util.scripting.dynamic;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IDynamicObject} provides access to dynamically bound properties and methods. The {@link IDynamicObject} APi is used to enrich instance with other instances at runtime.
 * This is especially useful if the instance to enrich is lower in the stack than the element to add.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IDynamicObjectAware
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDynamicObject {

    /**
     * Returns <code>true</code>, if the {@link IDynamicObject} has the requested property.
     *
     * @param propName the property name
     * @return true, if exists.
     */
    @PublishedMethod
    boolean hasProperty(String propName);

    /**
     * Gets the property.
     *
     * @param propName the prop name
     * @return the property
     * @throws DynamicMissingPropertyException the missing property exception
     */
    @PublishedMethod
    Object getProperty(String propName);

    /**
     * Sets the property.
     *
     * @param propName the prop name
     * @param value the value
     * @throws DynamicMissingPropertyException the missing property exception
     */
    @PublishedMethod
    void setProperty(String propName, Object value);

    /**
     * Returns <code>true</code>, if the {@link IDynamicObject} has the requested method.
     *
     * @param methodName the method name
     * @param arguments the arguments
     * @return true, if exists.
     */
    @PublishedMethod
    boolean hasMethod(String methodName, Object... arguments);

    /**
     * Invoke method.
     *
     * @param methodName the method name
     * @param arguments the arguments
     * @return the object
     * @throws DynamicMissingMethodException the missing method exception
     */
    @PublishedMethod
    Object invokeMethod(String methodName, Object... arguments);

}
