package com.vector.cfg.model.query.modeltraverser.strategies;

import static com.vector.cfg.util.text.format.Formatting.format;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
//CHECKSTYLE:OFF
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IInvalidTraverserView;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.ITraverserView;
import com.vector.cfg.model.query.modeltraverser.Path;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

//CHECKSTYLE:ON
/**
 * The {@link ViewProcessingTraverseStrategy} provides a base implementation for the {@link IViewProcessingTraverseStrategy} interface. See
 * {@link IViewProcessingTraverseStrategy} for code samples and usage.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see ITraverseStrategy
 * @see Path
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public abstract class ViewProcessingTraverseStrategy<PARENT_CFG extends MIHasDefinition, ELEM_CFG extends MIHasDefinition> extends TraverseStrategy implements
        IViewProcessingTraverseStrategy {

    /**
     * Instantiates a new traverser strategy.
     *
     * @param projectContext the project context
     * @param parentDefRef the parent {@link DefRef}, could be <code>null</code>, if the {@link ITraverseStrategy} is for the MainElement.
     * @param elementDefRef the element {@link DefRef} which shall be processed.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the projectContext parameter is null</li>
     * <li>if the elementDefRef parameter is null</li>
     * </ul>
     *
     */
    @PublishedMethod
    protected ViewProcessingTraverseStrategy(@Nonnull IProjectContext projectContext, @Nullable TypedDefRef<?, PARENT_CFG, ?> parentDefRef,
            @Nonnull TypedDefRef<?, ELEM_CFG, ?> elementDefRef) {
        super(projectContext, parentDefRef, elementDefRef);

    }

    /*
     * Interface impl
     */

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    public TypedDefRef<?, PARENT_CFG, ?> getParentDefRef() {
        return (TypedDefRef<?, PARENT_CFG, ?>) super.getParentDefRef();
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    public TypedDefRef<?, ELEM_CFG, ?> getDefRef() {
        return (TypedDefRef<?, ELEM_CFG, ?>) super.getDefRef();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    public final boolean acceptView(IInvalidTraverserView currentView, MIHasDefinition parent, MIHasDefinition currentElem) {
        checkElements(parent, currentElem);
        return acceptViewInternal(currentView, (PARENT_CFG) parent, (ELEM_CFG) currentElem);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    public final boolean acceptElement(IInvalidTraverserView currentView, MIHasDefinition parent, MIHasDefinition currentElem) {
        checkElements(parent, currentElem);
        return acceptElementInternal(currentView, (PARENT_CFG) parent, (ELEM_CFG) currentElem);
    }

    /**
     * @param parent
     * @param currentElem
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the value is null</li>
     * </ul>
     */
    private void checkElements(MIHasDefinition parent, MIHasDefinition currentElem) {

        if (getParentDefRef() != null) {
            if (!getParentDefRef().isDefinitionOf(parent)) {
                throw new IllegalArgumentException(format("The passed Parent {0} is not an instance of the specified parent definition {1}.", parent,
                        getParentDefRef()));
            }
        }

        if (!getDefRef().isDefinitionOf(currentElem)) {
            throw new IllegalArgumentException(format("The passed currentElement {0} is not an instance of the specified element definition {1}.", currentElem,
                    getDefRef()));
        }
    }

    /**
     * {@link #acceptViewInternal(IInvalidTraverserView, MIHasDefinition, MIHasDefinition)} is call for each currentElement in the instance tree.
     * <p>
     * If true is returned the process continues. If false is returned, the whole {@link ITraverserView} is marked as {@link IInvalidTraverserView} and returned to the called of
     * the {@link IModelTraverser}.
     * </p>
     *
     * <p>
     * Attention:The parent parameter is <code>null</code>, if the currentElem is the MainElement (root) of the {@link IModelTraverser} execution!
     * </p>
     *
     * <p>
     * The default implementation always returns <code>true</code>.
     * </p>
     *
     * @param currentView the {@link IInvalidTraverserView} before the Multiplicity checks were performed.
     * @param parent the parent configuration element of the currentElement, matching to the {@link #getParentDefRef()}. Could be <code>null</code>.
     * @param currentElem the current element to process, which matches to the {@link #getDefRef()}.
     * @return true, if the view shall be kept, otherwise false.
     */
    @PublishedMethod
    protected boolean acceptViewInternal(IInvalidTraverserView currentView, PARENT_CFG parent, ELEM_CFG currentElem) {
        return true;
    }

    /**
     * {@link #acceptViewInternal(IInvalidTraverserView, MIHasDefinition, MIHasDefinition)} is call for each currentElement in the instance tree.
     * <p>
     * If true is returned the element is kept in the instance tree. If false is returned, the currentElem is removed from the instance tree.
     * </p>
     *
     * <p>
     * Attention:The parent parameter is <code>null</code>, if the currentElem is the MainElement (root) of the {@link IModelTraverser} execution!
     * </p>
     *
     * <p>
     * The default implementation always returns <code>true</code>.
     * </p>
     *
     * @param currentView the {@link IInvalidTraverserView} before the Multiplicity checks were performed.
     * @param parent the parent configuration element of the currentElement, matching to the {@link #getParentDefRef()}. Could be <code>null</code>.
     * @param currentElem the current element to process, which matches to the {@link #getDefRef()}.
     * @return true, if the currentElem shall be kept, otherwise false.
     */
    @PublishedMethod
    protected boolean acceptElementInternal(IInvalidTraverserView currentView, PARENT_CFG parent, ELEM_CFG currentElem) {
        return true;
    }

}
