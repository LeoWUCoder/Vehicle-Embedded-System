package com.vector.cfg.automation.scripting.base;

import java.util.Map;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IScriptTaskUserData} caches data for a {@link IScriptTask}.
 *
 * <div class="extdoc" id="Common"> The {@link IScriptTaskUserData} provides methods to retrieve and store properties by a key (like a {@link Map}). The retrieval and store
 * methods are {@link Object} based, so any {@link Object} can be a key. The exception are {@link Class} instances (like <code>String.class</code>, which required that the value
 * is an instance of the {@link Class}).
 * <p>
 * On retrieval if a property does not exist an {@link UnknownPropertyException} is thrown. Properties can be set multiple times and will override the old value. The keys of the
 * properties used to retrieve and store data are compared with {@link Object#equals(Object)} for equality.
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptTaskUserData {

    /**
     * Retrieves a property value for the given key.
     *
     * <p>
     * The keys used to retrieve the value are compared with {@link Object#equals(Object)} for equality.
     * </p>
     *
     * @param propertyName the name of the property of interest
     * @return the given property
     * @throws UnknownPropertyException if the requested property does not exist
     */
    @PublishedMethod
    @Nullable
    Object get(@Nonnull Object key);

    /**
     * Returns <code>true</code>, if a value exists for the given key. The value may be <code>null</code>.
     *
     * @param key the key
     * @return true, if a value exists.
     */
    @PublishedMethod
    boolean has(@Nonnull Object key);

    /**
     * Sets the given property to the new value.
     *
     * @param propertyName the name of the property of interest
     * @param newValue the new value for the property
     */
    @PublishedMethod
    @Nullable
    Object set(@Nonnull Object key, @Nullable Object newValue);

    /**
     * Retrieves a property value.
     *
     * @param propertyName the name of the property of interest
     * @return the given property
     */
    @PublishedMethod
    <T> T get(Class<T> key);

    /**
     * Sets the given property to the new value.
     *
     * @param propertyName the name of the property of interest
     * @param newValue the new value for the property
     */
    @PublishedMethod
    <T> Object set(Class<T> key, T newValue);

    /**
     * Gets the value of the key. See {@link #get(Object)}.
     *
     * @param key the key
     * @return the value
     */
    @PublishedMethod
    Object getAt(Object key);

    /**
     * Gets the value of the key class. See {@link #get(Class)}.
     *
     * @param key the key
     * @return the value
     */
    @PublishedMethod
    <T> T getAt(Class<T> key);

    /**
     * Gets the value of the key class. See {@link #set(Class)}.
     *
     * @param key the key
     * @return the value
     */
    @PublishedMethod
    <T> void putAt(Class<T> key, T value);

    /**
     * Sets the value of the key. See {@link #set(Object)}.
     *
     * @param key the key
     * @return the value
     */
    @PublishedMethod
    void putAt(Object key, Object value);

    /**
     * Returns an Immutable Map of the current assigned properties of the {@link IScriptTaskUserData}.
     *
     * @return the properties
     */
    @PublishedMethod
    @Nonnull
    Map<Object, Object> getProperties();

    /**
     * The Class {@link UnknownPropertyException} is thrown by {@link IScriptTaskUserData} if a property is requested with a key that does not exist.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    class UnknownPropertyException extends IllegalArgumentException {
        private static final long serialVersionUID = -9058326933390054802L;

        @PublishedMethod
        public UnknownPropertyException(String s) {
            super(s);
        }

    }
}
