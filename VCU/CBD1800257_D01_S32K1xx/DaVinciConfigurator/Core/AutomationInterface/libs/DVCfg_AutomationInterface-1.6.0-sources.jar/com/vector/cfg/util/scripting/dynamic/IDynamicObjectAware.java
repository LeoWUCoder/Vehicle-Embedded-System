package com.vector.cfg.util.scripting.dynamic;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * A instance implementing {@link IDynamicObjectAware} marks itself that it has an underlying {@link IDynamicObject}, which could be enhanced at runtime.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IDynamicObject
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDynamicObjectAware {

    /**
     * Returns a {@link DynamicObject} for this object.
     *
     * @return The dynamic object.
     */
    @PublishedMethod
    IDynamicObject getAsDynamicObject();
}
