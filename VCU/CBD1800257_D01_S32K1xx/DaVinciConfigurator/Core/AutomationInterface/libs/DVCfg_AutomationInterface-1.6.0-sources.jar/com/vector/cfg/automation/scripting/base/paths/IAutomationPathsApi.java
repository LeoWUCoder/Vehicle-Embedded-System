package com.vector.cfg.automation.scripting.base.paths;

import java.io.File;
import java.net.URI;
import java.net.URL;
import java.nio.file.Path;
import java.util.concurrent.Callable;
import java.util.function.Supplier;

import javax.inject.Provider;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.IScript;
import com.vector.cfg.automation.scripting.base.IScriptExecutionContext;
import com.vector.cfg.automation.scripting.base.IScriptTask;
import com.vector.cfg.util.path.IHasURI;

/**
 * <div class="extdoc" id="Common"> Script tasks could resolve relative and absolute file system paths with the {@link IAutomationPathsApi}.
 *
 * <p>
 * As entry point call <code>paths</code> in a <code>code{ }</code> block (see {@link IScriptExecutionContext#getPaths()}).
 * </p>
 *
 * There are multiple ways to resolve relative paths:
 * <ul>
 * <li>by Script folder</li>
 * <li>by Temp folder</li>
 * <li>by SIP folder</li>
 * <li>by Project folder</li>
 * <li>by any parent folder</li>
 * </ul>
 *
 * </div>
 *
 * <div class="extdoc" id="OtherPaths"> The {@link IAutomationPathsApi} will also resolve any other Vector provided path variable like <code>$(EcucFile)</code>. The call would
 * be <code>paths.ecucFile</code>, add the variable to resolve as a Groovy property.
 *
 * Short list of available variables (not complete, please see DaVinci Configurator help for more details):
 * <ul>
 * <li>EcucFile</li>
 * <li>OutputFolder</li>
 * <li>SystemFolder</li>
 * <li>AutosarFolder</li>
 * <li>more ...</li>
 * </ul>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IAutomationPathsApi {

    /**
     * Return the SIP root folder. If multiple SIP folders exist the primary folder is returned.
     *
     * @return the SIP root folder
     */
    @PublishedMethod
    Path getSipRootFolder();

    /**
     * Return the folder where the currently executed {@link IScript} is located.
     *
     * @return the script folder
     */
    @PublishedMethod
    Path getScriptFolder();

    /**
     * Return the project folder of the current active project.
     *
     * @return the dpa project folder
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if there is not active project available</li>
     * </ul>
     */
    @PublishedMethod
    Path getDpaProjectFolder();

    /**
     * Returns a temporary created file system folder for this running {@link IScriptTask}.
     * <p>
     * The {@link Path} is absolute and the folder exists.
     * </p>
     *
     * <p>
     * The folder is created at the first invocation, and will return the same folder for subsequent calls. For a new execution a new folder is returned.
     * </p>
     *
     * @return the script temp folder
     */
    @PublishedMethod
    Path getTempFolder();

    /**
     * Resolves a file path relative to the passed parentPath directory.
     *
     * <div class="extdoc" id="ResolvePathParent">
     * <h3>Path Resolution by Parent Folder</h3> The <code>resolvePath(Path parent, Object path)</code> method resolves a file path relative to supplied parent folder.
     * <p>
     * This method converts the supplied path based on its type: <!--LaTeX:\label{sec:PathResolve}-->
     * <ul>
     * <li>A {@link CharSequence}, including {@link String} or <code>GString</code>. Interpreted relative to the parent directory. A string that starts with <code>file:</code>
     * is treated as a file URL.</li>
     * <li>A {@link File}: If the file is an absolute file, it is returned as is. Otherwise, the file's path is interpreted relative to the parent directory.</li>
     * <li>A {@link Path}: If the path is an absolute path, it is returned as is. Otherwise, the path is interpreted relative to the parent directory.</li>
     * <li>A {@link URI} or {@link URL}: The URL's path is interpreted as the file path. Currently, only <code>file:</code> URLs are supported.</li>
     * <li>A {@link IHasURI}: The returned URI is interpreted as defined above.</li>
     * <li>A <code>Closure</code>: The closure's return value is resolved recursively.</li>
     * <li>A {@link Callable}: The callable's return value is resolved recursively.</li>
     * <li>A {@link Supplier}: The supplier's return value is resolved recursively.</li>
     * <li>A {@link Provider}: The provider's return value is resolved recursively.</li>
     * </ul>
     * </p>
     * <p>
     * The return type is <code>java.nio.file.Path</code>.
     * </p>
     *
     * </div>
     *
     * @param parentPath the parent path to use for relative paths
     * @param path the path to resolve as {@link Path}
     * @return the {@link Path} instance
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the path could not be converted to a {@link Path} instance</li>
     * </ul>
     */
    @PublishedMethod
    Path resolvePath(Path parentPath, Object path);

    /**
     * Resolves a file path and preserves the relative path.
     *
     * <div class="extdoc" id="ResolvePath">
     * <h3>Path Resolution</h3><!--Label:IAutomationPathsApi.resolvePath--> The {@link #resolvePath(Object)} method resolves the {@link Object} to a file path. Relative paths
     * are preserved, so relative paths are not converted into absolute paths.
     *
     * <p>
     * This method converts the supplied path same as the {@link #resolvePath(Path, Object)} method. The return type is <code>java.nio.file.Path</code>. <!--LaTeX:See
     * \vref{sec:PathResolve}.--> But it does <b>NOT</b> convert relative paths into absolute.
     * </p>
     *
     * </div>
     *
     * @param path the path to resolve as {@link Path}
     * @return the {@link Path} instance
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the path could not be converted to a {@link Path} instance</li>
     * </ul>
     */
    @PublishedMethod
    Path resolvePath(Object path);

    /**
     * Resolves a file path relative to the script directory of the executed {@link IScript} (see {@link #getScript()}).
     *
     * <div class="extdoc" id="ResolveScriptPath">
     * <h3>Script Folder Path Resolution</h3><!--Label:IAutomationPathsApi.resolveScriptPath--> The {@link #resolveScriptPath(Object)} method resolves a file path relative to
     * the script directory of the executed {@link IScript}.
     *
     * <p>
     * This method converts the supplied path same as the {@link #resolvePath(Path, Object)} method. The return type is <code>java.nio.file.Path</code>. <!--LaTeX:See
     * \vref{sec:PathResolve}.-->
     * </p>
     *
     * </div>
     *
     * @param path the path to resolve as {@link Path}
     * @return the {@link Path} instance
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the path could not be converted to a {@link Path} instance</li>
     * </ul>
     */
    @PublishedMethod
    Path resolveScriptPath(Object path);

    /**
     * Resolves a file path relative to the project directory (see {@link #getDpaProjectFolder()}) of the current active project.
     *
     * <div class="extdoc" id="ResolveProjectPath">
     * <h3>Project Folder Path Resolution</h3> The {@link #resolveProjectPath(Object)} method resolves a file path relative to the project directory (see
     * {@link #getDpaProjectFolder()}) of the current active project.
     *
     * <p>
     * This method converts the supplied path same as the {@link #resolvePath(Path, Object)} method. The return type is <code>java.nio.file.Path</code>. <!--LaTeX:See
     * \vref{sec:PathResolve}.-->
     * </p>
     *
     * <p>
     * There must be an active project to use this method. <!--LaTeX:See chapter \vref{sec:ActiveProject} for details about active projects.-->
     *
     * </div>
     *
     * @param parentPath the parent path to use for relative paths
     * @param path the path to resolve as {@link Path}
     * @return the {@link Path} instance
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the path could not be converted to a {@link Path} instance</li>
     * </ul>
     * @exception IllegalStateException
     * <ul>
     * <li>if no active project exists</li>
     * </ul>
     */
    @PublishedMethod
    Path resolveProjectPath(Object path);

    /**
     * Resolves a file path relative to the SIP directory (see {@link #getSipRootFolder()}).
     *
     * <div class="extdoc" id="ResolveSipPath">
     * <h3>SIP Folder Path Resolution</h3> The {@link #resolveSipPath(Object)} method resolves a file path relative to the SIP directory (see {@link #getSipRootFolder()}).
     *
     * <p>
     * This method converts the supplied path same as the {@link #resolvePath(Path, Object)} method. The return type is <code>java.nio.file.Path</code>. <!--LaTeX:See
     * \vref{sec:PathResolve}.-->
     * </p>
     *
     * </div>
     *
     * @param parentPath the parent path to use for relative paths
     * @param path the path to resolve as {@link Path}
     * @return the {@link Path} instance
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the path could not be converted to a {@link Path} instance</li>
     * </ul>
     */
    @PublishedMethod
    Path resolveSipPath(Object path);

    /**
     * Resolves a file path relative to the script temp directory of the executed {@link IScript} (see {@link #getScript()}).
     *
     * <div class="extdoc" id="ResolveTempPath">
     * <h3>Temp Folder Path Resolution</h3> The {@link #resolveTempPath(Object)} method resolves a file path relative to the script temp directory of the executed
     * {@link IScript}. A new temporary folder is created for each {@link IScriptTask} execution.
     *
     * <p>
     * This method converts the supplied path same as the {@link #resolvePath(Path, Object)} method. The return type is <code>java.nio.file.Path</code>. <!--LaTeX:See
     * \vref{sec:PathResolve}.-->
     * </p>
     *
     * </div>
     *
     * @param path the path to resolve as {@link Path}
     * @return the {@link Path} instance
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the path could not be converted to a {@link Path} instance</li>
     * </ul>
     */
    @PublishedMethod
    Path resolveTempPath(Object path);
}
