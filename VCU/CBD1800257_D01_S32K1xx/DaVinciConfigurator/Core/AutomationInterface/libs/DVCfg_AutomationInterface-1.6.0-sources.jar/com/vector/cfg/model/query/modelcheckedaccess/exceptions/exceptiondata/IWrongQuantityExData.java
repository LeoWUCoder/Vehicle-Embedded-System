package com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.query.modelcheckedaccess.EQuantity;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongQuantityException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess exception data for the {@link McaWrongQuantityException}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see McaWrongQuantityException
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IWrongQuantityExData extends IElementTypeExData {

    /**
     * Gets the list of affected elements which have the wrong Quantity.
     *
     * @return The list of affected elements which have the wrong Quantity.
     */
    @PublishedMethod
    List<? extends MIHasDefinition> getElementList();

    /**
     * Gets the actual Quantity of the model request.
     *
     * @return The actual Quantity of the model request.
     */
    @PublishedMethod
    EQuantity getActualdQuantity();

    /**
     * Gets the expected Quantity of the model request.
     *
     * @return The expected Quantity of the model request.
     */
    @PublishedMethod
    EQuantity getExpectedQuantity();

}
