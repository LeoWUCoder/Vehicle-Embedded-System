package com.vector.cfg.gen.core.moduleinterface.variants;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.variant.IInvariantView;
import com.vector.cfg.model.view.config.variant.IPostBuildInvariantEcucDefView;
import com.vector.cfg.model.view.config.variant.IPostBuildInvariantValuesView;
import com.vector.cfg.model.view.config.variant.IPredefinedVariantView;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" id="Common_Part"> The {@link IGenPostBuildSelectableVariantsService} provides access to all Post-build variants in the loaded project. The generator could
 * retrieve the variants or if the project has no variants the {@link IPostBuildInvariantValuesView}.
 *
 * </div>
 *
 * <div class="extdoc" id="Code_Samples">
 *
 * <pre>
 * <code class="Java" id="Retrieve a list of post-build variants for your ModuleConfiguration">
 * //Get the IGenPostBuildSelectableVariantsService
 * IGenPostBuildSelectableVariantsService variantsService = projectContext.getService(IGenPostBuildSelectableVariantsService.class);
 *
 * MIModuleConfiguration myModule = ...;
 *
 * List<IModelView> variantList = variantsService.getAllPostBuildVariantViews(myModule);
 *
 * </code>
 * </pre>
 *
 * If you do not have a ModuleConfiguration, you could use the methods:
 * <ul>
 * <li><code>getAllPostBuildVariantViews()</code></li>
 * <li><code>getAllPostBuildVariantViewsOrInvariant()</code></li>
 * </ul>
 *
 * <pre>
 * <code class="Java" id="Retrieve a list of post-build variants">
 * //Get the IGenPostBuildSelectableVariantsService
 * IGenPostBuildSelectableVariantsService variantsService = projectContext.getService(IGenPostBuildSelectableVariantsService.class);
 *
 * List<IPredefinedVariantView> variantList = variantsService.getAllPostBuildVariantViews();
 *
 * // Or the list or variants or IInvariantValuesView
 * List<IModelView> variantList  = variantsService.getAllPostBuildVariantViewsOrInvariant();
 *
 * </code>
 * </pre>
 *
 * </div>
 *
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
@ThreadSafe
public interface IGenPostBuildSelectableVariantsService {

    /**
     * Returns true, if the loaded Project contains Post-build selectable predefined variants.
     *
     * @return true, if project is variant.
     */
    @PublishedMethod
    boolean hasProjectPredefinedVariants();

    /**
     * Gets the all Post-build selectable predefined variants, in the order of the definition of the {@link IPredefinedVariantView}s.
     *
     * <p>
     * If the project is invariant (see {@link #hasProjectPredefinedVariants()}, a empty {@link List} is returned.
     * </p>
     *
     * <p>
     * <b>Attention: </b> Normally you should use the method {@link #getAllPostBuildVariantViews(MIHasDefinition)}!
     * </p>
     *
     * @return the predefined variants, or empty List.
     */
    @PublishedMethod
    List<IPredefinedVariantView> getAllPostBuildVariantViews();

    /**
     * <div class="extdoc" id="getAllPostBuildVariantViews">The method <code>getAllPostBuildVariantViews(ecucElement)</code> returns the same model views as
     * {@link #getAllPostBuildVariantViews()} if:
     * <ul>
     * <li>The module configuration of the passed object implements Post-build selectable (the configuration variant is VARIANT-POST-BUILD-SELECTABLE or VARIANT-POST-BUILD).</li>
     * <li>The loaded project has variants.</li>
     * </ul>
     *
     *
     * <p>
     * When the module configuration doesn't implement Post-build selectable or the project contains no variants at all, this method returns a list containing the
     * {@link IInvariantView} only.
     * </p>
     *
     * <p>
     * Actually the specified object is only being used to find out if the related module configuration implements variance or not. This means that even specifying a (currently)
     * invisible object is supported as long as it is member of a module configuration.
     * </p>
     *
     * <p>
     * Normally you should use this method instead of other getter methods in {@link IGenPostBuildSelectableVariantsService}, to retrieve the variants in the system. It helps you
     * to simplify and unify your code in case the project or the related module doesn't have variants.
     * </p>
     *
     * </div>
     *
     * @param anyEcucElementInASpecificModuleConfig The ecucElement, which should be used to retrieve the ModuleConfiguration.
     * @return the predefined variants, or the invariant view.
     */
    @PublishedMethod
    List<IModelView> getAllPostBuildVariantViews(MIHasDefinition anyEcucElementInASpecificModuleConfig);

    /**
     * If the project contains variants, this method returns the same list as {@link #getAllPostBuildVariantViews()}. <br/>
     *
     *
     * <p>
     * If the project contains no variants (see {@link #hasProjectPredefinedVariants()}, a list containing the {@link IInvariantView} is returned.)
     * </p>
     *
     * <p>
     * <b>Attention: </b> Normally you should use the method {@link #getAllPostBuildVariantViews(MIHasDefinition)}!
     * </p>
     *
     * @return the {@link IPredefinedVariantView} list, or the list containing {@link IInvariantView}.
     */
    @PublishedMethod
    List<IModelView> getAllPostBuildVariantViewsOrInvariant();

    /**
     * <div class="extdoc" id="getInvariantView"> The method {@link #getInvariantView(MIHasDefinition)} allows generator developers, which implement PBS semantic in a generator, to
     * restrict invariant data access to those values which really don't support variance.
     *
     * This method has different behaviors in different conditions. See the following list:
     * <ul>
     * <li>Returns the {@link IPostBuildInvariantValuesView}, if the objects {@link MIModuleConfiguration} doesn't specify VARIANT-POST-BUILD-SELECTABLE in the implementation
     * ConfigurationVariant.</li>
     * <li>Returns the {@link IPostBuildInvariantEcucDefView}, if the objects {@link MIModuleConfiguration} specifies VARIANT-POST-BUILD-SELECTABLE in the implementation
     * ConfigurationVariant.</li>
     * </ul>
     *
     * <p>
     * Note: You could also pass invisible model objects, so you do not have to switch to any {@link IModelView}.
     * </p>
     *
     * </div>
     *
     *
     * @param anyEcucElementInASpecificModuleConfig The ecucElement, which should be used to retrieve the ModuleConfiguration.
     * @return One of the {@link IInvariantView}s
     */
    @PublishedMethod
    IInvariantView getInvariantView(MIHasDefinition anyEcucElementInASpecificModuleConfig);

}
