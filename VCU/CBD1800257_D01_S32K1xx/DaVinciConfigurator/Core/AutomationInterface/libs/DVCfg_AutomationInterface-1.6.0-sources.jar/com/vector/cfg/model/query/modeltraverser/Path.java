package com.vector.cfg.model.query.modeltraverser;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.vector.davinci.util.base.VUtil.NL;
import static com.vector.davinci.util.base.VUtil.uncheckedCast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;
import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.query.definitionverify.RequiredDefinitionDependency;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IInvalidTraverserView;
import com.vector.cfg.model.query.modeltraverser.ModelTraverserFactory.ETraverserVersion;
import com.vector.cfg.model.query.modeltraverser.strategies.ITraverseStrategy;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="ModelTraverserPath">The definition tree of an {@link IModelTraverser} consists of many
 * {@link DefRef DefRefs}, which are arranged as a tree with one root.
 * <p>
 * The definition tree represents the BSWMD structure for the data you are interested in, but the root is an element of your choice. All other elements are
 * "folded" under this root definition no matter where the element resides in the real BSWMD structure. So a parent definition (BSWMD) is a child of the root
 * element in the definition tree.
 *
 * The only constraints which apply are:
 * <ul>
 * <li>
 * The definition tree must not contain duplicated {@link DefRef DefRefs} as siblings on the same level.</li>
 * <li>There must be a simple way to get from one element to another:
 * <ul>
 * <li>Parent --> Child</li>
 * <li>Child --> Parent</li>
 * <li>Reference --> Target</li>
 * <li>Target --> Reference</li>
 * <li>Module --> Module</li>
 * <li>Module --> Same Module (Multiinstance modules)</li>
 * </ul>
 * </li>
 * </ul>
 * </p>
 * <p>
 * The {@link Path} class is the builder class for a definition tree ( {@link IModelTraverserPath}) which is used by an {@link IModelTraverser}.
 *
 * The {@link Path} has several static methods to compose a new definition tree.
 * </p>
 * <p>
 * <b>Usage in Java:<br/>
 * </b> Every path must start with a RootElementType (MainElement/Context object). You can create a root by calling {@link Path#rootElem(DefRef)}. Then the
 * definition tree contains all elements which are important for the {@link IModelTraverser}, starting at the MainElementType. You can append new siblings to the
 * childList of an element by calling a {@link Path#fork(DefRef...)} method. So consecutive fork calls will create new child elements at the subtree of the
 * parent element.<br>
 * The concatenation of {@link DefRef DefRefs} separated by a "," means the first element will be the parent of the second and so on. <br/>
 * <b>Example:</b>
 *
 * <pre>
 * <code class="Java" id="Java code sample for creating a deep child structure">
 * Java code:
 * ----------
 * rootElem(ROOT_DEFREF).
 *      fork(FOO_DEFREF,
 *             BAR_DEFREF,
 *                BAZZ_DEFREF)
 *
 *  will result in the following tree structure:
 *  -> ROOT_DEFREF
 *      -> FOO_DEFREF
 *          -> BAR_DEFREF
 *              -> BAZZ_DEFREF
 *
 *  </code>
 * </pre>
 *
 *
 * <pre>
 * <code class="Java" id="Java code sample for creating a narrow child structure with fork">
 * Java code:
 * ----------
 * rootElem(ROOT_DEFREF).
 *      fork(FOO_DEFREF).
 *      fork(BAR_DEFREF).
 *      fork(BAZZ_DEFREF,
 *          CHILD_BAZZ_DEFREF);
 *
 * will result in the following tree structure:
 *  ->ROOT_DEFREF
 *      -> FOO_DEFREF
 *      -> BAR_DEFREF
 *      -> BAZZ_DEFREF
 *           -> CHILD_BAZZ_DEFREF
 * </code>
 * </pre>
 *
 * <p>
 * <b>EclipseIDE setup for the first time:</b><br/>
 * In order to get support from the content assist within the EclipseIDE by the creation of the definition tree, you should add the following class
 * {@link com.vector.cfg.model.query.modeltraverser.Path} to your static import list in your EclipseIDE.
 * <ul>
 * <li>Click in the menubar of Window -> Preferences</li>
 * <li>Go to Java -> Editor -> Content Assist -> Favorites</li>
 * <li>Add the class to the favorite list</li>
 * <li>Now you can use the static method only by calling the name instead of always prepending the Path classname</li>
 * </ul>
 *
 * <b>Note:</b> You should also consider to add your used {@link DefRef} classes to the import static list, to reduce the "clutter" class names.
 *
 * <b>Path formatting: </b><br/>
 * To specify the Path elements as a tree in a convenient manner you should disable the Code-Formatter for the Path-Specification, then you can arrange the
 * calls to comply to the tree structure you want to specify. <br>
 * To allow the EclipseIDE disable the code formatter for a section you have to configure the following:
 * <ul>
 * <li>Click In the menubar of Window -> Preferences</li>
 * <!--LaTeX:\ifInternalDoc-->
 * <li>Go to Java -> Code Style -> Formatter -> Vector Style ->Edit</li>
 * <!--LaTeX:\fi-->
 * <!--LaTeX:\ifExternalDoc-->
 * <li>Go to Java -> Code Style -> Formatter -> &lt;<i>your active profile</i>&gt; ->Edit</li>
 * <!--LaTeX:\fi-->
 * <li>Go to the last tab On/Off Tags</li>
 * <li>Enable On/Off Tags feature with the following content: @formatter:off and @formatter:on</li>
 * </ul>
 * Now you can put a comment with the tags //@formatter:off and //@formatter:on in your code to disable the code formatter.
 * </p>
 *
 * <p>
 * <b>Definition tree creation sample: </b><br/>
 * The following example creates an definition tree for the {@link IModelTraverser} class. You can see, that the structure (indentation) of the calls correspond
 * to the structure of the definition tree. The indentation will help to recognize the relations between elements.
 *
 * <pre>
 * <code class="Java" id="Creating a definition tree with the Path class">
 * // @formatter:off
 *         final IModelTraverserPath path=
 *         rootElem(NM_CHANNEL_CONFIG_DEFREF).
 *             fork(NM_CHANNEL_ID_DEFREF).
 *             fork(NM_COM_MCHANNEL_REF_DEFREF,
 *                     COMM_CHANNEL_ID_DEFREF,
 *                         COMM_CHANNEL_DEFREF,
 *                             COMM_USER_PER_CHANNEL_DEFREF,
 *                                 COMM_USER_CHANNEL_DEFREF).
 *             fork(elem(NM_GLOBAL_CONFIG_DEFREF).
 *                     fork(NM_COM_USER_DATA_ENABLED_DEFREF).
 *                     fork(elem(NM_COORDINATOR_SUPPORT_ENABLED_DEFREF, OptionalMul, DisableInvalidValueCheck) ))
 *
 *        ;
 * // @formatter:on
 * </code>
 * </pre>
 *
 * </p>
 *
 * </div>
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="UsageOfElem"> <b>Usage of <code>elem()</code>:</b><br/>
 * You have to prepend a <code>elem()</code> to your {@link DefRef}, if you want to change the multiplicity (e.g. OptionalMul), disable a parameter check, or
 * spawn more then one child sibling.
 *
 * <p>
 * <b>Reuse of definition trees:</b><br/>
 * You could reuse definition trees (or subtrees) of a defined {@link Path}. You have to call {@link Path#clone()}, when you want to insert an already used Path
 * into another path.
 * </p>
 *
 * <p>
 * <b>Traverse strategies:</b><br/>
 * To further adapt the {@link IModelTraverser} behavior read the documentation of the class {@link ITraverseStrategy}.
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelTraverser
 * @see ModelTraverserFactory
 * @see IModelTraverserPathRoot
 * @see IModelTraverserPath
 */
// CHECKSTYLE:OFF The Element must be non final, because there is a subclass in the same file!
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@NotThreadSafe
@PublishedFilter(MsrPlatform.class)
public class Path implements IModelTraverserPath, IDebugable {
    // CHECKSTYLE:ON

    // CHECKSTYLE:OFF
    Path parent;

    // CHECKSTYLE:ON

    private final TypedDefRef<?, ?, ?> defRef;

    private final EPathMultiplicityType multiType;

    /*
     * CAUTION: if you add fields, which are not simple immutable properties, you have to change the clone implementation to copy the field correctly.
     * The fields of one instances shall not modify the fields of other instances of the Path after the clone operation.
     */
    @Nullable
    private LinkedHashSet<Path> children;

    @Nonnull
    private ImmutableSet<IModelTraverserPathOption> modelTraverserPathOptions;

    @Nullable
    private List<ITraverseStrategy> traverseStrategies;

    /*
     * Methods
     */
    private Path(DefRef defRef, EPathMultiplicityType multiType, ImmutableSet<? extends IModelTraverserPathOption> modelTraverserPathOption) {

        checkNotNull(defRef, "Parameter defRef is null.");
        checkArgument(defRef instanceof TypedDefRef<?, ?, ?>, "Parameter defRef must be an instance of TypedDefRef.");

        this.defRef = (TypedDefRef<?, ?, ?>) defRef;
        this.multiType = multiType;
        this.modelTraverserPathOptions = uncheckedCast(modelTraverserPathOption);
    }

    private Path(DefRef defRef, EPathMultiplicityType multiType) {
        this(defRef, multiType, ImmutableSet.<IModelTraverserPathOption> of());
    }

    /*
     * Public interfaces
     */
    /**
     * Creates a new {@link Path} element which is a {@link IModelTraverserPathRoot} element.
     *
     * <p>
     * This {@link #rootElem(DefRef)} will specify the MainElement/Context object of the {@link IModelTraverser}.
     * </p>
     *
     * <p>
     * Every {@link Path} must start with a rootElement created by {@link #rootElem(DefRef)}!
     * </p>
     *
     * @param defRef The {@link DefRef} of the MainElement/Context object/ Root
     * @return new {@link Path} instance
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the defRef parameter is null</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is not a {@link TypedDefRef}</li>
     * </ul>
     *
     */
    @PublishedMethod
    public static Path rootElem(DefRef defRef) {
        return new RootPath(defRef, null);
    }

    /**
     * Creates a new {@link Path} element as a sub element of a {@link #rootElem(DefRef)} call.
     *
     *
     * @param defRef The {@link DefRef} of the element
     * @return new {@link Path} instance
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the defRef parameter is null</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is not a {@link TypedDefRef}</li>
     * </ul>
     *
     */
    @PublishedMethod
    public static Path elem(DefRef defRef) {
        return new Path(defRef, null);
    }

    /**
     * Creates a new {@link Path} element as a sub element of a {@link #rootElem(DefRef)} call.
     *
     * <p>
     * The specified multiplicityType will override the Multiplicity information of the defRef.
     * </p>
     *
     * @param defRef The {@link DefRef} of the element
     * @param multiplicityType the Multiplicity which overrides the DefRef multiplicity
     * @return new {@link Path} instance
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the defRef parameter is null</li>
     * <li>if the multiplicityType parameter is null</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is not a {@link TypedDefRef}</li>
     * </ul>
     */
    @PublishedMethod
    public static Path elem(DefRef defRef, EPathMultiplicityType multiplicityType) {
        return new Path(defRef, checkNotNull(multiplicityType));
    }

    /**
     * Creates a new {@link Path} element as a sub element of a {@link #rootElem(DefRef)} call.
     *
     * <p>
     * The specified multiplicityType will override the Multiplicity information of the defRef.
     * </p>
     *
     * <p>
     * The {@link IModelTraverserPathOption} (evaluationOptions) could change certain options of the {@link Path} element. The standard options are contained in the classes:
     * <ul>
     * <li>{@link EEvaluationOptions}</li>
     * <li>{@link EPathTraversalOptions}</li>
     * </ul>
     * </p>
     *
     *
     * @param <DEF_TYPE> the DefRef types
     * @param <CONFIG_TYPE> the DefRef types
     * @param <VALUE_TYPE> the DefRef types
     * @param defRef The {@link DefRef} of the element
     * @param multiplicityType the Multiplicity which overrides the DefRef multiplicity
     * @param evaluationOptions the {@link IModelTraverserPathOption}, e.g. {@link EEvaluationOptions}.
     * @return new {@link Path} instance
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the defRef parameter is null</li>
     * <li>if the multiplicityType parameter is null</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is not a {@link TypedDefRef}</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE, OPTIONS extends IModelTraverserPathOption> Path elem(
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef,
            EPathMultiplicityType multiplicityType, Set<OPTIONS> evaluationOptions) {
        return new Path(defRef, checkNotNull(multiplicityType), ImmutableSet.copyOf(evaluationOptions));
    }

    /**
     * Creates a new {@link Path} element as a sub element of a {@link #rootElem(DefRef)} call.
     *
     * <p>
     * The {@link IModelTraverserPathOption} (evaluationOptions) could change certain options of the {@link Path} element. The standard options are contained in the classes:
     * <ul>
     * <li>{@link EEvaluationOptions}</li>
     * <li>{@link EPathTraversalOptions}</li>
     * </ul>
     * </p>
     *
     *
     * @param <DEF_TYPE> the DefRef types
     * @param <CONFIG_TYPE> the DefRef types
     * @param <VALUE_TYPE> the DefRef types
     * @param defRef The {@link DefRef} of the element
     * @param evaluationOptions the {@link IModelTraverserPathOption}, e.g. {@link EEvaluationOptions}.
     * @return new {@link Path} instance
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the defRef parameter is null</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is not a {@link TypedDefRef}</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE, OPTIONS extends IModelTraverserPathOption> Path elem(
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef, Set<OPTIONS> evaluationOptions) {
        return new Path(defRef, null, ImmutableSet.copyOf(evaluationOptions));
    }

    /**
     * Creates a new {@link Path} element as a sub element of a {@link #rootElem(DefRef)} call.
     *
     * <p>
     * The specified multiplicityType will override the Multiplicity information of the defRef.
     * </p>
     *
     * <p>
     * The {@link IModelTraverserPathOption} (evaluationOptions) could change certain options of the {@link Path} element. The standard options are contained in the classes:
     * <ul>
     * <li>{@link EEvaluationOptions}</li>
     * <li>{@link EPathTraversalOptions}</li>
     * </ul>
     * </p>
     *
     *
     * @param <DEF_TYPE> the DefRef types
     * @param <CONFIG_TYPE> the DefRef types
     * @param <VALUE_TYPE> the DefRef types
     * @param defRef The {@link DefRef} of the element
     * @param multiplicityType the Multiplicity which overrides the DefRef multiplicity
     * @param evaluationOptions the {@link IModelTraverserPathOption}, e.g. {@link EEvaluationOptions}.
     * @return new {@link Path} instance
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the defRef parameter is null</li>
     * <li>if the multiplicityType parameter is null</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is not a {@link TypedDefRef}</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> Path elem(TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef,
            EPathMultiplicityType multiplicityType, IModelTraverserPathOption... evaluationOptions) {
        return new Path(defRef, checkNotNull(multiplicityType), ImmutableSet.copyOf(Arrays.asList(evaluationOptions)));
    }

    /**
     * Creates a new {@link Path} element as a sub element of a {@link #rootElem(DefRef)} call.
     *
     * <p>
     * The {@link IModelTraverserPathOption} (evaluationOptions) could change certain options of the {@link Path} element. The standard options are contained in the classes:
     * <ul>
     * <li>{@link EEvaluationOptions}</li>
     * <li>{@link EPathTraversalOptions}</li>
     * </ul>
     * </p>
     *
     *
     * @param <DEF_TYPE> the DefRef types
     * @param <CONFIG_TYPE> the DefRef types
     * @param <VALUE_TYPE> the DefRef types
     * @param defRef The {@link DefRef} of the element
     * @param evaluationOptions the {@link IModelTraverserPathOption}, e.g. {@link EEvaluationOptions}.
     * @return new {@link Path} instance
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the defRef parameter is null</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is not a {@link TypedDefRef}</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> Path elem(TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef,
            IModelTraverserPathOption... evaluationOptions) {
        return new Path(defRef, null, ImmutableSet.copyOf(Arrays.asList(evaluationOptions)));
    }

    /*
     * Fork operations
     */

    /**
     * Forks a new Child of this element with the specified {@link Path}. The other elements are inserted a child of the new created element.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(Path path, DefRef... elems) {
        return fork(path.fork(elems));
    }

    /**
     * Forks a new Child of this element with the specified {@link Path}. The other elements are inserted a child of the new created element.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(Path path1, Path path2, DefRef... elems) {
        return fork(path1.fork(path2, elems));

    }

    /**
     * Forks a new Child of this element with the specified {@link Path}. The other elements are inserted a child of the new created element.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(Path path1, Path path2, Path path3, DefRef... elems) {
        return fork(path1.fork(path2, path3, elems));
    }

    /**
     * Forks a new Child of this element with the specified {@link Path}. The other elements are inserted a child of the new created element.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(Path path1, Path path2, Path path3, Path path4, DefRef... elems) {
        return fork(path1.fork(path2, path3, path4, elems));
    }

    /**
     * Forks a new Child of this element with the specified {@link Path}. The other elements are inserted as child of the new created element.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(DefRef... elems) {
        return forkInternal(Arrays.asList(elems), null);
    }

    /**
     * Forks a new Child of this element with the specified {@link Path} as sub path.
     *
     *
     * @param path the sub tree as path
     * @return the current Parent {@link Path} instance
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the path parameter is null</li>
     * </ul>
     */
    @PublishedMethod
    public Path fork(Path path) {
        final List<DefRef> list = Collections.emptyList();
        return forkInternal(list, checkNotNull(path));
    }

    /**
     * Forks a new Child of this element with the specified DefRefs. The other elements are inserted a child of the new created element. The last element will be the Child of the
     * predecessor but added as Subtree.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @param path the last child as subtree
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(DefRef elem1, Path path) {
        return forkInternal(ImmutableList.of(elem1), path);
    }

    /**
     * Forks a new Child of this element with the specified DefRefs. The other elements are inserted a child of the new created element. The last element will be the Child of the
     * predecessor but added as Subtree.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @param path the last child as subtree
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(DefRef elem1, DefRef elem2, Path path) {
        return forkInternal(ImmutableList.of(elem1, elem2), path);
    }

    /**
     * Forks a new Child of this element with the specified DefRefs. The other elements are inserted a child of the new created element. The last element will be the Child of the
     * predecessor but added as Subtree.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @param path the last child as subtree
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(DefRef elem1, DefRef elem2, DefRef elem3, Path path) {
        return forkInternal(ImmutableList.of(elem1, elem2, elem3), path);
    }

    /**
     * Forks a new Child of this element with the specified DefRefs. The other elements are inserted a child of the new created element. The last element will be the Child of the
     * predecessor but added as Subtree.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @param path the last child as subtree
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(DefRef elem1, DefRef elem2, DefRef elem3, DefRef elem4, Path path) {
        return forkInternal(ImmutableList.of(elem1, elem2, elem3, elem4), path);
    }

    /**
     * Forks a new Child of this element with the specified DefRefs. The other elements are inserted a child of the new created element. The last element will be the Child of the
     * predecessor but added as Subtree.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @param path the last child as subtree
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(DefRef elem1, DefRef elem2, DefRef elem3, DefRef elem4, DefRef elem5, Path path) {
        return forkInternal(ImmutableList.of(elem1, elem2, elem3, elem4, elem5), path);
    }

    /**
     * Forks a new Child of this element with the specified DefRefs. The other elements are inserted a child of the new created element. The last element will be the Child of the
     * predecessor but added as Subtree.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @param path the last child as subtree
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(DefRef elem1, DefRef elem2, DefRef elem3, DefRef elem4, DefRef elem5, DefRef elem6, Path path) {
        return forkInternal(ImmutableList.of(elem1, elem2, elem3, elem4, elem5, elem6), path);
    }

    /**
     * Forks a new Child of this element with the specified DefRefs. The other elements are inserted a child of the new created element. The last element will be the Child of the
     * predecessor but added as Subtree.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @param path the last child as subtree
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(DefRef elem1, DefRef elem2, DefRef elem3, DefRef elem4, DefRef elem5, DefRef elem6, DefRef elem7, Path path) {
        return forkInternal(ImmutableList.of(elem1, elem2, elem3, elem4, elem5, elem6, elem7), path);
    }

    /**
     * Forks a new Child of this element with the specified DefRefs. The other elements are inserted a child of the new created element. The last element will be the Child of the
     * predecessor but added as Subtree.
     *
     * <p>
     * Each element after the first element will be a child of its predecessor.
     * </p>
     *
     * @param elems The DefRef elements
     * @param path the last child as subtree
     * @return the current Parent {@link Path} instance
     */
    @PublishedMethod
    public Path fork(DefRef elem1, DefRef elem2, DefRef elem3, DefRef elem4, DefRef elem5, DefRef elem6, DefRef elem7, DefRef elem8, Path path) {
        return forkInternal(ImmutableList.of(elem1, elem2, elem3, elem4, elem5, elem6, elem7, elem8), path);
    }

    /**
     * Append a traverser strategy.
     *
     * @param adapter the adapter
     * @return the path
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the strategy parameter is null</li>
     * </ul>
     */
    @PublishedMethod
    public Path appendStrategy(ITraverseStrategy strategy) {
        checkNotNull(strategy);
        if (this.traverseStrategies == null) {
            this.traverseStrategies = new ArrayList<>();
        }
        this.traverseStrategies.add(strategy);
        return this;
    }

    /**
     * The Enum EPathMultiplicityType provides the ability to override the passed Multiplicity setting of the {@link TypedDefRef} instances.
     *
     * <p>
     * See {@link Path#elem(DefRef)} for more details
     * </p>
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public enum EPathMultiplicityType {

        /** Multiplicty of 1 - 1. */
        RequiredMul,
        /** Multiplicty of 0 - 1. */
        OptionalMul,
        /** Multiplicty of 1 - Unlimited. */
        OneToUnlimitedMul,
        /** Multiplicty of 0 - Unlimited. */
        ZeroToUnlimitedMul,
    }

    /**
     * The Enum EEvaluationOptions could be used to disable certain verification check during the {@link IModelTraverser} execution.
     *
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="EEvaluationOptions">
     *
     * <h3>Multiplicity, Value and other checks</h3> The {@link IModelTraverser} normally performs the following checks during initialization and execution:
     * <ul>
     * <li>Initialization
     * <ul>
     * <li>Definition dependencies</li>
     * </ul>
     * </li>
     * <li>Execution
     * <ul>
     * <li>Multiplicity</li>
     * <li>No value</li>
     * <li>Invalid value</li>
     * <li>Min/Max value</li>
     * </ul>
     * </li>
     * </ul>
     * All these checks are done according the given {@link DefRef}s respectively the actual definitions in the BSMWD files of the currently loaded SIP. So the ModelTraverser can
     * assure valid EcuC configurations. For certain validator use-cases all these checks could be disabled in the definition tree before initialization. At every
     * <code>Path.elem()</code> call you could append {@link EEvaluationOptions}.
     *
     *
     * <p>
     * <h4>Multiplicity check override:</h4> You can override the Multiplicity derived from the {@link DefRef} elements, by adding one of the following enum literals
     * {@link EPathMultiplicityType#RequiredMul}, <code>OptionalMul</code>, <code>OneToUnlimitedMul</code> or <code>ZeroToUnlimitedMul</code> to a <code>Path.elem()</code> call.
     *
     *
     *
     * <pre>
     * <code class="Java" id="Multiplicity override and disabled check">
     *  elem(NM_COORDINATOR_SUPPORT_ENABLED_DEFREF, OptionalMul, DisableInvalidValueCheck) ))
     * </code>
     * </pre>
     *
     * <h4>Value checks override:</h4> You could also disable certain ValueChecks by adding {@link EEvaluationOptions#DisableNoValueCheck}, {@link #DisableInvalidValueCheck} or
     * {@link #DisabledMinMaxValueCheck} to a <code>elem()</code> call. <br/>
     * If your validator calculates the correct value for a parameter, it is a good idea to disable these checks and have your code prepared for these cases. <br/>
     * E.g. a mandatory parameter without a default value (which is true for all reference parameters) might often occur without a value. If your validator wants to calculate the
     * correct value for that, {@link EEvaluationOptions#DisableNoValueCheck} should be used. You might also think about specifying a default value which is recommended in general
     * and not a risk if you have that validator.</div>
     *
     * <p>
     * See {@link Path#elem(DefRef)} for more details
     * </p>
     */
    @Immutable
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public enum EEvaluationOptions implements IModelTraverserPathOption {

        /**
         * Disables the NoValue check of Parameters and References definitions. By other definitions the value has no effect.
         */
        DisableNoValueCheck,
        /**
         * Disables the InvalidValue check of Parameters and References definitions. By other definitions the value has no effect.
         */
        DisableInvalidValueCheck,

        /**
         * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="OptionalDefinitionPath">
         *
         * <h4>OptionalDefinitionPath:</h4> <b> {@link EEvaluationOptions#OptionalDefinitionPath}</b> make the subsequent tree to an optional definition tree. This enum literal
         * disables the {@link RequiredDefinitionDependency} check of the path element! This means the {@link IModelTraverser} has a valid definition tree although the
         * {@link DefRef} of this element does not exist. So you could traverse structure which have "optional" definitions, e.g. CanIf Module is not in the currently loaded SIP.
         * <p>
         * <b>Note:</b> The Lower multiplicity of the element is automatically reduced to Optional, otherwise the non existing {@link DefRef} will always lead to an
         * {@link IInvalidTraverserView}.
         * </p>
         *
         * </div>
         */
        OptionalDefinitionPath,

        /**
         * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="MinMaxCheck">
         *
         * <h4>Min/Max value check override:</h4> <b>{@link EEvaluationOptions#DisableInvalidValueCheck}</b> <!--LaTeX:\label{sec:ModelTraverserMinMaxCheck}--> disables the Min/Max
         * value check for Integer and Float parameter.
         * <p>
         * <b>Attention:</b> The Min/Max value check is only active for {@link ETraverserVersion#VERSION_2} or greater!
         * </p>
         *
         * </div>
         *
         */
        DisabledMinMaxValueCheck,

    }

    /**
     * The enum {@link EPathTraversalOptions} could be used to override the path traversal behavior.
     *
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="EPathTraversalOptions">
     *
     * <h3>PathTraversal options</h3> <!--Index:EPathTraversalOptions--> <!--LaTeX:\label{sec:EPathTraversalOptions}-->
     *
     * The {@link IModelTraverser} normally determines the path traversal type (Parent --&gt; Child, Reference --&gt; Target, etc.) of two elements by their definitions. E.g. the
     * parent is a container and the child is a parameter in the definition, so the traversal type would be Parent-&gt;Child traversal.
     *
     * But it is necessary in some cases to override the default path resolution, when there are multiple ways to the same destination, and the chosen way does not represent the
     * expected path.
     *
     * <p>
     * The {@link EPathTraversalOptions} enum provides overrides for the default behavior. The enum is used like the {@link EEvaluationOptions} enum literals. The option is
     * appended to the child, where the traversal form parent to child shall apply.
     * </p>
     *
     * Available options in {@link EPathTraversalOptions}:
     * <ul>
     * <li>Parent --&gt; Child - {@link #TRAVERSE_FROM_PARENT_TO_CHILD}:
     * <ul>
     * <li>Selects that the traversal must be a parent to child descent, according to the definition.</li>
     * </ul>
     * </li>
     *
     * <li>Child --&gt; Parent - {@link #TRAVERSE_FROM_CHILD_TO_PARENT}:
     * <ul>
     * <li>Selects that the traversal must be a child to parent ascent, according to the definition.</li>
     * </ul>
     * </li>
     *
     * <li>Reference --&gt; RefTarget - {@link #TRAVERSE_FROM_REFERENCE_TO_REF_TARGET}:
     * <ul>
     * <li>Selects that the traversal must be a forward reference resolution to one reference target, according to the definition. E.g. Reference parameter to container.</li>
     * </ul>
     * </li>
     *
     * <li>RefTarget --&gt; Reference - {@link #TRAVERSE_FROM_REF_TARGET_TO_REFERENCE}:
     * <ul>
     * <li>Selects that the traversal must be a reverse reference resolution from the referenced target to the reference parameter. E.g. from container to reference parameter</li>
     * </ul>
     * </li>
     *
     * <li>Module --&gt; Module - {@link #TRAVERSE_FROM_MODULE_TO_MODULE}:
     * <ul>
     * <li>Selects that the traversal must start by a module and end by a module, whereas the both modules are not the same. This is used to traverse to other modules, which have
     * no connection to each other.E.g. from <code>Spi to EcuC</code> to retrieve common data.</li>
     * </ul>
     * </li>
     *
     * <li>Module --&gt; Same Modules - {@link #TRAVERSE_FROM_MODULE_TO_SAME_MODULES_WITHOUT_SELF}:
     * <ul>
     * <li>Selects that the traversal must start by a module and end by same module definition, whereas the both modules must have the same definition and an upper multiplicity
     * greater than 1. This is used to traverse to other instances of the same module for a multi instance modules like drivers. E.g. From <code>Spi01 to
     * Spi02</code>, to verify intermodule data.</li>
     * </ul>
     * </li>
     * </ul>
     *
     * <p>
     * The sample below uses the {@link EPathTraversalOptions#TRAVERSE_FROM_REF_TARGET_TO_REFERENCE} to change the traversal behavior of the following DefTree. The
     * <code>NmContainer</code> has a reference <code>NmRefToContainer</code>, which points to other <code>NmContainer</code> instance. Normally the path from
     * <code>NmRefToContainer</code> to <code>NmContainer</code> would be a Child -&gt; Parent path. But with the <code>TRAVERSE_FROM_REF_TARGET_TO_REFERENCE</code> option, the
     * ModelTraverser will follow the reference instead of traversing to the <b>same</b> the parent.
     *
     * <pre>
     * <code class="Java" id="PathTraversal override with Reference --&gt; RefTarget ">
     *  elem(NM_CONTAINER_DEFREF).
     *      fork(NM_REF_TO_CONTAINER_DEFREF,
     *          elem(NM_CONTAINER_DEFREF, EPathTraversalOptions.TRAVERSE_FROM_REFERENCE_TO_REF_TARGET)
     *      )
     * </code>
     * </pre>
     *
     * </p>
     *
     * </div>
     *
     * <p>
     * See {@link Path#elem(DefRef)} for more details
     * </p>
     */
    @Immutable
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public enum EPathTraversalOptions implements IModelTraverserPathOption {

        /** See {@link EPathTraversalOptions}. */
        TRAVERSE_FROM_PARENT_TO_CHILD("Parent -> Child"),

        /** See {@link EPathTraversalOptions}. */
        TRAVERSE_FROM_CHILD_TO_PARENT("Child -> Parent"),

        /** See {@link EPathTraversalOptions}. */
        TRAVERSE_FROM_REFERENCE_TO_REF_TARGET("Reference -> RefTarget"),

        /** See {@link EPathTraversalOptions}. */
        TRAVERSE_FROM_REF_TARGET_TO_REFERENCE("RefTarget -> Reference"),

        /** See {@link EPathTraversalOptions}. */
        TRAVERSE_FROM_MODULE_TO_MODULE("Module -> Module"),

        /** See {@link EPathTraversalOptions}. */
        TRAVERSE_FROM_MODULE_TO_SAME_MODULES_WITHOUT_SELF("Module -> Same Modules"),

        ;

        private final String descriptiveName;

        EPathTraversalOptions(String descriptiveName) {
            this.descriptiveName = descriptiveName;

        }

        /**
         * Returns a descriptive name of the {@link EPathTraversalOptions}, or the string &quot;Unknown&quot;, if <code>null</code> is passed.
         *
         * @param opt
         * @return A descriptive name.
         */
        @KeepSecretFromPublishedApi
        public static String toDescriptiveName(EPathTraversalOptions opt) {
            if (opt == null) {
                return "Unknown";
            }
            return opt.descriptiveName;
        }

        @KeepSecretFromPublishedApi
        public EPathTraversalOptions getInverseOption() {
            switch (this) {
            case TRAVERSE_FROM_PARENT_TO_CHILD:
                return TRAVERSE_FROM_CHILD_TO_PARENT;
            case TRAVERSE_FROM_CHILD_TO_PARENT:
                return TRAVERSE_FROM_PARENT_TO_CHILD;

            case TRAVERSE_FROM_MODULE_TO_MODULE:
                return TRAVERSE_FROM_MODULE_TO_MODULE;

            case TRAVERSE_FROM_MODULE_TO_SAME_MODULES_WITHOUT_SELF:
                return TRAVERSE_FROM_MODULE_TO_SAME_MODULES_WITHOUT_SELF;

            case TRAVERSE_FROM_REFERENCE_TO_REF_TARGET:
                return TRAVERSE_FROM_REF_TARGET_TO_REFERENCE;
            case TRAVERSE_FROM_REF_TARGET_TO_REFERENCE:
                return TRAVERSE_FROM_REFERENCE_TO_REF_TARGET;
            default:
                throw new IllegalArgumentException();

            }
        }

        @KeepSecretFromPublishedApi
        @Nullable
        public static EPathTraversalOptions getTraverseOptionFromPath(IModelTraverserPath path) {
            EPathTraversalOptions foundOpt = null;
            for (final IModelTraverserPathOption opt : path.getModelTraverserPathOptions()) {
                if (opt instanceof EPathTraversalOptions) {
                    final EPathTraversalOptions newTraversOpt = (EPathTraversalOptions) opt;
                    if (foundOpt != null) {
                        throw new IllegalArgumentException("Multipe EPathTraversalOptions instances found  "
                                + EPathTraversalOptions.toDescriptiveName(newTraversOpt)
                                + " " + EPathTraversalOptions.toDescriptiveName(foundOpt)
                                + "  for " + path.toString()
                                + ". You could not have multiple EPathTraversalOptions instances.");
                    }
                    foundOpt = newTraversOpt;
                }
            }
            return foundOpt;
        }

    }

    /*
     * Interface IModelTraverserPath impl
     */

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public TypedDefRef<?, ?, ?> getDefRef() {
        return defRef;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public EPathMultiplicityType getMultiplicityType() {
        return multiType;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Set<IModelTraverserPathOption> getModelTraverserPathOptions() {
        return modelTraverserPathOptions;
    }

    @Override
    @KeepSecretFromPublishedApi
    public void addModelTraverserPathOption(IModelTraverserPathOption option) {
        if (option instanceof EPathTraversalOptions) {
            verifyCurrentOptionDoesNotContainAPathTraversalOption();
        }
        final List<IModelTraverserPathOption> opts = new ArrayList<>();
        opts.addAll(modelTraverserPathOptions);
        opts.add(option);
        modelTraverserPathOptions = ImmutableSet.copyOf(opts);
    }

    private void verifyCurrentOptionDoesNotContainAPathTraversalOption() {
        for (final IModelTraverserPathOption opt : getModelTraverserPathOptions()) {
            if (opt instanceof EPathTraversalOptions) {
                throw new IllegalArgumentException("An EPathTraversalOptions object " + EPathTraversalOptions.toDescriptiveName((EPathTraversalOptions) opt)
                        + " already exists for element " + toString()
                        + ". You could not add another EPathTraversalOptions instance.");
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IModelTraverserPathRoot getRoot() {
        checkNotNull(parent, "The constructed path must have a root element. have you constructed the first elemen with the method rootElem()?");

        Path currElem = getParent();
        Path lastParent = currElem;
        while (currElem != null) {
            lastParent = currElem;
            currElem = currElem.getParent();
        }
        checkNotNull(lastParent, "The constructed path must have a root element. have you constructed the first elemen with the method rootElem()?");
        checkArgument(lastParent instanceof RootPath, "The constructed path must have a root element. have you constructed the first elemen with the method rootElem()?");
        return (RootPath) lastParent;
    }

    private void setParent(Path parent) {
        checkNotNull(parent);
        checkArgument(this.parent == null,
                "The child was already inserted into the Path you can not reuse instances! You can use yourPath.clone() to get another instance of the same path!");

        this.parent = parent;

    }

    private Path getParent() {
        return parent;
    }

    /**
     * Getter method for decisionAdapters.
     *
     * @return Returns the decisionAdapters.
     */
    @Override
    @PublishedMethod
    public List<ITraverseStrategy> getTraverserStrategies() {
        if (traverseStrategies == null) {
            return ImmutableList.of();
        }
        return traverseStrategies;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    public Set<Path> getChilds() {
        if (children == null) {
            return ImmutableSet.of();
        }
        return children;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Path clone() {
        /*
         * CAUTION: if you add fields, which are not simple immutable properties, you have to change the clone implementation to copy the field correctly.
         * The fields of one instances shall not modify the fields of other instances of the Path after the clone operation.
         */
        final Path clone;
        try {
            clone = (Path) super.clone();

            if (children != null) {
                final LinkedHashSet<Path> clonedChilds = Sets.newLinkedHashSet();
                for (final Path child : children) {
                    final Path childClone = child.clone();
                    childClone.setParent(clone);
                    clonedChilds.add(childClone);
                }
                clone.children = clonedChilds;
            }

            if (clone instanceof Path) {
                clone.parent = null;
            }
            if (this.traverseStrategies != null) {
                clone.traverseStrategies = new ArrayList<>(this.traverseStrategies);
            }
            clone.modelTraverserPathOptions = ImmutableSet.copyOf(modelTraverserPathOptions);

            return clone;
        } catch (final CloneNotSupportedException ex) {
            // not possible
            throw new AssertionError(ex);
        }

    }

    void getAllDefRefsInternal(Set<DefRef> defRefSet) {
        defRefSet.add(defRef);
        for (final Path child : getChilds()) {
            child.getAllDefRefsInternal(defRefSet);
        }
    }

    /*
     * Private section
     */

    private void addChild(Path child) {
        checkNotNull(child);
        if (this.children == null) {
            this.children = Sets.newLinkedHashSet();
        }
        this.children.add(child);
        child.parent = this;

    }

    private Path forkInternal(List<DefRef> elems, Path path) {

        Path lastElement = this;
        for (final DefRef defRefLoc : elems) {
            final Path currElement = elem(defRefLoc);
            lastElement.addChild(currElement);
            lastElement = currElement;
        }

        if (path != null) {
            lastElement.addChild(path);
        }

        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("Path [");
        if (defRef != null) {
            builder.append(defRef);
        }
        builder.append("]");
        return builder.toString();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toDebugString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("Path for ModelTraverser: " + NL);
        toDebugStringInternal(builder, 0);
        return builder.toString();
    }

    private void toDebugStringInternal(StringBuilder builder, int indent) {
        if (indent != 0) {
            builder.append("=> ");
        }

        builder.append(String.format("%-80s %s", getDefRef().getDefRefStringWithoutPackagePart(), getDefRef().getPackagePartOfDefRefString()));
        indent++;
        for (final Path child : getChilds()) {
            appendIndent(builder, indent);
            child.toDebugStringInternal(builder, indent);
        }
    }

    private void appendIndent(StringBuilder builder, int indent) {
        builder.append(NL);
        for (int x = 0; x < indent; x++) {
            builder.append("    ");
        }

    }

    private static class RootPath extends Path implements IModelTraverserPathRoot {

        /**
         * Constructor for RootPath.
         *
         * @param defRef
         * @param multiType
         */
        RootPath(DefRef defRef, EPathMultiplicityType multiType) {
            super(defRef, multiType);
            parent = null;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String toString() {
            final StringBuilder builder = new StringBuilder();
            builder.append("RootPath [");
            if (getDefRef() != null) {
                builder.append(getDefRef());
            }
            builder.append("]");
            return builder.toString();
        }

        @Override
        public IModelTraverserPathRoot getRoot() {
            if (parent != null) {
                return super.getRoot();
            }
            return this;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public Set<DefRef> getAllChildDefRefs() {

            final Set<DefRef> defRef = Sets.newHashSet();
            getAllDefRefsInternal(defRef);

            return Collections.unmodifiableSet(defRef);
        }

    }

}
