package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link UsageNotAllowed} marks a class, that is was exported due to internal compiler dependencies and should never be used in the client code which uses the
 * {@link PublishedApi}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see PublishedApi
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@Documented
@Retention(RetentionPolicy.CLASS)
@Target(ElementType.TYPE)
public @interface UsageNotAllowed {

    /**
     * Returns the message, why the usage is not allowed.
     *
     * @return the string
     */
    @PublishedMethod
    String value();
}
