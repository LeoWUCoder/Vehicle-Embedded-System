package com.vector.cfg.core.project;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <div class="extdoc" id="CommonModel" data-target-doc="ModelDocumentation">
 *
 * The {@link EEnvironmentTargetType} represents the possible target types and provides comfort functions to check whether target type supports real target (
 * {@link #isRealAvailable()}) and/or virtual target ( {@link #isVttAvailable()}).
 *
 * <pre>
 * <code class="Java" id="EEnvironmentTargetType usage sample">
 * final EEnvironmentTargetType targetType = projectContext.getService(IDpaAccessPublished.class).getProjectTargetType();
 * // ...
 * if (targetType.isRealAvailable()) {
 *   // Initialization code for real target
 * }
 * if (targetType.isVttAvailable()) {
 *   // Initialization code for virtual target
 * }
 * </code>
 * </pre>
 *
 * </div>
 *
 * Available literals are
 * <ul>
 * <li>{@link #REAL}</li>
 * <li>{@link #VIRTUAL}</li>
 * <li>{@link #REAL_AND_VIRTUAL}</li>
 * <li>{@link #NONE}</li>
 * </ul>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IDpaAccessPublished
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.GENERATOR_INTERNAL_ADDONS, DomainType.AUTOMATION_IF_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
@ThreadSafe
public enum EEnvironmentTargetType {
    // Note: If you make changes to this literals consider also
    // com.vector.cfg.persistency.internal.dpa.DpaContentCorrector.createMandatoryNodesInOldDpaFiles(IPersistencyLocationFactory, IDpaFile)
    /**
     * <code>REAL</code> describes the target of type 'Real Target'.
     */
    REAL("Real", "Real Target", false, true),
    /**
     * <code>VIRTUAL</code> describes the target type of type 'Virtual Target (vVIRTUALtarget)'.
     */
    VIRTUAL("Virtual", "Virtual Target (vVIRTUALtarget)", true, false),
    /**
     * <code>REAL_AND_VIRTUAL</code> describes the target type of type 'Real Target & Virtual Target (vVIRTUALtarget)'.
     */
    REAL_AND_VIRTUAL("RealAndVirtual", "Real Target & Virtual Target (vVIRTUALtarget)", true, true),
    /**
     * <code>NONE</code> describes the value which is used when no target type is set.
     */
    NONE("", "", false, false);

    private final String serializationLiteral;

    private final String representationLiteral;

    private final boolean vttAvailable;

    private final boolean realAvailable;

    /**
     * Constructor for EEnvironmentTargetTypes.
     *
     * @param serializationLiteral the literal which is used for serialization.
     * @param representationLiteral the literal which is used for UI representation.
     */
    EEnvironmentTargetType(final String serializationLiteral, final String representationLiteral, final boolean vtt, final boolean real) {
        this.serializationLiteral = serializationLiteral;
        this.representationLiteral = representationLiteral;
        this.vttAvailable = vtt;
        this.realAvailable = real;
    }

    /**
     * Gets the literal which is used for serialization.
     *
     * @return the serialization literal.
     */
    @KeepSecretFromPublishedApi
    public String getSerializationLiteral() {
        return serializationLiteral;
    }

    /**
     * Gets the literal which is used for UI representation.
     *
     * @return the representation literal.
     */
    @KeepSecretFromPublishedApi
    public String getRepresentationLiteral() {
        return representationLiteral;
    }

    /**
     * Gets whether VTT is available for target type.
     *
     * @return the availability of VTT target.
     */
    @PublishedMethod
    public boolean isVttAvailable() {
        return vttAvailable;
    }

    /**
     * Gets whether Real is available for target type.
     *
     * @return the availability of Real target.
     */
    @PublishedMethod
    public boolean isRealAvailable() {
        return realAvailable;
    }

    /**
     * Gets the corresponding ENUM value for the given representation literal (used in the UI).
     *
     * @param representation the literal which is used in the UI.
     * @return the corresponding ENUM value. If none could be found {@link EEnvironmentTargetType#NONE} is returned.
     */
    @KeepSecretFromPublishedApi
    public static EEnvironmentTargetType getItemForRepresentationLiteral(final String representation) {
        if (representation != null) {
            for (final EEnvironmentTargetType type : EEnvironmentTargetType.values()) {
                if (type.getRepresentationLiteral().equalsIgnoreCase(representation)) {
                    return type;
                }
            }
        }
        return NONE;
    }

    /**
     * Gets the corresponding ENUM value for the given serialization literal.
     *
     * @param serialization the literal which is used during serialization (to .dpa file).
     * @return the corresponding ENUM value. If none could be found {@link EEnvironmentTargetType#NONE} is returned.
     */
    @KeepSecretFromPublishedApi
    public static EEnvironmentTargetType getItemForSerializationLiteral(final String serialization) {
        if (serialization != null) {
            for (final EEnvironmentTargetType type : EEnvironmentTargetType.values()) {
                if (type.getSerializationLiteral().equalsIgnoreCase(serialization)) {
                    return type;
                }
            }
        }
        return NONE;
    }
}
