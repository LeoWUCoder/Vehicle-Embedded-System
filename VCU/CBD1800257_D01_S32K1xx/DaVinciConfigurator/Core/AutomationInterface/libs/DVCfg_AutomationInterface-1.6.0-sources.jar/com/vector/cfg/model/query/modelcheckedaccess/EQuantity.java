package com.vector.cfg.model.query.modelcheckedaccess;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.text.format.IFormattable;

/**
 * Enumeration of the different multiplicities of the request interface
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@PublishedFilter(MsrPlatform.class)
public enum EQuantity implements IFormattable {

    /**
     * None Quantity.
     */
    @PublishedField
    NONE {
        /**
         * {@inheritDoc}
         */
        @Override
        public String toString(String formatPattern) {
            return "No element";
        }
    },

    /**
     * Quantity ONE requested.
     */
    @PublishedField
    ONE {
        /**
         * {@inheritDoc}
         */
        @Override
        public String toString(String formatPattern) {
            return "One element";
        }
    },
    /**
     * Quantity MANY requested.
     */
    @PublishedField
    MANY {
        /**
         * {@inheritDoc}
         */
        @Override
        public String toString(String formatPattern) {
            return "Many elements";
        }
    };

}
