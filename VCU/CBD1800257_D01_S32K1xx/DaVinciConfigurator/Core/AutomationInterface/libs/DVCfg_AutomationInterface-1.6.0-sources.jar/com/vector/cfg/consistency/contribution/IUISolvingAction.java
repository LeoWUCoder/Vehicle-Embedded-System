package com.vector.cfg.consistency.contribution;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.consistency.IHasDescription;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SolvingActions;
import com.vector.cfg.consistency.contribution.helper.validationresults.IValidationResultBuilder;

/**
 * <div class="extdoc" id="Common"> An {@link IValidationResult} may have one or more {@link IUISolvingAction}s. An {@link IUISolvingAction} doesn't modify the data model
 * immediately like a normal solving action, but lets the user jump to a particular editor, wizard or any other part of the GUI. An {@link IUISolvingAction} is visualized
 * similar to a normal solving action, but with an extra overlay. An IUISolvingAction cannot be implemented by a validator, but there must be some kind of factory in the GUI
 * core to provide {@link IUISolvingAction}s. <br/>
 * An {@link IUISolvingAction} can also be used to tell the user about a manual solution, if there is no clickable solution available yet. E.g. "Please active the module DET in
 * the preferences editor." Please use {@link SolvingActions#createManualUISolvingAction(String)} in that case.
 *
 * An {@link IUISolvingAction} can also be the preferred solving action, see {@link IValidationResultBuilder#setPreferredUISolvingAction(IUISolvingAction)}. Of course a
 * preferred {@link IUISolvingAction} is not executed automatically with the "Solve All with preferred SA" feature, but the preference is visualized with an asterisk overlay
 * like with a normal preferred solving action.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@ReworkThisAtNextBreakingChange //Don't publish this and rename to IGUISolvingAction
public interface IUISolvingAction extends Runnable, IHasDescription {

}
