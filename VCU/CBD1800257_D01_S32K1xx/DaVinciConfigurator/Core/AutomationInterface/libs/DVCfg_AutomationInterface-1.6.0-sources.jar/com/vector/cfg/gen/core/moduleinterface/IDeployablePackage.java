package com.vector.cfg.gen.core.moduleinterface;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.consistency.contribution.IValidator;
import com.vector.cfg.util.IProjectContext;

/**
 * This represents one package deployed as a dynamic loadable jar for the DaVinciConfiguration GenCore. This interface is the EntryPoint for all activities associate with the
 * GenCore process.
 *
 * <p>
 * Also see {@link IGeneratorPackage}
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients. Please use abstract class AbstractPackage
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public interface IDeployablePackage {

    /**
     * Gets the package version of the {@link IDeployablePackage}.
     * <p>
     * Example:<br />
     * 1.02.08
     * </p>
     *
     * @return The package version
     */
    @PublishedMethod
    @ReworkThisAtNextBreakingChange("remove default implementation")
    default String getPackageVersionString() {
        return "00.00.1";
    }

    /**
     * Initializes the {@link IDeployablePackage} and creates the instances of the Generator interfaces e.g. Validators, Processor.
     *
     * <div class="extdoc" id="InitializePackage">
     * <h5>Constraints</h5> It is not allowed to access non definition data during initialization because any access leads to unexpected errors! </div>
     *
     * <p>
     * Note: {@link #setProjectContext(IProjectContext)} must have been called before calling this method!
     * </p>
     *
     */
    @PublishedMethod
    void initializePackage();

    /**
     * Gets the project context.
     *
     * @return the project context
     */
    @PublishedMethod
    IProjectContext getProjectContext();

    /**
     * Sets the project context.
     *
     * <p>
     * This method must be called by the GeneratorCore-Framework before the {@link #initializePackage()} method can be called.
     * </p>
     *
     * @param projectContext the new project context
     */
    @PublishedMethod
    void setProjectContext(IProjectContext projectContext);

    /**
     * Gets the CFG5 core feature version.
     *
     * <p>
     * Example:<br />
     * 1.00.00
     * </p>
     *
     * @return The current CFG core feature version.
     */
    @PublishedMethod
    String getCfgCoreFeatureVersionString();

    /**
     * Returns the qualified Java Package, where the Package resides. The last Part must be the ALMComponent name.
     *
     * @return Java Package String
     */
    @PublishedMethod
    String getQualifiedJavaPackageName();

    /**
     * Retrieve a registered GenService by its class object.
     *
     * <p>
     * Attention: This method can only be called, when the {@link IDeployablePackage} is already initialized.
     * </p>
     *
     * @param <T> the generic type of the service
     * @param clazz the class object of the Service.
     * @return the associated service.
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if no service was registered with the clazz object.</li>
     * </ul>
     */
    @PublishedMethod
    <T> T getGenService(Class<T> clazz);

    /**
     * Gets the registered configuration time Validators.
     *
     *
     * <p>
     * Attention: This method can only be called, when the {@link IGeneratorPackage} is already initialized.
     * </p>
     *
     * @return List of Validators
     */
    @KeepSecretFromPublishedApi
    List<IValidator> getValidationRules();

}
