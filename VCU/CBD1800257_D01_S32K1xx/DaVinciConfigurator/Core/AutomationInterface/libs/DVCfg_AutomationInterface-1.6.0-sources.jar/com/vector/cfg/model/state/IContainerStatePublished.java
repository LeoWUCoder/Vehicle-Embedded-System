package com.vector.cfg.model.state;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.core.project.EConfigurationPhase;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation">
 * <h3>IContainerStatePublished</h3> The <code>IContainerStatePublished</code> specifies a type-safe published API for container states. It mainly covers the following state
 * information
 * <ul>
 * <li>Does this container have a pre-configuration container (includes access to this container)? The same information is being provided for recommended and initial (derived)
 * values</li>
 * <li>Is change or deletion allowed in the current configuration phase (post-build loadable use case)?</li>
 * <li>In which configuration phase has this container been created in (post-build loadable use case)?</li>
 * <li>What is the configuration class of this container</li>
 * </ul>
 *
 * <p>
 * The figure <!--LaTeX: \vref{fig:ContainerStateClasses} --> shows the inheritance hierarchy of the {@link IContainerStatePublished} class and its sub classes.
 * </p>
 * <img src="{@docRoot} /../_doc/UML/IContainerStatePublished/Classes.png" alt="IContainerStatePublished class structure" id="fig:ContainerStateClasses " data-latex-style=
 * "scale=0.7"/>
 *
 * <pre>
 * <!--PlantUML: Classes
 *    {@link ICeStatePublished} <|-_ {@link IEcucStatePublished}
 *    {@link IEcucStatePublished} <|-_ {@link IHasContainerStatePublished}
 *    {@link IEcucStatePublished} <|-_ {@link IParameterStatePublished}
 *    {@link IHasContainerStatePublished} <|-_ {@link IContainerStatePublished}
 * -->
 * </pre>
 *
 * This API provides state information similar to IParameterStatePublished. Some of the states are container-specific, of course. <code>getCreationPhase()</code>, for example,
 * which returns the phase a container in a post-build loadable configuration has been created in.
 *
 * </div>
 *
 * <p>
 * Instances of related CeState implementations can be created by means of {@link CeStatePublishedFactory}.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IContainerStatePublished extends IHasContainerStatePublished {

    /**
     * Returns the same object as {@link #getSupervisedObject()} but type-safe.
     *
     * @return Never returns <code>null</code>
     */
    @PublishedMethod
    Optional<MIContainer> getSupervisedContainer();

    /**
     * Returns the project phase the container has been created in.
     *
     * @return
     */
    @PublishedMethod
    EConfigurationPhase getCreationPhase();

}