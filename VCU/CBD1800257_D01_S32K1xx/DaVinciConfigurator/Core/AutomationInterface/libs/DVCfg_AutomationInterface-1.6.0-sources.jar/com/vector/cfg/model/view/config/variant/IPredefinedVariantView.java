package com.vector.cfg.model.view.config.variant;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepInterfacesSecretFromPublishedApi;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedDeprecated;
import com.vector.cfg.model.formula.api.builder.IFormulaLogicalExpressionConvertible;
import com.vector.cfg.model.variance.IPredefinedVariant;
import com.vector.cfg.model.view.config.IModelView;

/**
 * This is the API of a model view which provides variant specific access to the model. This view makes all objects visible which are contained in one specific predefined
 * variant.
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedDeprecated("Please use the type IPostBuildPredefinedVariantView instead.")
@Immutable
@KeepInterfacesSecretFromPublishedApi(IFormulaLogicalExpressionConvertible.class)
public interface IPredefinedVariantView extends IModelView, IFormulaLogicalExpressionConvertible {

    /**
     * @return the covered PredefinedVariant
     * @deprecated Client code shall not use the {@link IPredefinedVariant}, please use this {@link IPredefinedVariantView}.
     */
    @KeepSecretFromPublishedApi
    @Deprecated
    IPredefinedVariant getPredefinedVariant();
}
