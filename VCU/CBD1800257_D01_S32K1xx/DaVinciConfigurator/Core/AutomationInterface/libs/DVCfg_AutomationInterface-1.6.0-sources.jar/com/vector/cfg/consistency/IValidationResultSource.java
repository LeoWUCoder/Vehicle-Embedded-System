package com.vector.cfg.consistency;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.consistency.contribution.IOnDemandResultSubmitter;
import com.vector.cfg.consistency.contribution.IOnDemandValidationResultSink;
import com.vector.cfg.consistency.contribution.helper.ValidationResultSource;

/**
 * IValidationResultSource is a marker interface for sources of ValidationResults, like Rules or Generators etc.
 *
 * <p>
 * See {@link ValidationResultSource} for a wrapper implementation
 * </p>
 *
 * <p>
 * A {@link IOnDemandResultSubmitter} could revoke all results from one {@link IValidationResultSource}.
 * </p>
 *
 * <p>
 * See {@link IOnDemandValidationResultSink} for details.
 * </p>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IValidationResultSource {

}
