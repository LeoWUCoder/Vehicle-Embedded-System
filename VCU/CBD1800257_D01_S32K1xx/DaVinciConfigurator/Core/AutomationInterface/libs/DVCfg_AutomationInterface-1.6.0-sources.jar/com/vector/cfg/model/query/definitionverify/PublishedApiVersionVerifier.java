package com.vector.cfg.model.query.definitionverify;

import static com.google.common.base.Preconditions.checkNotNull;

import java.text.MessageFormat;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiVersionCheck;
import com.vector.annotations.publishedapi.PublishedApiVersionInfo;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * PublishedApiVersionVerifier verifies an {@link PublishedApiVersionCheck} annotation of a class against the current VersionRange of the passed {@link DomainType}.
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
@ThreadSafe
public final class PublishedApiVersionVerifier extends AbstractPublishedApiVersionVerifier {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(PublishedApiVersionVerifier.class);

    private DomainType publishedApiDomainType;

    private PublishedApiVersionVerifier() {

    }

    /**
     * Creates a new {@link GenPublishedApiVersionVerifier} instance.
     *
     * @return the new {@link GenPublishedApiVersionVerifier}
     */
    @PublishedMethod
    public static PublishedApiVersionVerifier create() {
        return new PublishedApiVersionVerifier();
    }

    /**
     * {@inheritDoc}
     */
    @KeepSecretFromPublishedApi
    @Override
    protected RuntimeException reportFailedVersionCheck(Class<?> clazz, String expectedVersion, String actualVersionRange, String description) {
        final String msg = MessageFormat.format(
                "The VersionCheck for PublishedApi Domain {0} failed. The class {3} requires the version: {1}. But the current CfgCore version is: {2}. {4}",
                publishedApiDomainType, expectedVersion, actualVersionRange,
                clazz.getName(), description);
        throw new IncompatibleClassChangeError(msg);
    }

    /**
     * Verify class against the {@link PublishedApiVersionInfo} of the {@link DomainType#GENERATORS}.
     *
     * <p>
     * Attention: Please use {@link #verifyClass(IGeneratorPackageReferable, Class)}, if it is possible!
     * </p>
     *
     * @param clazz the Class to verify
     * @param publishedApiDomainTypeLoc the DomainType to verify the class.
     *
     * @exception IncompatibleClassChangeError
     * <ul>
     * <li>if the passed Class is not compatible with the actual Version of the {@link DomainType}.</li>
     * </ul>
     */
    @PublishedMethod
    public void verifyClass(Class<?> clazz, DomainType publishedApiDomainTypeLoc) {
        checkNotNull(clazz);
        checkNotNull(publishedApiDomainTypeLoc);

        synchronized (this) {

            this.publishedApiDomainType = publishedApiDomainTypeLoc;
            try {
                verifyClassInternal(clazz);
            } finally {
                publishedApiDomainType = null;
            }

        }

    }

    /**
     * {@inheritDoc}
     */
    @KeepSecretFromPublishedApi
    @Override
    protected DomainType getDomainTypeToVerify() {

        return publishedApiDomainType;
    }

}
