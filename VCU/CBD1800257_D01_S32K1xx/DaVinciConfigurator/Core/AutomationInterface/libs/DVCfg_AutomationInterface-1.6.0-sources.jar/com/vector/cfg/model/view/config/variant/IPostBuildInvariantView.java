package com.vector.cfg.model.view.config.variant;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.view.IModelViewManager;

/**
 * {@link IPostBuildInvariantView} defines a {@link IPostBuildView} for PostBuild invariant data. See {@link IInvariantView} for details. Normally you would used the
 * {@link IPostBuildInvariantValuesView}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IModelViewManager
 * @see IPostBuildInvariantValuesView
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
public interface IPostBuildInvariantView extends IPostBuildView, IInvariantView {

}
