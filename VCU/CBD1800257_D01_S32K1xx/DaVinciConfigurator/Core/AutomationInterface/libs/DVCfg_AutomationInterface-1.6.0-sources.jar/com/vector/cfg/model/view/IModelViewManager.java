package com.vector.cfg.model.view;

import java.util.Collection;
import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedDeprecated;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.variance.EProjectVarianceType;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.variant.IInvariantEcucDefView;
import com.vector.cfg.model.view.config.variant.IInvariantValuesView;
import com.vector.cfg.model.view.config.variant.IInvariantView;
import com.vector.cfg.model.view.config.variant.IPostBuildInvariantEcucDefView;
import com.vector.cfg.model.view.config.variant.IPostBuildInvariantValuesView;
import com.vector.cfg.model.view.config.variant.IPostBuildInvariantView;
import com.vector.cfg.model.view.config.variant.IPostBuildPredefinedVariantView;
import com.vector.cfg.model.view.config.variant.IPostBuildView;
import com.vector.cfg.model.view.config.variant.IPreBuildPredefinedVariantView;
import com.vector.cfg.model.view.config.variant.IPreBuildView;
import com.vector.cfg.model.view.config.variant.IPredefinedVariantView;

/**
 * <div class="extdoc" id="Common_Part"> The {@link IModelViewManager} handles model visibility in general. It provides the following means:
 * <ul>
 * <li>Get all available variants</li>
 * <li>Execute code with visibility of a specific predefined variant only. This means your code sees all objects contained in the specified variant. All objects which are not
 * contained in this variant will be invisible</li>
 * <li>Execute code with visibility of invariant data only (see {@link IInvariantView}).
 * <li>Execute code with unfiltered model visibility. This means that your code sees all objects unconditionally. If the project contains variant data, you see all variants
 * together</li>
 * </ul>
 *
 * It additionally provides detailed visibility information for single model objects:
 * <ul>
 * <li>Get all variants, a specific object is visible in</li>
 * <li>Find out if an object is visible in a specific variant</li>
 * </ul>
 * </div>
 *
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public interface IModelViewManager {

    /**
     * Returns the project variance type.
     * <p>
     * Note: you could also inject the variance type via guice!
     * </p>
     *
     * @return the project variance type
     */
    @KeepSecretFromPublishedApi
    EProjectVarianceType getProjectVarianceType();

    /**
     * Returns the {@link IPostBuildInvariantValuesView}, containing the elements, where all values are equal in all variants. See {@link IPostBuildInvariantValuesView} doc for
     * more details.
     *
     * <p>
     * Note: This method is {@link IModelView} aware, which means the result depends on the activated {@link IPreBuildView}, or the <code>IUnfilteredView</code>.
     * </p>
     *
     * @return the {@link IPostBuildInvariantValuesView}
     * @see IPostBuildInvariantValuesView
     */
    @PublishedMethod
    IPostBuildInvariantValuesView getPostBuildInvariantValuesView();

    /**
     * Returns the {@link IPostBuildInvariantValuesView}, containing the elements, where all values are equal in all variants. See {@link IPostBuildInvariantValuesView} doc for
     * more details.
     *
     * <p>
     * Note: This method is {@link IModelView} aware, which means the result depends on the activated {@link IPreBuildView}, or the <code>IUnfilteredView</code>.
     * </p>
     *
     * @return the {@link IPostBuildInvariantValuesView}
     * @see IPostBuildInvariantValuesView
     * @deprecated Please use the method {@link #getPostBuildInvariantValuesView()} instead!
     */
    @PublishedMethod
    @Deprecated
    @PublishedDeprecated("Please use the method getPostBuildInvariantValuesView() instead!")
    IInvariantValuesView getInvariantValuesView();

    /**
     * Returns the {@link IPostBuildInvariantEcucDefView}, containing the element which are invariant, according to their EcuC definition (See <code>IEcucDefinitionAccess</code>,
     * for the elements which are invariant). See {@link IPostBuildInvariantEcucDefView} doc for more details.
     *
     * <p>
     * Note: This method is {@link IModelView} aware, which means the result depends on the activated {@link IPreBuildView}, or the <code>IUnfilteredView</code>.
     * </p>
     *
     * @return the {@link IPostBuildInvariantEcucDefView}
     * @see IPostBuildInvariantEcucDefView
     */
    @PublishedMethod
    IPostBuildInvariantEcucDefView getPostBuildInvariantEcucDefView();

    /**
     * Returns the {@link IPostBuildInvariantEcucDefView}, containing the element which are invariant, according to their EcuC definition (See <code>IEcucDefinitionAccess</code>,
     * for the elements which are invariant). See {@link IPostBuildInvariantEcucDefView} doc for more details.
     *
     * <p>
     * Note: This method is {@link IModelView} aware, which means the result depends on the activated {@link IPreBuildView}, or the <code>IUnfilteredView</code>.
     * </p>
     *
     * @return the {@link IPostBuildInvariantEcucDefView}
     * @see IPostBuildInvariantEcucDefView
     * @deprecated Please use the method {@link #getPostBuildInvariantEcucDefView()} instead!
     */
    @Deprecated
    @PublishedMethod
    @PublishedDeprecated("Please use the method getPostBuildInvariantEcucDefView() instead!")
    IInvariantEcucDefView getInvariantEcucDefView();

    /**
     * Returns the currently active model view of the current thread.
     *
     * This method never returns {@code null}. If no variant is selected the <code> IUnfilteredView</code> is returned.
     * <p>
     * Note this could return an {@link IPostBuildView} or an <code>IPreBuildView</code>, depending on the currently active view.
     * </p>
     *
     * @return the currently active model view
     */
    @PublishedMethod
    IModelView getCurrentlyActiveView();

    /**
     * Returns {@code true} if the current model view is and instance of a {@link IPostBuildInvariantView}.
     *
     * @return
     * @deprecated Please use the method {@link #isCurrentlyPostBuildValueInvariant()} instead!
     */
    @PublishedMethod
    @Deprecated
    boolean isCurrentlyValueInvariant();

    /**
     * Returns {@code true} if the current model view is and instance of a {@link IPostBuildInvariantView}.
     *
     * @return
     */
    @PublishedMethod
    boolean isCurrentlyPostBuildValueInvariant();

    /**
     * <div class="extdoc" id="GetAllViews"> This method returns the model views of all PostBuild predefined variants defined in the evaluated variant set. It never returns
     * {@code null}. If the project contains no PostBuild variants, the result will be an empty list.
     *
     * <p>
     * The order of variant views returned is deterministic. It is the natural order of the names of the variants defined in the evaluated variant set.
     * </p>
     *
     * <p>
     * Caution: DO NOT use this method in the generators, please use the <code>IGenPostBuildSelectableVariantsService</code> instead.
     * </p>
     * </div>
     *
     * <p>
     * If your code needs no special handling for the non-variant use case, consider to call {@link IModelViewManagerCoreInternal#getAllPostBuildVariantViewsOrInvariant()} instead.
     * </p>
     *
     * <p>
     * Note: This method is {@link IModelView} aware, which means the result depends on the activated {@link IPreBuildView}, or the <code>IUnfilteredView</code>.
     * </p>
     *
     * @return The List of {@link IPostBuildPredefinedVariantView}s in the project.
     */
    @PublishedMethod
    List<IPostBuildPredefinedVariantView> getAllPostBuildVariantViews();

    /**
     * This method returns the model views of all PostBuild predefined variants defined in the evaluated variant set. It never returns {@code null}. If the project contains no
     * PostBuild variants, the result will be an empty list.
     *
     * <p>
     * The order of variant views returned is deterministic. It is the natural order of the names of the variants defined in the evaluated variant set.
     * </p>
     *
     * <p>
     * Caution: DO NOT use this method in the generators, please use the <code>IGenPostBuildSelectableVariantsService</code> instead.
     * </p>
     *
     * <p>
     * If your code needs no special handling for the non-variant use case, consider to call {@link IModelViewManagerCoreInternal#getAllPostBuildVariantViewsOrInvariant()} instead.
     * </p>
     *
     * <p>
     * Note: This method is {@link IModelView} aware, which means the result depends on the activated {@link IPreBuildView}, or the <code>IUnfilteredView</code>.
     * </p>
     *
     * @return The List of {@link IPredefinedVariantView}s in the project.
     * @deprecated Please use the method {@link #getAllPostBuildVariantViews()} instead!
     */
    @PublishedMethod
    @Deprecated
    List<IPredefinedVariantView> getAllVariantViews();

    /**
     * Returns {@code true} if the object and all its parents has no variation point conditions or formula expressions.
     * <p>
     * This will consider PreBuild and PostBuild variance.
     * </p>
     *
     * @param obj the {@link MIObject} to check.
     * @return true, if the {@link MIObject} is invariant in PreBuild and PostBuild
     * @exception IllegalArgumentException if the MIObject was already removed
     */
    @PublishedMethod
    boolean isModelInvariant(MIObject obj);

    /**
     * Returns {@code true} if the object has the same value in all PostBuild variants.
     * <p>
     * See {@link IPostBuildInvariantValuesView} for more details to the concept.
     * </p>
     *
     * <p>
     * Attention: This must also return true for elements in other variants as the first PostBuild Predefined Variant, when the element is invariant! This is not the same result as
     * {@link IPostBuildInvariantValuesView} <code>isVisible()</code> method returns.
     * </p>
     *
     *
     * @param obj the {@link MIObject} to check.
     * @return true, if the {@link MIObject} is invariant according to its value.
     * @exception IllegalArgumentException if the MIObject was already removed
     * @deprecated Please use the method {@link #isPostBuildValueInvariant()} instead!
     */
    @PublishedMethod
    @Deprecated
    boolean isValueInvariant(MIObject obj);

    /**
     * Returns {@code true} if the object has the same value in all PostBuild variants.
     * <p>
     * See {@link IPostBuildInvariantValuesView} for more details to the concept.
     * </p>
     *
     * <p>
     * Attention: This must also return true for elements in other variants as the first PostBuild Predefined Variant, when the element is invariant! This is not the same result as
     * {@link IPostBuildInvariantValuesView} <code>isVisible()</code> method returns.
     * </p>
     *
     *
     * @param obj the {@link MIObject} to check.
     * @return true, if the {@link MIObject} is invariant according to its value.
     * @exception IllegalArgumentException if the MIObject was already removed
     */
    @PublishedMethod
    boolean isPostBuildValueInvariant(MIObject obj);

    /**
     * Returns {@code true} if the object is invariant according to its EcuC definition.
     * <p>
     * See {@link IPostBuildInvariantEcucDefView} for more details to the concept.
     * </p>
     *
     * @param obj the {@link MIObject} to check.
     * @return true, if the {@link MIObject} is invariant according to its EcuC definition.
     * @exception IllegalArgumentException if the MIObject was already removed
     * @deprecated Please use the method {@link #isPostBuildEcucDefInvariant()} instead!
     */
    @Deprecated
    @PublishedMethod
    boolean isEcucDefInvariant(MIObject obj);

    /**
     * Returns {@code true} if the object is invariant according to its EcuC definition.
     * <p>
     * See {@link IPostBuildInvariantEcucDefView} for more details to the concept.
     * </p>
     *
     * @param obj the {@link MIObject} to check.
     * @return true, if the {@link MIObject} is invariant according to its EcuC definition.
     * @exception IllegalArgumentException if the MIObject was already removed
     */
    @PublishedMethod
    boolean isPostBuildEcucDefInvariant(MIObject obj);

    /**
     * Returns <code>true</code> if the object is visible in the current model view.
     *
     * @param object is the object to be checked
     * @return
     */
    @PublishedMethod
    boolean isVisible(MIObject object);

    /**
     * Returns {@code true} if the object is visible in the specified model view.
     *
     * <p>
     * If the passed {@link MIObject} is removed, the method will return <code>false</code>.
     * </p>
     *
     * @param obj The {@link MIObject} to check for visibility.
     * @param modelview the {@link IModelView} to check.
     * @return true, if visible, otherwise false.
     */
    @PublishedMethod
    boolean isVisibleInModelView(MIObject obj, IModelView modelview);

    /**
     * Returns all PostBuild variant views the specified object is visible in.
     *
     * <p>
     * If the passed {@link MIObject} is removed, the method will return an empty collection.
     * </p>
     *
     * <p>
     * Note: This method is {@link IModelView} aware, which means the result depends on the activated {@link IPreBuildView}, or the <code>IUnfilteredView</code>.
     * </p>
     *
     * @param obj
     * @return The collection of ModelViews, or empty collection.
     * @deprecated Please use the method {@link #getVisiblePostBuildVariantViews(MIObject)} instead!
     */
    @PublishedMethod
    @Deprecated
    Collection<IPredefinedVariantView> getVisibleVariantViews(MIObject obj);

    /**
     * Returns all PostBuild variant views the specified object is visible in.
     *
     * <p>
     * If the passed {@link MIObject} is removed, the method will return an empty collection.
     * </p>
     *
     * <p>
     * Note: This method is {@link IModelView} aware, which means the result depends on the activated {@link IPreBuildView}, or the <code>IUnfilteredView</code>.
     * </p>
     *
     * @param obj
     * @return The collection of ModelViews, or empty collection.
     */
    @PublishedMethod
    Collection<IPostBuildPredefinedVariantView> getVisiblePostBuildVariantViews(MIObject obj);

    /**
     * Returns all PreBuild variant views the specified object is visible in.
     *
     * <p>
     * If the passed {@link MIObject} is removed, the method will return an empty collection.
     * </p>
     *
     * <p>
     * Note: This method is <b>NOT</b> {@link IModelView} aware, which means the result does <b>NOT</b> depend on the activated {@link IPreBuildView}, or the
     * <code>IUnfilteredView</code>.
     * </p>
     *
     * @param obj
     * @return The collection of ModelViews, or empty collection.
     */
    @KeepSecretFromPublishedApi
    Collection<IPreBuildPredefinedVariantView> getVisiblePreBuildVariantViews(MIObject obj);

    /**
     * Returns all Pre and PostBuild variant views the specified object is visible in.
     *
     * <p>
     * If the passed {@link MIObject} is removed, the method will return an empty collection.
     * </p>
     *
     * <p>
     * Note: This method is <b>NOT</b> {@link IModelView} aware, which means the result does <b>NOT</b> depend on the activated {@link IPreBuildView}, or the
     * <code>IUnfilteredView</code>.
     * </p>
     *
     * @param obj
     * @return The collection of ModelViews, or empty collection.
     */
    @KeepSecretFromPublishedApi
    Collection<IPredefinedVariantView> getVisiblePreAndPostBuildVariantViews(MIObject obj);

    /**
     * This method returns the {@link IPostBuildInvariantView} in the following cases.
     * <ul>
     * <li>The project contains no PostBuild variants
     * <li>The specified object is a member of a module configuration which doesn't support post-build selectable according to
     * <code>IEcucModuleConfiguration.supportsPostBuildVariance()</code>.
     * </ul>
     * In all other cases, this method returns the same list as {@link #getVisiblePostBuildVariantViews(MIObject)}.
     * <p>
     * If the passed {@link MIObject} is removed, the method will return an empty collection in either case.
     * </p>
     *
     * <p>
     * Note: This method is {@link IModelView} aware, which means the result depends on the activated {@link IPreBuildView}, or the <code>IUnfilteredView</code>.
     * </p>
     *
     * @param obj
     * @return
     * @deprecated Please use the method {@link #getVisiblePostBuildVariantViewsOrInvariant(MIObject)} instead!
     */
    @PublishedMethod
    @Deprecated
    Collection<IModelView> getVisibleVariantViewsOrInvariant(MIObject obj);

    /**
     * This method returns the {@link IPostBuildInvariantView} in the following cases.
     * <ul>
     * <li>The project contains no PostBuild variants
     * <li>The specified object is a member of a module configuration which doesn't support post-build selectable according to
     * <code>IEcucModuleConfiguration.supportsPostBuildVariance()</code>.
     * </ul>
     * In all other cases, this method returns the same list as {@link #getVisiblePostBuildVariantViews(MIObject)}.
     * <p>
     * If the passed {@link MIObject} is removed, the method will return an empty collection in either case.
     * </p>
     *
     * <p>
     * Note: This method is {@link IModelView} aware, which means the result depends on the activated {@link IPreBuildView}, or the <code>IUnfilteredView</code>.
     * </p>
     *
     * @param obj
     * @return
     */
    @PublishedMethod
    Collection<IPostBuildView> getVisiblePostBuildVariantViewsOrInvariant(MIObject obj);

    /**
     * Returns <code>true</code> if the object is invisible in all PostBuild variant views. That's, for example, the case for objects with contradicting variation point conditions
     * (parent is visible in variant A only and the child object in variant B). In this case the specified object is visible in the unfiltered view only.
     * <p>
     * Special cases:
     * <ul>
     * <li>This method returns <code>true</code> for removed objects (really deleted from the MDF-model and not only invisible)</li>
     * <li>This method returns <code>false</code> when the project contains no variants at all</li>
     * </ul>
     * </p>
     *
     * @param obj
     * @return true, if the obj is never visible in any {@link IPostBuildPredefinedVariantView}.
     * @deprecated Please use the method {@link #isNeverPostBuildVisible(MIObject)} instead!
     */
    @PublishedMethod
    @Deprecated
    boolean isNeverVisible(MIObject obj);

    /**
     * Returns <code>true</code> if the object is invisible in all PostBuild variant views. That's, for example, the case for objects with contradicting variation point conditions
     * (parent is visible in variant A only and the child object in variant B). In this case the specified object is visible in the unfiltered view only.
     * <p>
     * Special cases:
     * <ul>
     * <li>This method returns <code>true</code> for removed objects (really deleted from the MDF-model and not only invisible)</li>
     * <li>This method returns <code>false</code> when the project contains no variants at all</li>
     * </ul>
     * </p>
     *
     * @param obj
     * @return true, if the obj is never visible in any {@link IPostBuildPredefinedVariantView}.
     */
    @PublishedMethod
    boolean isNeverPostBuildVisible(MIObject obj);

    /**
     * Executes the code under visibility of the specified model view.
     * <p>
     * <strong>The returned {@link IModelViewExecutionContext} must be used within a Java "try-with-resources" feature.</strong> It makes sure, that the old view is restored when
     * the try is completed.
     * </p>
     * <p>
     * Example:
     *
     * <pre>
     * <code>
     * public void foo({@link IModelViewManagerCoreInternal} modelViewManager) {
     *     {@link IModelView} allView = modelViewManager.getUnfilteredView();
     *
     *     try (final {@link IModelViewExecutionContext} context = modelViewManager.executeWithModelView(allView)) {
     *         // do some operations
     *         ...
     *     }
     * }
     * </code>
     * </pre>
     *
     * </p>
     *
     * @param modelview the modelview
     * @return The execution context
     */
    @PublishedMethod
    IModelViewExecutionContext executeWithModelView(IModelView modelview);

    /**
     * <p>
     * Executes the code with the variant specific change mode which guarantees that all model changes implicitly modify the current variant only. If required this method creates
     * model object clones to guarantee that other variants have the same content afterwards.
     * </p>
     *
     * <div class="extdoc" id="ExecuteWithVariantSpecificModelChanges"><!--Index:VariantSpecifcModelChanges --> The CFG5 data model provides an execution context which guarantees
     * that only the selected variant is being modified. Objects which are visible in more than one variant are cloned automatically. The clones and the object which is being
     * modified (or their parents) automatically get a variation point with the required post-build conditions.
     *
     *
     * The following picture shows how this execution context works:<br/>
     * <!--LaTeX: See figure \vref{fig:VariantSpecificModelChangeOfParameter}.-->
     *
     * <img src="{@docRoot} /../_doc/VariantSpecificModelChange.png" alt="Variant specific change of a parameter value" data-latex-style="width=\textwidth" id="
     * fig:VariantSpecificModelChangeOfParameter" />
     *
     * <ul>
     * <li>Before modifying the parameter, this instance is invariant. The same MDF instance is visible in all variants
     * <li>When the client code changes the parameter value, the model automatically clones the parameter first
     * <li>Only the parameter instance which is visible in the currently active view is being modified. The content of other variants stays untouched
     * </ul>
     * <p>
     * <b>Remark:</b> This change mode is implicitly turned off when executing code in the {@link IInvariantView} or in an unfiltered context.
     * </p>
     * </div>
     *
     * @return The execution context
     */
    @PublishedMethod
    IModelViewExecutionContext executeWithVariantSpecificModelChanges();

    /**
     * Executes the code with the variant common change mode which guarantees that all model changes implicitly modify siblings in other variants too.
     *
     *
     * <div class="extdoc" id="ExecuteWithVariantCommonModelChanges"><!--Index:VariantCommonModelChanges --> The CFG5 data model provides an execution context which guarantees that
     * model objects are modified in all variants.
     * <p>
     * The behavior of this mode depends on the mode flag parameter as follows:
     * <ul>
     * <li><b>mode == ALL</b> : All parameters and containers are affected
     * <li><b>mode == DEFINITION_BASED</b> : Only those parameters and containers are affected which do not support variance (according to their definition in the BSWMD file and
     * the implementation configuration variant of their module configuration)
     * <li><b>mode == OFF</b> : Doesn't turn on this change mode (this value is used internally only)
     * </ul>
     * <b>Remark:</b> This method doesn't allow to reduce the scope of this change mode. So if ALL is already set, this method doesn't permit to use DEFINITION_BASED (or OFF) to
     * reduce the effective amount of objects. ALL will be still active then.
     * </p>
     * <p>
     *
     * The following picture shows how this execution context works:<br/>
     * <!--LaTeX: See figure \vref{fig:VariantCommonModelChangeOfParameter}.-->
     *
     * <img src="{@docRoot} /../_doc/VariantCommonModelChange.png" alt="Variant common change of a parameter value" data-latex-style="width=\textwidth" id="
     * fig:VariantCommonModelChangeOfParameter" />
     *
     * <ul>
     * <li>We start with a variant model which contains one parameter in two instances - one per variant - with the values 3 and 7
     * <li>When the client code sets the parameter value in variant 1 to 4, the model automatically modifies the variant sibling in variant 2
     * <li>As a result, the parameter has the same value in all variants
     * </ul>
     * </p>
     * <p>
     *
     * This change mode works with parameters and containers. The following operations are supported:
     * <ul>
     * <li><b>Container/parameter creation:</b> The created object afterwards exists in all variants the related parent exists in. Already existing objects are not modified.
     * Missing objects are created
     * <li><b>Container/parameter deletion:</b> The deleted object afterwards is being removed from all variants the related parent exists in. So actually all variant siblings are
     * deleted
     * <li><b>Parameter value change:</b> The parameter exists and has the same value in all variants the parent container exists in. If a parameter instance is missing in a
     * variant, it is being created
     * </ul>
     * </p>
     * <p>
     *
     * Special behavior for multi-instance parameters:
     * <ul>
     * <li>This mode guarantees that a set of multi-instance parameters is equal in all variants
     * <li>Only the values of multi-instance parameters are relevant. Their order can be different in different variants
     * <li>Beside the values, this change mode guarantees that all variants contain the same number of parameter instances. So, when a multi-instance set is being modified in a
     * variant view, this change mode creates or deletes objects in other variants to guarantee an equal number of instances in all variant sibling sets
     * </ul>
     * <p>
     * <b>Remark:</b> This change mode is implicitly turned on with the mode flag ALL when code is being executed in the {@link IInvariantView}. It is being ignored implicitly when
     * executing code in an unfiltered context.
     * </p>
     * </div>
     *
     *
     * @param mode
     * @return The execution context
     */
    @PublishedMethod
    IModelViewExecutionContext executeWithVariantCommonModelChanges(EVariantCommonMode mode);

}
