package com.vector.cfg.model.query.modelcheckedaccess.exceptions.references;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.references.IRefHasNoRefTargetExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Thrown when a reference has no TargetRef.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaReferenceHasNoRefTargetException extends McaReferenceException {

    private static final long serialVersionUID = -114855441665636489L;

    private final List<IRefHasNoRefTargetExData> exDataList;

    /**
     * Constructor for McaParameterWrongTypeException.
     *
     * @param wrongTypeExDataList
     */
    @PublishedMethod
    public McaReferenceHasNoRefTargetException(List<IRefHasNoRefTargetExData> exDataList) {
        super(exDataList);
        this.exDataList = exDataList;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<IRefHasNoRefTargetExData> getExceptionDataList() {
        return exDataList;
    }
}
