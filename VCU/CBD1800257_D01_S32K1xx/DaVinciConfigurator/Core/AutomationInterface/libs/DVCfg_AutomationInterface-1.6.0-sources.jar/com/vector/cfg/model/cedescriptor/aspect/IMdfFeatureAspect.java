package com.vector.cfg.model.cedescriptor.aspect;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.cedescriptor.IDescriptorAspect;
import com.vector.cfg.model.cedescriptor.validator.AspectValidator;
import com.vector.cfg.model.cedescriptor.validator.impl.MdfFeatureAspectValidator;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@AspectValidator(MdfFeatureAspectValidator.class)
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IMdfFeatureAspect extends IDescriptorAspect {
    @PublishedMethod
    String getFeature();
}
