package com.vector.cfg.gen.core.bswmdmodel;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Interface which represents a collection for {@link GIContainer} with upper multiplicity > 1.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @param <VALUE> the generic type
 */
//CHECKSTYLE:OFF Class Naming problem
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface GICList<VALUE extends GIModelObject> extends GIList<VALUE> {
    //CHECKSTYLE:ON

    /**
     * Creates a new child element with the specified shortName and appends it to this {@link GICList}. The new object is finally returned.
     *
     * <p>
     * The shortname must be a valid AUTOSAR shortname and NOT an AUTOSAR-Path (no /).
     * </p>
     *
     * @throws InvalidShortNameExceptin if shortName is not a valid AUTOSAR shortname
     *
     * @param shortName the short name
     * @return the created element
     */
    @PublishedMethod
    VALUE createAndAdd(String shortName);

    /**
     * Creates a new child element with the specified shortName and inserts it to this {@link GICList} at the specified index position. The new object is finally returned.
     *
     * <p>
     * The shortname must be a valid AUTOSAR shortname and NOT an AUTOSAR-Path (no /).
     * </p>
     *
     * @throws InvalidShortNameExceptin if shortName is not a valid AUTOSAR shortname
     *
     * @param shortName the short name
     * @param index the index
     * @return the created element
     */
    @PublishedMethod
    VALUE createAndAdd(String shortName, int index);

    /**
     * Gets the container by specified shortName.
     *
     * @param shortName the short name of the container
     * @exception BswmdModelNotExistsException If requested container does not exist.
     * @return the requested container
     */
    @PublishedMethod
    VALUE byName(String shortName);

    /**
     * Gets the container by specified shortName or null if not existing.
     *
     * @param shortName the short name
     * @return the requested container or null
     */
    @PublishedMethod
    VALUE byNameOrNull(String shortName);

    /**
     * Gets the container by specified shortName or creates a new one if not existing.
     *
     * @param shortName the short name of the container
     * @return the requested container
     */
    @PublishedMethod
    VALUE byNameOrCreate(String shortName);

    /**
     * Returns true if the container exists, otherwise false.
     *
     * @param shortName the short name of the container
     * @return true, if the container exists.
     */
    @PublishedMethod
    boolean exists(String shortName);

    /**
     * Gets the container by specified shortName.
     *
     * @param shortName the short name of the container
     * @exception BswmdModelNotExistsException If requested container does not exist.
     * @return the requested container
     */
    @PublishedMethod
    VALUE getAt(String shortName);

}
