package com.vector.cfg.model.query.modelcheckedaccess.elements;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The common base element for all IModelCheckedAccess request interfaces.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelCheckedAccess
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IMcaCommonElement<T extends IMcaCommonElement<T>> {

}
