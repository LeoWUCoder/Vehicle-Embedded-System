package com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.params;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.EParameterType;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterWrongTypeException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess exception data for the {@link McaParameterWrongTypeException}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see McaParameterWrongTypeException
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IParamWrongTypeExData extends IParamExData {

    /**
     * Gets the expected type of the model request.
     *
     * @return The expected type of the model request.
     */
    @PublishedMethod
    EParameterType getExpectedType();

    /**
     * Gets the actual type of the model request.
     *
     * @return The actual type of the model request.
     */
    @PublishedMethod
    EParameterType getActualType();

}
