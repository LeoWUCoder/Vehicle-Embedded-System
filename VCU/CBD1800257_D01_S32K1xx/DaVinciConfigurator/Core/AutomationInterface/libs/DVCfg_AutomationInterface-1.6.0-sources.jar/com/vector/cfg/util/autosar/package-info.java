/**
 * Basic AUTOSAR utilities like shortname handling, without any loaded model.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.autosar;