package com.vector.cfg.model.query.modeltraverser;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.internal.modeltraverser.definitiontree.EMultiplicity;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IInvalidReason;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IInvalidTraverserView;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.text.log.IUserMessage;

//@NEWLINE_CONVERSION:OFF
/**
 * <div class="extdoc" id="Common" data-target-doc="ConsistencyDocumentation">
 *
 *
 * <h5>InvalidView reasons</h5> <!--LaTeX:\label{sec:IInvalidViewReasons}-->
 *
 * The interface {@link IInvalidViewReasons} provides the information why the corresponding {@link IInvalidTraverserView} is invalid. This could be used to display a detailed
 * message to the user.
 *
 * An instance of {@link IInvalidViewReasons} could be retrieved by the method <br/>
 * {@link IInvalidTraverserView#getInvalidViewReasons()}. The {@link IInvalidViewReasons} object provides a list of {@link IInvalidReason}s, to retrieve each reason.
 *
 *
 * The figure <!--LaTeX:\vref{fig:InvalidViewReasons}--> describes the containment of the reasons for one {@link IInvalidTraverserView}.
 *
 * <img src="{@docRoot} /../_doc/UML/IInvalidViewReasons/InvalidViewReasons.png" alt= "Containment structure of the invalid reasons of one IInvalidTraverserView" id=
 * "fig:InvalidViewReasons" data-latex-style=" scale=0.6" />
 *
 *
 * <pre>
 * <!--PlantUML: InvalidViewReasons
 * enum {@link EInvalidViewReasonType} {
 * }
 * {@link EInvalidViewReasonType} <-_ {@link IInvalidViewReason}
 * note right of {@link IInvalidViewReason} : For each reason \nin the invalid view
 * {@link IInvalidViewReasons} "1" *-_ "1..*" {@link IInvalidViewReason}
 * {@link IInvalidTraverserView} "1" *-_ "1" {@link IInvalidViewReasons}
 * -->
 * </pre>
 *
 *
 * <p>
 * In order to use the {@link IInvalidViewReasons} you have to enable the feature during construction of the IModelTraverser. If the feature is not enabled at construction time,
 * the {@link IInvalidTraverserView} will always throw an exception, when retrieving the {@link IInvalidViewReasons}.
 * </p>
 *
 * </div>
 *
 *
 * <p>
 * See details to method {@link IModelTraverserBuilder#enableInvalidViewReasonsSupport()} to enable the feature.
 * </p>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IModelTraverserBuilder
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IInvalidViewReasons extends IUserMessage {

    /**
     * Return the corresponding {@link IInvalidTraverserView}.
     *
     * @return the invalid view.
     */
    @PublishedMethod
    IInvalidTraverserView getInvalidView();

    /**
     * Returns the {@link IInvalidViewReason} objects, why the view ({@link #getInvalidView()}) is invalid.
     *
     * @return the reasons
     */
    @PublishedMethod
    List<IInvalidViewReason> getReasons();

    /**
     * The Interface IInvalidViewReason contains the information of one reason, why an {@link IInvalidTraverserView} was invalid.
     */
    @NotThreadSafe
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public interface IInvalidViewReason extends IInvalidReason {

        /**
         * Returns the {@link EInvalidViewReasonType}. This could be used to "filter" or otherwise handle specific types of invalid reasons.
         *
         * @return the reason type.
         */
        @PublishedMethod
        EInvalidViewReasonType getReasonType();
    }

    /**
     * The Enum {@link EInvalidViewReasonType} specifies the different types of an {@link IInvalidViewReason} of one {@link IInvalidTraverserView}.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    enum EInvalidViewReasonType {

        /** The element was removed, or is invisible in the corresponding view. See {@link IInvalidViewReason#getActiveModelViewDuringRequest()} */
        REMOVED_OR_INVISIBLE,

        /** The {@link EMultiplicity#OPTIONAL} was violated. */
        MULTIPLICITY_VIOLATION_OPTIONAL,

        /** The {@link EMultiplicity#REQUIRED} was violated. */
        MULTIPLICITY_VIOLATION_REQUIRED,

        /** The {@link EMultiplicity#ONE_TO_UNLIMITED} was violated. */
        MULTIPLICITY_VIOLATION_ONE_TO_UNLIMITED,

        /** The parameter of reference has no value. */
        HAS_NO_VALUE,

        /** The parameter of reference has an invalid value. */
        HAS_INVALID_VALUE,

        /** The float or integer parameter is out of range of the min/max values. */
        MIN_MAX_VALUE_VIOLATION,

        ;

    }
}
