package com.vector.annotations.publishedapi;

/**
 * {@link PublishedFilterValue} defines predicates for the {@link PublishedFilter} annotation.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see PublishedFilter
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
//CHECKSTYLE:OFF Naming issue, but used in annotations.
public interface PublishedFilterValue {
    //CHECKSTYLE:ON
}
