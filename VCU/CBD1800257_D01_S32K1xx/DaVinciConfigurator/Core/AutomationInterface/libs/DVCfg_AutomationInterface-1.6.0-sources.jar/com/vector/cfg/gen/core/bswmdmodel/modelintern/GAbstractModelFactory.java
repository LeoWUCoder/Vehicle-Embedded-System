package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static com.vector.davinci.util.base.VUtil.NL;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.gen.core.bswmdmodel.GIModelFactory;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIModuleConfiguration;
import com.vector.cfg.gen.core.bswmdmodel.GIOptional;
import com.vector.cfg.gen.core.moduleinterface.variants.IGenPostBuildSelectableVariantsService;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaException;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.IModelViewManagerCoreInternal;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.exceptions.InterruptedRuntimeException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedFilter(MsrPlatform.class)
@NotThreadSafe
public abstract class GAbstractModelFactory implements GIModelFactory {
    private final Map<IModelView, IInternalGeneratorModelAccess> viewMap = Maps.newHashMap();

    private final IModelViewManager modelViewMgr;

    private final IProjectContext projectContext;

    private final GModelChangeListener modelChangeListener;

    protected GAbstractModelFactory(IProjectContext projectContext, IModelViewManager modelViewMgr) {
        this.modelViewMgr = modelViewMgr;
        this.projectContext = projectContext;

        modelChangeListener = projectContext.getInstance(GModelChangeListener.class);
        modelChangeListener.init();

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final <T extends GIModelObject> T getInstance(Class<T> giModelClazz, MIHasDefinition mdfCfgElement) {
        final IModelView view = modelViewMgr.getCurrentlyActiveView();
        return getInstance(giModelClazz, mdfCfgElement, view);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final <T extends GIModelObject> T getInstance(Class<T> giModelClazz, MIHasDefinition mdfCfgElement, IModelView viewToBindToElement) {
        checkNotNull(giModelClazz);
        checkNotNull(mdfCfgElement);
        checkNotNull(viewToBindToElement);

        final GIModelObject giElem = getOrCreateGenModelAccessForModelView(viewToBindToElement).getGenModelObjectByMDFObject(mdfCfgElement);
        if (!giModelClazz.isInstance(giElem)) {
            throw new IllegalArgumentException("The passed MDFElement " + ModelAccessUtil.toDebugStringMDFObject(mdfCfgElement) + " is no " + giModelClazz
                    + ". The real class was "
                    + giElem.getClass() + ".");
        }
        return giModelClazz.cast(giElem);
    }

    private <T extends GIModelObject> T getInstance(Class<T> giModelClazz, MIHasDefinition mdfCfgElement, IModelView viewToBindToElement, DefRef defRef) {
        checkNotNull(giModelClazz);
        checkNotNull(mdfCfgElement);
        checkNotNull(viewToBindToElement);

        final GIModelObject giElem = getOrCreateGenModelAccessForModelView(viewToBindToElement).getGenModelObjectByMDFObject(mdfCfgElement, defRef);
        if (!giModelClazz.isInstance(giElem)) {
            throw new IllegalArgumentException("The passed MDFElement " + ModelAccessUtil.toDebugStringMDFObject(mdfCfgElement) + " is no " + giModelClazz
                    + ". The real class was "
                    + giElem.getClass() + ". " + NL + " The classloader are:" + NL + giModelClazz.getClassLoader() + NL + giElem.getClass().getClassLoader());
        }
        return giModelClazz.cast(giElem);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T extends GIModelObject> List<T> getAllInstancesForAllPostBuildVariants(Class<T> giModelClazz, DefRef defRefOfRequestedElement) {
        checkNotNull(giModelClazz);
        checkNotNull(defRefOfRequestedElement);

        final List<T> resList = Lists.newArrayList();

        try (IModelViewExecutionContext context = ((IModelViewManagerCoreInternal) modelViewMgr).executeUnfiltered()) {

            final List<MIHasDefinition> allWithDefinition = projectContext.getService(IModelAccess.class).getAllWithDefinition(defRefOfRequestedElement);

            for (final MIHasDefinition elem : allWithDefinition) {
                final List<IModelView> allViews = projectContext.getService(IGenPostBuildSelectableVariantsService.class).getAllPostBuildVariantViews(elem);

                for (final IModelView modelView : allViews) {
                    try (IModelViewExecutionContext context2 = modelViewMgr.executeWithModelView(modelView)) {

                        if (modelViewMgr.isVisible(elem)) {
                            if (defRefOfRequestedElement.isDefinitionOf(elem)) {

                                resList.add(this.getInstance(giModelClazz, elem, modelView, defRefOfRequestedElement));
                            }
                        }
                    }

                }
            }
        }

        return resList;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T extends GIModelObject> List<T> getAllInstancesForAllPostBuildVariants(Class<T> giModelClazz, MIHasDefinition mdfCfgElement) {
        checkNotNull(giModelClazz);
        checkNotNull(mdfCfgElement);

        final List<T> resList = Lists.newArrayList();

        final List<IModelView> allViews = projectContext.getService(IGenPostBuildSelectableVariantsService.class).getAllPostBuildVariantViews(mdfCfgElement);

        for (final IModelView modelView : allViews) {
            try (IModelViewExecutionContext context = modelViewMgr.executeWithModelView(modelView)) {
                if (modelViewMgr.isVisible(mdfCfgElement)) {

                    resList.add(this.getInstance(giModelClazz, mdfCfgElement));
                }
            }

        }

        return resList;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T extends GIModelObject> List<T> getAllInstancesForCurrentActiveView(WrappedTypedDefRef<?, ?, ?, T> defRefOfRequestedElement) {
        checkNotNull(defRefOfRequestedElement);
        final Class<T> giModelClazz = defRefOfRequestedElement.getModelWrapperClass();
        final List<T> resList = Lists.newArrayList();

        final List<MIHasDefinition> allWithDefinition = projectContext.getService(IModelAccess.class).getAllWithDefinition(defRefOfRequestedElement);
        final IModelView modelView = modelViewMgr.getCurrentlyActiveView();
        for (final MIHasDefinition elem : allWithDefinition) {

            if (defRefOfRequestedElement.isDefinitionOf(elem)) {
                /*
                 * Only allow the real exact matching element, or if the DefRef is a Wildcard.
                 * This shall prevent the instantiation of BswmdModel from refined elements, when the requested element was a parent.
                 * E.g. Passed DefRef is /AUTOSAR but the instance is of type /MICROSAR, which could instantiate the wrong ModelElement.
                 */
                if (defRefOfRequestedElement.hasWildcards() || defRefOfRequestedElement.getDefRefString().equals(ModelUtil.getDefinitionString(elem))) {

                    resList.add(this.getInstance(giModelClazz, elem, modelView, defRefOfRequestedElement));
                }
            }
        }

        return resList;
    }

    public final IInternalGeneratorModelAccess getOrCreateGenModelAccessForModelView(IModelView view) {

        IInternalGeneratorModelAccess generatorModelAccess = viewMap.get(view);
        if (generatorModelAccess != null) {
            return generatorModelAccess;
        }

        try (IModelViewExecutionContext context = modelViewMgr.executeWithModelView(view)) {
            generatorModelAccess = createNewGeneratorModelAccess();
        }

        viewMap.put(view, generatorModelAccess);
        return generatorModelAccess;

    }

    void checkCacheAndInvalidateIfNecessary() {
        if (modelChangeListener.isCacheValid()) {
            return;
        }
        invalidateCache();
    }

    /**
     * Invalidate cache.
     *
     */
    private void invalidateCache() {

        InterruptedRuntimeException.checkThreadInterruptedAndThrowInterruptedRuntimeException();
        modelChangeListener.notifyStartCacheUpdate();

        final Collection<IInternalGeneratorModelAccess> models = viewMap.values();

        for (final IInternalGeneratorModelAccess model : models) {
            model.invalidateCache();
        }
        InterruptedRuntimeException.checkThreadInterruptedAndThrowInterruptedRuntimeException();
        checkState(modelChangeListener.isCacheValid(),
                "The MDF Model was concurrently modified, but the reader thread was not canceled, the caller of this code, must cancel this Reader-Thread, when a UnitOfWork was started.");
    }

    protected <T extends GIModuleConfiguration> List<T> getModuleConfigInternalMult(DefRef defRef, Class<T> giModelClazz) {

        final List<MIModuleConfiguration> moduleConfigList = getIModelCheckedAccess().moduleConfig(defRef).getManyModuleConfigs();
        final List<T> bswmdmoduleConfigList = new ArrayList<>();

        for (final MIModuleConfiguration moduleConfig : moduleConfigList) {
            bswmdmoduleConfigList.add(this.getInstance(giModelClazz, moduleConfig));
        }

        return bswmdmoduleConfigList;
    }

    protected <T extends GIModuleConfiguration> T getModuleConfigInternalMand(DefRef defRef, Class<T> giModelClazz) {

        return getModuleConfigInternalOptional(defRef, giModelClazz, true).get();
    }

    protected <T extends GIModuleConfiguration> GIOptional<T> getModuleConfigInternalOpt(DefRef defRef, Class<T> giModelClazz) {

        return getModuleConfigInternalOptional(defRef, giModelClazz, false);
    }

    private <T extends GIModuleConfiguration> GIOptional<T> getModuleConfigInternalOptional(DefRef defRef, Class<T> giModelClazz, boolean throwException) {
        GIOptional<T> opt;
        final MIModuleConfiguration moduleConfig;

        try {
            moduleConfig = getIModelCheckedAccess().moduleConfig(defRef).getModuleConfig();
            final T giModuleConfig = this.getInstance(giModelClazz, moduleConfig);
            opt = new GOptional<>(true, giModuleConfig, null);
        } catch (final McaException e) {
            if (throwException) {
                throw e;
            }

            opt = new GOptional<>(false, null, new Runnable() {

                @Override
                public void run() {
                    throw new ModelException("get() was called, but module config does not exist.", e);
                }
            });
        }

        return opt;
    }

    private IModelCheckedAccess getIModelCheckedAccess() {
        return this.getProjectContext().getService(IModelCheckedAccess.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IProjectContext getProjectContext() {
        return projectContext;
    }

    protected abstract IInternalGeneratorModelAccess createNewGeneratorModelAccess();

}
