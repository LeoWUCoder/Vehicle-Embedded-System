package com.vector.cfg.model.query.definitionverify;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Verifies defRef Object and reports error the the Log.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public final class LogDefinitionVerifier extends AbstractDefinitionVerifier {

    private static final ILogger logger = Logger.INSTANCE.createLogger(LogDefinitionVerifier.class);

    /**
     * Constructor for DefinitionVerifier.
     *
     * @param context
     */
    private LogDefinitionVerifier(IProjectContext context) {
        super(context);
    }

    /**
     * Creates a new LogDefinitionVerifier.
     *
     * @param context the context
     * @return the log definition verifier
     */
    @PublishedMethod
    public static LogDefinitionVerifier create(IProjectContext context) {
        return new LogDefinitionVerifier(context);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void reportMissingDefinitionDependency(DefRef defRef) {
        logger.error("Missing required Definition: " + defRef);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void reportInvalidDefinitionDependency(TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?> typedDefRef, MIParamConfMultiplicity defObj, String errorMsg) {
        logger.error("Invalid Definition found, which was marked as required/optional with a certain type. " + (errorMsg != null && !errorMsg.isEmpty() ? errorMsg + " " : "")
                + "Requested type: " + typedDefRef + " ActualType: " + ModelAccessUtil.toDebugStringMDFObject(defObj));
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void reportIllegalProcessingField(String msg, Throwable ex) {
        logger.error(msg, ex);
    }

}
