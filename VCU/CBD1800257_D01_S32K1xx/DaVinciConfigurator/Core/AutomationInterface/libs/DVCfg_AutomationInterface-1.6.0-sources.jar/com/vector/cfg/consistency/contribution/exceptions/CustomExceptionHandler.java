package com.vector.cfg.consistency.contribution.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class CustomExceptionHandler implements ICustomExceptionHandler {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(CustomExceptionHandler.class);

    /**
     * Instantiates a new custom exception handler.
     */
    @PublishedMethod
    public CustomExceptionHandler() {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void onModelException(IValidationResultSink resultSink, ModelException ex) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void onException(IValidationResultSink resultSink, Exception ex) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean suppressReThrowOfUnhandledExceptions() {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void onUnhandledException(IValidationResultSink resultSink, Exception ex) {

    }

}
