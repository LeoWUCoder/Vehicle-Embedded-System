package com.vector.cfg.persistency;

import java.util.List;

import org.eclipse.core.runtime.IStatus;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.util.text.format.FormattingService;
import com.vector.cfg.util.text.format.ISpecificFormatterProvider.EFormatType;
import com.vector.cfg.util.text.log.IUserMessage;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * This class defines an exception object being used for persistency problems.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ReworkThisAtNextBreakingChange("move this interface to c.v.c.persistency.base")
public class PersistencyRuntimeException extends RuntimeException implements IUserMessage {
    private static final long serialVersionUID = -2006670415499201866L;

    private static final String NL = System.lineSeparator();

    private final List<? extends PersistencyRuntimeException> innerList;

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public PersistencyRuntimeException() {
        this("");
    }

    /**
     * Constructor.
     *
     * @param msg
     */
    @KeepSecretFromPublishedApi
    public PersistencyRuntimeException(String msg) {
        this(msg, (Throwable) null);

    }

    /**
     * Constructor.
     *
     * @param msg
     * @param cause
     */
    @KeepSecretFromPublishedApi
    public PersistencyRuntimeException(String msg, Throwable cause) {
        super(msg, cause);
        innerList = ImmutableList.of();
    }

    /**
     * When the given {@link IStatus} is of type {@link IStatus#ERROR} an {@link PersistencyRuntimeException} is created and thrown built of the given status.
     *
     * @param status the status to evaluate.
     */
    @KeepSecretFromPublishedApi
    public static void throwPersistencyRuntimExceptionOnErrorStatus(IStatus status) {
        if (status.matches(IStatus.ERROR)) {
            throw new PersistencyRuntimeException(FormattingService.INSTANCE.formatObject(status, "", EFormatType.USER), status.getException());
        }
    }

    /**
     * Constructor.
     *
     * @param msg
     * @param cause
     */
    @KeepSecretFromPublishedApi
    public PersistencyRuntimeException(String msg, List<? extends PersistencyRuntimeException> cause) {
        super(msg);
        innerList = ImmutableList.copyOf(cause);
    }

    @Override
    @KeepSecretFromPublishedApi
    public IMixedText getUserMessage() {
        return MixedText.fromConstantString(getMessage());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {

        final StringBuilder sb = new StringBuilder();
        sb.append(this.getClass().getSimpleName()).append(" [").append(getMessage());
        sb.append("]");

        if (!innerList.isEmpty()) {
            appendNl(sb);
            sb.append("Inner ExceptionList:");
            appendNl(sb);
            for (final PersistencyRuntimeException ex : innerList) {
                if (ex != this) {
                    sb.append(ex.toString());
                    appendNl(sb);
                }
            }
        } else {
            if (getCause() != null) {
                Throwable inner = this.getCause();
                while (inner != null) {

                    appendNl(sb);
                    sb.append("Cause: ");
                    sb.append(inner.toString().trim());
                    if (inner instanceof PersistencyRuntimeException) {
                        // The toString method will print all => Recursion
                        break;
                    }
                    inner = inner.getCause();
                }

                appendNl(sb);
            }
        }
        return sb.toString();
    }

    /**
     * @param sb
     */
    private void appendNl(final StringBuilder sb) {
        sb.append(NL);
    }

}
