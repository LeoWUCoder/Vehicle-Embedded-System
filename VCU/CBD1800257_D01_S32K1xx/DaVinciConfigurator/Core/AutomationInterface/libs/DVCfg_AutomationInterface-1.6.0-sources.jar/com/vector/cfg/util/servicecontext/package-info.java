/**
 * {@link com.vector.cfg.util.servicecontext.IServiceContext} API definition. base types of all provided {@link com.vector.cfg.util.servicecontext.IServiceContext}s like
 * Application, Projects, GUI.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.servicecontext;