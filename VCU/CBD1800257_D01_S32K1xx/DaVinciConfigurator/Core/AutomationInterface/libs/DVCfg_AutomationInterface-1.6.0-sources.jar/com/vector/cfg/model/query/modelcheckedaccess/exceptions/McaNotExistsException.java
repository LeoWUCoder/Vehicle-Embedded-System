package com.vector.cfg.model.query.modelcheckedaccess.exceptions;

import java.util.Collections;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.INotExistsExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Thrown when a model request can't find a corresponding object in the model for the request.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaNotExistsException extends McaException {

    private static final long serialVersionUID = -2051770079600952367L;

    private final INotExistsExData exData;

    /**
     * Constructor for McaParameterWrongTypeException.
     *
     * @param wrongTypeExDataList
     */
    @PublishedMethod
    public McaNotExistsException(INotExistsExData exData) {
        super(Collections.singletonList(exData));
        this.exData = exData;
    }

    /**
     * Gets a {@link INotExistsExData} object with detailed information about the exception cause.
     *
     * @return The exception cause data object
     */
    @PublishedMethod
    @Override
    public INotExistsExData getExceptionData() {
        return exData;
    }

}
