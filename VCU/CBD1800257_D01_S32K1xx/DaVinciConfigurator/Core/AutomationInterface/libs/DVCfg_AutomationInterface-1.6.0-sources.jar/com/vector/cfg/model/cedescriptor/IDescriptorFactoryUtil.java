package com.vector.cfg.model.cedescriptor;

import java.util.List;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedAsrPath;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.base.MIARElement;
import com.vector.cfg.model.mdf.model.autosar.base.MIARPackage;
import com.vector.cfg.model.mdf.model.autosar.base.MIAUTOSAR;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * This service builds on top of {@link IDescriptorFactory} and contains utility methods to build descriptor chains.
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IDescriptorFactoryUtil {

    /**
     *
     * Creates a builder that has the indirectParent as some parent descriptor, followed by several child-descriptor-levels with the according DefRefAspect until the
     * indirectChildDefRef is reached.
     * <ul>
     * <li>If the indirectParent is null, the root descriptor is the ModelInfo object with the MdfFeatureAspect "ACTIVE_MODULE_CONFIGURATIONS".</li>
     * <li>If the indirectChild is not null, the other parameters are not used, but the indirectChild is immediately forwarded to the IDescriptorFactory.</li>
     * <li>If the indirectChild is null, indirectChildDefRef must be a DefRef that specifies the package part. Otherwise an {@link IllegalStateException} will be thrown.</li>
     * </ul>
     * <p>
     * The usage of the term '<b>indirect</b>' is derived from the strong hierarchical nature of the {@link DefRef}s (which represent AUTOSAR definition strings).
     * </p>
     * <p>
     * Example:
     * <ul>
     * <li><b>P</b>: "/MICROSAR/CanIf" is the definition of the CanIf MICROSAR Module.</li>
     * <li><b>D</b>: "/MICROSAR/CanIf/CanIfDispatchCfg" is the definition of a container in the CanIf Module.</li>
     * <li><b>C</b>: "/MICROSAR/CanIf/CanIfInitCfg/CanIfBufferCfg/CanIfBufferSize" is the definition of a parameter in the CanIfBufferCfg-container.</li>
     * <li><b>C</b> is an indirect child of <b>P</b></li>
     * <li><b>P</b> is an indirect parent of <b>C</b></li>
     * <li><b>D</b> is a direct child of <b>P</b></li>
     * <li><b>P</b> is a direct parent of <b>D</b></li>
     * </ul>
     * </p>
     *
     * @param indirectChildDefRef can be null if the indirectChild is not null
     * @param indirectChild if this is null, the MdfObjectObject aspect won't be set
     * @param indirectParent if this is null, the root descriptor is the ModelInfo object with the MdfFeatureAspect
     *
     * @return the descriptor builder that represents the indirectChild with as much information as specified
     */
    @PublishedMethod
    IDescriptorBuilder createBuilder(@Nullable DefRef indirectChildDefRef, @Nullable MIHasDefinition indirectChild, @Nullable MIHasDefinition indirectParent);

    /**
     *
     * Equal to {@link #createBuilder(DefRef, MIHasDefinition, MIHasDefinition)} but it immediately calls {@link IDescriptorBuilder#create()} on the builder.
     *
     * @param indirectChildDefRef can be null if the indirectChild is not null
     * @param indirectChild if this is null, the MdfObjectObject aspect won't be set
     * @param indirectParent if this is null, the root descriptor is the ModelInfo object with the MdfFeatureAspect
     *
     * @return the descriptor builder that represents the indirectChild with as much information as specified
     */
    @PublishedMethod
    IDescriptor createDescriptor(DefRef indirectChildDefRef, MIHasDefinition indirectChild, MIHasDefinition indirectParent);

    /**
     * Creates a {@link IDescriptorBuilder} for a missing Model element, which has no {@link DefRef} (e.g. SystemDescription).
     *
     * <p>
     * The {@link AsrPath} elem describes the missing element. The AUTOSAR path of the asrPath is the path from ModelRoot to the missing element (e.g.
     * /MICROSAR/Swc/NvM/MyElement). If there is no root package, MIAUTOSAR is used. For further restrictions on the used {@link AsrPath} see
     * {@link com.vector.cfg.model.cedescriptor.aspect.IAsrPathAspect IAsrPathAspect}.
     * </p>
     *
     * <p>
     * <b>Important:</b> This method must be used for descriptors, which are covered only by an AsrPath-filter.
     * </p>
     *
     * @param <T> the generic type
     * @param asrPath the full autosar path to the missing element.
     * @return the descriptor builder that represents the {@link AsrPath} object.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if parameter asrPath is null</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the evaluated path does not consist only of Packages, except of the last element</li>
     * </ul>
     *
     * @see com.vector.cfg.model.cedescriptor.aspect.IAsrPathAspect IAsrPathAspect
     * @see com.vector.cfg.consistency.contribution.IRuleFilterAsrPathContribution IRuleFilterAsrPathContribution
     *
     */
    @KeepSecretFromPublishedApi
    IDescriptorBuilder createBuilderForAutosarElementByPlainAsrPath(AsrPath asrPath);

    /**
     * Creates a {@link IDescriptorBuilder} for a missing Model element, which has no {@link DefRef} (e.g. SystemDescription).
     *
     * <p>
     * The {@link TypedAsrPath} elem describes the missing element, therefore it must have a valid MetaClass object({@link TypedAsrPath} instead of {@link AsrPath}). The AUTOSAR
     * path of the asrPath is the path from ModelRoot to the missing element (.e.g. /MICROSAR/Swc/NvM/MyElement). And the ModelRoot object, which should be used to start the
     * Descriptor chain. If there is no root package, MIAUTOSAR is used. All missing element in the chain are assumed as {@link MIARPackage} elements. If you have to describe an
     * element below another element, please use the method {@link #createBuilderForAutosarElementByAsrPath(TypedAsrPath, MIARElement, TypedAsrPath...)}.
     * </p>
     *
     *
     * @param <T> the generic type
     * @param asrPath the full autosar path to the missing element.
     * @return the descriptor builder that represents the {@link AsrPath} object.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if parameter asrPath is null</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the evaluated path does not no consist only of Packages, except of the last element</li>
     * </ul>
     *
     *
     */
    @PublishedMethod
    <T extends MIARElement> IDescriptorBuilder createBuilderForAutosarElementByAsrPath(TypedAsrPath<T> asrPath);

    /**
     * Creates a {@link IDescriptorBuilder} for a missing Model element, which has no {@link DefRef} (e.g. SystemDescription elements).
     *
     * <p>
     * The {@link TypedAsrPath} indirectChild describes the missing element, therefore it must have a valid MetaClass object({@link TypedAsrPath} instead of {@link AsrPath}).
     * </p>
     *
     * <p>
     * This method will build a Descriptor-Chain starting at Root({@link MIAUTOSAR}), via the indirectParent, then for each element in the chain, to the indirectChild.
     * </p>
     *
     * <p>
     * If the indirectParent is null, the chain must start at the outermost parent element, which is no {@link MIARPackage} (The {@link MIARPackage} elements are added
     * automatically).
     * </p>
     *
     * <p>
     * Every element in the chainFromParentToIndirectChild must be the parent of the indirectChild and must be a child or equal to indirectParent. Every element in the list must
     * be the parent of the nextElement in list. If the chainFromParentToIndirectChild list is empty, the indirectChild must be the direct Child of the indirectParent.
     * </p>
     *
     * <p>
     * Attention: This method will not set all {@link com.vector.cfg.model.cedescriptor.aspect.IMdfFeatureAspect IMdfFeatureAspects} of the generated {@link IDescriptor
     * IDescriptors}. This could lead to problems in the GUI, if the {@link IDescriptor IDescriptors} are used as erroneous objects.
     * </p>
     *
     *
     * @param <T> the generic type
     * @param indirectChild the indirectChild for which a {@link IDescriptorBuilder} is created.
     * @param indirectParent the existing indirectParent. this could be null.
     * @param chainFromParentToIndirectChild the Path-Chain form parent to child.
     * @return the descriptor builder that represents the {@link AsrPath} object.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if parameter indirectChild is null</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the indirectChild in no child of indirectParent</li>
     * <li>if an element in the chainFromParentToIndirectChild is no parent of the indirectChild</li>
     * <li>if an element in the chainFromParentToIndirectChild is no child or equal of the indirectParent</li>
     * <li>if an element in the chainFromParentToIndirectChild is not the parent of the next element in list</li>
     * </ul>
     *
     */
    @PublishedMethod
    <T extends MIReferrable> IDescriptorBuilder createBuilderForAutosarElementByAsrPath(TypedAsrPath<T> indirectChild, MIARElement indirectParent,
            @SuppressWarnings("unchecked") TypedAsrPath<? extends MIReferrable>... chainFromParentToIndirectChild);

    /**
     * Creates a {@link IDescriptorBuilder} for a missing Model element, which has no {@link DefRef} (e.g. SystemDescription elements).
     *
     * <p>
     * The {@link TypedAsrPath} indirectChild describes the missing element, therefore it must have a valid MetaClass object({@link TypedAsrPath} instead of {@link AsrPath}).
     * </p>
     *
     * <p>
     * This method will build a Descriptor-Chain starting at Root({@link MIAUTOSAR}), via the indirectParent, then for each element in the chain, to the indirectChild.
     * </p>
     *
     * <p>
     * If the indirectParent is null, the chain must start at the outermost parent element, which is no {@link MIARPackage} (The {@link MIARPackage} elements are added
     * automatically).
     * </p>
     *
     * <p>
     * Every element in the chainFromParentToIndirectChild must be the parent of the indirectChild and must be a child or equal to indirectParent. Every element in the list must
     * be the parent of the nextElement in list. If the chainFromParentToIndirectChild list is empty, the indirectChild must be the direct Child of the indirectParent.
     * </p>
     *
     * <p>
     * Attention: This method will not set all {@link com.vector.cfg.model.cedescriptor.aspect.IMdfFeatureAspect IMdfFeatureAspects} of the generated {@link IDescriptor
     * IDescriptors}. This could lead to problems in the GUI, if the {@link IDescriptor IDescriptors} are used as erroneous objects.
     * </p>
     *
     *
     * @param <T> the generic type
     * @param indirectChild the indirectChild for which a {@link IDescriptorBuilder} is created.
     * @param indirectParent the existing indirectParent. this could be null.
     * @param chainFromParentToIndirectChild the Path-Chain form parent to child.
     * @return the descriptor builder that represents the {@link AsrPath} object.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if parameter indirectChild is null</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the indirectChild in no child of indirectParent</li>
     * <li>if an element in the chainFromParentToIndirectChild is no parent of the indirectChild</li>
     * <li>if an element in the chainFromParentToIndirectChild is no child or equal of the indirectParent</li>
     * <li>if an element in the chainFromParentToIndirectChild is not the parent of the next element in list</li>
     * </ul>
     *
     */
    @PublishedMethod
    <T extends MIReferrable> IDescriptorBuilder createBuilderForAutosarElementByAsrPath(TypedAsrPath<T> indirectChild, MIARElement indirectParent,
            List<TypedAsrPath<? extends MIReferrable>> chainFromParentToIndirectChild);

    @PublishedMethod
    IDescriptorFactory getDescriptorFactory();
}
