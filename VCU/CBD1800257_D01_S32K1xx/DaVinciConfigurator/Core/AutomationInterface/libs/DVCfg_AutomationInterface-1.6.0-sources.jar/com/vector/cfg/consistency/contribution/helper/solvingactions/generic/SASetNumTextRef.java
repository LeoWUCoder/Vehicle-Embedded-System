package com.vector.cfg.consistency.contribution.helper.solvingactions.generic;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public abstract class SASetNumTextRef<NUM_TEXT_REF_TYPE> extends SASetParam {

    private final NUM_TEXT_REF_TYPE param;

    /**
     * Getter method for param.
     *
     * @return Returns the param.
     */
    @PublishedMethod
    public NUM_TEXT_REF_TYPE getParam() {
        return param;
    }

    private final IMixedText targetValue;

    /**
     * Constructor for SASetNumTextRef.
     *
     * @param param
     * @param targetValue
     */
    @PublishedMethod
    public SASetNumTextRef(NUM_TEXT_REF_TYPE param, IMixedText targetValue) {
        super();
        this.param = param;
        this.targetValue = targetValue;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    protected IMixedText getParameter() {
        return MixedText.newBuilder().append(param).flushResult();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    protected IMixedText getTargetValue() {
        return MixedText.newBuilder().append(targetValue).flushResult();
    }
}
