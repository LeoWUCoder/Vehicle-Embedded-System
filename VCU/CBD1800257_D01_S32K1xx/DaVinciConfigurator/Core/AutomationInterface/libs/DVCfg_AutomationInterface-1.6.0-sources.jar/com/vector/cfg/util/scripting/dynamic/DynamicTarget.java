package com.vector.cfg.util.scripting.dynamic;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 * {@link DynamicTarget} marks the types that it is enriched at runtime which the specified type. This annotation helps IDEs to provide code completion at compile time for
 * runtime enhanced types.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public @interface DynamicTarget {
    String[] value();
}
