package com.vector.cfg.util.log;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface ILogger {
    @PublishedMethod
    void trace(Object message);

    @PublishedMethod
    void trace(Throwable t);

    @PublishedMethod
    void trace(Object message, Throwable t);

    /**
     * Logs a message with parameters at the {@link ELogLevel#TRACE} level.
     *
     * @param message the message to log; the format depends on the active {@link ILoggerMessageFormatter}.
     * @param arguments parameters to the message.
     *
     */
    @PublishedMethod
    void traceFormat(String message, Object... arguments);

    @PublishedMethod
    void debug(Object message);

    @PublishedMethod
    void debug(Throwable t);

    @PublishedMethod
    void debug(Object message, Throwable t);

    /**
     * Logs a message with parameters at the {@link ELogLevel#DEBUG} level.
     *
     * @param message the message to log; the format depends on the active {@link ILoggerMessageFormatter}.
     * @param arguments parameters to the message.
     *
     */
    @PublishedMethod
    void debugFormat(String message, Object... arguments);

    @PublishedMethod
    void info(Object message);

    @PublishedMethod
    void info(Throwable t);

    @PublishedMethod
    void info(Object message, Throwable t);

    /**
     * Logs a message with parameters at the {@link ELogLevel#INFO} level.
     *
     * @param message the message to log; the format depends on the active {@link ILoggerMessageFormatter}.
     * @param arguments parameters to the message.
     *
     */
    @PublishedMethod
    void infoFormat(String message, Object... arguments);

    @PublishedMethod
    void warn(Object message);

    @PublishedMethod
    void warn(Throwable t);

    @PublishedMethod
    void warn(Object message, Throwable t);

    /**
     * Logs a message with parameters at the {@link ELogLevel#WARN} level.
     *
     * @param message the message to log; the format depends on the active {@link ILoggerMessageFormatter}.
     * @param arguments parameters to the message.
     *
     */
    @PublishedMethod
    void warnFormat(String message, Object... arguments);

    @PublishedMethod
    void error(Object message);

    @PublishedMethod
    void error(Throwable t);

    @PublishedMethod
    void error(Object message, Throwable t);

    /**
     * Logs a message with parameters at the {@link ELogLevel#ERROR} level.
     *
     * @param message the message to log; the format depends on the active {@link ILoggerMessageFormatter}.
     * @param arguments parameters to the message.
     *
     */
    @PublishedMethod
    void errorFormat(String message, Object... arguments);

    @PublishedMethod
    void fatal(Object message);

    @PublishedMethod
    void fatal(Throwable t);

    @PublishedMethod
    void fatal(Object message, Throwable t);

    /**
     * Logs a message with parameters at the {@link ELogLevel#FATAL} level.
     *
     * @param message the message to log; the format depends on the active {@link ILoggerMessageFormatter}.
     * @param arguments parameters to the message.
     *
     */
    @PublishedMethod
    void fatalFormat(String message, Object... arguments);

    /**
     * Logs the passed message and exception at the passed {@link ELogLevel}.
     *
     * @param level the level
     * @param message the message to log, maybe <code>null</code>.
     * @param t the {@link Throwable} to log, maybe <code>null</code>.
     */
    @PublishedMethod
    void log(ELogLevel level, Object message, Throwable t);

    /**
     * Checks whether this Logger is enabled for the {@link ELogLevel#TRACE}.
     *
     * @return {@code true} if this Logger is enabled for {@link ELogLevel#TRACE} otherwise {@code false}.
     */
    @PublishedMethod
    boolean isTraceEnabled();

    /**
     * Checks whether this Logger is enabled for the {@link ELogLevel#DEBUG}.
     *
     * @return {@code true} if this Logger is enabled for {@link ELogLevel#DEBUG} otherwise {@code false}.
     */
    @PublishedMethod
    boolean isDebugEnabled();

    /**
     * Checks whether this Logger is enabled for the {@link ELogLevel#INFO}.
     *
     * @return {@code true} if this Logger is enabled for {@link ELogLevel#INFO} otherwise {@code false}.
     */
    @PublishedMethod
    boolean isInfoEnabled();

    /**
     * Checks whether this Logger is enabled for the {@link ELogLevel#WARN}.
     *
     * @return {@code true} if this Logger is enabled for {@link ELogLevel#WARN} otherwise {@code false}.
     */
    @PublishedMethod
    boolean isWarnEnabled();

    @PublishedMethod
    String getLoggerName();

    /**
     * Gets the Level of this Logger.
     *
     * @return the Level of this Logger.
     */
    @PublishedMethod
    ELogLevel getLevel();
}
