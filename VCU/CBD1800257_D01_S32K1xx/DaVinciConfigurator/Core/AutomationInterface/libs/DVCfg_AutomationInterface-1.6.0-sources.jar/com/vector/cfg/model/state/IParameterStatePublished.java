package com.vector.cfg.model.state;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation">
 * <h3>IParameterStatePublished</h3> The <code>IParameterStatePublished</code> specifies a type-safe published API for parameter states. It mainly covers the following state
 * information
 * <ul>
 * <li>Does this parameter have a pre-configuration value? What is this value? The same information is being provided for recommended and initial (derived) values</li>
 * <li>Is this parameter user-defined?</li>
 * <li>Is value change or deletion allowed in the current configuration phase (post-build loadable use case)?</li>
 * <li>What is the configuration class of this parameter</li>
 * </ul>
 *
 * <p>
 * The figure <!--LaTeX: \vref{fig:ParameterStateClasses} --> shows the inheritance hierarchy of the {@link IParameterStatePublished} class and its sub classes.
 * </p>
 * <img src="{@docRoot} /../_doc/UML/IParameterStatePublished/Classes.png" alt= "IParameterStatePublished class structure" id="fig:ParameterStateClasses" data-latex-style=
 * "scale=0.7"/>
 *
 * <pre>
 * <!--PlantUML: Classes
 *    {@link ICeStatePublished} <|-_ {@link IEcucStatePublished}
 *    {@link IEcucStatePublished} <|-_ {@link IParameterStatePublished}
 * -->
 * </pre>
 *
 * Parameters have different types of state information:
 * <ul>
 * <li><b>Simple state retrieval</b><br>
 * Example: The method <code>isUserDefined()</code> returns true when the parameter has a user-defined flag.</li>
 * <li><b>States and values</b> (pre-configuration, recommended configuration and inital (derived) values)<br>
 * Example: The method <code>hasPreConfigurationValue()</code> returns true when the parameter has a pre-configured value. <code>getPreConfigurationValue()</code> returns this
 * value.</li>
 * <li><b>States and reasons</b><br>
 * Example: The method <code>isDeletionAllowedAccordingToCurrentConfigurationPhase()</code> returns true if the parameter can be deleted in the current configuration phase
 * (post-build loadable projects only). <code>getNotDeletionAllowedAccordingToCurrentConfigurationPhaseReasons()</code> returns the reasons if deletion is not allowed.</li>
 * </ul>
 *
 * </div>
 *
 * Instances of related CeState implementations can be created by means of {@link CeStatePublishedFactory}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IParameterStatePublished extends IEcucStatePublished {

    /**
     * Returns the same object as {@link #getSupervisedObject()} but type-safe.
     *
     * @return Never returns <code>null</code>
     */
    @PublishedMethod
    Optional<MIParameterValue> getSupervisedParameter();

    /**
     * @return the value as string as by specified by the pre-configuration.
     */
    @PublishedMethod
    String getPreConfigParameterValue();

    /**
     * @return the value as string as specified by the initial configuration.
     */
    @PublishedMethod
    String getInitialParameterValue();

    /**
     * @return the value as string as specified by the recommended configuration.
     */
    @PublishedMethod
    String getRecommendedParameterValue();

}