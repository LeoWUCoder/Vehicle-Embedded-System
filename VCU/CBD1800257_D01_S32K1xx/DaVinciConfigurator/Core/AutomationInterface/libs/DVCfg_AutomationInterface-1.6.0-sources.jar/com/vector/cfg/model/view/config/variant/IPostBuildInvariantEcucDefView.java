package com.vector.cfg.model.view.config.variant;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;

/**
 * <div class="extdoc" id="IPostBuildInvariantEcucDefView">
 * <h4>The PostBuild Invariant EcuC definition model view</h4>
 *
 * <!--Index:Invariant EcuC definition model view--> The {@link IPostBuildInvariantEcucDefView} contains the same objects as the invariant values view but additionally excludes
 * all objects which, by (EcuC / BSWMD) definition, support variance. Using this view you can avoid dealing with objects which are accidentally equal by value (in your test
 * configurations) but potentially can be different because they support variance.
 *
 * <p>
 * More exact the {@link IPostBuildInvariantEcucDefView} will additionally exclude elements which have the following properties:
 * <ul>
 * <li>If the parent module configuration specifies VARIANT-POST-BUILD-SELECTABLE as implementation configuration variant
 * <ul>
 * <li>All objects ( {@link MIContainer}, {@link MINumericalValue}, ...) are <i>excluded</i>, which <b>support</b> variance according to their EcuC definition. (potentially
 * variant objects)</li>
 * </ul>
 * </li>
 * <li>If the parent module configuration doesn't specify VARIANT-POST-BUILD-SELECTABLE as implementation configuration variant. All contained objects <b>do not</b> support
 * variance, so the view actually shows the same objects as the {@link IPostBuildInvariantValuesView}.</li>
 * </ul>
 *
 * <p>
 * The implementation configuration variant in fact overwrites the objects definition for elements in the {@link MIModuleConfiguration ModuleConfiguration}.
 * </p>
 *
 * <h5>Reasons to Use the view</h5> The EcucDef view guarantees that you don't access potentially variant data without using variant specific model views. So it allows you to
 * improve code quality in your generator.
 * <p>
 * When your test configuration for example contains equal values for a parameter which is potentially variant you will see this parameter in the invariant values view but not
 * in the EcucDef view. Consequences if you access data in other module configurations: When the BSWMD file of this other module is being changed, e.g. a parameter now supports
 * variance, objects can become invisible due to this change. You are forced to adapt your code then.
 * </p>
 *
 * <h5>Usage</h5>
 *
 * You could retrieve an instance of {@link IPostBuildInvariantEcucDefView} by calling <code>IModelViewManager.getInvariantEcucDefView()</code>. And then use is as any other
 * {@link IModelView}.
 *
 * <pre>
 * <code class="Java" id="Retrieving an InvariantEcucDefView model view">
 * IModelViewManager viewMgr =...;
 * IInvariantEcucDefView invariantView = viewMgr.getInvariantEcucDefView();
 * // Use the invariantView like any other model view
 * </code>
 * </pre>
 *
 *
 *
 *
 *
 * <p>
 * <h5>Specification</h5> See also the
 * <a href= "https://vistrgensvn1.vi.vector.int/svn/AUTOSAR/Solution/ECU Configuration/CFG5/20_Design/Variant Handling/BaseFunctionality/PBS-ModelViews4Generators.pptx"
 * >specification</a> for details of the {@link IPostBuildInvariantEcucDefView}.
 * </p>
 *
 * </div>
 *
 * <p>
 * The EVALs EVAL00119174, EVAL00119176 describe the changes.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelViewManager
 * @see IInvariantView
 * @see IPostBuildInvariantValuesView
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
public interface IPostBuildInvariantEcucDefView extends IInvariantEcucDefView, IPostBuildInvariantView {

}
