package com.vector.cfg.core;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import javax.annotation.concurrent.GuardedBy;
import javax.annotation.concurrent.ThreadSafe;

import org.eclipse.osgi.service.resolver.VersionRange;
import org.osgi.framework.Bundle;
import org.osgi.framework.Version;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiVersionInfo;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.VersionType;
import com.vector.cfg.core.internal.Activator;

/**
 * The enum {@link ECoreFeatureVersion} describes the compatibility of the Cfg5 of external components like Generators.
 *
 * <p>
 * See EVAL00120924: Introduce Enum for the CoreFeature Version of the cfg5
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@ThreadSafe
public enum ECoreFeatureVersion {

    VERSION_1_0_0("1.0.0", "[1.0.0 , 1.1)", "Cfg5.1"),
    VERSION_2_0_0("2.0.0", "[2.0.0 , 2.1)", "Cfg5.2 - AR4-R5"),
    VERSION_2_2_0("2.2.0", "[2.0.0 , 2.3)", "Cfg5.3 - AR4-R6"),
    VERSION_3_0_0("3.0.0", "[3.0.0 , 4.0)", "Cfg5.4 - AR4-R7"),
    VERSION_4_0_0("4.0.0", "[3.0.0 , 4.1)", "Cfg5.5 - AR4-R8"),
    VERSION_4_1_0("4.1.0", "[3.0.0 , 4.2)", "Cfg5.5 SP2 - AR4-R8"),
    VERSION_4_2_0("4.2.0", "[3.0.0 , 4.3)", "Cfg5.6 - AR4-R9"),
    VERSION_4_3_0("4.3.0", "[3.0.0 , 4.4)", "Cfg5.6 SP2 - AR4-R9.1"),
    VERSION_4_4_0("4.4.0", "[3.0.0 , 4.5)", "Cfg5.7 - AR4-R10"),
    VERSION_4_4_1("4.4.1", "[3.0.0 , 4.5)", "Cfg5.8 - AR4-R11 Post-build selectable API Impl Freeze"),
    VERSION_4_6_0("4.6.0", "[3.0.0 , 4.7)", "Cfg5.8 - AR4-R11"),
    VERSION_4_6_1("4.6.1", "[3.0.0 , 4.7)", "Cfg5.8 - AR4-R11 API Impl Freeze2"),
    VERSION_4_7_0("4.7.0", "[3.0.0 , 4.8)", "Cfg5.8 SP2 - AR4-R11.1"),
    VERSION_4_8_0("4.8.0", "[3.0.0 , 4.9)", "Cfg5.8 SP3 - AR4-R11.2"),
    VERSION_4_9_0("4.9.0", "[3.0.0 , 4.10)", "Cfg5.9 - AR4-R12"),
    VERSION_4_9_1("4.9.1", "[3.0.0 , 4.10)", "Cfg5.9 - AR4-R12"),
    VERSION_4_10_0("4.10.0", "[3.0.0 , 4.11)", "Cfg5.10 - AR4-R13"),
    VERSION_4_10_1("4.10.1", "[3.0.0 , 4.11)", "Cfg5.10 - AR4-R13"),
    VERSION_5_0_0("5.0.0", "[5.0.0 , 5.1)", "Cfg5.11 - AR4-R14"),
    VERSION_5_1_0("5.1.0", "[5.0.0 , 5.2)", "Cfg5.12 - AR4-R15"),
    VERSION_5_2_0("5.2.0", "[5.0.0 , 5.3)", "Cfg5.13 - AR4-R16"),
    VERSION_5_3_0("5.3.0", "[5.0.0 , 5.4)", "Cfg5.14 - AR4-R17"),
    VERSION_5_4_0("5.4.0", "[5.0.0 , 5.5)", "Cfg5.15 - AR4-R18"),
    VERSION_5_5_0("5.5.0", "[5.0.0 , 5.6)", "Cfg5.16 S-5 - AR4-19"),
    VERSION_5_6_0("5.6.0", "[5.0.0 , 5.7)", "Cfg5.16 S-6 - AR4-R19"),
    VERSION_5_7_0("5.7.0", "[5.0.0 , 5.8)", "Cfg5.17 S-1 - AR4-R20"),
    VERSION_5_8_0("5.8.0", "[5.0.0 , 5.9)", "Cfg5.17 S-3 - AR4-R20"),
    VERSION_5_9_0("5.9.0", "[5.0.0 , 5.10)", "Cfg5.17 S-6 - AR4-R20"),
    VERSION_5_10_0("5.10.0", "[5.0.0 , 5.11)", "Cfg5.17 S-7 - AR4-R20"),
    //------------------------------------------------------------------------------
    //Now         |<VERSION>|<VERSIONRANGE MSR><VERSIONRANGE AMSR>|<DESCRIPTION>   |
    //------------------------------------------------------------------------------
    VERSION_5_11_0("5.11.0", "[5.0.0 , 5.12)", "[5.0.0 , 5.12)", "Cfg5.18 S-1 - AR4-R21"),
    VERSION_5_12_0("5.12.0", "[5.0.0 , 5.13)", "[5.0.0 , 5.13)", "Cfg5.18 S-2 - AR4-R21"),
    VERSION_5_13_0("5.13.0", "[5.0.0 , 5.14)", "[5.13.0 , 5.14)", "Cfg5.18 S-3 - AR4-R21"),
    VERSION_5_14_0("5.14.0", "[5.0.0 , 5.15)", "[5.13.0 , 5.15)", "Cfg5.18 S-4 - AR4-R21"),
    ;

    /**
     * <div class="extdoc" id="CFG_CORE_FEATURE_VERSION_RANGE_STRING">CfgCoreFeatureVersionRange specifies the compatibility of Cfg Core Versions to external components like
     * Generators.
     *
     * <p>
     * This VersionRanges is used to determine which Generators are compatible to the current Cfg5Core. The CFG_CORE_FEATURE_VERSION_STRING specifies the current version. The
     * VeersionRange should start at the last BreakingChange (e.g. MajorVersion 3.0.0) and end at the current Major.Minor Version incl. all patches<br />
     * Example: Current Version 5.14.0 => Range: [5.0.0,5.15)
     * </p>
     * </div>
     *
     * @See IGeneratorPackage for the usage of the Version and VersionRange
     */
    /* JavaListing CfgCoreFeatureVersionRange "Cfg Core Feature version range in the source code" */
    @PublishedApiVersionInfo(domainType = DomainType.GENERATORS, versionType = VersionType.VERSION_RANGE)
    public static final String CFG_CORE_FEATURE_VERSION_RANGE_STRING = "[5.0.0 , 5.15)";

    /* End JavaListing */

    /**
     * <div class="extdoc" id="CFG_CORE_FEATURE_VERSION_STRING"> CfgCoreFeatureVersion specifies the current version of Cfg Core feature (Model, Consistency, GenCore, Basic system
     * etc.).
     *
     * <p>
     * Cfg Core Version is encoded into every GeneratorPackage. The GenCore framework will check the compiled class with this version against the CfgCoreFeatureVersionRange. If the
     * Range includes the version of the generator, the generator is loaded.
     * </p>
     *
     * <p>
     * The CfgCoreFeature version shall be incremented, when any PublishedAPI classes are changed. <br/>
     * <ul>
     * <li>Additions to classes => Increment Minor version</li>
     * <li>BreakingChanges to classes => Increment Major version</li>
     * </ul>
     * </p>
     *
     *
     * <p>
     * The following version history is a mapping from Cfg-Core version to Cfg5 releases / MICROSAR releases:
     * <ul>
     * <li><b>3.0.0</b>: Cfg5.4 - AR4-R7</li>
     * <li><b>4.0.0</b>: Cfg5.5 - AR4-R8</li>
     * <li><b>4.1.0</b>: Cfg5.5 SP2 - AR4-R8</li>
     * <li><b>4.2.0</b>: Cfg5.6 - AR4-R9</li>
     * <li><b>4.3.0</b>: Cfg5.6 SP2 - AR4-R9.1</li>
     * <li><b>4.4.0</b>: Cfg5.7 - AR4-R10 API Impl Freeze</li>
     * <li><b>4.4.1</b>: Cfg5.8 - AR4-R11 Post-build selectable API Impl Freeze</li>
     * <li><b>4.6.0</b>: Cfg5.8 - AR4-R11 API Impl Freeze</li>
     * <li><b>4.6.1</b>: Cfg5.8 - AR4-R11 API Impl Freeze 2</li>
     * <li><b>4.7.0</b>: Cfg5.8 SP2 - AR4-R11.1</li>
     * <li><b>4.8.0</b>: Cfg5.8 SP3 - AR4-R11.2</li>
     * <li><b>4.9.0</b>: Cfg5.9 - AR4-R12</li>
     * <li><b>4.9.1</b>: Cfg5.9 - AR4-R12</li>
     * <li><b>4.10.0</b>: Cfg5.10 - AR4-R13</li>
     * <li><b>5.0.0</b>: Cfg5.11 - AR4-R14</li>
     * <li><b>5.1.0</b>: Cfg5.12 - AR4-R15</li>
     * <li><b>5.2.0</b>: Cfg5.13 - AR4-R16</li>
     * <li><b>5.3.0</b>: Cfg5.14 - AR4-R17</li>
     * <li><b>5.4.0</b>: Cfg5.15 - AR4-R18</li>
     * <li><b>5.5.0</b>: Cfg5.16 S-5 - AR4-19</li>
     * <li><b>5.6.0</b>: Cfg5.16 S-6 - AR4-R19</li>
     * <li><b>5.7.0</b>: Cfg5.17 - AR4-R20 S-1</li>
     * <li><b>5.8.0</b>: Cfg5.17 - AR4-R20 S-3</li>
     * <li><b>5.9.0</b>: Cfg5.17 - AR4-R20 S-6</li>
     * <li><b>5.10.0</b>: Cfg5.17 - AR4-R20 S-7</li>
     * <li><b>5.11.0</b>: Cfg5.18 - AR4-R21 S-1</li>
     * <li><b>5.12.0</b>: Cfg5.18 - AR4-R21 S-2</li>
     * <li><b>5.13.0</b>: Cfg5.18 - AR4-R21 S-3</li>
     * <li><b>5.14.0</b>: Cfg5.18 - AR4-R21 S-4</li>
     * </ul>
     * </p>
     * </div>
     *
     * @See IGeneratorPackage for the usage of the Version and VersionRange
     */
    /* JavaListing CfgCoreFeatureVersion "Cfg Core Feature version in the source code"*/
    @PublishedApiVersionInfo(domainType = DomainType.GENERATORS, versionType = VersionType.VERSION)
    public static final String CFG_CORE_FEATURE_VERSION_STRING = "5.14.0";

    /* End JavaListing */

    @GuardedBy("Class Obj")
    private static ECoreFeatureVersion currentVersion;

    /**
     * Return the current {@link ECoreFeatureVersion} of this DaVinci Configurator at runtime.
     *
     * @return the current version.
     */
    @PublishedMethod
    public static ECoreFeatureVersion getCurrentVersion() {
        return initAndGetCurrentVersion();
    }

    private static ECoreFeatureVersion initAndGetCurrentVersion() {
        synchronized (ECoreFeatureVersion.class) {
            if (currentVersion != null) {
                return currentVersion;
            }
            final Optional<ECoreFeatureVersion> versionOf = versionOf(CFG_CORE_FEATURE_VERSION_STRING);
            if (!versionOf.isPresent()) {
                throw new IncompatibleClassChangeError("The Current CoreFeatureVersion " + CFG_CORE_FEATURE_VERSION_STRING
                        + " has no corresponding ECoreFeatureVersion object. You have to create an enum literal for each version increment.");
            }

            verifyManifestMfVersion(versionOf.get().getVersion());
            currentVersion = versionOf.get();
            return currentVersion;
        }

    }

    private static void verifyManifestMfVersion(Version currentVersionOfCoreFeature) {
        final Bundle bundle = Activator.getContext().getBundle();
        final Version manifestMdfVersion = bundle.getVersion();

        if (manifestMdfVersion.getMajor() == currentVersionOfCoreFeature.getMajor()) {
            if (manifestMdfVersion.getMinor() == currentVersionOfCoreFeature.getMinor()) {
                if (manifestMdfVersion.getMicro() == currentVersionOfCoreFeature.getMicro()) {
                    // Both versions are equal => Valid
                    return;
                }
            }
        }
        throw new IncompatibleClassChangeError("The Manifest.MF Eclipse version " + manifestMdfVersion + " of " + bundle.getSymbolicName()
                + " is NOT equal to the CoreFeatureVersion " + currentVersionOfCoreFeature
                + ". Both versions must be the same in Major.Minor.Path. You have to synchronize these versions!");

    }

    /**
     * Parses the passed versionStr and returns an {@link ECoreFeatureVersion}, if exists.
     *
     * @param versionStr the version to parse.
     * @return the {@link ECoreFeatureVersion} literal of the parsed version.
     */
    @PublishedMethod
    public static Optional<ECoreFeatureVersion> versionOf(String versionStr) {
        checkNotNull(versionStr);
        final String versionStrTemp = versionStr.trim();
        for (final ECoreFeatureVersion ver : values()) {

            if (versionStrTemp.equals(ver.getVersionString())) {
                return Optional.of(ver);
            }
        }
        return Optional.absent();
    }

    /*
     * Instance fields and methods
     */

    /**
     * Specifies the compatibility of Cfg Core Versions.
     *
     * @See IGeneratorPackage for the Corresponding Version
     */
    private final VersionRange versionRangeMsr;

    private final VersionRange versionRangeAMsr;

    private final Version version;

    private final String versionString;

    private final String versionRangeMsrString;

    private final String versionRangeAMsrString;

    private final String description;

    ECoreFeatureVersion(String versionStr, String versionRangeMsrStr, String description) {
        this(versionStr, versionRangeMsrStr, versionRangeMsrStr, description);
    }

    ECoreFeatureVersion(String versionStr, String versionRangeMsrStr, String versionRangeAMsrStr, String description) {
        versionString = versionStr;
        this.versionRangeMsrString = versionRangeMsrStr;
        this.versionRangeAMsrString = versionRangeAMsrStr;
        this.description = description;

        this.versionRangeMsr = new VersionRange(versionRangeMsrStr);
        this.versionRangeAMsr = new VersionRange(versionRangeAMsrStr);
        version = org.osgi.framework.Version.parseVersion(versionStr);
        checkArgument(versionRangeMsr.includes(version));
    }

    /**
     * Returns the version as String.
     *
     * @return the version string
     */
    @PublishedMethod
    public String getVersionString() {
        return versionString;
    }

    @PublishedMethod
    public Version getVersion() {
        return version;
    }

    /**
     * Returns the versionRange as String.
     *
     * @return Returns the versionRange.
     */
    @PublishedMethod
    public String getVersionRangeString() {
        return getVersionRangeStringMsr();
    }

    /**
     * Returns the versionRange as String.
     *
     * @return Returns the versionRange.
     */
    @KeepSecretFromPublishedApi
    public String getVersionRangeStringMsr() {
        return versionRangeMsrString;
    }

    /**
     * Returns the versionRange as String.
     *
     * @return Returns the versionRange.
     */
    @KeepSecretFromPublishedApi
    public String getVersionRangeStringAMsr() {
        return versionRangeAMsrString;
    }

    /**
     * Return the compatible Core version range as {@link VersionRange} object. This returns the version range for MSR
     */
    @PublishedMethod
    public VersionRange getCompatibleCoreVersionRange() {
        return getCompatibleCoreVersionRangeMsr();
    }

    /**
     * Return the compatible Core version range as {@link VersionRange} object. This returns the version range for AMSR
     */
    @KeepSecretFromPublishedApi
    public VersionRange getCompatibleCoreVersionRangeAMsr() {
        return versionRangeAMsr;
    }

    /**
     * Return the compatible Core version range as {@link VersionRange} object. This returns the version range for MSR
     */
    @KeepSecretFromPublishedApi
    public VersionRange getCompatibleCoreVersionRangeMsr() {
        return versionRangeMsr;
    }

    /**
     * Returns the description of the Version, to display for the user.
     * <p>
     * Normally this shall contain the Cfg5 version and the MICROSAR release.
     *
     *
     * @return Returns the description.
     */
    @PublishedMethod
    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return getDescription() + " (CoreFeatureVersion: " + getVersionString() + ")";
    }

    @KeepSecretFromPublishedApi
    public String toStringWithRange() {
        return getDescription() + " (CoreFeatureVersion: " + getVersionString() + " Compatible range MSR: " + getVersionRangeStringMsr() + " Compatible range AMSR: "
                + getVersionRangeStringAMsr() + ")";
    }
}
