package com.vector.cfg.model.query.modeltraverser;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.exceptions.ModelDefinitionInvalidException;
import com.vector.cfg.model.exceptions.ModelDefinitionNotFoundException;
import com.vector.cfg.model.query.internal.modeltraverser.ModelTraverserBuilder;
import com.vector.cfg.model.query.internal.modeltraverser.ModelTraverserInitializationException;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IInvalidSubTraverserView;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IValidSubTraverserView;
import com.vector.cfg.model.query.modeltraverser.Path.EEvaluationOptions;
import com.vector.cfg.model.query.modeltraverser.variant.IVariantModelTraverser;
import com.vector.cfg.model.query.modeltraverser.variant.IVariantModelTraverserBuilder;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * ModelTraverserFactory provides methods to create new {@link IModelTraverser} instances by specifying a definition tree. See {@link Path} for more details to definition trees.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelTraverser
 * @see Path
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public final class ModelTraverserFactory {

    /**
     * Creates a new {@link IModelTraverserBuilder} which is used to create an {@link IModelTraverser}. See {@link IModelTraverserBuilder} for more details.
     *
     * @param version the Version of the ModelTraverser. Please always use the newest version!
     * @param projectContext the project context
     * @param clientSideLogger The optional logger is then used to log all activities of the created {@link IVariantModelTraverser}
     * @param path the model traverser path.
     * @return The new {@link IVariantModelTraverserBuilder}, or throws an exception
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the version is null</li>
     * <li>if the projectContext is null</li>
     * <li>if the path is null</li>
     * </ul>
     */
    @PublishedMethod
    public static IModelTraverserBuilder newBuilder(@Nonnull ETraverserVersion version, @Nonnull IProjectContext projectContext, @Nullable ILogger clientSideLogger,
            @Nonnull IModelTraverserPath path) {
        return new ModelTraverserBuilder(version, projectContext, clientSideLogger, path);
    }

    /**
     * Creates a new {@link IModelTraverser} by the specified path.
     *
     * @param version the Version of the ModelTraverser. Please always use the newest version!
     * @param projectContext the project context
     * @param clientSideLogger The logger is then used to log all activities of the created {@link IModelTraverser}
     * @param path the path
     * @return The create {@link IModelTraverser}, or throws an exception
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the version is null</li>
     * <li>if the projectContext is null</li>
     * <li>if the path is null</li>
     * </ul>
     * @exception ModelTraverserInitializationException
     * <ul>
     * <li>if the passed path is not traversable by the loaded definition</li>
     * </ul>
     * @exception ModelDefinitionInvalidException
     * <ul>
     * <li>if the DefRef verification has failed, and reported an invalid definition</li>
     * </ul>
     * @exception ModelDefinitionNotFoundException
     * <ul>
     * <li>if the DefRef verification has failed, and reported an not existing definition</li>
     * </ul>
     */
    @PublishedMethod
    public static IModelTraverser create(ETraverserVersion version, IProjectContext projectContext, ILogger clientSideLogger, IModelTraverserPath path) {
        final IModelTraverserBuilder builder = newBuilder(version, projectContext, clientSideLogger, path);
        return builder.build();
    }

    /**
     * Creates a new {@link IModelTraverser} by the specified path.
     *
     * @param version the Version of the ModelTraverser. Please always use the newest version!
     * @param projectContext the project context
     * @param path the path
     * @return The create {@link IModelTraverser}, or throws an exception
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the version is null</li>
     * <li>if the projectContext is null</li>
     * <li>if the path is null</li>
     * </ul>
     * @exception ModelTraverserInitializationException
     * <ul>
     * <li>if the passed path is not traversable by the loaded definition</li>
     * </ul>
     * @exception ModelDefinitionInvalidException
     * <ul>
     * <li>if the DefRef verification has failed, and reported an invalid definition</li>
     * </ul>
     * @exception ModelDefinitionNotFoundException
     * <ul>
     * <li>if the DefRef verification has failed, and reported an not existing definition</li>
     * </ul>
     *
     */
    @PublishedMethod
    public static IModelTraverser create(ETraverserVersion version, IProjectContext projectContext, IModelTraverserPath path) {
        final IModelTraverserBuilder builder = newBuilder(version, projectContext, null, path);
        return builder.build();
    }

    /**
     * Creates a new {@link IModelTraverser} by the specified path.
     *
     * @param projectContext the project context
     * @param path the path
     * @return The create {@link IModelTraverser}, or throws an exception
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the projectContext is null</li>
     * <li>if the path is null</li>
     * </ul>
     * @exception ModelTraverserInitializationException
     * <ul>
     * <li>if the passed path is not traversable by the loaded definition</li>
     * </ul>
     * @exception ModelDefinitionInvalidException
     * <ul>
     * <li>if the DefRef verification has failed, and reported an invalid definition</li>
     * </ul>
     * @exception ModelDefinitionNotFoundException
     * <ul>
     * <li>if the DefRef verification has failed, and reported an not existing definition</li>
     * </ul>
     *
     * @deprecated Please use {@link #create(ETraverserVersion, IProjectContext, ILogger, IModelTraverserPath)} instead!
     */
    @PublishedMethod
    @Deprecated
    public static IModelTraverser create(IProjectContext projectContext, IModelTraverserPath path) {
        return create(ETraverserVersion.VERSION_1, projectContext, path);
    }

    /**
     * Creates a new {@link IModelTraverser} by the specified path.
     *
     * @param projectContext the project context
     * @param clientSideLogger The logger is then used to log all activities of the created {@link IModelTraverser}
     * @param path the path
     * @return The create {@link IModelTraverser}, or throws an exception
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the projectContext is null</li>
     * <li>if the path is null</li>
     * </ul>
     * @exception ModelTraverserInitializationException
     * <ul>
     * <li>if the passed path is not traversable by the loaded definition</li>
     * </ul>
     * @exception ModelDefinitionInvalidException
     * <ul>
     * <li>if the DefRef verification has failed, and reported an invalid definition</li>
     * </ul>
     * @exception ModelDefinitionNotFoundException
     * <ul>
     * <li>if the DefRef verification has failed, and reported an not existing definition</li>
     * </ul>
     *
     * @deprecated Please use {@link #create(ETraverserVersion, IProjectContext, ILogger, IModelTraverserPath)} instead!
     */
    @Deprecated
    @PublishedMethod
    public static IModelTraverser create(IProjectContext projectContext, ILogger clientSideLogger, IModelTraverserPath path) {
        return create(ETraverserVersion.VERSION_1, projectContext, clientSideLogger, path);
    }

    /**
     * The ETraverserVersion. defines the version of the {@link IModelTraverser}.
     *
     *
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="TraverserVersionHistory">
     * <p>
     * The ModelTraverser has its own version schema. So we could introduce new features or semantic changes in new versions, and also be compatible with old versions of the
     * {@link IModelTraverser}.
     * </p>
     *
     * <p>
     * The version is passed to the create method in the {@link ModelTraverserFactory} class.
     * </p>
     *
     * <p>
     * <b>Please always try to use the newest available version!</b> But when you switch to a new version you have to verify, that your code still work properly. The sections below
     * document the changes in the different versions.
     * </p>
     *
     * <h3>Version 1</h3> {@link ETraverserVersion#VERSION_1}: The original version of the first ModelTraverser API.
     *
     * <h3>Version 2</h3> {@link ETraverserVersion#VERSION_2}:
     * <ul>
     * <li>New Min/Max value check introduced for Integer and Float parameter. See {@link EEvaluationOptions} <!--LaTeX:\vref{sec:ModelTraverserMinMaxCheck}--> for more
     * details.</li>
     * <li>{@link IValidSubTraverserView} and {@link IInvalidSubTraverserView} introduced. See {@link IValidSubTraverserView} <!--LaTeX:\vref{sec:ModelTraverserSubViews}--> for
     * more details. Now some <code>selectxxx()</code> statements throw an {@link IllegalArgumentException}, to notify that these selects must be replaced by the new
     * <code>selectxxxAsSubview()</code> API.</li>
     * </ul>
     * </div>
     *
     *
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public enum ETraverserVersion {
        /**
         * @deprecated Please use the newest version!
         */
        @Deprecated
        VERSION_1,

        /**
         * Current newest version.
         */
        VERSION_2,

        ;

        @KeepSecretFromPublishedApi
        public static ETraverserVersion getNewest() {
            return VERSION_2;
        }

    }

    private ModelTraverserFactory() {

    }
}
