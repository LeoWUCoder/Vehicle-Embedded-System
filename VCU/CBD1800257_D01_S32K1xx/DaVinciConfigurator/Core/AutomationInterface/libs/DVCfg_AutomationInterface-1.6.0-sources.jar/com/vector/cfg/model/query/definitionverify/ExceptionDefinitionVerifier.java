package com.vector.cfg.model.query.definitionverify;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.exceptions.ModelDefinitionInvalidException;
import com.vector.cfg.model.exceptions.ModelDefinitionNotFoundException;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Verifies DefRef Objects and reports error as {@link ModelDefinitionInvalidException}s or {@link ModelDefinitionNotFoundException}s.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class ExceptionDefinitionVerifier extends AbstractDefinitionVerifier {

    /** The Constant logger. */
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(ExceptionDefinitionVerifier.class);

    /**
     * Constructor for DefinitionVerifier.
     *
     * @param context the context
     */
    @PublishedMethod
    protected ExceptionDefinitionVerifier(IProjectContext context) {
        super(context);
    }

    /**
     * Create an new ExceptionDefinitionVerifier.
     *
     * @param context the context
     * @return the exception definition verifier
     */
    @PublishedMethod
    public static ExceptionDefinitionVerifier create(IProjectContext context) {
        return new ExceptionDefinitionVerifier(context);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void reportMissingDefinitionDependency(DefRef defRef) {
        throw new ModelDefinitionNotFoundException("Missing required Definition: " + defRef, defRef);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void reportInvalidDefinitionDependency(TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?> typedDefRef, MIParamConfMultiplicity defObj, String errorMsg) {
        throw new ModelDefinitionInvalidException("Invalid Definition found, which was marked as required/optional with a certain type. "
                + (errorMsg != null && !errorMsg.isEmpty() ? errorMsg + " " : "") + "Requested type: " + typedDefRef.toDebugString() + " ActualType: "
                + ModelAccessUtil.toDebugStringMDFObject(defObj), typedDefRef);
    }
}
