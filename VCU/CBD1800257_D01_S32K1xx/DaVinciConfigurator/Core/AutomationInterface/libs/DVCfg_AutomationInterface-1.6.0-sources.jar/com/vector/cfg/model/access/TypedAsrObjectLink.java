package com.vector.cfg.model.access;

import static com.vector.davinci.util.base.VUtil.uncheckedCast;

import javax.annotation.concurrent.Immutable;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.internal.access.ObjectLinkFeatureData;
import com.vector.cfg.model.internal.access.ObjectLinkParameterData;
import com.vector.cfg.model.internal.access.ObjectLinkVarianceData;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.IProjectContext;

/**
 * This class implements an immutable identifier for AUTOSAR objects with type information.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@Immutable
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class TypedAsrObjectLink<METACLASS_TYPE extends MIObject> extends AsrObjectLink implements IDebugable {

    private final Class<METACLASS_TYPE> metaModelClass;

    TypedAsrObjectLink(String bestEffortPath, boolean isParameterValueLink, boolean isReferrableLink, final Class<METACLASS_TYPE> metaModelClass) {
        super(bestEffortPath, isParameterValueLink, isReferrableLink);
        checkMetaClassNonNull(metaModelClass);
        this.metaModelClass = metaModelClass;
    }

    TypedAsrObjectLink(String bestEffortPath, ObjectLinkVarianceData variantData, final Class<METACLASS_TYPE> metaModelClass) {
        super(bestEffortPath, variantData);
        checkMetaClassNonNull(metaModelClass);
        this.metaModelClass = metaModelClass;
    }

    TypedAsrObjectLink(String bestEffortPath, ObjectLinkParameterData parameterData, ObjectLinkVarianceData variantData, final Class<METACLASS_TYPE> metaModelClass) {
        super(bestEffortPath, parameterData, variantData);
        checkMetaClassNonNull(metaModelClass);
        this.metaModelClass = metaModelClass;
    }

    TypedAsrObjectLink(ObjectLinkFeatureData featureData, final Class<METACLASS_TYPE> metaModelClass) {
        super(featureData);
        checkMetaClassNonNull(metaModelClass);
        this.metaModelClass = metaModelClass;
    }

    private void checkMetaClassNonNull(final Class<METACLASS_TYPE> metaModelClassLoc) {
        if (metaModelClassLoc == null) {
            throw new IllegalArgumentException("metaModelClass is null.");
        }
    }

    /**
     * Returns the MetaModelClass object of the AUTOSAR element.
     *
     * @return the MetaModel class object.
     */
    @PublishedMethod
    public Class<METACLASS_TYPE> getMetaModelClass() {
        return metaModelClass;
    }

    /**
     * Returns an AUTOSAR object which matches this link. See {@link AsrObjectLink} for details about restrictions of retrieving objects by link.
     * <p>
     * <b>Remark:</b> This method will probably return an invisible MDF object!
     * </p>
     *
     * @param projectContext
     * @return
     */
    @PublishedMethod
    public Optional<METACLASS_TYPE> getTypedAutosarObject(final IProjectContext projectContext) {
        final Optional<MIObject> optObj = getAutosarObject(projectContext);
        if (optObj.isPresent()) {
            final Optional<METACLASS_TYPE> optTypedObj = uncheckedCast(Optional.of(optObj.get()));
            return optTypedObj;
        }
        return Optional.absent();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toDebugString() {
        return TypedAsrObjectLink.class.getSimpleName() + ": " + getObjectLinkString() + "<" + metaModelClass.getSimpleName() + ">";
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return getObjectLinkString() + "<" + metaModelClass.getSimpleName() + ">";
    }

}
