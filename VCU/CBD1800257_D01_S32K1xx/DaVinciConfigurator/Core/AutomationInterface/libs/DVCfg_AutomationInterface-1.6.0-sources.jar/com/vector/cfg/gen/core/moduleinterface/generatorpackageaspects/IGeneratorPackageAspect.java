package com.vector.cfg.gen.core.moduleinterface.generatorpackageaspects;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;

/**
 *
 * <div class="extdoc" id="Common"> GeneratorPackageAspects are a generic concept to add a special behavior to an {@link IGeneratorPackage}. Every <code>GeneratorPackage</code>
 * could have many different aspects to configure certain behavior for each different aspect. Aspects are for example a SipLicense check.
 *
 * To register an {@link IGeneratorPackageAspect} you could override the <code>registerGeneratorPackageAspects()</code> method in your <code>GeneratorPackage</code>.
 *
 * <pre>
 * <code class="Java" id="GeneratorPackageAspect registration">
 *  //Insert this code in your GeneratorPackage
 *
 * protected void registerGeneratorPackageAspects() {
 *    addPackageAspect(&lt;AspectClass&gt;,&lt;AspectImpl&gt;);
 * }
 * </code>
 * </pre>
 *
 * </div>
 *
 * The {@link IGeneratorPackageAspect} marks all interfaces which could be contributed to a {@link IGeneratorPackage} as an aspect.
 *
 * See {@link IGeneratorPackage#getPackageAspect(Class)} for more details. The abstract implementation of {@link IGeneratorPackage} provides methods to register aspects.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IGeneratorPackageAspect {

}
