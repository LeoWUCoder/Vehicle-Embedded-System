package com.vector.cfg.gen.core.moduleinterface.fileoutput;

import static com.google.common.base.Preconditions.checkNotNull;

import java.io.File;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGenFolders;
import com.vector.cfg.gen.core.moduleinterface.IGenerationProcessor;

/**
 * {@link FileTypeSpecification} indicates which file type a {@link IOutputFile} has.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IGenerationProcessor
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class FileTypeSpecification {

    private final IOutputFile file;

    /**
     * Instantiates a new file type specification.
     *
     * @param file the {@link IOutputFile}
     */
    @PublishedMethod
    public FileTypeSpecification(IOutputFile file) {
        this.file = checkNotNull(file);
    }

    /**
     * Return a String that will mark the File between Header and FileContent as illegal file.
     *
     * This method is used, when the user want to generate an erroneous configuration.
     *
     * @return
     */
    @PublishedMethod
    public abstract String getIllegalFilePatternToMarkFileAsErronous();

    /**
     * Format string to comment. E.g. surrounds the string with /* <Content> *&nbsp;/
     *
     * @param content the content
     * @return the string
     */
    @PublishedMethod
    public abstract String formatStringToComment(String content);

    /**
     * Gets the corresponding output file.
     *
     * @return the output file
     */
    @PublishedMethod
    public final IOutputFile getOutputFile() {
        return file;
    }

    /**
     * Returns true, if this file type supports the conditional file writing of the GenerationOutputWriter.
     *
     * @return
     */
    @PublishedMethod
    public abstract boolean supportsConditionalFileWriting();

    /**
     * Shall return the striped content for the conditional output file writing. E.g. Strip the generated date from the content.
     *
     * <p>
     * This method shall throw an exception, if the {@link #supportsConditionalFileWriting()} is false!
     * </p>
     *
     * @param currentFileContent
     * @return
     */
    @PublishedMethod
    public abstract String stripContentForConditionalFileWriting(String currentFileContent);

    /**
     * This method shall return the correct outputFolde of this file type. The folders could be retrieved from the {@link IGenFolders} object.
     *
     * @param genFolders the {@link IGenFolders} instance of the {@link IGenerationProcessor}.
     * @return the output folder of the {@link IOutputFile}.
     */
    @PublishedMethod
    public abstract File getOutputFolder(IGenFolders genFolders);

}
