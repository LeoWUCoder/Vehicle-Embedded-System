package com.vector.cfg.model.query.modeltraverser;

import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import javax.annotation.concurrent.Immutable;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.query.modeltraverser.Path.EEvaluationOptions;
import com.vector.cfg.model.query.modeltraverser.Path.EPathMultiplicityType;
import com.vector.cfg.model.query.modeltraverser.Path.EPathTraversalOptions;
import com.vector.cfg.model.query.modeltraverser.strategies.ITraverseStrategy;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * {@link IModelTraverserPath} one path element for the definition tree of an {@link IModelTraverser}.
 * <p>
 * Every definition tree must start with an {@link IModelTraverserPathRoot} element.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 * @see Path
 * @see IModelTraverser
 * @see IModelTraverserPathRoot
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@NotThreadSafe
@PublishedFilter(MsrPlatform.class)
public interface IModelTraverserPath extends Cloneable {

    /**
     * Gets the root of the {@link IModelTraverserPath}.
     *
     * @return the root
     */
    @PublishedMethod
    IModelTraverserPathRoot getRoot();

    /**
     * Returns the Childs for this {@link IModelTraverserPath}.
     *
     * <p>
     * Note: The returned {@link Set} must have a defined order, e.g. a <code>LinkedHashSet</code>.
     * </p>
     *
     * @param <T> the generic type
     * @return the childs
     */
    @PublishedMethod
    <T extends IModelTraverserPath> Set<T> getChilds();

    /**
     * Gets the {@link DefRef} of the path elements.
     *
     * @return the {@link DefRef}
     */
    @PublishedMethod
    TypedDefRef<?, ?, ?> getDefRef();

    /**
     * Gets the associated multiplicity for this path element. This could be the {@link DefRef} multiplicity or an overridden multiplicity specified by the client.
     *
     * @return the multiplicity type
     */
    @PublishedMethod
    EPathMultiplicityType getMultiplicityType();

    /**
     * Gets a {@link EnumSet} of additional {@link IModelTraverserPathOption}.
     * <p>
     * The standard options are contained in the classes:
     * <ul>
     * <li>{@link EEvaluationOptions}</li>
     * <li>{@link EPathTraversalOptions}</li>
     * </ul>
     * </p>
     *
     * @return the evaluation options
     */
    @PublishedMethod
    Set<IModelTraverserPathOption> getModelTraverserPathOptions();

    @KeepSecretFromPublishedApi
    void addModelTraverserPathOption(IModelTraverserPathOption option);

    /**
     * Returns the assigned {@link ITraverseStrategy} to this {@link IModelTraverserPath}.
     *
     * @return the traverser strategies
     */
    @PublishedMethod
    List<ITraverseStrategy> getTraverserStrategies();

    /**
     * Creates and returns a copy of this object and recursively copies the whole {@link IModelTraverserPath}.
     *
     *
     * @return the cloned {@link IModelTraverserPath} and all cloned childs.
     */
    @PublishedMethod
    IModelTraverserPath clone();

    /**
     * {@link IModelTraverserPathRoot} describes the root (MainElement/Context object) of a definition tree of the {@link IModelTraverser}.
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     * @since 1.0
     * @noimplement This interface is not intended to be implemented by clients.
     * @see IModelTraverserPath
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public interface IModelTraverserPathRoot extends IModelTraverserPath {

        /**
         * Gets a {@link Set} of all {@link DefRef}s of all child below this root object.
         *
         * @return the all child {@link DefRef}s
         */
        @PublishedMethod
        Set<DefRef> getAllChildDefRefs();
    }

    /**
     * All subclasses of the interface {@link IModelTraverserPathOption} could be passed the {@link Path#} element create methods. There are multiple option classes like:
     * <ul>
     * <li>{@link EEvaluationOptions}</li>
     * <li>{@link EPathTraversalOptions}</li>
     * </ul>
     *
     * Go to these classes for details and usage samples.
     *
     *
     * @noimplement This interface is not intended to be implemented by clients.
     * @see IModelTraverserPath
     * @see EEvaluationOptions
     * @see EPathTraversalOptions
     */
    @Immutable
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public interface IModelTraverserPathOption {

    }

}
