package com.vector.cfg.util.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="DeferredExecution"> Indicates that the annotated lambda or closure is deferred executed. </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.CLASS)
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@Documented
public @interface DeferredExecution {

    /**
     * The description.
     *
     * @return the description for the deferred execution
     */
    @PublishedMethod
    String description() default "";

}
