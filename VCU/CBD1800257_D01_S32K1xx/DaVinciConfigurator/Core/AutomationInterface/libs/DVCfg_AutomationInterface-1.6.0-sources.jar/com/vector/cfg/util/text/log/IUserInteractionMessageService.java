package com.vector.cfg.util.text.log;

import java.lang.reflect.Array;
import java.util.Iterator;

import javax.annotation.concurrent.ThreadSafe;

import org.eclipse.core.runtime.IStatus;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ELogLevel;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.format.IFormattable;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * The {@link IUserInteractionMessageService} provides an API to communicate directly with the user in multiple application scenarios like UI, Cmd, AI.
 *
 * <p>
 * The {@link IUserInteractionMessageService} shall only be used to directly inform the user about something, like a MessageBox which need immediate attention. If the tool could
 * continue, or recover itself from the message YOu shall use EndUserLoggers instead. See {@link Logger#createEndUserLogger(Class)} for details.
 * </p>
 *
 * <p>
 * All methods could consume {@link Object}s as message, which are evaluated in the following order:
 *
 * The passed message understands following types with special cases, in the following order:
 * <ul>
 * <li>{@link IDetailedUserMessage}</li>
 * <li>{@link IUserMessage}</li>
 * <li>{@link IMixedText}</li>
 * <li>{@link Throwable}</li>
 * <li>{@link IStatus}</li>
 * <li>{@link IFormattable}</li>
 * <li>{@link Iterable}</li>
 * <li>{@link Iterator}</li>
 * <li>{@link Array}</li>
 * <li>Ask the FormattingService, if there is a custom formatter for the type.</li>
 * <li>{@link String}</li>
 * <li>{@link Object}</li>
 * </ul>
 * </p>
 *
 * <p>
 * This is an ApplicationService.
 * </p>
 *
 * <p>
 * This ApplicationService is threadsafe.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IUserInteractionMessageService {

    /**
     * Reports an error to the user.
     *
     * @param exception the exception
     */
    @PublishedMethod
    void errorToUser(Throwable exception);

    /**
     * Reports an error to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message the message
     */
    @PublishedMethod
    void errorToUser(Object message);

    /**
     * Reports an error to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message the message
     * @param exception the exception
     */
    @PublishedMethod
    void errorToUser(Object message, Throwable exception);

    /**
     * Reports an error to the user.
     *
     * <p>
     * The passed message is evaluated a described in {@link MixedText}.
     * </p>
     *
     * @param message the message
     * @param arguments the arguments in the message.
     */
    @PublishedMethod
    void errorToUser(String message, Object... arguments);

    /**
     * Reports a warning to the user.
     *
     * @param exception the exception
     */
    @PublishedMethod
    void warnToUser(Throwable exception);

    /**
     * Reports a warning to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message the message
     */
    @PublishedMethod
    void warnToUser(Object message);

    /**
     * Reports a warning to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message the message
     * @param exception the exception
     */
    @PublishedMethod
    void warnToUser(Object message, Throwable exception);

    /**
     * Reports a warning to the user.
     *
     * <p>
     * The passed message is evaluated a described in {@link MixedText}.
     * </p>
     *
     * @param message the message
     * @param arguments the arguments in the message.
     */
    @PublishedMethod
    void warnToUser(String message, Object... arguments);

    /**
     * Reports an info message to the user.
     *
     * @param exception the exception
     */
    @PublishedMethod
    void infoToUser(Throwable exception);

    /**
     * Reports an info message to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message the message
     */
    @PublishedMethod
    void infoToUser(Object message);

    /**
     * Reports an info message to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param message the message
     * @param exception the exception
     */
    @PublishedMethod
    void infoToUser(Object message, Throwable exception);

    /**
     * Reports an info message to the user.
     *
     * <p>
     * The passed message is evaluated a described in {@link MixedText}.
     * </p>
     *
     * @param message the message
     * @param arguments the arguments in the message.
     */
    @PublishedMethod
    void infoToUser(String message, Object... arguments);

    /**
     * Reports a message with {@link ELogLevel} to the user.
     *
     * @param level the {@link ELogLevel} of the message.
     * @param exception the exception
     */
    @PublishedMethod
    void messageToUser(ELogLevel level, Throwable exception);

    /**
     * Reports a message with {@link ELogLevel} to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param level the {@link ELogLevel} of the message.
     * @param message the message
     */
    @PublishedMethod
    void messageToUser(ELogLevel level, Object message);

    /**
     * Reports a message with {@link ELogLevel} to the user.
     *
     * <p>
     * The passed message is evaluated as described in the {@link IUserInteractionMessageService} class.
     * </p>
     *
     * @param level the {@link ELogLevel} of the message.
     * @param message the message
     * @param exception the exception
     */
    @PublishedMethod
    void messageToUser(ELogLevel level, Object message, Throwable exception);

    /**
     * Reports a message with {@link ELogLevel} to the user.
     *
     * <p>
     * The passed message is evaluated a described in {@link MixedText}.
     * </p>
     *
     * @param level the {@link ELogLevel} of the message.
     * @param message the message
     * @param arguments the arguments in the message.
     */
    @PublishedMethod
    void messageToUser(ELogLevel level, String message, Object... arguments);

}
