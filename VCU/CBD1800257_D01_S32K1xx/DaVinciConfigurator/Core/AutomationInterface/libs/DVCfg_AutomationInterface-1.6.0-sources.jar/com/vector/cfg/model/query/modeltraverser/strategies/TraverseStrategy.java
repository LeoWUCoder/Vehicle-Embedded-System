package com.vector.cfg.model.query.modeltraverser.strategies;

import static com.google.common.base.Preconditions.checkNotNull;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
//CHECKSTYLE:OFF
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.query.modeltraverser.Path;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

//CHECKSTYLE:ON
/**
 * The {@link TraverseStrategy} provides a base implementation for the {@link ITraverseStrategy} interface. See {@link ITraverseStrategy} for code samples and usage.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see ITraverseStrategy
 * @see Path
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public abstract class TraverseStrategy implements ITraverseStrategy {

    private final TypedDefRef<?, ?, ?> parentDefRef;

    private final TypedDefRef<?, ?, ?> elementDefRef;

    @PublishedField
    protected final IProjectContext projectContext;

    /**
     * Instantiates a new traverser strategy.
     *
     * @param projectContext the project context
     * @param parentDefRef the parent {@link DefRef}, could be <code>null</code>, if the {@link ITraverseStrategy} is for the MainElement.
     * @param elementDefRef the element {@link DefRef} which shall be processed.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the projectContext parameter is null</li>
     * <li>if the elementDefRef parameter is null</li>
     * </ul>
     *
     */
    @PublishedMethod
    protected TraverseStrategy(@Nonnull IProjectContext projectContext, @Nullable TypedDefRef<?, ?, ?> parentDefRef, @Nonnull TypedDefRef<?, ?, ?> elementDefRef) {
        checkNotNull(projectContext);
        checkNotNull(elementDefRef);

        this.projectContext = projectContext;
        this.parentDefRef = parentDefRef;
        this.elementDefRef = elementDefRef;

    }

    /*
     * Interface impl
     */

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @Nullable
    public TypedDefRef<?, ?, ?> getParentDefRef() {
        return parentDefRef;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public TypedDefRef<?, ?, ?> getDefRef() {
        return elementDefRef;
    }

}
