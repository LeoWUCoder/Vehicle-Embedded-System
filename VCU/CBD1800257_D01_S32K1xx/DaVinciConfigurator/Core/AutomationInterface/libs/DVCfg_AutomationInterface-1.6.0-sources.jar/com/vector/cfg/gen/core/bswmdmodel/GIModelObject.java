package com.vector.cfg.gen.core.bswmdmodel;

import java.util.function.Supplier;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucDefinition;
import com.vector.cfg.model.access.ecuconfiguration.IEcuConfigurationAccess;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucHasDefinition;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.state.CeStatePublishedFactory;
import com.vector.cfg.model.state.ICeStatePublished;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.IViewedModelObject;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Base interface of all bswmd model objects.
 *
 * <div class="extdoc" id="BswmdModelTypes">
 *
 * <h4>DefinitionModel</h4> The DefinitionModel is the base implementation of every BswmdModel. Every BswmdModel class is a subclass of the DefinitionModel where the classes
 * begin with <code>GI</code>, like {@link GIContainer}.
 *
 * <h3>Types of DefinitionModels</h3> There are two types of DefinitionModels:
 * <ol>
 * <li><b>BswmdModel</b> (formally known as DefinitionTyped BswmdModel)</li>
 * <li><b>DefRef API</b> (formally known as Untyped BswmdModel)</li>
 * </ol>
 *
 * <p>
 * The <b>BswmdModel</b> consists of generated classes for the module definition elements like <code>ModuleDefinitions, Containers, Parameters</code> in bswmd files. The
 * generated class contains getter methods for each child element. So you can access every child by the corresponding getter method with compile time safety of the sub type.
 * </p>
 * <p>
 * The <b>BswmdModel</b> derives from the <b>DefinitionModel DefRef API</b>, so the <b>BswmdModel</b> contains all functionalities of the <b>DefRef API</b>.
 * </p>
 * <p>
 * The <b>DefRef API</b> of the DefinitionModel provides an generic access to the Ecu configuration structure via {@link DefRef DefRefs}. There are <b>NO</b> generated classes
 * for the Definition structure. The <b>DefRef API</b> uses the base classes of the DefinitionModel to provide this {@link DefRef} based access. Every interface in the
 * DefinitionModel starts with an <code>GI</code>. The Ecu Configuration elements have corresponding base interfaces for each element:
 *
 * <ul>
 * <li>ModuleConfiguration - {@link GIModuleConfiguration}</li>
 * <li>Container - {@link GIContainer}</li>
 * <li>ChoiceContainer - {@link GIChoiceContainer}</li>
 * <li>Parameter - {@link GIParameter}&lt;?&gt;</li>
 * <ul>
 * <li>Integer Parameter - {@link GIParameter}&lt;BigInteger&gt;</li>
 * <li>Boolean Parameter - {@link GIParameter}&lt;Boolean&gt;</li>
 * <li>Float Parameter - {@link GIParameter}&lt;BigDecimal&gt;</li>
 * <li>String Parameter - {@link GIParameter}&lt;String&gt;</li>
 * </ul>
 * <li>Reference - {@link GIReference}&lt;?&gt;</li>
 * <ul>
 * <li>Container Reference - {@link GIReferenceToContainer}</li>
 * <li>Foreign Reference- {@link GIReference}&lt;Class&gt;</li>
 * </ul>
 * </ul>
 *
 * </p>
 * </div>
 *
 * <div class="extdoc" id="DefRefGetterMethods"> The DefRef API classes have no getter methods for the specific child types, but the children could be retrieve via the generic
 * getter methods like:
 * <ul>
 * <li>{@link GIContainer#getSubContainers()}</li>
 * <li>{@link GIContainer#getParameters()}</li>
 * <li>{@link GIContainer#getParameters(TypedDefRef)}</li>
 * <li>{@link GIContainer#getParameter(TypedDefRef)}</li>
 * <li>{@link GIContainer#getReferencesToContainer(TypedDefRef)}</li>
 * <li>{@link GIModuleConfiguration#getSubContainer(TypedDefRef)}</li>
 * <li>{@link GIParameter#getValueMdf()}</li>
 * </ul>
 *
 * Additionally there are methods to retrieve other referenced elements, like parent of reference reverse lookup:
 * <ul>
 * <li>{@link GIContainer#getParent()}</li>
 * <li>{@link GIContainer#getParent(DefRef)}</li>
 * <li>{@link GIContainer#getReferencesPointingToMe()}</li>
 * <li>{@link GIContainer#getReferencesPointingToMe(DefRef)}</li>
 * </ul>
 *
 *
 * </div>
 *
 *
 * <div class="extdoc" id="PBSelectable">
 *
 * The BswmdModel supports the Post-build selectable use case, in respect that you do not have to switch nor cache the corresponding {@link IModelView}. The BswmdModel objects
 * cache the so called Creation ModelView and switch transparently to that view when accessing the Model. So you don't have to switch to the correct view on access. See figure
 * <!--LaTeX:\vref{fig:BswmdModelCreatePBSelectable}-->. You only have to ensure, that the requested {@link IModelView} is active or passed as parameter, when you create an
 * instance at the {@link GIModelFactory}. Note: A lazy created object will inherit the view of the existing element.
 *
 * <img src="{@docRoot} /../_doc/BswmdModel_Create_PBSelectable.png" alt="Creating a BswmdModel in the Post-build selectable use case" id="fig:BswmdModelCreatePBSelectable "
 * data-latex-style="scale=1.0" />
 *
 * </div>
 *
 * <div class="extdoc" id="CreationModelView">
 *
 * Every {@link GIModelObject} (BswmdModel object) has a creation {@link IModelView}. This is the {@link IModelView}, which was active or passed during creation of the
 * BswmdModel. At every method call to the BswmdModel, the model will switch to this view.
 *
 * </div>
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 * @see TypedDefRef
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
// CHECKSTYLE:OFF Class Naming problem
public interface GIModelObject extends IViewedModelObject {
    // CHECKSTYLE:ON

    /**
     * Returns the generator model access service of this object.
     *
     * @return
     */
    @PublishedMethod
    GIModelAccess getGeneratorModelAccess();

    /**
     * Returns the EcucDefinition of this object.
     *
     * @return the ecuc definition
     */
    @PublishedMethod
    IEcucDefinition getEcucDefinition();

    /**
     * Returns the EcucConfiguration object of this object as provided by {@link IEcuConfigurationAccess}. The returned object provides convenient access to the related MDF model
     * object.
     *
     * @return the ecuc configuration
     */
    @PublishedMethod
    IEcucHasDefinition getEcuConfiguration();

    /**
     * Returns the related configuration object in the MDF model.
     *
     * <p>
     * Attention: The returned {@link MIObject} could be invisible in the current active {@link IModelView}! You have to check the visibility in the client side code!
     * </p>
     *
     * @return the underlying MDF model object.
     */
    @Override
    @PublishedMethod
    MIHasDefinition getMdfObject();

    /**
     * Returns the root object (ModuleConfiguration) of this model object. If it is the moduleConfig it will return itself.
     *
     * @return
     */
    @PublishedMethod
    GIModuleConfiguration getModuleConfiguration();

    /**
     * Returns the related definition object in the MDF model.
     *
     * @return The MDF definition object of the {@link GIModelObject}.
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the element does not exist in the MDF model</li>
     * </ul>
     *
     */
    @PublishedMethod
    MIParamConfMultiplicity getDefinition();

    /**
     * Returns the object link as provided by the MDF model (see {@link IModelAccess#getObjectLink(MIHasDefinition)}).
     *
     * @return
     */
    @PublishedMethod
    String getObjectLink();

    /**
     * Returns the immediate parent of this model object or <code>null</code> if this object has no parent (module configurations).
     *
     * @return
     */
    @PublishedMethod
    GIHasContainer getParent();

    /**
     * Returns the parent of this model object or throws an {@link IllegalArgumentException}, if the passed {@link DefRef} could not be the parent of the element.
     *
     * <p>
     * Note: this method search the parent recursively for the requested parent.
     * </p>
     *
     * @return The parent with the passed DefRef.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the passed DefRef could never be the parent of this element</li>
     * </ul>
     */
    @PublishedMethod
    GIHasContainer getParent(DefRef parentDefRef);

    /**
     * Returns the parent of this model object or throws an {@link IllegalArgumentException}, if the passed {@link DefRef} could not be the parent of the element.
     *
     * <p>
     * Note: this method search the parent recursively for the requested parent.
     * </p>
     *
     * @return The parent with the passed DefRef.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the passed DefRef could never be the parent of this element</li>
     * </ul>
     */
    @PublishedMethod
    <DEF extends MIParamConfMultiplicity, CFG extends MIHasDefinition, VAL, WRAPPER extends GIHasContainer> WRAPPER getParent(
            WrappedTypedDefRef<DEF, CFG, VAL, WRAPPER> parentDefRef);

    /**
     * Returns the DefRef Object of the configuration element.
     *
     * @return The {@link DefRef}
     */
    @PublishedMethod
    DefRef getDefRef();

    /**
     * Checks if <code>this</code> object is an instance of the passed {@link DefRef}.
     *
     * <p>
     * Note: This method tests also refinements. So, if the {@link GIModelObject} is refined of the passed {@link DefRef}, it will also yield to true.
     * </p>
     *
     * <p>
     * See also method {@link DefRef#isDefinitionOf(MIObject)}.
     * </p>
     *
     * @param defRef The defRef to check.
     * @return <code>true</code>, if this is an instance of the defRef.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the passed DefRef is null</li>
     * </ul>
     */
    @PublishedMethod
    boolean isInstanceOfDefRef(DefRef defRef);

    /**
     * Returns the {@link ICeStatePublished} of the corresponding model object (see {@link #getMdfObject()}.
     *
     * <p>
     * <b>Note:</b> The returned {@link ICeStatePublished} is from the {@link CeStatePublishedFactory}.
     * </p>
     *
     * <p>
     * The method will never return <code>null</code>.
     * </p>
     *
     * @return the CeState.
     */
    @PublishedMethod
    ICeStatePublished getCeState();

    /**
     * <div class="extdoc" id="Using_getCreationModelView"> The method {@link #getCreationModelView()} returns the {@link IModelView} of this {@link GIModelObject}, which was
     * active during the creation of this BswmdModel.
     *
     * </div>
     *
     * @return the creation model view of the BswmdModel
     *
     * <p>
     * The method will never return <code>null</code>.
     * </p>
     */
    @Override
    @PublishedMethod
    IModelView getCreationModelView();

    /**
     * <div class="extdoc" id="Using_executeWithCreationModelView"> The method {@link #executeWithCreationModelView()} executes the code under visibility of the
     * {@link #getCreationModelView()} of this {@link GIModelObject}.
     * <p>
     * <b>The returned {@link IModelViewExecutionContext} must be used within a Java "try-with-resources" feature.</b> It makes sure, that the old view is restored when the try is
     * completed.
     * </p>
     *
     * <pre>
     * <code class="Java" id="Java: Execute code with creation IModelView of BswmdModel object">
     * GIModelObject myModelObject = ...;
     *
     * try (final IModelViewExecutionContext context = myModelObject.executeWithCreationModelView()) {
     *         // do some operations
     *         ...
     * }
     * </code>
     * </pre>
     *
     * </div>
     *
     * @return The execution context
     * @see IModelViewManager#executeWithModelView(IModelView)
     */
    @PublishedMethod
    IModelViewExecutionContext executeWithCreationModelView();

    /**
     * <div class="extdoc" id="Using_executeWithCreationModelView_Supplier"> The method {@link #executeWithCreationModelView()} executes the {@link Supplier} code under visibility
     * of the {@link #getCreationModelView()} of this {@link GIModelObject}. You could use this method, if you want to return an object from this operation.
     * <p>
     *
     *
     * <pre>
     * <code class="Java" id="Java: Execute code with creation IModelView of BswmdModel object">
     * GIModelObject myModelObject = ...;
     *
     * ReturnType returnVal = myModelObject.executeWithCreationModelView(()->{
     *   // do some operations
     *   return theValue;
     *  });
     *
     * </code>
     * </pre>
     *
     * </div>
     *
     * @return The execution context
     * @see IModelViewManager#executeWithModelView(IModelView)
     */
    @PublishedMethod
    <T> T executeWithCreationModelView(Supplier<T> code);

    /**
     * <div class="extdoc" id="Using_executeWithCreationModelView_Runnable"> The method {@link #executeWithCreationModelView(Runnable)} executes the {@link Runnable} code under
     * visibility of the {@link #getCreationModelView()} of this {@link GIModelObject}.
     * <p>
     *
     * <pre>
     * <code class="Java" id="Java: Execute code with creation IModelView of BswmdModel object via runnable">
     *  GIModelObject myModelObject = ...;
     *
     *  myModelObject.executeWithCreationModelView(()->{
     *   // do some operations
     *  });
     * </code>
     * </pre>
     *
     * </div>
     *
     * @return The execution context
     * @see IModelViewManager#executeWithModelView(IModelView)
     */
    @PublishedMethod
    void executeWithCreationModelView(Runnable code);

    /**
     * Returns a bswmd model instance for the passed {@link MIHasDefinition} (mdfCfgElement). The element will be casted to type giModelClazz.
     *
     * <p>
     * Note: The used {@link IModelView} is the creation {@link IModelView}, from the {@link GIModelObject#getCreationModelView()}!
     * </p>
     *
     * @param <T> the generic type
     * @param giModelClazz the class of the bswmd model element.
     * @param mdfCfgElement the MDF configuration element.
     * @return single instance for the passed {@link MIHasDefinition}.
     */
    @PublishedMethod
    <T extends GIModelObject> T getInstanceInContextOfCreationModelView(Class<T> giModelClazz, MIHasDefinition mdfCfgElement);

    /**
     * Deletes the specified object from the model. <br>
     *
     * @throws IllegalStateException if object can not be deleted.
     *
     * @param obj is the object to be deleted
     */
    @PublishedMethod
    void moRemove();

    /**
     * Returns <code>true</code>, if the object was removed from repository, or is invisible in the current active {@link IModelView}.
     *
     * <p>
     * Note: The return value is dependent on the current active thread and the current active {@link IModelView} in this thread!
     * </p>
     *
     * @return true, if object were removed or is currently invisible.
     */
    @PublishedMethod
    boolean moIsRemoved();

}
