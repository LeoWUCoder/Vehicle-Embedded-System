package com.vector.cfg.model.query.modelcheckedaccess.exceptions;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IDefinitionUndefinedExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Thrown when a model request can't the specified DefinitionRef in the model for the request.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaDefinitionUndefinedException extends McaException {

    private static final long serialVersionUID = 4442381387809916321L;

    private final IDefinitionUndefinedExData exData;

    /**
     * Constructor for McaParameterWrongTypeException.
     *
     * @param wrongTypeExDataList
     */
    @PublishedMethod
    public McaDefinitionUndefinedException(IDefinitionUndefinedExData exData) {
        super(ImmutableList.of(exData));
        this.exData = exData;
    }

    /**
     * Gets a {@link IDefinitionUndefinedExData} object with detailed information about the exception cause.
     *
     * @return The exception cause data object
     */
    @PublishedMethod
    @Override
    public IDefinitionUndefinedExData getExceptionData() {
        return exData;
    }

}
