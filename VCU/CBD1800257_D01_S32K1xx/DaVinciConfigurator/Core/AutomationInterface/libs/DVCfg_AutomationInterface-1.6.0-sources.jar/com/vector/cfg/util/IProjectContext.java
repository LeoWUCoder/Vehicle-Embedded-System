package com.vector.cfg.util;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.annotation.concurrent.ThreadSafe;

import com.google.inject.BindingAnnotation;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.util.servicecontext.IServiceContext;

/**
 * Implementations of this interface allow retrieving system-wide services related to a specific project context. Each project shall maintain its own context (one per project).
 * <p>
 * Service registration is being handled via an extension point.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ReworkThisAtNextBreakingChange("Move IProjectContext to the package projectcontext")
public interface IProjectContext extends IServiceContext {

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    <T> T getService(Class<T> service);

    @Retention(RUNTIME)
    @Target({ ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD, ElementType.TYPE })
    @BindingAnnotation
    public @interface ProjectContextService {

    }
}
