package com.vector.cfg.consistency.contribution.helper.solvingactions;

import static com.google.common.base.Preconditions.checkNotNull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IReferrableAccess;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.operations.IModelOperations;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * This class is an {@link ISolvingAction} that creates a container when executed.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class SACreateContainer implements ISolvingAction {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SACreateContainer.class);

    private final MIHasContainer parent;

    private final DefRef containerDef;

    private final IModelOperations modelOperations;

    private final String shortName;

    private final String description;

    private final IReferrableAccess referrableAccess;

    /**
     * Instantiates a new create container solving action.
     *
     * @param parent the parent
     * @param containerDef the container def
     * @param shortName the short name
     * @param description the description
     */
    @PublishedMethod
    public SACreateContainer(MIHasContainer parent, DefRef containerDef, String shortName, String description) {

        this.parent = checkNotNull(parent);
        this.modelOperations = ModelUtil.getService(parent, IModelOperations.class);
        this.referrableAccess = ModelUtil.getService(parent, IReferrableAccess.class);

        this.containerDef = checkNotNull(containerDef);
        this.shortName = shortName;

        this.description = checkNotNull(description);
        if (description.isEmpty()) {
            throw new IllegalArgumentException("The description is empty.");
        }

    }

    /**
     * Instantiates a new create container solving action.
     *
     * @param parent the parent
     * @param containerDef the container def
     * @param shortName the short name
     */
    @PublishedMethod
    public SACreateContainer(MIHasContainer parent, DefRef containerDef, String shortName) {
        this(parent, checkNotNull(containerDef), shortName, "Create Container " + containerDef.getLastShortname());
    }

    /**
     * Instantiates a new create container solving action.
     *
     * @param parent the parent
     * @param containerDef the container definition of the new container
     */
    @PublishedMethod
    public SACreateContainer(MIHasContainer parent, DefRef containerDef) {
        this(parent, checkNotNull(containerDef), null);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void run() {
        String newName = shortName;
        if ((newName == null) || (newName.isEmpty())) {
            newName = containerDef.getLastShortname();
            newName = referrableAccess.getValidShortnameForContainer(parent, newName, 1, newName);
        }
        modelOperations.createContainerByDefinition(parent, containerDef, newName);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getDescription() {
        return description;
    }
}
