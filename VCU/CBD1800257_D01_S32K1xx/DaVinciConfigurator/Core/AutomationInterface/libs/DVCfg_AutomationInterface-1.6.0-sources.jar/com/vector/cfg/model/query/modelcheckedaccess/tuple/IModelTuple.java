package com.vector.cfg.model.query.modelcheckedaccess.tuple;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.query.modelcheckedaccess.elements.params.IMcaTypesafeParam;
import com.vector.cfg.model.query.modelcheckedaccess.elements.references.IMcaTypesafeRef;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * This interface represents a tuple of value model element pairs.
 *
 * <p>
 * The tuple has to the element(Parameter/Reference) the value (retrieved by getValue()) and Element (retrieved by getElement())
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IMcaTypesafeParam
 * @see IMcaTypesafeRef
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IModelTuple<VALUE, ELEM extends MIParameterValue> {

    /**
     * Gets the value object of the tuple which is included in the Element object returned by {@link IModelTuple#getElement()}.
     *
     * @return The value object
     */
    @PublishedMethod
    VALUE getValue();

    /**
     * Gets the MDFElement of the tuple which includes the value object returned by {@link IModelTuple#getValue()}.
     *
     * @return The MDFElement of the tuple
     */
    @PublishedMethod
    ELEM getElement();
}
