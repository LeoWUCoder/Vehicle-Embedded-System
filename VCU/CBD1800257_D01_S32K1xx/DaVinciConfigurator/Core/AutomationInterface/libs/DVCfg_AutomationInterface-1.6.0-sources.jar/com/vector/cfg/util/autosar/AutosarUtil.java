package com.vector.cfg.util.autosar;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.function.Predicate;
import java.util.function.ToLongBiFunction;
import java.util.regex.Pattern;
import java.util.zip.CRC32;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.google.common.base.Strings;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.HashMap;
import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.debug.CacheDebugUtil;
import com.vector.cfg.util.internal.UtilPluginId;
import com.vector.cfg.util.lang.CLangUtil;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.postfix.NumericPostfixFormatter;
import com.vector.cfg.util.postfix.NumericPostfixSet;
import com.vector.cfg.util.string.StringUtil;

/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation">
 * <h2>AutosarUtil</h2> The class {@link AutosarUtil} is a static utility class. Its methods are not directly related to the MDF model but are useful when client code deals with
 * AUTOSAR paths and shortnames on string basis.
 *
 * Some of these methods are
 * <ul>
 * <li>{@link #isValidShortname(String)}: Checks if this shortname is valid according the rules, the AUTOSAR standard defines (character set for example)
 * <li>{@link #getLastShortname(String)}: Returns the last shortname of the specified AUTOSAR path
 * <li>{@link #getFirstShortname(String)}: Returns the first shortname of the specified AUTOSAR path
 * <li>{@link #getAllShortnames(String)}: Returns all shortnames of the specified AUTOSAR path
 * </ul>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class AutosarUtil {
    private static final ILogger logger = Logger.INSTANCE.createLogger(AutosarUtil.class);

    /** The path separator used by AUTOSAR as <code>char</code>. */
    @PublishedField
    public static final char PATHSEP = '/';

    /** The path separator used by AUTOSAR as {@link String}. */
    @PublishedField
    public static final String PATHSEP_STR = "/";

    private static final char ASCII_0 = '0';

    private static final char ASCII_9 = '9';

    private static final char ASCII_A = 'A';

    private static final char ASCII_Z = 'Z';

    // @CHECKSTYLE:OFF
    private static final char ASCII_a = 'a';

    private static final char ASCII_z = 'z';

    // @CHECKSTYLE:ON
    private static final int PATH_SPLIT_CACHE_SIZE = 30000;

    private static final int MAX_IDENTIFIER_LENGTH = 128;

    /**
     * Global cache for AUTOSAR path split.
     */
    private static final LoadingCache<String, List<String>> pathSplitCache;

    static {

        final CacheBuilder<Object, Object> pathSplitCacheBuilder = CacheBuilder.newBuilder();
        pathSplitCacheBuilder.maximumSize(PATH_SPLIT_CACHE_SIZE).concurrencyLevel(4);
        if (logger.isDebugEnabled()) {
            pathSplitCacheBuilder.recordStats();
        }
        pathSplitCache = pathSplitCacheBuilder.build(new CacheLoader<String, List<String>>() {
            @Override
            public List<String> load(final String key) throws Exception {
                final List<String> split = StringUtil.split(key, PATHSEP);
                if (split.get(0).isEmpty()) {
                    // The first shortname is empty for absolute paths
                    split.remove(0);
                }
                return ImmutableList.copyOf(split);
            }
        });

        CacheDebugUtil.startCacheDebugDeamonThread(logger, pathSplitCache, "AutosarUtil-PathSplitCache");
    }

    /**
     * Constructor is private since this class provides static methods only.
     */
    private AutosarUtil() {
    }

    /**
     * Clears all static caches explicitly.
     */
    @PublishedMethod
    public static void clearStaticCaches() {
        pathSplitCache.invalidateAll();
    }

    /**
     * Checks if the specified short-name is valid regarding to the AUTOSAR rules.
     * <p>
     * The following checks are made:
     * <ul>
     * <li>Is the short-name <code>null</code> or empty?</li>
     * <li>Does the short-name contains invalid characters?</li>
     * </ul>
     *
     * @param name
     * @return
     */
    @PublishedMethod
    public static IStatus isValidShortname(final String name) {
        if (name == null) {
            return ShortnameState.NULL;
        }
        if (name.isEmpty()) {
            return ShortnameState.EMPTY;
        }
        if (!isAsciiLetter(name.charAt(0))) {
            return ShortnameState.STARTS_INVALID_CHAR;
        }
        for (final char c : name.toCharArray()) {
            if (!(isAsciiDigit(c) || isAsciiLetter(c) || c == '_')) {
                return ShortnameState.CONTAINS_INVALID_CHAR;
            }
        }
        return ShortnameState.OK;
    }

    /**
     * Checks if the specified short-name is valid regarding to the technical restrictions in the MDFModel about the validity of shortnames.
     * <p>
     * The following checks are made:
     * <ul>
     * <li>Is the short-name <code>null</code> or empty?</li>
     * <li>Does the short-name contains invalid characters?</li>
     * </ul>
     *
     * @param name
     * @return
     */
    @KeepSecretFromPublishedApi
    public static IStatus isTechnicallyValidShortname(final String name) {
        if (name == null) {
            return ShortnameState.NULL;
        }
        if (name.isEmpty()) {
            return ShortnameState.EMPTY;
        }
        for (final char c : name.toCharArray()) {
            if (!(isAsciiDigit(c) || isAsciiLetter(c) || c == '_' || c == '-' || c == ' ')) {
                return new Status(IStatus.ERROR, UtilPluginId.PLUGIN_ID, "Shortname '" + name + "' contains invalid characters (valid are [a-zA-Z0-9 _-]).");
            }
        }
        return ShortnameState.OK;
    }

    /**
     * Checks if the passed path is a valid AUTOSAR path.
     * <ul>
     * <li>Not null</li>
     * <li>Not empty</li>
     * <li>Starts with /</li>
     * <li>All parts are valid shortnames</li>
     * </ul>
     *
     * @param path the path
     * @return true, if is valid autosar path
     */
    @PublishedMethod
    public static boolean isValidAutosarPath(final String path) {
        if (path == null) {
            return false;
        }
        if (path.isEmpty()) {
            return false;
        }
        if (path.charAt(0) != PATHSEP) {
            return false;
        }
        final List<String> allShortnamesInTheRightOrder = getAllShortnamesInTheRightOrder(path);

        for (final String shortName : allShortnamesInTheRightOrder) {
            if (!isValidShortname(shortName).isOK()) {
                return false;
            }
        }
        return true;
    }

    /** The Constant LINKER_SYMBOL_PATTERN for the method boolean isValidLinkerSymbol(String linkerSymbolValue). */
    private static final Pattern LINKER_SYMBOL_PATTERN = Pattern.compile("[_.$%a-zA-Z][_.$%a-zA-Z0-9]*"); //$NON-NLS-1$

    /**
     * According to XML 1.0 an NMTOKEN is.
     *
     * Nmtoken ::= (NameChar)+
     *
     * NameChar ::= Letter | Digit | '.' | '-' | '_' | ':' | CombiningChar | Extender
     *
     * (Ignoring 'CombiningChar' and 'Extender' here because we don't support e.g. arabic numbers currently)
     */
    private static final Pattern NMTOKEN_PATTERN = Pattern.compile("[a-zA-Z0-9.\\-_:]+");

    /**
     * Checks if the specified short-name is a valid LinkerSymbol regarding to the AUTOSAR rules.
     * <p>
     * The following checks are made:
     * <ul>
     * <li>Is the linkerSymbol <code>null</code> or empty?</li>
     * <li>Does the linkerSymbol contain invalid characters?</li>
     * <li>Is linkerSymbol a C-Keyword?</li>
     * </ul>
     *
     * <p>
     * See Also method ModelUtil.isValidLinkerSymbol() for LinkerCheck depending on the definition.
     * </p>
     *
     * @param name
     * @return true, if it is a valid LinkerSymbol.
     */
    @PublishedMethod
    public static boolean isValidLinkerSymbol(final String linkerSymbolValue) {
        if (linkerSymbolValue == null || linkerSymbolValue.isEmpty()) {
            return false;
        } else if (CLangUtil.isCKeyword(linkerSymbolValue)) {
            return false;
        }
        return LINKER_SYMBOL_PATTERN.matcher(linkerSymbolValue).matches();
    }

    /**
     * Checks if the specified string is an NMTOKEN according to XML 1.0.
     * <p>
     * The following checks are made:
     * <ul>
     * <li>Is the string <code>null</code> or empty?</li>
     * <li>Does the string contain invalid characters?</li>
     * </ul>
     *
     * @param nmtoken
     * @return true, if it is a valid NMTOKEN.
     */
    @KeepSecretFromPublishedApi
    public static boolean isValidNmToken(final String nmtoken) {
        if (Strings.isNullOrEmpty(nmtoken)) {
            return false;
        }
        return NMTOKEN_PATTERN.matcher(nmtoken).matches();
    }

    /**
     * Returns <code>true</code> if the specified parent AUTOSAR path is a prefix of the specified child path and <code>false</code> otherwise. If the paths are equal, this
     * method returns <code>false</code> too.
     * <p>
     * Be aware that a simple string prefix check is not sufficient here because the parent path must be followed by a short-name separator ('/') in the childPath.
     * <code>"/MICROSAR/Can"</code> for example is not a parent path of <code>"/MICROSAR/CanIf/CanIfPrivateConfiguration"</code> but "/MICROSAR/CanIf" is one.
     *
     * @param parentPath
     * @param childPath
     * @return
     */
    @PublishedMethod
    public static boolean isParentPath(final String parentPath, final String childPath) {
        if (parentPath == null || childPath == null) {
            return false;
        }
        final int childLen = childPath.length();
        final int parentLen = parentPath.length();
        if (parentLen >= childLen) {
            return false;
        }
        if (childPath.startsWith(parentPath)) {
            return (childPath.charAt(parentLen) == PATHSEP);
        }
        return false;
    }

    /**
     * Returns the last shortname of the specified AUTOSAR path. Relative paths are allowed (path doesn't start with '/').
     * <p>
     * This method implements string handling only. The specified AUTOSAR path doesn't need to point to an existing object.
     * </p>
     *
     * @param autosarPath
     * @return The shortname if found. If the AUTOSAR path is empty or <code>null</code>, this method returns <code>null</code>
     */
    @PublishedMethod
    public static String getLastShortname(final String autosarPath) {
        if (autosarPath == null || autosarPath.isEmpty()) {
            return null;
        }
        final List<String> split = getPathSplit(autosarPath);
        return split.get(split.size() - 1);
    }

    /**
     * Returns the first shortname of the specified AUTOSAR path. Relative paths are allowed (path doesn't start with '/').
     * <p>
     * This method implements string handling only. The specified AUTOSAR path doesn't need to point to an existing object.
     * </p>
     *
     * @param autosarPath
     * @return The shortname if found. If the AUTOSAR path is empty or <code>null</code>, this method returns <code>null</code>
     */
    @PublishedMethod
    public static String getFirstShortname(final String autosarPath) {
        if (autosarPath == null || autosarPath.isEmpty()) {
            return null;
        }
        final List<String> split = getPathSplit(autosarPath);
        return split.get(0);
    }

    /**
     * Returns the specified AUTOSAR path without the last shortname. In other words: This method returns the AUTOSAR path of the referrable parent object. Relative paths are
     * allowed (path doesn't start with '/').
     * <p>
     * This method implements string handling only. The specified AUTOSAR path doesn't need to point to an existing object.
     * </p>
     *
     * @param autosarPath
     * @return The reduced path if possible. If the AUTOSAR path is empty or <code>null</code>, this method returns <code>null</code>. If the removed shortname was the only one
     * contained, this method returns the empty string.
     */
    @PublishedMethod
    public static String getPathWithoutLastShortname(final String autosarPath) {
        if (autosarPath == null || autosarPath.isEmpty()) {
            return null;
        }
        final int i = autosarPath.lastIndexOf(PATHSEP);
        if (i <= 0) {
            return "";
        }
        return autosarPath.substring(0, i);
    }

    /**
     * Returns the specified ObjectLink (See IModelAccess#getObejctLink()) without the last element. In other words: This method returns the AUTOSAR path of the referrable
     * parent object. Relative paths are allowed (path doesn't start with '/').
     * <p>
     * This method implements string handling only. The specified AUTOSAR path doesn't need to point to an existing object.
     * </p>
     *
     * @param autosarPath
     * @return The reduced path if possible. If the AUTOSAR path is empty or <code>null</code>, this method returns <code>null</code>. If the removed shortname was the only one
     * contained, this method returns the empty string.
     */
    @PublishedMethod
    public static String getObjectLinkWithoutLastElement(final String objectLink) {
        if (objectLink == null || objectLink.isEmpty()) {
            return null;
        }

        if (objectLink.contains("[")) {
            /*
             * ParameterObjectLink
             */
            return objectLink.substring(0, objectLink.indexOf("["));
        }

        return getPathWithoutLastShortname(objectLink);
    }

    /**
     * Returns the specified AUTOSAR path of the element with the element index (elementIndex) without the last shortname.
     * <p>
     * This method implements string handling only. The specified AUTOSAR path doesn't need to point to an existing object.
     * </p>
     *
     * @param autosarPath
     * @return The element path if possible. If the AUTOSAR path is empty or <code>null</code>, this method returns <code>null</code>. If the index does not exist in to string
     * null is returned.
     */
    @PublishedMethod
    public static String getPathOfElementWithSpecificIndex(final String autosarPath, final int elementIndex) {
        if (autosarPath == null || autosarPath.isEmpty()) {
            return null;
        }
        if (elementIndex < 0) {
            return null;
        }

        int start = 0;
        if (autosarPath.charAt(0) == PATHSEP) {
            start = 1;
        }
        int indexOf = start;
        for (int x = 0; x <= elementIndex; x++) {
            if (x != 0) {
                // Add one char because of "/" in the string
                indexOf++;
            }
            indexOf = autosarPath.indexOf(PATHSEP, indexOf);
            if (indexOf == -1) {

                if (x == elementIndex) {
                    indexOf = autosarPath.length();
                    break;
                } else {
                    // Wrong index
                    return null;
                }
            }

        }
        return autosarPath.substring(0, indexOf);
    }

    /**
     * Returns the passed shortname, truncated if the shortname exceeds the MAX_SHORTNAME_LENGTH and adds a CRC-Value at the end.
     *
     * <p>
     * If the shortname does not exceeds the length, it is returned without suffix.
     * </p>
     *
     * @param shortName the short name
     * @return the short name truncated and a crc suffix
     */
    @PublishedMethod
    public static String getShortnameTruncatedWithCrcSuffix(final String shortName) {

        if (shortName.length() <= MAX_IDENTIFIER_LENGTH) {
            return shortName;
        }

        final CRC32 crc = new CRC32();
        final byte[] bytes = shortName.getBytes(UTF_8);
        crc.update(bytes, 0, bytes.length);

        final int maxShortLen = MAX_IDENTIFIER_LENGTH - 9;

        String oldName = shortName.substring(0, maxShortLen);
        while (oldName.endsWith("_")) {
            oldName = oldName.substring(0, oldName.length() - 1);
        }
        return String.format("%s_%08x", oldName, crc.getValue());
    }

    /**
     * Returns the specified AUTOSAR path without the first shortname. In other words: This method returns a relative AUTOSAR path missing the first shortname. Absolute and
     * relative shortnames are supported as parameters here.
     * <p>
     * This method implements string handling only. The specified AUTOSAR path doesn't need to point to an existing object.
     *
     * @param autosarPath
     * @return The reduced path if possible. If the AUTOSAR path is empty or <code>null</code>, this method returns <code>null</code>. If the removed shortname was the only one
     * contained, this method returns the empty string.
     */
    @PublishedMethod
    public static String getPathWithoutFirstShortname(final String autosarPath) {
        if (autosarPath == null || autosarPath.isEmpty()) {
            return null;
        }
        final int startAt = (autosarPath.charAt(0) == PATHSEP ? 1 : 0);
        final int i = autosarPath.indexOf(PATHSEP, startAt);
        if (i == -1) {
            return "";
        }
        return autosarPath.substring(i + 1);
    }

    /**
     * Returns all shortnames of the specified AUTOSAR path.
     *
     * @param autosarPath
     * @return
     */
    @PublishedMethod
    public static Collection<String> getAllShortnames(final String autosarPath) {
        return getAllShortnamesInTheRightOrder(autosarPath);
    }

    /**
     * Returns all shortnames of the specified AUTOSAR path in the order they occur in the path.
     *
     * @param autosarPath is an absolute or relative AUTOSAR path
     * @return
     */
    @PublishedMethod
    public static List<String> getAllShortnamesInTheRightOrder(final String autosarPath) {
        if (autosarPath == null || autosarPath.isEmpty()) {
            return Collections.emptyList();
        }
        final List<String> split = getPathSplit(autosarPath);
        return split;
    }

    /**
     * Returns the longest common common relative path of the two specified AUTOSAR paths.
     *
     * <h1>Example</h1> "/MICROSAR/Can/CanGeneral" and "/AUTOSAR/Can/CanGeneral" have "Can/CanGeneral" as longest common prefix path.
     *
     * @param autosarPath1
     * @param autosarPath2
     * @return
     */
    @PublishedMethod
    public static String getLongestCommonPostfixPath(final String autosarPath1, final String autosarPath2) {
        final List<String> shortnames1 = getAllShortnamesInTheRightOrder(autosarPath1);
        final List<String> shortnames2 = getAllShortnamesInTheRightOrder(autosarPath2);
        int i1 = shortnames1.size() - 1;
        int i2 = shortnames2.size() - 1;
        while (i1 >= 0 && i2 >= 0 && shortnames1.get(i1).equals(shortnames2.get(i2))) {
            --i1;
            --i2;
        }

        /**
         * PathSep as first char if the paths are equal and absolute
         */
        final boolean bothPathsAbsolute = (autosarPath1.charAt(0) == PATHSEP && autosarPath2.charAt(0) == PATHSEP);
        boolean appendPathSep = (i1 < 0 && i2 < 0 && bothPathsAbsolute);

        final StringBuilder postfixPath = new StringBuilder();
        while (++i1 < shortnames1.size()) {
            if (appendPathSep) {
                postfixPath.append(PATHSEP);
            } else {
                appendPathSep = true;
            }
            postfixPath.append(shortnames1.get(i1));
        }
        return postfixPath.toString();
    }

    private static List<String> getPathSplit(final String path) {
        try {
            return pathSplitCache.get(path);
        } catch (final ExecutionException e) {
            // Should never occur
            logger.error(e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Returns the second last short name of the specified AUTOSAR path. This is useful, if you have the full definition of a parameter, and would like to extract the definition
     * short name of the parent container.
     *
     * @param autosarPath
     * @return
     */
    @PublishedMethod
    public static String getSecondLastShortname(final String autosarPath) {
        return AutosarUtil.getLastShortname(AutosarUtil.getPathWithoutLastShortname(autosarPath));
    }

    /**
     * Create unique name for given name according to already existing names. Same algorithm as IReferrableAccess.getValidShortname, but without access to MDF Objects and
     * without truncation of name to valid AUTOSAR length.
     *
     * @param existingNames
     * @param name
     * @param numDigits
     * @return
     */
    @PublishedMethod
    public static String getUniqueChildName(final Set<String> existingNames, String name, int numDigits) {

        if (existingNames == null || name == null || existingNames.isEmpty() || !existingNames.contains(name)) {
            return name;
        }

        // prepare existing postfixes
        final Map<String, NumericPostfixSet> postfixValues = new HashMap<>();
        for (final String existingName : existingNames) {
            if (NumericPostfixFormatter.hasPostfix(existingName)) {
                final NumericPostfixSet postfixSet = postfixValues.get(NumericPostfixFormatter.parseBasename(existingName));
                if (postfixSet != null) {
                    postfixSet.addUsedPostfix(name);
                }
            }
        }

        return getUniqueChildName(name, numDigits, false, nextName -> existingNames.contains(nextName),
                (basename, num) -> getNextUnusedPostfixValue(existingNames, postfixValues, basename, num));

    }

    private static long getNextUnusedPostfixValue(Set<String> existingNames, final Map<String, NumericPostfixSet> postfixValues, String basename, long lastUsedPostfixValue) {
        NumericPostfixSet postfixSet = postfixValues.get(basename);
        if (postfixSet == null) {
            postfixSet = NumericPostfixFormatter.calculatePostfixesForBasename(existingNames, basename);
            postfixValues.put(basename, postfixSet);

        }
        final long value = postfixSet.getNextUnusedValueGreaterThan(lastUsedPostfixValue);
        if (value <= lastUsedPostfixValue) {
            return lastUsedPostfixValue + 1; // ... to avoid endless loops in the calling method
        }
        return value;
    }

    /**
     *
     * If the (potentially truncated) shortname does not exist below the specified parent it is returned without further changes. If it already exists, the method attaches an
     * underscore followed by a number starting from 1. The number postfix is being increased as long as the resulting shortname exists. Finally a new non-existing shortname is
     * returned.
     *
     * <p>
     * The numDigits parameter specifies the minimum number of digits to be attached. The attached number is prefixed by '0' to fill this length. If the finally found number is
     * larger, it will not be cut to the specified number of digits - the number length is simply exceeded.
     * <p>
     * <b>Example:</b> If the shortname <code>"abc"</code> already exists and 3 is specified as minimum number of digits, the method starts trying <code>"abc_001"</code>.
     *
     * If the specified name already ends with a number sequence as specified above, the method returns the next unused one. The specified <code>numDigits</code> value will be
     * ignored in this case and the actually found number of digits will be used.
     * <p>
     * <b>Example:</b> If the shortname <code>"abc_009"</code> already exists, the method starts trying <code>"abc_010"</code>.
     *
     * @param name The name to make unique
     * @param numDigits Is the number of digits, the attached number shall be formated with. If this value is 1 or lower, no leading '0' will be attached. If it is larger that
     * 32, it will be set to 32.
     * @param truncateNameForValidAutosarLength if true, the name will be truncated if too long according to AUTOSAR.
     * @param nameIsInUsePredicate Predicate to test if name is already in use.
     * @param getNextUnusedPostfixValue Function to get the next unused postfix for the given name and postfix
     * @return The unique child name
     */
    @KeepSecretFromPublishedApi
    public static String getUniqueChildName(String name, final int numDigits, final boolean truncateNameForValidAutosarLength, final Predicate<String> nameIsInUsePredicate,
            final ToLongBiFunction<String, Long> getNextUnusedPostfixValue) {

        NumericPostfixFormatter postfixFormatter = new NumericPostfixFormatter(name, numDigits);
        if (truncateNameForValidAutosarLength && postfixFormatter.isShortnameTooLongToPostfix()) {
            name = postfixFormatter.getBasenameShortEnoughToPostfix();
            postfixFormatter = new NumericPostfixFormatter(name, numDigits);
        }

        // Check if the name is already used
        if (nameIsInUsePredicate.test(name)) {
            final String basename = postfixFormatter.getBasename();
            long num = postfixFormatter.getInitialUnusedValue();
            name = postfixFormatter.getPostfixedName(num);
            while (nameIsInUsePredicate.test(name)) {
                num = getNextUnusedPostfixValue.applyAsLong(basename, num);
                name = postfixFormatter.getPostfixedName(num);
            }
        }

        return name;
    }

    /**
     * Checks if the specified char is an ASCII digit (one of [0-9]).
     * <p>
     * We cannot use {@link Character#isDigit(char)} because this method checks for unicode digits which is too much ...
     *
     * @param c
     * @return
     */
    private static boolean isAsciiDigit(final char c) {
        return (ASCII_0 <= c && c <= ASCII_9);
    }

    /**
     * Checks if the specified char is an ASCII letter (one of [A-Za-z]).
     * <p>
     * We cannot use {@link Character#isLetter(char)} because this method checks for unicode letters which is (far) too much ...
     *
     * @param c
     * @return
     */
    private static boolean isAsciiLetter(final char c) {
        return (ASCII_A <= c && c <= ASCII_Z) || (ASCII_a <= c && c <= ASCII_z);
    }
}
