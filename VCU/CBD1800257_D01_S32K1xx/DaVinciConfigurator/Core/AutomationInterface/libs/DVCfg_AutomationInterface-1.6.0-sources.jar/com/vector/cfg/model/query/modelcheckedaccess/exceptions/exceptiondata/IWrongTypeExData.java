package com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceWrongTypeException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess exception data for the {@link McaReferenceWrongTypeException}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see McaReferenceWrongTypeException
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IWrongTypeExData extends IElementTypeExData {

    /**
     * Gets the expected type of the element of the model request.
     *
     * @return The expected type of the model request.
     */
    @PublishedMethod
    Class<?> getExpectedType();

    /**
     * Gets the actual type of the element of the model request.
     *
     * @return The actual type of the model request.
     */
    @PublishedMethod
    Class<?> getActualType();

}
