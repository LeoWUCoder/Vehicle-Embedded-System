/**
 * This package contains API to query and create annotations for model objects.
 * <p>
 * This supports annotations based on AUTOSAR MDF model annotations and AUTOSAR MDF admin data annotations.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.model.annotation;