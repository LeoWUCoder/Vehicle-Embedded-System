package com.vector.cfg.model.access.ecuconfiguration.elements.parameter;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucBooleanDefinition;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucBooleanParameter extends IEcucNumericalParameter<Boolean> {

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucBooleanDefinition getEcucDefinition();

    /**
     * Sets the parameter value.
     *
     * @param value
     */
    @PublishedMethod
    void setValue(boolean value);

}
