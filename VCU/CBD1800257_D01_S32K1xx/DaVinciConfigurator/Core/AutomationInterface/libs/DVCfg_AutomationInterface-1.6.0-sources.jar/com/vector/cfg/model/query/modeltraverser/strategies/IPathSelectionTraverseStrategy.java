package com.vector.cfg.model.query.modeltraverser.strategies;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser;
import com.vector.cfg.model.query.modeltraverser.Path;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="TraverseStrategy"> An {@link IPathSelectionTraverseStrategy} is an {@link ITraverseStrategy}, to integrate
 * overlapping definition subtrees, into an {@link IModelTraverser}. E.g. You have to include the same {@link DefRef} twice in your definition tree with a different semantic.
 * This is only executed for the path traversal from children to root (MainElement). By the traversal down, the {@link IPathSelectionTraverseStrategy} is IGNORED!
 *
 *
 *
 * <p>
 * The Class {@link PathSelectionTraverseStrategy} provides a basic implementation for the {@link IPathSelectionTraverseStrategy}. <b>Please subclass the
 * {@link PathSelectionTraverseStrategy} to implement you own strategy.</b>
 * </p>
 *
 * <p>
 * <b>Attention</b>: Your implementation must be <b>threadsafe</b>, because a {@link IModelTraverser} could be called by different threads!
 * </p>
 *
 *
 * <pre>
 * <code class="Java" id="IPathSelectionTraverseStrategy sample implementation">
 *  public class YourStrategy extends PathSelectionTraverseStrategy<?,?> {
 *
 *         protected YourStrategy(IProjectContext projectContext, TypedDefRef<?, ?, ?> parentDefRef, TypedDefRef<?, ?, ?> elementDefRef) {
 *          super(projectContext,parentDefRef,elementDefRef
 *         }
 *
 *
 *         &#64;Override
 *         public boolean acceptPathTraversalInternal(MIHasDefinition currentElem) {
 *             if (getParentDefRef().equals(COM_SIGNAL_GROUP_DEFREF)) {
 *                //Decide if the subtree must be processed.
 *                 return true;
 *             } else {
 *                  ....
 *             }
 *             return false;
 *         }
 *
 *     }
 * </code>
 * </pre>
 *
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 * @see TraverseStrategy
 * @see IModelTraverser
 * @see ITraverseStrategy
 * @see Path
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IPathSelectionTraverseStrategy extends ITraverseStrategy {

    /**
     * Is called for each element of type {@link #getDefRef()}.
     *
     * <p>
     * If the method returns true, the traversal is continued, otherwise the traversal will stop at this element.
     * </p>
     *
     * @param currentElem the current elem
     * @return true, if the traversal shall proceed.
     */
    @PublishedMethod
    boolean acceptPathTraversal(MIHasDefinition currentElem);
}
