package com.vector.cfg.consistency.contribution.helper.solvingactions;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.Collection;
import java.util.Collections;

import javax.annotation.Nullable;

import com.google.common.collect.Iterables;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IHasDescriptionAsMixedText;
import com.vector.cfg.consistency.contribution.IHasSolvingActionGroups;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.IUISolvingAction;
import com.vector.cfg.consistency.contribution.IVariantSolvingAction;
import com.vector.cfg.consistency.contribution.helper.validationresults.ISolvingActionGroup;
import com.vector.cfg.consistency.coreinternal.wrappedinterface.IHasWrappedInterfaces;
import com.vector.cfg.consistency.coreinternal.wrappedinterface.WrappedInterfaceUtil;
import com.vector.cfg.consistency.internal.resultprovisioning.SolvingActionWrapperExternal;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.string.StringUtil;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation;GenDevKitDocumentation" id="Common">
 *
 * <h5>SolvingAction utilities</h5> The class {@link SolvingActions} provides static utility methods for {@link ISolvingAction}s.
 *
 * The class provides methods to :
 * <ul>
 * <li>Combine multiple {@link ISolvingAction}s to one</li>
 * <li>Assign an {@link IModelView} to an {@link ISolvingAction} for execution</li>
 * <li>Wraps a {@link Runnable} into an {@link ISolvingAction}</li>
 * </ul>
 *
 * </div>
 *
 * <p>
 * Please also see the class {@link SolvingActionBuilder} to construct {@link ISolvingAction}s
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class SolvingActions {
    // private static final ILogger logger = Logger.INSTANCE.createLogger(SolvingActions.class);

    /** This is the highest solving action group id that can be used for contributed {@link ISolvingActionGroup}. */
    @PublishedField
    public static final int MAX_GROUP_ID = 100000;

    /**
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation;GenDevKitDocumentation" id="executeInView">
     * <p>
     * The method {@link #executeInView(IModelView,ISolvingAction)} creates a {@link ISolvingAction} and wraps the passed {@link ISolvingAction}, which switches to the passed
     * {@link IModelView}, before execution of the passed action.
     *
     * This could be required for {@link ISolvingAction}s in the Post-build selectable use case.
     * </p>
     * </div>
     *
     * @param view the {@link IModelView} which is active before {@link ISolvingAction#run()} is called.
     * @param solvingAction the new solving action
     * @return the combined solvingAction
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the view is null</li>
     * <li>if the solvingAction is null</li>
     * </ul>
     */
    @PublishedMethod
    public static IVariantSolvingAction executeInView(final IModelView view, final ISolvingAction solvingAction) {

        class VariantSolvingAction implements IVariantSolvingAction, IHasWrappedInterfaces, IHasSolvingActionGroups {
            @Override
            public String getDescription() {
                try (IModelViewExecutionContext ctx = view.executeWithThisView()) {
                    return solvingAction.getDescription();
                }
            }

            @Override
            public void run() {
                try (IModelViewExecutionContext ctx = view.executeWithThisView()) {
                    solvingAction.run();
                }
            }

            @Override
            public String toString() {
                return "SolvingAction (" + getDescription() + ") in ModelView " + view.toString();
            }

            /**
             * {@inheritDoc}
             */
            @Override
            public <T> T extractInterface(Class<T> classObj) {
                return WrappedInterfaceUtil.extractInterface(classObj, this, solvingAction);
            }

            /**
             * {@inheritDoc}
             */
            @Override
            public Collection<ISolvingActionGroup> getAssignedSolvingActionGroups() {
                if (solvingAction instanceof IHasSolvingActionGroups) {
                    return ((IHasSolvingActionGroups) solvingAction).getAssignedSolvingActionGroups();
                }
                return Collections.emptyList();
            }
        }

        checkNotNull(view);
        checkNotNull(solvingAction);
        return new VariantSolvingAction();
    }

    static class CombinedSolvingAction<T extends ISolvingAction> implements ISolvingAction, IHasDescriptionAsMixedText

    {

        private final IMixedText descriptionAsMixedText;

        private final Iterable<T> solvingActionToCombine;

        CombinedSolvingAction(@Nullable IMixedText descriptionAsMixedText, final Iterable<T> solvingActionToCombine) {
            this.solvingActionToCombine = solvingActionToCombine;
            if (descriptionAsMixedText != null) {
                this.descriptionAsMixedText = descriptionAsMixedText;
            } else {
                this.descriptionAsMixedText = combineDescriptions(solvingActionToCombine);
            }
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void run() {
            for (final ISolvingAction sa : solvingActionToCombine) {
                sa.run();
            }
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public IMixedText getDescriptionAsMixedText() {
            return descriptionAsMixedText;
        }

        @Override
        public String toString() {
            return "SolvingAction (" + getDescriptionAsMixedText() + ") combined from " + Iterables.toString(solvingActionToCombine);
        }
    }

    /**
     * Combines many {@link ISolvingAction}s to one solvingAction with the passed description.
     *
     * <p>
     * If you want also combine the description, you could use the method {@link #combineDescriptions(Iterable)}.
     * </p>
     *
     * @param <T> the generic type
     * @param description the description
     * @param solvingActionToCombine the solving actions to combine
     * @return the combined solvingAction
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the description is null</li>
     * <li>if the solvingActionToCombine is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <T extends ISolvingAction> ISolvingAction combine(final String description, final Iterable<T> solvingActionToCombine) {
        checkNotNull(description);
        checkNotNull(solvingActionToCombine);

        return new CombinedSolvingAction<>(MixedText.fromConstantString(description), solvingActionToCombine);
    }

    /**
     * Combines many {@link ISolvingAction}s to one solvingAction with the passed description.
     *
     * <p>
     * If you want also combine the description, you could use the method {@link #combineDescriptions(Iterable)}.
     * </p>
     *
     * @param <T> the generic type
     * @param description the description
     * @param solvingActionToCombine the solving actions to combine
     * @return the combined solvingAction
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the description is null</li>
     * <li>if the solvingActionToCombine is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <T extends ISolvingAction> ISolvingAction combine(final IMixedText descriptionAsMixedText, final Iterable<T> solvingActionToCombine) {
        checkNotNull(descriptionAsMixedText);
        checkNotNull(solvingActionToCombine);

        return new CombinedSolvingAction<>(descriptionAsMixedText, solvingActionToCombine);
    }

    /**
     * Combines many {@link ISolvingAction}s to one solvingAction and concatenates all {@link ISolvingAction#getDescription()} strings to one description.
     *
     * <p>
     * If you want also combine the description, you could use the method {@link #combineDescriptions(Iterable)}.
     * </p>
     *
     * @param <T> the generic type
     * @param solvingActionToCombine the solving actions to combine
     * @return the combined solvingAction
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the solvingActionToCombine is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <T extends ISolvingAction> ISolvingAction combines(final Iterable<T> solvingActionToCombine) {
        checkNotNull(solvingActionToCombine);

        return new CombinedSolvingAction<>(null, solvingActionToCombine);
    }

    /**
     * Combines many {@link ISolvingAction#getDescription()}s to one description.
     *
     *
     * @param <T> the generic type
     * @param description the description
     * @param solvingActionToCombine the solving actions to combine
     * @return the combined solvingAction descriptions.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the solvingActionToCombine is null</li>
     * </ul>
     */
    @KeepSecretFromPublishedApi
    public static <T extends ISolvingAction> IMixedText combineDescriptions(final Iterable<T> solvingActionToCombine) {
        checkNotNull(solvingActionToCombine);

        final IMixedTextBuilder mtBuilder = MixedText.newBuilder();

        int i = 0;
        for (final ISolvingAction sa : solvingActionToCombine) {
            if (i > 0) {
                mtBuilder.append(StringUtil.LINE_SEPARATOR, true);
            }
            mtBuilder.append(SolvingActionWrapperExternal.outputDescriptionAsMixedText(sa));
            ++i;
        }

        return mtBuilder.flushResult();
    }

    /**
     * Creates a {@link ISolvingAction} form a {@link Runnable}.
     *
     * @param description the description
     * @param r the code
     * @return the {@link ISolvingAction} wrapper
     */
    @PublishedMethod
    public static ISolvingAction createSolvingActionWrapper(final String description, final Runnable r) {
        return new ISolvingAction() {

            @Override
            @PublishedMethod
            public void run() {
                r.run();
            }

            @Override
            @PublishedMethod
            public String getDescription() {
                return description;
            }

            @Override
            public String toString() {
                return "SolvingAction (" + getDescription() + ")";
            }
        };
    }

    /**
     * Creates a {@link ISolvingAction} form a {@link Runnable}.
     *
     * @param description the description
     * @param r the code
     * @return the {@link ISolvingAction} wrapper
     */
    @PublishedMethod
    public static ISolvingAction createSolvingActionWrapper(final String description, final Runnable r, final Collection<ISolvingActionGroup> solvingActionGroups) {
        class SolvingAction implements ISolvingAction, IHasSolvingActionGroups {

            @Override
            public void run() {
                r.run();
            }

            @Override
            public String getDescription() {
                return description;
            }

            @Override
            public Collection<ISolvingActionGroup> getAssignedSolvingActionGroups() {
                return solvingActionGroups;
            }

            @Override
            public String toString() {
                return "SolvingAction (" + getDescription() + ")";
            }
        }
        return new SolvingAction();
    }

    private SolvingActions() {

    }

    /**
     * Creates an {@link IUISolvingAction} that does nothing, but is used to tell the user a solution that has to be performed manually by the user. "[MANUAL ACTION] " is
     * automatically prepended to the actual description/instruction.
     *
     * @param manualDescriptionText the manual description text
     * @return the IUI solving action
     */
    @PublishedMethod
    public static IUISolvingAction createManualUISolvingAction(String manualDescriptionText) {
        checkNotNull(manualDescriptionText);
        final String description = "[MANUAL ACTION] " + manualDescriptionText;
        return new IUISolvingAction() {

            @Override
            public String getDescription() {
                return description;
            }

            @Override
            public void run() {
                // do nothing
            }
        };
    }
}
