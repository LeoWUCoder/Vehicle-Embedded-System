package com.vector.cfg.util.text.format;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface ISpecificFormatterProvider extends IFormatterProvider {

    @PublishedMethod
    <T> IFormatter<T> getFormatter(Class<T> clazz, EFormatType type);

    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    enum EFormatType {

        USER,
        DEBUG; // The Type Debug includes User

        /**
         * Checks if the passed type is compatible to this.
         *
         * @param typeToCheck the type to check
         * @return true, if is type compatible
         */
        @PublishedMethod
        public boolean isTypeCompatible(EFormatType typeToCheck) {

            if (this == typeToCheck) {
                //Same types are compatible
                return true;
            }

            if (this == DEBUG) {
                //Every type is compatible to DEBUG
                return true;
            }

            //Otherwise false
            return false;
        }
    }

}
