package com.vector.cfg.consistency;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.<BR>
 * <BR>
 * </p>
 *
 * See {@link IHasDependencyType#getDependencyType()}
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EDependencyType {
    HARD(false), SOFT(true),;

    private final boolean changeAllowed;

    /**
     * See class doc.
     *
     */
    EDependencyType(boolean changeAllowed) {
        this.changeAllowed = changeAllowed;
    }

    /**
     * Getter method for changeAllowed.
     *
     * @return Returns the changeAllowed.
     */
    @PublishedMethod
    public boolean isChangeAllowed() {
        return changeAllowed;
    }

    /**
     * @param dependencyType
     * @return
     */
    @PublishedMethod
    public EDependencyType combine(EDependencyType other) {
        if ((this == HARD) || (other == HARD)) {
            return HARD;
        } else {
            return SOFT;
        }
    }

}
