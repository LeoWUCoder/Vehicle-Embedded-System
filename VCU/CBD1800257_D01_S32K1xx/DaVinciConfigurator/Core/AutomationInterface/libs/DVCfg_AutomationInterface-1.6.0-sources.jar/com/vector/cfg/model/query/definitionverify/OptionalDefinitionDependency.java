package com.vector.cfg.model.query.definitionverify;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * This annotation will mark a {@link TypedDefRef} field, that is should be checked by an DefinitionVerifier. Only a type check is performed, if the definition exists. A
 * Verifier will report an problem, if the Definition has not the type specified by the DefRef in the passed {@link IProjectContext}.
 *
 * <p>
 * There are some Verifiers available:
 * <ul>
 * <li>{@link LogDefinitionVerifier} - Will log any problem to it's logger</li>
 * <li>{@link ExceptionDefinitionVerifier} - Will throw an exception, when any problem occurs</li>
 * <li>{@link GenDefinitionVerifier} - Will throw a corresponding GeneratorPackageException</li>
 * </ul>
 *
 * <p>
 * You can verify any class by a call to {@link AbstractDefinitionVerifier#verifyClass(Class) verifyClass()}.
 * </p>
 * <p>
 * You can only annotate static fields with type {@link TypedDefRef}.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see AbstractDefinitionVerifier
 * @see RequiredDefinitionDependency
 * @see OptionalDefinitionDependency
 * @see LogDefinitionVerifier
 * @see ExceptionDefinitionVerifier
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@PublishedFilter(MsrPlatform.class)
public @interface OptionalDefinitionDependency {

}
