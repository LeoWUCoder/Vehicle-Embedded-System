package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIOptional;
import com.vector.cfg.gen.core.bswmdmodel.GIReferenceToContainer;
import com.vector.cfg.gen.core.bswmdmodel.param.GChoiceReference;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Optional BswmdModel object representation implementation for {@link GIReferenceToContainer} which have multiple targets.
 *
 * <p>
 * Attention: Please use {@link GIOptional} interface in client code.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public final class GRefOptional {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GRefOptional.class);

    /**
     * Creates a new {@link GIOptional} for the passed {@link GChoiceReference}.
     *
     * @param <R> the generic type
     * @param targetClass the target class
     * @param targetDefRef the target def ref
     * @param choiceRef the choice ref
     * @return the g optional
     */
    @PublishedMethod
    public static <R extends GIModelObject> GOptional<R> create(final Class<R> targetClass, final DefRef targetDefRef, final GChoiceReference choiceRef) {
        final IInternalGeneratorModelAccess genMa = choiceRef.getGenModelAccessInternal();
        try {
            genMa.switchView();

            if (!choiceRef.hasRefTarget()) {
                return new GOptional<>(false, null, new Runnable() {

                    @Override
                    public void run() {
                        try {
                            genMa.switchView();

                            choiceRef.getRefTargetMdf();

                        } finally {
                            genMa.restoreView();
                        }
                    }
                });
            }

            final MIContainer mdfTarget = choiceRef.getRefTargetMdf();
            if (!targetDefRef.isDefinitionOf(mdfTarget)) {
                return new GOptional<>(false, null, new Runnable() {

                    @Override
                    public void run() {
                        try {
                            genMa.switchView();

                            genMa.getExceptionCreator().issueExceptionBecauseReferencePointsToIncorrectTarget(choiceRef, targetClass, targetDefRef);

                        } finally {
                            genMa.restoreView();
                        }

                    }
                });
            }

            final R bswmdTarget = targetClass.cast(choiceRef.getRefTarget());
            return new GOptional<>(true, bswmdTarget, null);

        } finally {
            genMa.restoreView();
        }
    }

    private GRefOptional() {

    }
}
