package com.vector.cfg.model.query.modelcheckedaccess.exceptions;

import java.util.ArrayList;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IWrongQuantityExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Thrown when a a model request will result in a wrong Quantity.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaWrongQuantityException extends McaException {

    private static final long serialVersionUID = 128501355142900896L;

    private final IWrongQuantityExData exData;

    /**
     * Constructor for McaParameterWrongTypeException.
     *
     * @param wrongTypeExDataList
     */
    @PublishedMethod
    public McaWrongQuantityException(IWrongQuantityExData exData) {
        super(createListForElement(exData));
        this.exData = exData;
    }

    /**
     * @param exDataList2
     * @return
     */
    private static List<? extends IExData> createListForElement(IWrongQuantityExData exData) {
        final List<IWrongQuantityExData> list = new ArrayList<>();

        list.add(exData);
        return list;
    }

    /**
     * Gets a {@link IWrongQuantityExData} object with detailed information about the exception cause.
     *
     * @return The exception cause data object
     */
    @Override
    @PublishedMethod
    public IWrongQuantityExData getExceptionData() {
        return exData;
    }

}
