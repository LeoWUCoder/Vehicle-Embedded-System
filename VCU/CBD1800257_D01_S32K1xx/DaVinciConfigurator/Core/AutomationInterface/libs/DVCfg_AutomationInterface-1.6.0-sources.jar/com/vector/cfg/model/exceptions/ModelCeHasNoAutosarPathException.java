package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 * Thrown to indicate that a {@link MIHasDefinition} object like Container has no corresponding definition.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelCeHasNoAutosarPathException extends ModelInconsistencyException {

    private static final long serialVersionUID = -6250273989567268892L;

    private final MIReferrable mdfObject;

    /**
     * Constructor.
     *
     * @param mdfObject the MIObject which has no Definition
     * @param ex
     */
    @PublishedMethod
    public ModelCeHasNoAutosarPathException(MIReferrable mdfObject, Throwable ex) {
        super("The AUTOSAR path is missing for " + checkMdfObjNonNull(mdfObject).toString() + ".", ex);

        this.mdfObject = mdfObject;
    }

    @PublishedMethod
    public MIReferrable getCe() {
        return mdfObject;
    }
}
