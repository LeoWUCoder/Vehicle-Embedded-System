package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.concurrent.ThreadSafe;
import javax.inject.Inject;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 *
 * <p>
 * Caution: This class is no intended to be used by clients!
 * </p>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@ThreadSafe
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedFilter(MsrPlatform.class)
class GModelChangeListener {

    private final AtomicBoolean isCacheValid = new AtomicBoolean();

    private final IBswmdModelChangeSupervisionService supervisionService;

    @Inject
    GModelChangeListener(IBswmdModelChangeSupervisionService supervisionService) {
        this.supervisionService = supervisionService;

    }

    /**
     * Inits the {@link GModelChangeListener} and registers it internally.
     *
     */
    public void init() {
        supervisionService.addListener(this);
    }

    /**
     * Marks the cache as invalid.
     *
     * <p>
     * Attention: This method shall only be called by the {@link IBswmdModelChangeSupervisionService} service!
     * </p>
     *
     * <p>
     * Caution: This method is called from different threads, so the implementation must be threadsafe!
     * </p>
     *
     */
    void markCacheAsInvalid() {
        isCacheValid.set(false);
    }

    boolean isCacheValid() {
        return isCacheValid.get();
    }

    /**
     * Notify start cache update.
     */
    void notifyStartCacheUpdate() {
        do {
            supervisionService.setCacheStateToActive();
            isCacheValid.set(true);
            //Active the cache twice, because during the boolean update it is possible that anyone has updated the MDF model, now we know if anyone has already marked the caches as still invalid.
            supervisionService.setCacheStateToActive();

        } while (!isCacheValid.get());
    }

}
