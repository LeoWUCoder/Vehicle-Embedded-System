package com.vector.cfg.model.query.modeltraverser;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.concurrent.NotThreadSafe;
import javax.annotation.concurrent.ThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.query.internal.modeltraverser.ModelTraverserExecutionException;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.tuple.IModelTuple;
import com.vector.cfg.model.query.modelcheckedaccess.tuple.IModelTupleList;
import com.vector.cfg.model.query.modeltraverser.ModelTraverserFactory.ETraverserVersion;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Common_Part"> The ModelTraverser is a common concept to simplify the access to mainly the EcuC MDF
 * Model by specifying the definitions ({@link DefRef}s) of interest at the initialization, and traverse the model elements which match the definitions later for example during live validation.
 * <p>
 * <img src="{@docRoot}/../_doc/Images/ModelTraverser_Navigating_EcuC_Model.PNG"
 *   alt="Example for traversing the EcuC model"
 *   data-latex-style="scale=0.75" />
 * </p>
 * <p>
 * This will help to reduce the amount of model access code for Live Validations. Beside this the ModelTraverser could be used outside of the validation
 * context. The following sections will describe the initialization and the usage/execution of this concept.
 * </p>
 *
 * The goals of the {@link IModelTraverser} are:
 * <ul>
 * <li>The User shall have to ability to access the model without checking the basic consistency/validity of the model. E.g. Multiplicity correct? Parameter has
 * value? ...</li>
 * <li>The start of the traverse process must be possible with arbitrary model changes. Especially, the ModelTraverser will find all elements by even one single model change.</li>
 * <li>The ModelTraverser shall collect all traversed elements during the execution => DependentCes/GeneralCEs.</li>
 * <li>Reduction of the client side model code (less ModelAccess, ModelCheckedAccess, etc. usage).</li>
 * <li>Minimization of possible programming errors during development at the client side.</li>
 * </ul>
 *
 * <p>
 * The ModelTraverser splits the process into two phases:
 * <ul>
 * <li>Initialization => Executed at creation time of the {@link IModelTraverser}</li>
 * <li>Execution => Executed for each traverse operation</li>
 * </ul>
 * The client has to specify the definition of the elements ({@link DefRef DefRefs}) of interest. This is called the <b>definition tree</b>. The definition tree
 * has one root also called <b>MainElement</b> or ContextObject.
 * </p>
 * <p>
 * The MainElement is the smallest traversable entity. This means if you choose a {@link DefRef} of a ModuleConfiguration as MainElement you could only traverse
 * for each ModuleConfiguration => Getting only one error in the Validation use case. But if you choose for example a {@link DefRef} of a Channel as MainElement, you will get
 * a validation result for each affected channel container in the system instead of only a ModuleConfiguration.
 * </p>
 * <p>
 * <b>So the choice of the MainElement is very important</b> for the resulting traversal behavior. Try to answer the following question with your MainElement:
 * </p>
 * <p>
 * <i>How many ValidationResults does the User expect for the execution of the Validation Rule?</i>
 * </p>
 * <p>
 *
 * It must be possible to validate an instance of the MainElementType without the need of other instances of this type. E.g. if your rule checks the count
 * of channel containers, the channel container can not be the MainElementType, but probably its parent.
 *
 *
 * </p>
 * </div>
 * <p>
 * See the class {@link Path} for the specification of a definition tree.
 * </p>
 *
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Initialization" > To initialize an {@link IModelTraverser} instance, we assume that you
 * have already specified a definition tree with the {@link Path} class. The following code sample shows the creation of an {@link IModelTraverser}.
 *
 * <pre>
 * <code class="Java" id="Creating an instance of an IModelTraverser class">
 * // @formatter:off
 *   final IModelTraverserPath path=...;
 * // @formatter:on
 *
 * final IModelTraverser modelTraverser = ModelTraverserFactory.create(ETraverserVersion.VERSION_2, projectContext, path);
 * //If you reach this line the initialization was successful
 * </code>
 * </pre>
 *
 * An initialization could fail for the following reasons:
 * <ul>
 * <li>One of the {@link DefRef DefRefs} specified is not present in the current sip.</li>
 * <li>The {@link TypedDefRef TypedDefRef} type information is not satisfied by the current sip.</li>
 * <li>The passed definition tree is not valid.
 * <ul>
 * <li>No valid path from one element to another</li>
 * <li>The tree contains a cycle</li>
 * <li>There is no root element in the tree</li>
 * </ul>
 * </li>
 * </ul>
 * Every case above will lead to an exception during the create-call! So if the create-call returns it is possible to traverse through the loaded model by the
 * specified definition tree.
 *
 * </div>
 *
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Execution">You could start an execution by calling on of the <code>startTraverser()</code>
 * methods. You need at least one StartElement for the traversal.
 *
 * <pre>
 * <code class="Java" id="Traverse execution sample">
 * MIHasDefinition startElement = ...;
 *
 * ITraverseResult traverserResult = modelTraverser.startTraverse(startElement);
 * //Evaluate the result ...
 * </code>
 * </pre>
 *
 * </div>
 *
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Logging"> The {@link IModelTraverser} provides a huge amount of information of the
 * initialization and execution of the traverser as debug and trace messages. You should enable the debug/trace logging for your ModelTraverser to see the trees
 * and execution paths. The ModelTraverser normally logs to its own logger (<code>com.vector.cfg.model.query.internal.modeltraverser.ModelTraverser</code>) but
 * you can replace the used logger during the construction of the ModelTraver with your own. The traverser will log all messages to the passed logger.
 *
 * <pre>
 * <code class="Java" id="ModelTraverser creation with client side logging">
 * ModelTraverserFactory.create(ETraverserVersion.VERSION_2, projectContext, clientSideLogger,path);
 * </code>
 * </pre>
 *
 * <pre>
 * <code class="Java" id="Logging output sample of the ModelTraverser - Initialization">
 * 09:47:03,046[main  ] DEBUG ModelTraverser            - DefinitionTree after Initialization:
 * DefTree:
 * /MICRO.../NmChannelConfig                         REQUIRED
 *    => /MICRO.../NmChannelConfig/NmChannelId            REQUIRED
 *       => /MICRO.../NmChannelConfig/NmComMChannelRef        ZERO_TO_UNLIMITED
 *    => /MI.../NmGlobalConfig                            REQUIRED
 *       => /MI...NmGlobalConfig/NmComUserDataEnabled         REQUIRED
 *         => /MI...Config/NmCoordinatorSupportEnabled           OPTIONAL
 * </code>
 * </pre>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see ModelTraverserFactory
 * @see Path
 * @see IModelTraverserPath
 * @noimplement This interface is not intended to be implemented by clients.
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IModelTraverser {

    /**
     * Gets the {@link DefRef} of the MainElement/Context object.
     *
     * @return the MainElement {@link DefRef}
     */
    @PublishedMethod
    DefRef getMainElementDefRef();

    /**
     * Gets the all {@link DefRef} associated with the {@link IModelTraverser}, at construction time.
     *
     * @return the {@link Set} of {@link DefRef}s.
     * @see IModelTraverserPath
     */
    @PublishedMethod
    Set<DefRef> getAllDefRefs();

    /**
     * Starts the traverse operation at the passed startElement and returns an {@link ITraverseResult}.
     *
     * <p>
     * The startElement does not have to be an instance of valid {@link DefRef}s (see {@link #getAllDefRefs()}), the {@link IModelTraverser} will then return a
     * {@link ITraverseResult} with no valid views.
     * </p>
     *
     * @param startElement the start element
     * @return the created {@link ITraverseResult}.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the startElement is null</li>
     * </ul>
     */
    @PublishedMethod
    ITraverseResult startTraverse(MIHasDefinition startElement);

    /**
     * Starts the traverse operation by each passed startElement and returns an {@link ITraverseResult}.
     *
     * <p>
     * See {@link #startTraverse(MIHasDefinition)} for more details. This will will "call" {@link #startTraverse(MIHasDefinition)} for each element in the {@link Collection}.
     * </p>
     *
     * @param <T> the generic type of the StartElements collection
     * @param startElements a {@link Collection} of startElement of type {@link MIHasDefinition}.
     * @return the created {@link ITraverseResult}.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the startElements parameter is null</li>
     * </ul>
     */
    @PublishedMethod
    <T extends MIHasDefinition> ITraverseResult startTraverse(Collection<T> startElements);

    /**
     * Returns the settings passed to the {@link IModelTraverser} during construction. This could be used to query properties later in the traverse process.
     *
     * @return the creation configuration.
     * @see IModelTraverserSettings
     */
    @PublishedMethod
    IModelTraverserSettings getCreationSettings();

    /**
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="TraverseResult">{@link ITraverseResult} represents the result of one execution of an
     * <code>IModelTraverser.startTraverse()</code> operation.
     *
     * <p>
     * The {@link ITraverseResult} contains {@link IValidTraverserView}s and {@link IInvalidTraverserView}s.
     * <ul>
     * <li>ValidViews have passed the internal verification checks of the ModelTraverser</li>
     * <li>InvalidViews have not passed the verification checks, or some elements are missing to start the verification.</li>
     * </ul>
     *
     * </div>
     *
     * <p>
     * Attention: you should not cache any {@link ITraverseResult} object in fields or other things, because an {@link ITraverseResult} is <b>not</b> threadsafe!
     * </p>
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     * @since 1.0
     * @noimplement This interface is not intended to be implemented by clients.
     */
    @NotThreadSafe
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public interface ITraverseResult {

        /**
         * Gets a {@link List} of {@link IValidTraverserView} from the {@link IModelTraverser} execution.
         *
         * @return the valid traverser views
         */
        @PublishedMethod
        List<IValidTraverserView> getValidTraverserViews();

        /**
         * Gets a {@link List} of {@link IInvalidTraverserView} from the {@link IModelTraverser} execution.
         *
         * @return the invalid traverser views
         */
        @PublishedMethod
        List<IInvalidTraverserView> getInvalidTraverserViews();

        /**
         * Gets a {@link Collection} of all MainElement in all {@link IValidTraverserView} and {@link IInvalidTraverserView}s.
         *
         * @return the MainElements of all views
         */
        @PublishedMethod
        Collection<MIHasDefinition> getAffectedMainElements();

        /**
         * Returns the {@link IModelTraverser} which has created this {@link ITraverseResult}.
         *
         * @return the source traverser
         */
        @PublishedMethod
        IModelTraverser getSourceTraverser();
    }

    /**
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="TraverserView"> An {@link ITraverserView} represents an InstanceTree of one execution with a root of one
     * MainElement instance.
     *
     * <p>
     * To explain this, start with a model traverser defined as:
     * </p>
     * <p>
     * <!--LaTex:\includeCodeListing{ModelTraverserExample2/ModelTraverser_InstanceTree}-->
     * </p>
     * <p>
     *
     * <pre>
     * <code class="Java" id="Example model traverser definition tree">
     * DefTree:
     * /[ANY]/IpduM/IpduMConfig/IpduMRxPathway/IpduMRxIndication  REQUIRED  Root
     *  => /[ANY]/IpduM/IpduMConfig/IpduMRxPathway/IpduMRxIndication/IpduMRxIndicationPduRef                REQUIRED  Parent -> Child
     *    => /[ANY]/EcuC/EcucPduCollection/Pdu       REQUIRED  Reference -> RefTarget
     *      => /[ANY]/EcuC/EcucPduCollection/Pdu/PduLength  REQUIRED  Parent -> Child
     * </code>
     * </pre>
     * </p>
     * <p>
     * In the following figure<!--LaTex: \vref{fig:ExampleForMainElementInstance}-->, the marked container is one MainElement instance: the container definition is the rootElement
     * {@link DefRef} in the example definition tree.
     * </p>
     * <p>
     * <img src="{@docRoot}/../_doc/Images/ModelTraverser_Navigating_EcuC_Model2.PNG" alt="Example for MainElement instance" id="fig:ExampleForMainElementInstance" data-latex-style
     * ="scale=0.75"/>
     * </p>
     *
     * The method {@link ITraverserView#getMainElement()} will return this instance. <!--LaTex:See \vref{sec:BswmdDefandInstancetreesample} for a detailed example of definition and
     * instance tree.-->
     * <p>
     * {@link ITraverserView#getWalkedElements()} returns a {@link Collection} of GeneralCEs which were traversed during execution. These can be used in a validator to set the
     * dependent CEs of a validation result.
     * </p>
     *
     * <p>
     * <b>Attention:</b> You should not cache any {@link ITraverserView} object in fields or other things, because an {@link ITraverserView} is <b>not</b> threadsafe!
     * </p>
     *
     * The figure <!--LaTeX:\vref{fig:TraverserClassHierarchy}--> shows the hierarchy of the different {@link ITraverserView}s.
     *
     * <img src="{@docRoot} /../_doc/UML/IModelTraverser/TraverserClassHierarchy.png" alt= "TraverserViews class hierarchy" id="fig:TraverserClassHierarchy" data-latex-style= "
     * scale=0.70" />
     *
     * <pre>
     * <!--PlantUML: TraverserClassHierarchy
     * {@link ITraverserView} "<creates>" <..  {@link IModelTraverser}
     * {@link ITraverserView} <|-_ {@link IValidTraverserView}
     * {@link ITraverserView} <|-_ {@link IInvalidTraverserView}
     * {@link IValidTraverserView} <|-_ {@link IValidSubTraverserView}
     * {@link IInvalidTraverserView} <|-_ {@link IInvalidSubTraverserView}
     *
     * -->
     * </pre>
     *
     * </div>
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     * @since 1.0
     * @noimplement This interface is not intended to be implemented by clients.
     */
    @NotThreadSafe
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public interface ITraverserView extends IHasGeneralCEs {

        /**
         * Gets the main element. Returns the root the this {@link ITraverserView} instance.
         *
         * @return the main element
         */
        @PublishedMethod
        MIHasDefinition getMainElement();

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        Collection<IDescriptor> getGeneralCEs();

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        Set<MIHasDefinition> getWalkedElements();

        /**
         * Gets the predecessor result.
         *
         * @param predecessor the predecessor
         * @return the predecessor result
         */
        @PublishedMethod
        ITraverseResult getPredecessorResult(IModelTraverser predecessor);

        /**
         * Gets the predecessor result map.
         *
         * @return the predecessor result map
         */
        @PublishedMethod
        Map<IModelTraverser, ITraverseResult> getPredecessorResultMap();

        /**
         * Returns the subtree of the internal instance tree of the {@link ITraverserView}, which the root as the passed requested root.
         *
         * @param requestedRoot the root of the instance subtree.
         * @return The same model element as {@link IInstanceNode}
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the requestedRoot parameter is null</li>
         * </ul>
         * @exception IllegalArgumentException
         * <ul>
         * <li>if the requestedRoot is not in the instance tree.</li>
         * </ul>
         *
         */
        @PublishedMethod
        IInstanceNode selectInstanceTree(MIHasDefinition requestedRoot);

        /**
         * Selects <b>many</b> elements in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only select a subtree under the
         * predecessor instead of the whole instance tree.
         *
         * <p>
         * The this select method is usable for any type of Multiplicity. E.g. Optional, Required, ZeroToUnlimited ... If the passed {@link DefRef} violates the Many Multiplicity
         * constraint of the definition tree <b>no</b> {@link ModelTraverserExecutionException} is thrown.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return A {@link List} of model elements which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> List<CONFIG_TYPE> selectManyUnsafe(MIHasDefinition predecessor,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>many</b> elements in the instance tree by the passed {@link DefRef}, but <b>does not</b> check the Multiplicity constraint
         *
         * <p>
         * The this select method is usable for any type of Multiplicity. E.g. Optional, Required, ZeroToUnlimited ... If the passed {@link DefRef} violates the any Multiplicity
         * constraint of the definition tree <b>no</b> {@link ModelTraverserExecutionException} is thrown.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param defRef the definition of the requested Element
         * @return A {@link List} of model elements which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> List<CONFIG_TYPE> selectManyUnsafe(
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>many</b> elements as an {@link IModelTupleList} in the instance tree by the passed {@link DefRef}.
         *
         * <p>
         * This method can be used to retrieve the value of an {@link MIParameterValue}!
         * </p>
         *
         * <p>
         * The this select method is usable for any type of Multiplicity. E.g. Optional, Required, ZeroToUnlimited ... If the passed {@link DefRef} violates the any Multiplicity
         * constraint of the definition tree <b>no</b> {@link ModelTraverserExecutionException} is thrown.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * <p>
         * <b>Caution:</b> The returned {@link IModelTupleList} could contain {@link IModelTuple}s where the value is <code>null</code>. This happends, when the parameter value is
         * invalid!
         * </p>
         *
         * @param defRef the definition of the requested Element
         * @return A {@link List} of the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIConfigParameter, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IModelTupleList<VALUE_TYPE, CONFIG_TYPE> selectManyTupleUnsafe(
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>many</b> elements as an {@link IModelTupleList} in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only
         * select a subtree under the predecessor instead of the whole instance tree.
         *
         * <p>
         * This method can be used to retrieve the value of an {@link MIParameterValue}!
         * </p>
         *
         * <p>
         * The this select method is usable for any type of Multiplicity. E.g. Optional, Required, ZeroToUnlimited ... If the passed {@link DefRef} violates the any Multiplicity
         * constraint of the definition tree <b>no</b> {@link ModelTraverserExecutionException} is thrown.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * <p>
         * <b>Caution:</b> The returned {@link IModelTupleList} could contain {@link IModelTuple}s where the value is <code>null</code>. This happends, when the parameter value is
         * invalid!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return A {@link List} of the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIConfigParameter, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IModelTupleList<VALUE_TYPE, CONFIG_TYPE> selectManyTupleUnsafe(
                MIHasDefinition predecessor, TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);
    }

    /**
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="InvalidView"> An {@link IInvalidTraverserView} has not passed the verification process of the
     * {@link IModelTraverser}. One of the following reasons are possible:
     * <ul>
     * <li>A multiplicity constraint was violated. E.g. a mandatory element is missing.</li>
     * <li>A parameter has no values.</li>
     * <li>A parameter has an invalid value.</li>
     * <li>A user defined verification has failed.</li>
     * </ul>
     * So you can't access elements via the select methods of an {@link IValidTraverserView}, but you can use the walked elements to process the invalid view.
     *
     * <p>
     * An invalid view can be used for example to validate, that a part of the Model is inconsistent and to issue an error/ValidationResult for the user.
     * </p>
     *
     * </div>
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     * @since 1.0
     * @noimplement This interface is not intended to be implemented by clients.
     */
    @NotThreadSafe
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public interface IInvalidTraverserView extends ITraverserView {

        /**
         * Selects the nearest parent of the specified child in the instance tree by the passed parent {@link DefRef}.
         *
         * <p>
         * Attention, If the passed predecessor may be occur multiple times in the instance tree, you may not use this method, but you must use select*AsSubView() to focus on the
         * predecessor. Otherwise an {@link IllegalArgumentException} will be thrown at validator runtime.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param child The child element of the requested parent.
         * @param parentDefRef the definition of the requested Element
         * @return A model elements which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> CONFIG_TYPE selectPredecessor(MIHasDefinition child,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> parentDefRef);

        /**
         * Selects <b>many</b> elements in the instance tree by the passed {@link DefRef}.
         * <p/>
         * If the passed {@link DefRef} occurs multiple times in the definition tree, this method will use the first occurrence with the shortest possible path, even if the
         * requested element is not available via that path.<br/>
         * If you want to select another occurrence of the {@link DefRef} in the definition tree, please use selectxxxAsSubView()!
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param defRef the definition of the requested Element
         * @return A {@link List} of model elements which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> List<CONFIG_TYPE> selectMany(
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>many</b> elements in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only select a subtree under the
         * predecessor instead of the whole instance tree.
         * <p/>
         *
         *
         * <p>
         * Attention, If the passed predecessor may be occur multiple times in the instance tree, you may not use this method, but you must use select*AsSubView() to focus on the
         * predecessor. Otherwise an {@link IllegalArgumentException} will be thrown at validator runtime.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return A {@link List} of model elements which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> List<CONFIG_TYPE> selectMany(MIHasDefinition predecessor,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>many</b> elements in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only select a subtree under the
         * predecessor instead of the whole instance tree.
         *
         * <p>
         * Returns a {@link IValidSubTraverserView}, for the passed element. This is used to disambiguate {@link DefRef}, multiply used in the Definition tree.
         * <p>
         *
         * <p>
         * See EVAL00119913: ModelTraverser: Bug when the same MIHasDefinition Object is traversed twice with other DefNodes, in DefSubTrees
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return A {@link List} of {@link IValidSubTraverserView} for the selected elements.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> List<IInvalidSubTraverserView> selectManyAsSubView(MIHasDefinition predecessor,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Returns the reasons, why this {@link IInvalidTraverserView} is invalid. This could be used to display a detailed message to the user.
         *
         * <p>
         * The ModelTraverser has to be configured to support IInvalidViewReasons. You have to enable the feature with the method
         * {@link IModelTraverserBuilder#enableInvalidViewReasonsSupport()} during the construction of the IModelTraverser. Otherwise the method will thrown an exception.
         * </p>
         *
         * @return the invalid view reasons.
         * @exception IllegalStateException
         * <ul>
         * <li>if the {@link IModelTraverser} was not create with InvalidViewsProvideInvalidViewReasons enabled.</li>
         * </ul>
         */
        @PublishedMethod
        IInvalidViewReasons getInvalidViewReasons();

    }

    /**
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="ValidView"> An {@link IValidTraverserView} has passed all verification checks during the execution and
     * provides methods to access the traversed elements.
     *
     * All access methods begin with the prefix "select" and end with the use case you want.
     * <ul>
     * <li>A call to <code>select(DEFREF)</code> will return the element in the instance tree for the {@link DefRef}.</li>
     * <li>A call to <code>selectMany(DEFREF)</code> will return a {@link List} of elements in the instance tree for the {@link DefRef}.</li>
     * <li>A call to <code>selectOpt(DEFREF)</code> will return an optional of the element in the instance tree for the {@link DefRef}.</li>
     * <li>All above mentioned methods are available as <code>selectTuple(DEFREF)</code> calls: Additionally to the element in the instance tree a tuple provides the value of the
     * element.</li>
     * </ul>
     * Single, Many or Opt has to be chosen correctly according to the relation of the DefRef to the main element, otherwise an exception will be thrown.
     *
     * <p>
     * <b>ErrorHandling:</b> If the chosen select method (<code>select</code>, <code>selectOpt</code>, <code>selectMany</code>) does not match the Multiplicity in the definition
     * tree the call to the method will always throw an {@link ModelTraverserExecutionException}! This will prevent development errors issued by the wrong multiplicity.
     * </p>
     *
     * <p>
     * <b>Subtree selection:</b> For each <code>select</code> method with a {@link DefRef} there is a corresponding <code>select</code> method with
     * <code>select(predecessor, defRef)</code>. These methods can be used to select subtrees of the instance tree by specifying the root of the subtree. So a call to
     * <code>select(DefRef)</code> is the same as a call to <code>select(getMainElement(), DefRef)</code>.<br/>
     * <b>Attention!</b> If the passed predecessor may occur multiple times in the instance tree, you may not use this method, but you have to work with subviews, otherwise an
     * exception will be thrown. This is especially the case if there are duplicated {@link DefRef}s in the definition tree. Working with subviews is the newer and safer approach
     * and should be preferred compared to working with a predecessor. See <code>select...AsSubView()</code>,{@link IValidSubTraverserView}<!--LaTeX:, and see chapter
     * \vref{sec:ModelTraverserSubViews}-->.
     * </p>
     *
     * <p>
     * You should not use any {@link IModelAccess} or {@link IModelCheckedAccess} method, if you have a valid model, because all elements returned by the model accesses are not
     * included in the GeneralCE list and so on. To get a value of a Parameter for example you should use one of the <code>selectTuple</code> methods.
     * </p>
     *
     * <pre>
     * <code class="Java" id="Usage of an IValidTraverserView">
     *  // We have already a View
     *  IValidTraverserView validModel = ...;
     *
     *  // Get exact one element
     *  MIContainer comMUserPerChl = validModel.select(COMM_USER_PER_CHANNEL_DEFREF);
     *
     *  // Get many elements
     *  List<MIContainer> nmChls = validModel.selectMany(NM_CHANNEL_CONFIG_DEFREF);
     *
     *  // Get optional element
     *  Optional<MINumericalValue> isGlobal = validModel.selectOpt(COMM_COMMCONFIGSET_COMMCHANNEL_COMM_GLOBAL_NVM_BLOCK_DESCRIPTOR_DEFREF);
     *
     *  //Get many parameters as a list of tuples, with the predecessor comMUserPerChl
     *  IModelTupleList<MIParameterValue, MIReferenceValue> tupleList
     *           = model.selectManyTuple(comMUserPerChl, NM_COM_MCHANNEL_REF_DEFREF);
     * </code>
     * </pre>
     *
     *
     * </div>
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     * @since 1.0
     * @noimplement This interface is not intended to be implemented by clients.
     */
    @NotThreadSafe
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public interface IValidTraverserView extends ITraverserView {

        /**
         * Selects the nearest parent of the specified child in the instance tree by the passed parent {@link DefRef}.
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * <p>
         * Attention, If the passed predecessor may be occur multiple times in the instance tree, you may not use this method, but you must use select*AsSubView() to focus on the
         * predecessor. Otherwise an {@link IllegalArgumentException} will be thrown at validator runtime.
         * </p>
         *
         * @param child The child element of the requested parent.
         * @param parentDefRef the definition of the requested Element
         * @return A model elements which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the parentDefRef parameter is null</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> CONFIG_TYPE selectPredecessor(MIHasDefinition child,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> parentDefRef);

        /**
         * Selects <b>one</b> element in the instance tree by the passed {@link DefRef}.
         * <p/>
         * If the passed {@link DefRef} occurs multiple times in the definition tree, this method will use the first occurrence with the shortest possible path, even if the
         * requested element is not available via that path.<br/>
         * If you want to select another occurrence of the {@link DefRef} in the definition tree, please use selectxxxAsSubView()!
         *
         *
         *
         * <p>
         * If the passed {@link DefRef} violates the Required Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param defRef the definition of the requested Element
         * @return the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Required Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> CONFIG_TYPE select(TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>many</b> elements in the instance tree by the passed {@link DefRef}.
         * <p/>
         * If the passed {@link DefRef} occurs multiple times in the definition tree, this method will use the first occurrence with the shortest possible path, even if the
         * requested element is not available via that path.<br/>
         * If you want to select another occurrence of the {@link DefRef} in the definition tree, please use selectxxxAsSubView()!
         *
         * <p>
         * If the passed {@link DefRef} violates the Many Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param defRef the definition of the requested Element
         * @return A {@link List} of model elements which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Many Multiplicity is violated!</li>
         * </ul>
         *
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> List<CONFIG_TYPE> selectMany(
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>one optional</b> element in the instance tree by the passed {@link DefRef}.
         * <p/>
         * If the passed {@link DefRef} occurs multiple times in the definition tree, this method will use the first occurrence with the shortest possible path, even if the
         * requested element is not available via that path.<br/>
         * If you want to select another occurrence of the {@link DefRef} in the definition tree, please use selectxxxAsSubView()!
         *
         * <p>
         * If the passed {@link DefRef} violates the Optional Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param defRef the definition of the requested Element
         * @return An optional of the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Optional Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> Optional<CONFIG_TYPE> selectOpt(
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>one</b> element as an {@link IModelTuple} in the instance tree by the passed {@link DefRef}.
         * <p/>
         * If the passed {@link DefRef} occurs multiple times in the definition tree, this method will use the first occurrence with the shortest possible path, even if the
         * requested element is not available via that path.<br/>
         * If you want to select another occurrence of the {@link DefRef} in the definition tree, please use selectxxxAsSubView()!
         *
         * <p>
         * This method can be used to retrieve the value of an {@link MIParameterValue}!
         * </p>
         *
         * <p>
         * If the passed {@link DefRef} violates the Required Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param defRef the definition of the requested Element
         * @return An optional of the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Required Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIConfigParameter, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IModelTuple<VALUE_TYPE, CONFIG_TYPE> selectTuple(
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>many</b> elements as an {@link IModelTupleList} in the instance tree by the passed {@link DefRef}.
         * <p/>
         * If the passed {@link DefRef} occurs multiple times in the definition tree, this method will use the first occurrence with the shortest possible path, even if the
         * requested element is not available via that path.<br/>
         * If you want to select another occurrence of the {@link DefRef} in the definition tree, please use selectxxxAsSubView()!
         *
         * <p>
         * This method can be used to retrieve the value of an {@link MIParameterValue}!
         * </p>
         *
         * <p>
         * If the passed {@link DefRef} violates the Many Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param defRef the definition of the requested Element
         * @return A {@link List} of the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Many Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIConfigParameter, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IModelTupleList<VALUE_TYPE, CONFIG_TYPE> selectManyTuple(
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>one optional</b> element as an {@link IModelTuple} in the instance tree by the passed {@link DefRef}.
         * <p/>
         * If the passed {@link DefRef} occurs multiple times in the definition tree, this method will use the first occurrence with the shortest possible path, even if the
         * requested element is not available via that path.<br/>
         * If you want to select another occurrence of the {@link DefRef} in the definition tree, please use selectxxxAsSubView()!
         *
         * <p>
         * This method can be used to retrieve the value of an {@link MIParameterValue}!
         * </p>
         *
         * <p>
         * If the passed {@link DefRef} violates the Optional Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param defRef the definition of the requested Element
         * @return An optional of the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Optional Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIConfigParameter, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> Optional<IModelTuple<VALUE_TYPE, CONFIG_TYPE>> selectOptTuple(
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /*
         * Predecessor select section
         */
        /**
         * Selects <b>one</b> element in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only select a subtree under the
         * predecessor instead of the whole instance tree. The Multiplicity constraint is calculated from the predecessor!
         *
         *
         * <p>
         * If the passed {@link DefRef} violates the Required Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * Attention, If the passed predecessor may be occur multiple times in the instance tree, you may not use this method, but you must use select*AsSubView() to focus on the
         * predecessor. Otherwise an {@link IllegalArgumentException} will be thrown at validator runtime.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Required Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> CONFIG_TYPE select(MIHasDefinition predecessor,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>many</b> elements in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only select a subtree under the
         * predecessor instead of the whole instance tree. The Multiplicity constraint is calculated from the predecessor!
         *
         * <p>
         * If the passed {@link DefRef} violates the Many Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * Attention, If the passed predecessor may be occur multiple times in the instance tree, you may not use this method, but you must use select*AsSubView() to focus on the
         * predecessor. Otherwise an {@link IllegalArgumentException} will be thrown at validator runtime.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return A {@link List} of model elements which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Many Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> List<CONFIG_TYPE> selectMany(MIHasDefinition predecessor,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>one optional</b> element in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only select a subtree under
         * the predecessor instead of the whole instance tree. The Multiplicity constraint is calculated from the predecessor!
         *
         * <p>
         * If the passed {@link DefRef} violates the Optional Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * Attention, If the passed predecessor may be occur multiple times in the instance tree, you may not use this method, but you must use select*AsSubView() to focus on the
         * predecessor. Otherwise an {@link IllegalArgumentException} will be thrown at validator runtime.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return An optional of the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the predecessor parameter is null</li>
         * <li>if the defRef parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Optional Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> Optional<CONFIG_TYPE> selectOpt(MIHasDefinition predecessor,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>one</b> element as an {@link IModelTuple} in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only select a
         * subtree under the predecessor instead of the whole instance tree. The Multiplicity constraint is calculated from the predecessor!
         *
         * <p>
         * This method can be used to retrieve the value of an {@link MIParameterValue}!
         * </p>
         *
         * <p>
         * If the passed {@link DefRef} violates the Required Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * Attention, If the passed predecessor may be occur multiple times in the instance tree, you may not use this method, but you must use select*AsSubView() to focus on the
         * predecessor. Otherwise an {@link IllegalArgumentException} will be thrown at validator runtime.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return An optional of the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Required Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIConfigParameter, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IModelTuple<VALUE_TYPE, CONFIG_TYPE> selectTuple(MIHasDefinition predecessor,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>many</b> elements as an {@link IModelTupleList} in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only
         * select a subtree under the predecessor instead of the whole instance tree. The Multiplicity constraint is calculated from the predecessor!
         *
         * <p>
         * This method can be used to retrieve the value of an {@link MIParameterValue}!
         * </p>
         *
         * <p>
         * If the passed {@link DefRef} violates the Many Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * Attention, If the passed predecessor may be occur multiple times in the instance tree, you may not use this method, but you must use select*AsSubView() to focus on the
         * predecessor. Otherwise an {@link IllegalArgumentException} will be thrown at validator runtime.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return A {@link List} of the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Many Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIConfigParameter, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IModelTupleList<VALUE_TYPE, CONFIG_TYPE> selectManyTuple(
                MIHasDefinition predecessor, TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>one optional</b> element as an {@link IModelTuple} in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only
         * select a subtree under the predecessor instead of the whole instance tree. The Multiplicity constraint is calculated from the predecessor!
         *
         * <p>
         * This method can be used to retrieve the value of an {@link MIParameterValue}!
         * </p>
         *
         * <p>
         * If the passed {@link DefRef} violates the Optional Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * Attention, If the passed predecessor may be occur multiple times in the instance tree, you may not use this method, but you must use select*AsSubView() to focus on the
         * predecessor. Otherwise an {@link IllegalArgumentException} will be thrown at validator runtime.
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return An optional of the model element which has the definition {@link DefRef}.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Optional Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIConfigParameter, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> Optional<IModelTuple<VALUE_TYPE, CONFIG_TYPE>> selectOptTuple(
                MIHasDefinition predecessor, TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /*
         * Subview selection
         */
        /**
         * Selects <b>one</b> element in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only select a subtree under the
         * predecessor instead of the whole instance tree. The Multiplicity constraint is calculated from the predecessor!
         * <p/>
         * If the passed {@link DefRef} occurs multiple times in the definition tree, this method will use the first occurrence with the shortest possible path, even if the
         * requested element is not available via that path.<br/>
         * If you want to select another occurrence of the {@link DefRef} in the definition tree you have to use a predecessor from which the requested {@link DefRef} is the first
         * occurrence with the shortest possible path.
         *
         *
         * <p>
         * If the passed {@link DefRef} violates the Required Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * Returns a {@link IValidSubTraverserView}, for the passed element. This is used to disambiguate {@link DefRef}, multiply used in the Definition tree.
         * <p>
         *
         * <p>
         * See EVAL00119913: ModelTraverser: Bug when the same MIHasDefinition Object is traversed twice with other DefNodes, in DefSubTrees
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return the {@link IValidSubTraverserView} for the selected element.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Required Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> IValidSubTraverserView selectAsSubView(MIHasDefinition predecessor,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>many</b> elements in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only select a subtree under the
         * predecessor instead of the whole instance tree. The Multiplicity constraint is calculated from the predecessor!
         * <p/>
         * If the passed {@link DefRef} occurs multiple times in the definition tree, this method will use the first occurrence with the shortest possible path, even if the
         * requested element is not available via that path.<br/>
         * If you want to select another occurrence of the {@link DefRef} in the definition tree you have to use a predecessor from which the requested {@link DefRef} is the first
         * occurrence with the shortest possible path.
         *
         * <p>
         * If the passed {@link DefRef} violates the Many Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * Returns a {@link IValidSubTraverserView}, for the passed element. This is used to disambiguate {@link DefRef}, multiply used in the Definition tree.
         * <p>
         *
         * <p>
         * See EVAL00119913: ModelTraverser: Bug when the same MIHasDefinition Object is traversed twice with other DefNodes, in DefSubTrees
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return A {@link List} of {@link IValidSubTraverserView} for the selected elements.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the defRef parameter is null</li>
         * <li>if the predecessor parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Many Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> List<IValidSubTraverserView> selectManyAsSubView(MIHasDefinition predecessor,
                TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

        /**
         * Selects <b>one optional</b> element in the instance tree by the passed {@link DefRef} and the specified predecessor. This select call will only select a subtree under
         * the predecessor instead of the whole instance tree. The Multiplicity constraint is calculated from the predecessor!
         * <p/>
         * If the passed {@link DefRef} occurs multiple times in the definition tree, this method will use the first occurrence with the shortest possible path, even if the
         * requested element is not available via that path.<br/>
         * If you want to select another occurrence of the {@link DefRef} in the definition tree you have to use a predecessor from which the requested {@link DefRef} is the first
         * occurrence with the shortest possible path.
         *
         * <p>
         * If the passed {@link DefRef} violates the Optional Multiplicity constraint of the definition tree an {@link IllegalArgumentException} is thrown for every call!
         * </p>
         *
         * <p>
         * Returns a {@link IValidSubTraverserView}, for the passed element. This is used to disambiguate {@link DefRef}, multiply used in the Definition tree.
         * <p>
         *
         * <p>
         * See EVAL00119913: ModelTraverser: Bug when the same MIHasDefinition Object is traversed twice with other DefNodes, in DefSubTrees
         * </p>
         *
         * <p>
         * This method will never return <code>null</code>!
         * </p>
         *
         * @param predecessor the root of the subtree which is used for the selection
         * @param defRef the definition of the requested Element
         * @return An optional of the {@link IValidSubTraverserView} for the selected element.
         *
         * @exception NullPointerException
         * <ul>
         * <li>if the predecessor parameter is null</li>
         * <li>if the defRef parameter is null</li>
         * </ul>
         * @exception ModelTraverserExecutionException
         * <ul>
         * <li>if the Optional Multiplicity is violated!</li>
         * </ul>
         */
        @PublishedMethod
        <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> Optional<IValidSubTraverserView> selectOptAsSubView(
                MIHasDefinition predecessor, TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    }

    /**
     * The Interface {@link IValidSubTraverserView} is used to navigate instance sub tree, when one {@link DefRef} is used multiple times in the Definition tree.
     *
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="ModelTraverserSubViews"> <!--LaTeX:\label{sec:ModelTraverserSubViews}--> If a definition tree contains
     * duplicated {@link DefRef}s, the client side navigation with {@link ITraverserView}s may result in unexpected results. Precisely, the usage of the
     * <code>IValidTraverserView.select...(DefRef)</code> and <code>IValidTraverserView.select...(predecessor, DefRef)</code> statements can result in unexpected results or
     * exceptions in case the used {@link DefRef} or the {@link DefRef} of the predecessor is not unique in the definition tree.
     *
     * In case the used {@link DefRef} is not unique in the definition tree, the <code>IValidTraverserView.select... (DefRef)</code> method will use the {@link DefRef} with the
     * shortest distance to the root of the definition tree. In case there are multiple {@link DefRef}s with this distance it will use the first found when traversing forward
     * according to the definition tree.
     *
     * In case the {@link DefRef} of the predecessor is not unique in the definition tree, the <code>IValidTraverserView.select...(predecessor, DefRef)</code> method will throw an
     * {@link IllegalArgumentException} in {@link ETraverserVersion#VERSION_2} and above and will write an logger error entry in lower versions.
     *
     *
     * <p/>
     * To get unambiguous results, the <code>select...()</code> operations have to be applied to subviews of the definition tree. The scope of a subview can be defined by
     * <code>select...AsSubView()</code> methods and shall be defined in a way that allows unambiguous access to the instances that have duplicated {@link DefRef}s in the
     * definition tree. A subview is represented by a {@link IValidSubTraverserView} or {@link IInvalidSubTraverserView}.
     *
     *
     * <p/>
     * The definition tree used in the following examples contains {@link DefRef} duplicates and overrides the multiplicity of the PduRef-paths to
     * <code>EPathMultiplicityType.OptionalMul</code>.
     *
     * <p/>
     * <!--LaTeX:\includeCodeListing{ModelTraverserMultiDefRefSameCfgInstanceTest/createPathExtended}-->
     *
     * <b>Selection at a predecessor with duplicated DefRef:</b>
     * <p/>
     * In the following example we illustrate that the <code>IValidTraverserView.select...(predecessor, DefRef)</code> statement leads to an exception in case the predecessor
     * {@link DefRef} is duplicated in the definition tree.
     * <p/>
     * First get an instance for a duplicated {@link DefRef}, in this example: <code>PDUR_SRC_PDU_REF_DEFREF</code>. We use a <code>select...(PDUR_SRC_PDU_REF_DEFREF)</code>
     * statement. As already asserted at the beginning of this chapter, the {@link DefRef} nearest to the root it used by the <code>IValidTraverserView.select...(DefRef)</code>
     * method. I.e the <code>DUPLICATE_SPR_TWO</code> is returned. <!--LaTeX:\includeCodeListing{ModelTraverserMultiDefRefSameCfgInstanceTest/getAPredecessorInstance}-->
     *
     * <p/>
     * Use this instance as predecessor and try to get the <code>pdurRoutingPath</code> instance with a <code>select...(predecessor, DefRef)</code>.
     * <!--LaTeX:\includeCodeListing{ModelTraverserMultiDefRefSameCfgInstanceTest/amgiuousPredecessor}-->
     *
     * <b>LessonsLearned:</b> You can not use a predecessor in case its definition has duplicates in the definition tree.
     *
     *
     *
     * <p/>
     * <b>Selection inside a subview:</b>
     *
     * <p/>
     * In the next example we use a subview to get the <code>pdurRoutingPath</code> instance that is reachable via the <code>pdurSrcPduRef</code>.
     * <p/>
     * First want we get a subview in which <code>DUPLICATE_SPR_TWO</code> is the root. Again: using the duplicated <code>PDUR_SRC_PDU_REF_DEFREF</code> in the
     * <code>IValidTraverserView.select...AsSubView(root, DefRef)</code> statement results in a subview at <code>DUPLICATE_SPR_TWO</code> because this is nearest to the root of the
     * definition tree.
     * <p/>
     * <!--LaTeX:\includeCodeListing{ModelTraverserMultiDefRefSameCfgInstanceTest/useSubViewAtDuplicateTwo}-->
     *
     * <p/>
     * Now we can get the <code>pdurRoutingPath</code> instance unambiguously from the subView:
     * <!--LaTeX:\includeCodeListing{ModelTraverserMultiDefRefSameCfgInstanceTest/getRoutingPathInSubView}-->
     *
     *
     * <b>LessonsLearned:</b> This is the recommended way to get the <code>pdurRoutingPath</code> instance that is reachable via the <code>pdurSrcPduRef</code>! To get the
     * <code>pdurRoutingPath</code> instance that is reachable via the <code>pdurDestPduRef</code> we should use a subview that contains <code>DUPLICATE_RP_ONE</code>.
     *
     * <p/>
     * <b>Subview containing the other duplicate:</b>
     * <p/>
     * In the following example we analyse a subview which has <code>PDUR_DEST_PDU_REF_DEFREF</code> as root:
     * <!--LaTeX:\includeCodeListing{ModelTraverserMultiDefRefSameCfgInstanceTest/useSubViewAtDestPduRef}-->
     *
     * <p/>
     * We can get the <code>pdurRoutingPath</code> instance unambiguously from the subview:
     * <!--LaTeX:\includeCodeListing{ModelTraverserMultiDefRefSameCfgInstanceTest/getRoutingPathInAlternativeSubView}-->
     *
     * <p/>
     * The subview contains <code>DUPLICATE_SPR_ONE</code>, one of the duplicates of <code>PDUR_SRC_PDU_REF_DEFREF</code>:
     * <!--LaTeX:\includeCodeListing{ModelTraverserMultiDefRefSameCfgInstanceTest/getDupOne}-->
     *
     * <p/>
     * One could ask, if the <code>DUPLICATE_SPR_ONE</code> could be used as predecessor, to get the <code>pdurRoutingPath</code>. The answer is NO. The {@link IModelTraverser}
     * traverses only forwards and therefore will not reach the <code>pdurRoutingPath</code>, when starting at the <code>DUPLICATE_SPR_ONE</code>:
     * <!--LaTeX:\includeCodeListing{ModelTraverserMultiDefRefSameCfgInstanceTest/useSrcPduRefInAlternativeSubview}-->
     *
     * </div>
     *
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="ModelTraverserSubViewsUseCaseChoices"> <!--LaTeX:\label{sec:UseCaseChoices}-->
     * <p/>
     * <b>Choices</b>
     * <p/>
     * The next example deals with a choice reference. The relationship of the instances can be illustrated in the form of a diamond which means that there is one element at the
     * beginning, one at the end and that there are several optional paths between both.
     * <p/>
     * <img src="{@docRoot} /../_doc/UML/ValidSubViewUsage/DiamondExample.png" alt="Choice Reference example illustration" id= "fig:DiamondExample" data-latex-style="scale=0.7"
     * <p/>
     * At each point of time only one of the choices is set so there is always only one existing path from the <code>ChoiceRef</code> instance to
     * <code>LeafRef_TargetContainer</code> instance. Therefore one may think that <code>selectxxx()</code> statements should work to get the <code>LeafRef_TargetContainer</code>
     * instance for every possible choice. But the {@link IModelTraverser} evaluates the definition tree and not the values of the choice options. And in case the definition tree
     * contains duplicated {@link DefRef}s the problems described in chapter <!--LaTeX: \vref{sec:ModelTraverserSubViews}--> may occur. Therefore subviews have to be defined for
     * the particular options.
     *
     * Since the different paths in the diamonds are optional the multiplicity of each path start element has to be overriden with <code>EPathMultiplicityType.OptionalMul</code>.
     *
     * <!--LaTeX:\includeCodeListing{ChoiceRefTestDiamond/PathDiamondB}-->
     *
     *
     * <!--LaTeX:\includeCodeListing{ChoiceRefTestDiamond/ModelTraverserValidSubViewUsageInChoiceRef}-->
     *
     * </div>
     *
     *
     * See {@link IValidTraverserView}.
     */
    @NotThreadSafe
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public interface IValidSubTraverserView extends IValidTraverserView {

    }

    /**
     * The Interface {@link IInvalidSubTraverserView} is used to navigate instance sub tree, when one {@link DefRef} is used multiple times in the Definition tree.
     *
     * See {@link IValidTraverserView}.
     */
    @NotThreadSafe
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public interface IInvalidSubTraverserView extends IInvalidTraverserView {

    }

    /**
     * The Interface IInstanceNode represent one element in the Instance tree of the {@link ITraverserView}.
     *
     * See {@link ITraverserView#selectInstanceTree(MIHasDefinition)}.
     */
    @NotThreadSafe
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public interface IInstanceNode {

        /**
         * Gets the parent of this {@link IInstanceNode}, or <code>null</code> if it is the root element.
         *
         * @return the parent of this.
         */
        @PublishedMethod
        IInstanceNode getParent();

        /**
         * Returns the ModelElement of this instance tree node.
         *
         * @return the element
         */
        @PublishedMethod
        MIHasDefinition getElement();

        /**
         * Gets the childs of this node.
         *
         * @return the childs
         */
        @PublishedMethod
        List<IInstanceNode> getChilds();

    }
}
