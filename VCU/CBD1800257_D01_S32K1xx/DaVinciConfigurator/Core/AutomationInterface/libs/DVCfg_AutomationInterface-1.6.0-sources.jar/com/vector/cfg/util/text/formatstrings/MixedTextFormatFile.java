package com.vector.cfg.util.text.formatstrings;

import java.io.File;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class MixedTextFormatFile {
    // private static final ILogger logger = Logger.INSTANCE.createLogger(MixedTextFormatFile.class);

    /**
     * FILE_FORMAT_ABSOLUTE formats the {@link File} object with {@link File#getAbsolutePath()}. This is the default.
     */
    @PublishedField
    public static final String FILE_FORMAT_ABSOLUTE = "absolute";

    @PublishedField
    public static final String FILE_FORMAT_RELATIVE = "relative";

    private MixedTextFormatFile() {

    }
}
