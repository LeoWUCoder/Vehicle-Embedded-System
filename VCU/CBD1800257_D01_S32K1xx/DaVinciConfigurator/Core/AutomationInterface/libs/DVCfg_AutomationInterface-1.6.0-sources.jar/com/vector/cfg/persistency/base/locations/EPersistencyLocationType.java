package com.vector.cfg.persistency.base.locations;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.model.persistency.EPersistencyLocationContentType;

/**
 * <div class="extdoc" id="General" data-target-doc="ModelDocumentation"> With this type a {@link IPersistencyLocationPublished} will be specified. Each type is mapped
 * <span class="javadocOnly"> to exact one {@link EPersistencyLocationContentType} and </span> to exact one location within the dpa model. <span class="javadocOnly"> See
 * {@link IPersistencyLocationTypePathService} for more details. </span>
 *
 * <p>
 * <h4>Available types</h4>
 * <ul>
 * <li><code>DEFAULT_ADAPTIVE_ARXML</code>: Describes currently all adaptive arxml files. Only simple file names and relative paths are allowed to create a location with this
 * type.</li>
 * </ul>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.GENERATOR_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
public enum EPersistencyLocationType {

    /**
     * <code>DEFAULT_ADAPTIVE_ARXML</code> describes currently all ADAPTIVE_ARXMLs.
     */
    DEFAULT_ADAPTIVE_ARXML(EPersistencyLocationContentType.ADAPTIVE_ARXMLS),;

    private EPersistencyLocationContentType contentType;

    EPersistencyLocationType(final EPersistencyLocationContentType contentType) {
        this.contentType = contentType;
    }

    @KeepSecretFromPublishedApi
    public EPersistencyLocationContentType getPersistencyContentType() {
        return contentType;
    }
}
