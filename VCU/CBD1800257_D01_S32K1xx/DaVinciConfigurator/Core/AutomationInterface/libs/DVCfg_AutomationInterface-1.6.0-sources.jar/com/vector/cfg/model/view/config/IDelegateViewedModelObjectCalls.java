package com.vector.cfg.model.view.config;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.mdf.MIObject;

/**
 * The Interface IDelegateViewedModelObjectCalls marks that subclasses of this type, will delegate undefined calls to the underlying {@link MIObject}. This will activate the
 * same behavior as <code>IHasModelObject</code> for {@link IViewedModelObject}s. This is currently done in Groovy code clients automatically.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public interface IDelegateViewedModelObjectCalls extends IViewedModelObject {

}