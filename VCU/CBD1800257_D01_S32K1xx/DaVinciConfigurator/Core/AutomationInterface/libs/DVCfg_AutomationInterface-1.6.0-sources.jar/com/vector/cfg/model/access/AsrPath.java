package com.vector.cfg.model.access;

import static com.google.common.base.Preconditions.checkNotNull;

import java.text.MessageFormat;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.annotation.Nullable;

import ru.novosoft.mdf.ext.MDFObject;

import com.google.common.base.Objects;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.exceptions.InvisibleVariantObjectException;
import com.vector.cfg.model.exceptions.ModelCeAlreadyRemovedException;
import com.vector.cfg.model.exceptions.ModelCeHasNoAutosarPathException;
import com.vector.cfg.model.exceptions.ModelCeHasNoDefinitionException;
import com.vector.cfg.model.exceptions.MultipleVariantObjectsException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.base.MIAUTOSAR;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.autosar.AutosarUtil;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.string.StringCache;
import com.vector.cfg.util.testing.IMockProvider;

/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation">
 * <h2>AsrPath</h2> <!--LaTeX: \label{sec:AsrPath} --> The {@link AsrPath} class represents an AUTOSAR path without a connection to any model.
 *
 * {@link AsrPath}s are constant; their values cannot be changed after they are created. This class is immutable!
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see DefRef
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ReworkThisAtNextBreakingChange("Make this class abstract since we want TypedAsrPath instances only")
public class AsrPath {
    private static final ILogger logger = Logger.INSTANCE.createLogger(AsrPath.class);

    private static final String SEPARATOR = DefRef.SEPARATOR;

    /**
     * The Constant INVALID_ASRPATH describes an AUTOSAR path, which will never be equal to any other autosar paths.
     */
    @PublishedField
    public static final AsrPath INVALID_ASRPATH = create("/INVALID-PACKAGE/INVALID-SHORTNAME");

    /*
     * Private fields
     */
    private final String pathString;

    private String shortname;

    @Nullable // Null when it has no parent
    private AsrPath parent = INVALID_ASRPATH;

    /*
     * Factory methods
     */
    /**
     * Constructs an AUTOSAR path from a MDF model object.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param referrable The model object,
     * @return The AsrPath object
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the mdfObj is null</li>
     * </ul>
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if the mdfObj has no AUTOSAR path</li>
     * </ul>
     * @exception ModelCeAlreadyRemovedException
     * <ul>
     * <li>if the mdfObj is already removed</li>
     * </ul>
     *
     * @see #tryCreate(MIReferrable)
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    public static <T extends MIReferrable> TypedAsrPath<T> create(final T referrable) {
        if (referrable == null) {
            throw new IllegalArgumentException("mdfObj is null.");
        }

        ModelUtil.ensureIsNotRemovedOnly(referrable);

        try {
            final String autosarPath = ModelUtil.getReferrableAccess(referrable).getAutosarPath(referrable);

            final Class<? extends MIReferrable> clazz = referrable.mdfGetInterfaceClass();
            return (TypedAsrPath<T>) create(autosarPath, clazz);

        } catch (final IllegalStateException ex) {
            throw new ModelCeHasNoAutosarPathException(referrable, ex);
        }
    }

    /**
     * Constructs an AUTOSAR path from a MDF model object.
     *
     * <p>
     * The {@link AsrPath#tryCreate(MIReferrable)} supports the {@link IMockProvider} interface. See IMockProvider for more details.
     * </p>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param mdfObj The model object,
     * @return The AsrPath object or <code>null</code> if the mdfObj has no AUTOSAR path.
     *
     * @see #create(MIReferrable)
     */
    @PublishedMethod
    public static AsrPath tryCreate(final MIReferrable mdfObj) {
        if (mdfObj == null) {
            return null;
        }

        if (mdfObj instanceof IMockProvider) {
            return handleMockedMDFObjects((IMockProvider) mdfObj);
        }

        if (ModelAccessUtil.isRemovedOnly(mdfObj)) {
            return null;
        }

        final String autosarPath;
        try {
            autosarPath = ModelUtil.getReferrableAccess(mdfObj).getAutosarPath(mdfObj);
        } catch (final IllegalStateException | InvisibleVariantObjectException ex) {
            /*
             * No Path
             */
            return null;
        }
        @SuppressWarnings("unchecked")
        final Class<? extends MIReferrable> clazz = mdfObj.mdfGetInterfaceClass();
        return create(autosarPath, clazz);
    }

    /**
     * Tries to create a {@link TypedAsrPath} from the mocked {@link IMockProvider}.
     *
     *
     * @param mdfObj the MockObject
     * @return the {@link TypedAsrPath} of the mocked obj or NULL.
     * <ul>
     * <li>if the mdfObj does not support {@link TypedAsrPath}s</li>
     * </ul>
     */
    private static AsrPath handleMockedMDFObjects(final IMockProvider mdfObj) {
        AsrPath asrPath = mdfObj.get(TypedAsrPath.class);
        if (asrPath == null) {
            asrPath = mdfObj.get(AsrPath.class);
        }

        return asrPath;
    }

    /**
     * Constructs an AUTOSAR path by a path string and a parent AsrPath object. The path String can be absolute or relative to the parent object.
     *
     * @param parentAsrPath The parent AsrPath
     * @param childPathString The path string of the child
     *
     * @return The child AsrPath object
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentAsrPath is null</li>
     * <li>if the childPathString is null</li>
     * <li>if the childPathString is empty</li>
     * <li>if the childPathString is absolute and is no child of the parent object</li>
     * <li>if the childPathString ends with '/'</li>
     * </ul>
     */
    @PublishedMethod
    public static AsrPath create(final AsrPath parentAsrPath, final String childPathString) {
        return new TypedAsrPath<>(parentAsrPath, childPathString, MIReferrable.class);
    }

    /**
     * Constructs an AUTOSAR path by a path string and a parent AsrPath object. The path String can be absolute or relative to the parent object.
     *
     * @param parentAsrPath The parent AsrPath
     * @param childPathString The path string of the child
     *
     * @return The child AsrPath object
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentAsrPath is null</li>
     * <li>if the childPathString is null</li>
     * <li>if the metaModelClass is null</li>
     * <li>if the childPathString is empty</li>
     * <li>if the childPathString is absolute and is no child of the parent object</li>
     * <li>if the childPathString ends with '/'</li>
     * </ul>
     */
    @PublishedMethod
    public static <T extends MIReferrable> TypedAsrPath<T> create(final AsrPath parentAsrPath, final String childPathString, final Class<T> metaModelClass) {
        return new TypedAsrPath<>(parentAsrPath, childPathString, metaModelClass);
    }

    /**
     * Constructs an AUTOSAR path by a path string. The path string must be absolute.
     *
     * @param pathString The path string starting with a '/'
     * @param metaModelClass The metaModelClass for the specified path.
     * @return the {@link AsrPath} for the passed pathString
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the pathString is null</li>
     * <li>if the metaModelClass is null</li>
     * <li>if the pathString is empty</li>
     * <li>if the pathString is not an absolute path</li>
     * <li>if the pathString ends with '/'</li>
     * </ul>
     */
    @PublishedMethod
    public static <T extends MIReferrable> TypedAsrPath<T> create(final String pathString, final Class<T> metaModelClass) {
        return new TypedAsrPath<>(pathString, metaModelClass);
    }

    /**
     * Constructs an AUTOSAR path by a path string. The path string must be absolute.
     *
     * @param pathString The path string starting with a '/'
     * @return the {@link AsrPath} for the passed pathString
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the pathString is null</li>
     * <li>if the pathString is empty</li>
     * <li>if the pathString is not an absolute path</li>
     * <li>if the pathString ends with '/'</li>
     * </ul>
     */
    @PublishedMethod
    public static AsrPath create(final String pathString) {
        return create(pathString, MIReferrable.class);
    }

    /**
     * Constructs an AUTOSAR path by a path string. The path string must be absolute.
     *
     * @param pathString The path string starting with a '/'
     *
     * @return The AsrPath object or <code>null</code> if the passed pathString is invalid
     *
     * @see #create(MIReferrable)
     */
    @PublishedMethod
    public static AsrPath tryCreate(String pathString) {
        if (pathString == null) {
            return null;
        }

        try {
            return create(pathString);
        } catch (final IllegalArgumentException ex) {
            /*
             * No valid Path
             */
            return null;
        }
    }

    /**
     * Constructs an AUTOSAR path by a path string. The path string must be absolute.
     *
     * @param pathString The path string starting with a '/'
     * @param metaModelClass The metaModelClass for the specified path.
     * @return The AsrPath object or <code>null</code> if the passed pathString is invalid
     *
     * @see #create(MIReferrable)
     */
    @PublishedMethod
    public static <T extends MIReferrable> TypedAsrPath<T> tryCreate(final String pathString, final Class<T> metaModelClass) {
        if (pathString == null) {
            return null;
        }

        try {
            return create(pathString, metaModelClass);
        } catch (final IllegalArgumentException ex) {
            /*
             * No valid Path
             */
            return null;
        }
    }

    /*
     * Internal Constructors
     */
    /**
     * Constructor for AsrPath.
     *
     * @param pathString
     * @param variantList
     */
    AsrPath(String pathString) {
        if (logger.isTraceEnabled()) {
            logger.traceFormat("called with ({0})", pathString);
        }

        if (pathString == null) {
            throw new IllegalArgumentException("pathString is null");
        }
        if (pathString.isEmpty()) {
            throw new IllegalArgumentException("pathString is empty");
        }

        pathString = pathString.trim();

        if (!pathString.startsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The pathString ({0}) is not absolute. The pathString must start with a \"/\".", pathString));
        }
        if (pathString.endsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The pathString ({0}) ends with a \"/\". The AUTOSAR path shall not end with a Seperator.", pathString));
        }

        this.pathString = StringCache.INSTANCE.getUniqueString(pathString);

        if (logger.isTraceEnabled()) {
            logger.traceFormat("AsrPath created pathString:({0}).", this.pathString);
        }
    }

    /**
     * Constructs a AsrPath by a AUTOSAR path string and a parent MDF model object. The path string can be absolute or relative to the parent object.
     *
     * @param parentAsrPath The parent AsrPath object
     * @param childPathString The new path string
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentAsrPath is null</li>
     * <li>if the childPathString is null</li>
     * <li>if the childPathString is empty</li>
     * <li>if the childPathString is absolute and is no child of the parent object</li>
     * <li>if the childPathString ends with '/'</li>
     * </ul>
     */
    AsrPath(final AsrPath parentAsrPath, final String childPathString) {

        if (logger.isTraceEnabled()) {
            logger.traceFormat("called with ({0};{1})", parentAsrPath, childPathString);
        }

        if (parentAsrPath == null) {
            throw new IllegalArgumentException("parentDefRefObj is null.");
        }
        if (childPathString == null) {
            throw new IllegalArgumentException("childPathString is null");
        }
        if (childPathString.isEmpty()) {
            throw new IllegalArgumentException("childPathString is empty");
        }

        if (childPathString.endsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The childPathString ({0}) ends with a \"/\". The AUTOSAR path shall not end with a Seperator.",
                    childPathString));
        }

        final String parentPathString = parentAsrPath.pathString;

        if (childPathString.startsWith(SEPARATOR)) {
            // It is a Absolute path
            // check if the the parentObj is really a parent
            if (childPathString.startsWith(parentPathString + SEPARATOR)) {
                this.pathString = childPathString;
            } else {
                throw new IllegalArgumentException(MessageFormat.format(
                        "The childPathString ({0}) is an absolute AUTOAST path but does not start with parentAsrPath({1}). The childPath must be a child of the parentAsrPath.",
                        childPathString, parentAsrPath));
            }

        } else {
            // it is a relative path
            this.pathString = (parentPathString + SEPARATOR + childPathString);

        }

        if (logger.isTraceEnabled()) {
            logger.traceFormat("AsrPath created pathString:({0}).", this.pathString);
        }

    }

    /*
     * Public methods
     */

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return pathString.hashCode();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(final Object obj) {

        if (this == INVALID_ASRPATH || obj == INVALID_ASRPATH) {
            /*
             * A INVALID_ASRPATH is never equal to anything!
             */
            return false;
        }

        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }

        if (!(obj instanceof AsrPath)) {
            return false;
        }

        final AsrPath other = (AsrPath) obj;
        if (!pathString.equals(other.pathString)) {
            return false;
        }

        if (!this.equalsTypedAsrPath(other)) {
            return false;
        }

        return true;
    }

    /**
     * Equals {@link TypedAsrPath} objects with each other. Returns true, if the path objects are equal, or one of the element is no {@link TypedAsrPath}, otherwise false.
     *
     * @param other the other
     * @return true, if successful
     */
    private boolean equalsTypedAsrPath(final AsrPath other) {

        Class<?> metaClass1 = null;
        Class<?> metaClass2 = null;

        if (this instanceof TypedAsrPath<?>) {
            metaClass1 = ((TypedAsrPath<?>) this).getMetaModelClass();
        }
        if (other instanceof TypedAsrPath<?>) {
            metaClass2 = ((TypedAsrPath<?>) other).getMetaModelClass();
        }

        if (metaClass1 == null || metaClass2 == null) {
            // One of the two elements is no TypedAsrPath, so we can't check if the types are correct => IT is OK
            return true;
        }

        if (metaClass1 == metaClass2) {
            return true;
        }

        if (metaClass1.isAssignableFrom(metaClass2) || metaClass2.isAssignableFrom(metaClass1)) {
            // One of the two classes is a SuperClass of the other=> This is correct
            return true;
        }

        // The two element do not share a connection in the Class-Hierarchy, so the AsrPath could not be equal!
        return false;
    }

    /**
     * Gets the AUTOSAR path string of this {@link AsrPath}.
     *
     * @return the path string
     */
    @PublishedMethod
    public String getAutosarPathString() {
        return pathString;
    }

    /**
     * Returns the shortnames of the AUTOSAR path in the order they occur in the path.
     *
     * @return
     */
    @PublishedMethod
    public List<String> getShortnames() {
        return AutosarUtil.getAllShortnamesInTheRightOrder(pathString);
    }

    /**
     * Checks if <code>this</code> object is parent of the passed {@link AsrPath}.
     *
     * @param presumableChild The child AsrPath
     * @return <code>true</code>, if the parameter is a child of <code>this</code>.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the presumableChild is null</li>
     * </ul>
     *
     * @see AutosarUtil#isParentPath(String, String)
     */
    @PublishedMethod
    public boolean isParentOf(final AsrPath presumableChild) {

        if (presumableChild == null) {
            throw new IllegalArgumentException("presumableChild is null");
        }

        return AutosarUtil.isParentPath(this.getAutosarPathString(), presumableChild.getAutosarPathString());
    }

    /**
     * Checks if <code>this</code> object is the immediate parent of the passed {@link AsrPath}.
     *
     * @param presumableChild The child AsrPath
     * @return <code>true</code>, if the parameter is a immediate child of <code>this</code>.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the presumableChild is null</li>
     * </ul>
     *
     * @see AutosarUtil#isParentPath(String, String)
     * @see #isParentOf(AsrPath)
     * @see #isParentOf(MIObject)
     */
    @PublishedMethod
    public boolean isImmediateParentOf(final AsrPath presumableChild) {

        if (presumableChild == null) {
            throw new IllegalArgumentException("presumableChild is null");
        }

        if (!this.isParentOf(presumableChild)) {
            // This parent it not the parent of the presumableChild, so it can't be the immediate parent.
            return false;
        }

        final AsrPath immediateChild = this.getImmediateChild(presumableChild);

        if (immediateChild.equals(presumableChild)) {
            return true;
        }

        return false;
    }

    /**
     * Checks if <code>this</code> object is parent of the passed {@link AsrPath}.
     *
     * @param presumableChild The child ModelObject
     * @return <code>true</code>, if the parameter is a child of <code>this</code>.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the presumableChild is null</li>
     * </ul>
     *
     * @see AutosarUtil#isParentPath(String, String)
     */
    @PublishedMethod
    public boolean isParentOf(final MIObject presumableChild) {

        if (presumableChild == null) {
            throw new IllegalArgumentException("presumableChild is null");
        }

        if (!(presumableChild instanceof MIReferrable)) {
            return false;
        }
        int mdfDepth = 1;
        MDFObject parentMdfLoc = presumableChild;
        while (!(parentMdfLoc instanceof MIAUTOSAR)) {
            mdfDepth++;
            parentMdfLoc = parentMdfLoc.refImmediateComposite();
        }
        int asrPathDepth = 1;
        AsrPath parentLoc = this;
        while (parentLoc != null) {
            asrPathDepth++;
            parentLoc = parentLoc.getParentAsrPath();
        }
        if (mdfDepth <= asrPathDepth) {
            return false;
        }
        final int delta = mdfDepth - asrPathDepth;
        MDFObject parentModelStart = presumableChild;
        for (int x = 0; x < delta; x++) {
            parentModelStart = parentModelStart.refImmediateComposite();
        }
        return isParentOfInternal(this, parentModelStart, asrPathDepth - 1);
    }

    private static boolean isParentOfInternal(AsrPath asrPath, MDFObject elemMdf, int depth) {
        if (depth > 1) {

            final AsrPath parentPath = asrPath.getParentAsrPath();
            final MDFObject parentMdf = elemMdf.refImmediateComposite();

            if (!isParentOfInternal(parentPath, parentMdf, depth - 1)) {
                return false;
            }
        }
        if (!(elemMdf instanceof MIReferrable)) {
            return false;
        }
        final String mdfShortname = ((MIReferrable) elemMdf).getName();
        final String asrPathShortname = asrPath.getLastShortname();
        if (Objects.equal(asrPathShortname, mdfShortname)) {
            return true;
        }
        return false;
    }

    /**
     * Returns a parent {@link AsrPath} Object. The last part of this {@link AsrPath} object is truncated.
     *
     * @return The parent {@link AsrPath}, or null, when there is no parent {@link AsrPath}.
     */
    @PublishedMethod
    public AsrPath getParentAsrPath() {
        if (parent != INVALID_ASRPATH) {
            return parent;
        }
        final String parentPath = AutosarUtil.getPathWithoutLastShortname(pathString);
        if (parentPath == null || parentPath.isEmpty()) {
            this.parent = null;
            return null;
        }
        final AsrPath parentLoc = AsrPath.create(parentPath);
        this.parent = parentLoc;
        return parentLoc;
    }

    /**
     * Gets the last Shortname of the {@link AsrPath}.
     *
     * @return The last Shortname of this {@link AsrPath}.
     */
    @PublishedMethod
    public String getLastShortname() {
        if (shortname != null) {
            return shortname;
        }
        final String shortnameLoc = AutosarUtil.getLastShortname(pathString);
        this.shortname = shortnameLoc;
        return shortname;
    }

    /**
     * Returns the immediate child if the this {@link AsrPath}, if this object is parent of the indirectChild.
     *
     * @param indirectChild
     * @return the immediate child {@link AsrPath} of this object.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if indirectChild is null</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if presumed indirectChild DefRef is no child of this Parent object.</li>
     * </ul>
     */
    @PublishedMethod
    public AsrPath getImmediateChild(final AsrPath indirectChild) {
        if (indirectChild == null) {
            throw new IllegalArgumentException("Parameter indirectChild is null.");
        }
        if (!isParentOf(indirectChild)) {
            throw new IllegalArgumentException("The presumed indirectChild AsrPath(" + indirectChild + ") is no child of this Parent AsrPath (" + this + ").");
        }

        final String remainingPath = indirectChild.getAutosarPathString().substring(getAutosarPathString().length() + 1);
        return create(this, AutosarUtil.getFirstShortname(remainingPath));
    }

    /**
     * Constructs a {@link TypedAsrPath} by this {@link AsrPath} object.
     *
     * @param metaModelClass The metamodel class of the AUTOSAR path. E.g. MIContainer.class
     *
     * @return the created {@link TypedAsrPath}
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the metaModelClass is null</li>
     * </ul>
     */
    @PublishedMethod
    public <METACLASS_TYPE extends MIReferrable> TypedAsrPath<METACLASS_TYPE> createTypedAsrPath(final Class<METACLASS_TYPE> metaModelClass) {

        return new TypedAsrPath<>(this, metaModelClass);
    }

    /**
     * Checks if <code>this</code> object is the AUTOSAR path of the passed modelObject.
     *
     *
     * <p>
     * Note: This method is an implicit null and {@link MIReferrable} check. This means, if it returns true, the modelObject is an instance of {@link MIReferrable}.
     *
     * @param modelObject The modelObject to check.
     * @return <code>true</code>, if this is the definition of the modelObject.
     *
     */
    @PublishedMethod
    public boolean isPathOf(final MIObject modelObject) {

        return isPathOfInternal(modelObject);
    }

    @PublishedMethod
    protected boolean isPathOfInternal(final MIObject modelObject) {

        if (this == INVALID_ASRPATH) {
            return false;
        }
        if (modelObject instanceof MIReferrable) {
            final MIReferrable ref = (MIReferrable) modelObject;
            if (this.getLastShortname().equals(ref.getName())) {
                final MDFObject parentMdf = modelObject.refImmediateComposite();
                if (parentMdf instanceof MIReferrable) {
                    final AsrPath parentAsrPath = this.getParentAsrPath();
                    if (parentAsrPath != null && parentAsrPath.isPathOf((MIReferrable) parentMdf)) {
                        return true;
                    }
                }
                if (parentMdf instanceof MIAUTOSAR) {
                    if (this.getParentAsrPath() == null) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Checks if <code>this</code> object is the AUTOSAR path of the passed modelObject and an instance of classToCheck.
     *
     * <p>
     * Note: This method is an implicit null and classToCheck class check. This means, if it returns true, the modelObject is an instance of classToCheck.
     * </p>
     *
     * @param modelObject The modelObject to check.
     * @param classToCheck The class which the modelObject must be an instance of.
     * @return <code>true</code>, if this is the AUTOSAR path of the modelObject and it is instance of classToCheck.
     * @see #isPathOf(MIObject)
     *
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the classToCheck is null</li>
     * </ul>
     */
    @PublishedMethod
    public <T extends MIReferrable> boolean isPathOf(final MIObject modelObject, final Class<T> classToCheck) {

        return isPathOfInternal(modelObject, classToCheck);
    }

    @PublishedMethod
    protected <T extends MIReferrable> boolean isPathOfInternal(final MIObject modelObject, final Class<T> classToCheck) {
        if (classToCheck == null) {
            throw new IllegalArgumentException("classToCheck is null.");
        }

        /*
         * Check Definition
         */
        if (!isPathOfInternal(modelObject)) {
            return false;
        }

        if (classToCheck.isInstance(modelObject)) {
            return true;
        }
        return false;
    }

    /**
     * Checks if <code>this</code> object is the AUTOSAR path of the passed modelObject and an instance of modelObjectClass. If the check is true, the method returns the object
     * casted to modelObjectClass. Otherwise the method return <code>null</code>.
     *
     * <p>
     * Note: This method is an implicit null and classToCheck class check. This means, if it returns true, the modelObject is an instance of classToCheck.
     * </p>
     *
     * @param modelObject The modelObject to check.
     * @return <code>object</code>, if this is the AUTOSAR path of the modelObject and it is instance of modelObjectClass. Otherwise null.
     * @see #isDefinitionOf(MIObject)
     *
     */
    @PublishedMethod
    public <T extends MIReferrable> T asPathOf(final MIObject modelObject, final Class<T> classToCheck) {
        return this.asPathOfInternal(modelObject, classToCheck);
    }

    @SuppressWarnings("unchecked")
    @PublishedMethod
    protected <T extends MIReferrable> T asPathOfInternal(final MIObject modelObject, final Class<T> classToCheck) {

        checkNotNull(classToCheck);
        /*
         * Check Definition and class
         */
        if (!isPathOfInternal(modelObject, classToCheck)) {
            return null;
        }
        /*
         * Cast element
         */
        return (T) modelObject;
    }

    /**
     * Returns the absolute AUTOSAR path in string representation.
     *
     * <p>
     * Attention: Do not use toString to retrieve the AUTOSAR path string from a {@link AsrPath} object. Please use {@link #getAutosarPathString()}.
     * </p>
     *
     * @return The DefRef representation
     */
    @PublishedMethod
    @Override
    public String toString() {
        return "AsrPath: " + getAutosarPathString();
    }

    /**
     * Returns the MDF AUTOSAR object for this path.
     *
     * Returns null, if no MDF AUTOSAR object exists.
     *
     * @return The MDF AUTOSAR object, or null if no object exists.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if projectContext is null</li>
     * </ul>
     * @exception MultipleVariantObjectsException
     * <ul>
     * <li>if more than one object have been found. Better use {@link #getAutosarObjects(IProjectContext)} in variant contexts!</li>
     * </ul>
     */
    @PublishedMethod
    public MIReferrable getAutosarObject(final IProjectContext projectContext) {
        if (projectContext == null) {
            throw new IllegalArgumentException("projectContext is null");
        }

        final MIReferrable referrableByPath = projectContext.getService(IReferrableAccess.class).getReferrableByPath(pathString);
        if (referrableByPath == null) {
            return null;
        }
        return referrableByPath;
    }

    /**
     * Returns all MDF AUTOSAR objects for this path.
     *
     * Returns an empty list, if no MDF AUTOSAR object exists.
     *
     * @return The MDF AUTOSAR objects, or an empty list if no object exists (never <code>null</code>)
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if projectContext is null</li>
     * </ul>
     */
    @PublishedMethod
    public Collection<MIReferrable> getAutosarObjects(final IProjectContext projectContext) {
        if (projectContext == null) {
            throw new IllegalArgumentException("projectContext is null");
        }

        final Collection<MIReferrable> referrablesByPath = projectContext.getService(IReferrableAccess.class).getReferrablesByPath(pathString);
        if (referrablesByPath == null || referrablesByPath.isEmpty()) {
            return Collections.emptyList();
        }
        return referrablesByPath;
    }

}
