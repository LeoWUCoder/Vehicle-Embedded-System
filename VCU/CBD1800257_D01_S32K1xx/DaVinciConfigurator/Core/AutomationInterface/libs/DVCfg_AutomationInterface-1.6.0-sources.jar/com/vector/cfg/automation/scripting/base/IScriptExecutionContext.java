package com.vector.cfg.automation.scripting.base;

import java.nio.file.Path;
import java.util.List;

import com.google.inject.ConfigurationException;
import com.google.inject.ProvisionException;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.paths.IAutomationPathsApi;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.scripting.dynamic.DynamicTarget;
import com.vector.cfg.util.scripting.dynamic.IDynamicObjectAware;
import com.vector.cfg.util.servicecontext.IServiceContext;

/**
 * {@link IScriptExecutionContext} class represents one {@link IScriptTask} execution of the client code.
 *
 * <div class="extdoc" id="Common"> Every {@link IScriptTask} could be be executed, and retrieve passed arguments and other context information. This execution information of a
 * script task is tracked by the {@link IScriptExecutionContext}.
 *
 * <p>
 * The {@link IScriptExecutionContext} holds the context of the execution:
 * <ul>
 * <li>The script task arguments</li>
 * <li>The current running script task</li>
 * <li>The current active script logger</li>
 * <li>The active project, if existing</li>
 * <li>The script temp folder</li>
 * <li>The script task user defined arguments</li>
 * </ul>
 * </p>
 *
 * <p>
 * The {@link IScriptExecutionContext} is also the entry point into every automation API, and provide access to the different API classes. The classes are describes in their own
 * chapters like <code>IProjectHandlingApiEntryPoint</code> or <code>IWorkflowApiEntryPoint</code>.
 * </p>
 * <p>
 * The context is immediately active, when the code block of an {@link IScriptTask} is called.
 * </p>
 *
 *
 *
 * <h5>Groovy Code</h5> The client sample illustrates the seamless usage of the {@link IScriptExecutionContext} class in Groovy:
 *
 * <pre>
 * <code class="Groovy" id="Access automation API in Groovy clients by the IScriptExecutionContext">
 * scriptTask("taskName", DV_APPLICATION){
 *   code{  // The IScriptExecutionContext is automatically active here
 *      // Call methods of the IScriptExecutionContext
 *      def logger = scriptLogger
 *      def temp = paths.tempFolder
 *
 *      // Use an automation API
 *      workflow{
 *          // Now the Workflow API is active
 *      }
 *   }
 * }
 * </code>
 * </pre>
 *
 * In Groovy the {@link IScriptExecutionContext} is automatically activated inside of the <code>code{}</code> block.
 *
 * <h5>Java Code</h5> For java clients the method {@link IScriptExecutionContext#getInstance(Class)} provides access to the API classes, which are seamlessly available for the
 * groovy clients:
 *
 * <pre>
 * <code class="Java" id="Access to automation API in Java clients by the IScriptExecutionContext">
 * // Java code
 * // Passed from the script task:
 * IScriptExecutionContext scriptContext = ...;
 *
 * // Retrieve automation API in Java
 * IWorkflowApi workflow = scriptContext.getInstance(IWorkflowApiEntryPoint.class).getWorkflow();
 * IWorkflowContext workflowCtx = workflow.getWorkflow();
 *
 *
 * // In groovy code it would be:
 * workflow{
 *
 * }
 *
 * </code>
 * </pre>
 *
 * In Java code the context is always the first parameter passed to every task code (see {@link IScriptTaskCode}).
 *
 * <h3>Code Block Arguments</h3> The code block can have arguments passed into the script task execution. The arguments passed into the <code>code{ }</code> block are defined by
 * the {@link IScriptTaskType} of the script task. <!--LaTeX: See chapter \vref{sec:ScriptTaskTypes} for the list of arguments (including types) passed by each individual task
 * type.-->
 *
 * <pre>
 * <code class="Java" id="Script task code block arguments">
 * scriptTask("Task"){
 *   code{ arg1, arg2, ... -> // arguments here defined by the IScriptTaskType
 *
 *   }
 * }
 *
 * scriptTask("Task2"){
 *   // Or you could specify the type of the arguments for code completion
 *   code{ String arg1, List<Double> arg2 ->
 *   }
 * }
 * </code>
 * </pre>
 *
 * <p>
 * The arguments can also retrieved with {@link IScriptExecutionContext#getScriptTaskArguments()}.
 * </p>
 *
 * </div>
 *
 * <div class="extdoc" id="StatefulScriptTasks"> Script tasks normally have no state or cached data, but it can be useful to cache data during an execution, or over multiple
 * task executions. The {@link IScriptExecutionContext} provides two methods to save and restore data for that purpose:
 * <ul>
 * <li>{@link #getExecutionData()} - caches data during one task execution</li>
 * <li>{@link #getSessionData()} - caches data over multiple task executions</li>
 * </ul>
 * </div>
 *
 * <p>
 * For each {@link IScriptTask} execution a new {@link IScriptExecutionContext} is created.
 * </p>
 *
 * <p>
 * To retrieve the {@link IScriptExecutionContext} of the currently running thread, see class {@link ScriptExecutionContexts}.
 * </p>
 *
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 * @see ScriptExecutionContexts
 * @see IScriptTask
 */
@DynamicTarget({
        "com.vector.cfg.automation.api.project.IProjectHandlingApiEntryPoint",
        "com.vector.cfg.automation.api.userinteraction.IUserInteractionApiEntryPoint",
        "com.vector.cfg.automation.api.userinteraction.IUserInputApiEntryPoint",
        "com.vector.cfg.automation.scripting.api.scriptaccess.IScriptAccessEntryPoint",
        "com.vector.cfg.workflow.groovy.parse.IWorkflowApiEntryPoint",
        "com.vector.cfg.gen.core.bswmdmodel.groovy.api.IBswmdModelDefRefApiEntryPoint",
        "com.vector.cfg.gen.core.testinfrastructure.published.IGeneratorTestingApiEntryPoint",
})
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptExecutionContext extends IDynamicObjectAware, IAutomationContext {

    /**
     * Returns the script of the running {@link IScriptTask}.
     *
     * @return the script
     */
    @PublishedMethod
    IScript getScript();

    /**
     * Returns the currently running {@link IScriptTask}.
     *
     * @return the currently running script task
     */
    @Override
    @PublishedMethod
    IScriptTask getScriptTask();

    /**
     * Returns the script logger of the {@link IScript}, see {@link IScript#getScriptLogger()}.
     *
     * <div class="extdoc" id="ScriptLogger"> The script task execution ({@link IScriptExecutionContext}) provides a script logger to log events during an execution. The method
     * {@link #getScriptLogger()} returns the logger. The logger can be used to log:
     * <ul>
     * <li>Errors</li>
     * <li>Warnings</li>
     * <li>Debug messages</li>
     * <li>More...</li>
     * </ul>
     *
     * <p>
     * You shall <b>always prefer</b> the usage of the <b>logger</b> before using the <code>println()</code> of <code>stdout or stderr</code>.
     * </p>
     *
     * <p>
     * In any code block without direct access to the script API, you can write the following code to access the logger: <code>ScriptApi.scriptLogger</code>
     * </p>
     * </div>
     *
     * <div class="extdoc" id="ScriptLoggerFormatting"> The {@link ILogger} also provides a formatting syntax for the format String. The syntax is <code>{IndexNumber}</code> and
     * the index of arguments after the format {@link String}.
     *
     * <p>
     * It is also possible to use the Groovy <code>GString</code> syntax for formatting.
     * </p>
     * </div>
     *
     * @return the script logger
     */
    @PublishedMethod
    ILogger getScriptLogger();

    /**
     * Returns the paths API to retrieve and resolve {@link Path} objects.
     * <p>
     * Possible paths are:
     * <ul>
     * <li>Script folder</li>
     * <li>Temp folder</li>
     * <li>SIP folder</li>
     * <li>Project folder</li>
     * </ul>
     *
     * @return the paths API
     * @see IAutomationPathsApi
     */
    @Override
    @PublishedMethod
    IAutomationPathsApi getPaths();

    /**
     * Returns a temporary created file system folder for this running {@link IScriptTask}.
     * <p>
     * The {@link Path} is absolute and the folder exists.
     * </p>
     *
     * <p>
     * The folder is created at the first invocation, and will return the same folder for subsequent calls. For a new execution a new folder is returned.
     * </p>
     *
     * @return the script temp folder
     */
    @PublishedMethod
    Path getScriptTempFolder();

    /**
     * Returns the list of arguments passed to the {@link IScriptTask} code during execution ( see {@link IScriptTaskCode}).
     * <p>
     * The types of the arguments is defined in the {@link IScriptTaskType} of the currently running task.
     * </p>
     *
     * @return the script task arguments
     */
    @PublishedMethod
    List<Object> getScriptTaskArguments();

    /**
     * Return this instance.
     * <p>
     * This could be used the get the {@link IScriptExecutionContext}, when it is only a delegate of a Closure in Groovy code.
     * </p>
     *
     * @return the script context
     */
    @PublishedMethod
    IScriptExecutionContext getScriptContext();

    /**
     * Returns the requested service instance by the passed {@link Class}.
     *
     * <p>
     * Normally this method is used to retrieve automation API instance from Java code clients, where these instance are not available like in Groovy.
     * </p>
     *
     * @param <T> the type of the instance to retrieve
     * @param type the class of the requested instance.
     * @return service instance
     * @throws IllegalArgumentException - if the argument is <code>null</code>
     * @throws ConfigurationException if this {@link IServiceContext} cannot find or create the provider.
     * @throws ProvisionException if there was a runtime failure while providing an instance.
     */
    @Override
    @PublishedMethod
    <T> T getInstance(Class<T> clazz);

    /**
     * Gets the session data.
     *
     * <div class="extdoc" id="SessionData"> Caches data over multiple task executions, which allows to implement a stateful task, by saving and retrieving any data calculated by
     * the task itself.
     *
     * <p>
     * <b>Caution:</b> The data is saved globally so the usage of the <code>sessionData</code> can lead to memory leaks or {@link OutOfMemoryError}s. You have to take care not to
     * store too much memory in the <code>sessionData</code>.
     *
     * The DaVinci Configurator will also free the <code>sessionData</code>, when the system run low on free memory. So you have to deal with the fact, that the
     * <code>sessionData</code> was freed, when the script task getting executed again. But the data is not deallocated during a running execution.
     * </p>
     *
     * </div>
     *
     * @return the session data of the script task.
     */
    @PublishedMethod
    IScriptTaskUserData getSessionData();

    /**
     * Gets the execution data.
     *
     * <div class="extdoc" id="ExecutionData"> Caches data during a single script task execution, which allows to save calculated values or services needed in multiple parts of the
     * task, without recalculating or creating it. Note: When the task is executed again the <code>executionData</code> will be empty. </div>
     *
     * @return the execution data of this task execution.
     */
    @PublishedMethod
    IScriptTaskUserData getExecutionData();

}
