package com.vector.cfg.model.query.definitionverify;

import static com.google.common.base.Preconditions.checkNotNull;

import java.lang.reflect.Field;
import java.math.BigInteger;
import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.access.TypedDefRef.ITypeInfoKey;
import com.vector.cfg.model.access.TypedDefRef.TypeInfo;
import com.vector.cfg.model.access.TypedDefRef.TypeInfoKey;
import com.vector.cfg.model.access.ecucdefinition.IEcucDefinitionAccess;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The {@link AbstractDefinitionVerifier} is the base implementation of the DefinitionVerifier.
 * <p>
 * There are some Verifiers available:
 * <ul>
 * <li>{@link LogDefinitionVerifier} - Will log any problem to it's logger</li>
 * <li>{@link ExceptionDefinitionVerifier} - Will throw an exception, when any problem occurs</li>
 * <li>{@link GenDefinitionVerifier} - Will throw a corresponding GeneratorPackageException</li>
 * </ul>
 *
 * <p>
 * You can verify any class by a call to {@link AbstractDefinitionVerifier#verifyClass(Class) verifyClass()}.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see AbstractDefinitionVerifier
 * @see RequiredDefinitionDependency
 * @see OptionalDefinitionDependency
 * @see LogDefinitionVerifier
 * @see ExceptionDefinitionVerifier
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public abstract class AbstractDefinitionVerifier {

    private final IProjectContext projectContext;

    private final IEcucDefinitionAccess defAccess;

    @PublishedMethod
    protected AbstractDefinitionVerifier(IProjectContext projectContext) {
        this.projectContext = projectContext;

        defAccess = projectContext.getService(IEcucDefinitionAccess.class);
    }

    /**
     * Verify the definition fields (DefRef) in the class.
     *
     * @param clazz the class to verify
     */
    @PublishedMethod
    public final void verifyClass(Class<?> clazz) {

        checkNotNull(clazz, "Parameter clazz is null");

        verifyClassInternal(clazz);
    }

    /**
     * Verifies one {@link DefRef}.
     *
     * @param defRefContent the def ref content
     * @param processType the process type
     */
    @PublishedMethod
    public final void verifyDefRef(DefRef defRefContent, EProcessingType processType) {
        checkNotNull(defRefContent, "Parameter defRefContent is null");
        checkNotNull(processType, "Parameter processType is null");

        verifyDefRefInternal(defRefContent, processType);
    }

    /**
     * Verify the definition fields (String/DefRef) of every class in the classList.
     *
     * @param clazz the classes to verify
     */
    @PublishedMethod
    public final void verifyClasses(Class<?>... classList) {
        checkNotNull(classList, "Parameter classList is null");
        for (final Class<?> clazz : classList) {
            verifyClass(clazz);
        }
    }

    /**
     * Verify the definition fields (String/DefRef) of every class in the classList.
     *
     * @param clazz the classes to verify
     */
    @PublishedMethod
    public final void verifyClasses(final Collection<? extends Class<?>> classList) {
        checkNotNull(classList, "Parameter classList is null");
        for (final Class<?> clazz : classList) {
            verifyClass(clazz);
        }
    }

    /*
     * Implementation
     */

    @PublishedMethod
    protected void verifyClassInternal(Class<?> clazz) {

        final Field[] fields = clazz.getFields();
        for (final Field field : fields) {
            verifyField(field);

        }
    }

    /**
     * @param field
     */
    @PublishedMethod
    protected void verifyField(Field field) {
        final RequiredDefinitionDependency requiredDefinitionDependency = field.getAnnotation(RequiredDefinitionDependency.class);
        final OptionalDefinitionDependency optionalDefinitionDependency = field.getAnnotation(OptionalDefinitionDependency.class);

        if (requiredDefinitionDependency != null || optionalDefinitionDependency != null) {
            // process field
            if (requiredDefinitionDependency != null && optionalDefinitionDependency != null) {
                reportIllegalProcessingFieldInternal(field,
                        " is annotated with RequiredDefinitionDependency and OptionalDefinitionDependency at the same time. This makes no sense.");
                return;
            }

            final EProcessingType processType;
            if (optionalDefinitionDependency != null) {
                processType = EProcessingType.OPTIONAL;
            } else {
                processType = EProcessingType.REQUIRED;
            }

            final Class<?> type = field.getType();

            if (!DefRef.class.isAssignableFrom(type)) {
                reportIllegalProcessingFieldInternal(field,
                        " has not the Type DefRef. You can only annotate DefRefs with RequiredDefinitionDependency or OptionalDefinitionDependency.");
                return;
            }

            final DefRef defRefContent = getDefRefObjectFromField(field);
            if (defRefContent == null) {
                return;
            }

            verifyDefRefPrivate(defRefContent, processType);
        }

    }

    private DefRef getDefRefObjectFromField(Field field) {
        DefRef defRefContent = null;
        try {
            final Object object = field.get(null);

            if (object instanceof DefRef) {
                defRefContent = (DefRef) object;
            } else {
                reportIllegalProcessingFieldInternal(field,
                        " has no valid DefRef instance. You can only annotate DefRefs with RequiredDefinitionDependency or OptionalDefinitionDependency.");
                return null;
            }

        } catch (final NullPointerException ex) {
            reportIllegalProcessingFieldInternal(field,
                    " is not a static field. You can only annotate static DefRef fields with RequiredDefinitionDependency or OptionalDefinitionDependency.", ex);
            return null;
        } catch (final IllegalAccessException ex) {
            reportIllegalProcessingFieldInternal(field, " is not accessible.", ex);
            return null;
        } catch (final ExceptionInInitializerError ex) {
            reportIllegalProcessingFieldInternal(field, " is not accessible. The class could not be initialized correctly.", ex);
            return null;
        }
        return defRefContent;
    }

    @PublishedMethod
    protected void verifyDefRefInternal(DefRef defRefContent, EProcessingType processType) {
        verifyDefRefPrivate(defRefContent, processType);
    }

    @PublishedMethod
    private void verifyDefRefPrivate(DefRef defRefContent, EProcessingType processType) {

        final MIParamConfMultiplicity def = defRefContent.getDefinitionObject(projectContext);
        if (def != null) {
            // Definition found check Content
            verifyTypesOfDefinition(defRefContent, processType, def);
            return;
        }

        /*
         * Check if there are multiple Definitions, if true don't report an error
         */
        if (defRefContent.getPossibleDefinitionsForDefRefWithWildcard(projectContext).size() > 1) {
            return;
        }

        // The DefRef has no Definition => Report error
        if (processType == EProcessingType.REQUIRED) {
            reportMissingDefinitionDependency(defRefContent);
        } else {
            reportMissingOptionalDefinitionDependency(defRefContent);
        }

    }

    /**
     * @param field
     * @param defRefContent
     * @param processType
     * @param def
     */
    private void verifyTypesOfDefinition(DefRef defRefContent, EProcessingType processType, MIParamConfMultiplicity def) {

        // If the defRef is no TypedDefRef we could not verify Types of the Definition
        if (defRefContent instanceof TypedDefRef<?, ?, ?>) {

            @SuppressWarnings("unchecked")
            final TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?> typedDefRef = (TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?>) defRefContent;

            if (!typedDefRef.getModelDefinitionClass().isInstance(def)) {
                // Wrong definition Type
                reportInvalidDefinitionDependency(typedDefRef, def, "The real definition is not an instance of the TypedDefRef definition.");
            }

            verifyAdditionalTypeInfo(processType, def, typedDefRef);
            return;
        }

    }

    private void verifyAdditionalTypeInfo(EProcessingType processType, MIParamConfMultiplicity def, final TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?> typedDefRef) {
        final TypeInfo typeInfo = typedDefRef.getAdditionalTypeInformation();
        if (typeInfo != TypeInfo.NONE) {
            verifyMultiplicity(typedDefRef, typeInfo, processType, def);

        }
    }

    /**
     * Verify multiplicity.
     *
     * @param defRef the def ref
     * @param typeInfo the type info
     * @param processType the process type
     * @param def the def
     */
    private void verifyMultiplicity(TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?> defRef, TypeInfo typeInfo, EProcessingType processType, MIParamConfMultiplicity def) {

        // Check of Multiplicity information is present
        final Collection<ITypeInfoKey<?>> keys = typeInfo.getAllExistingTypeKeys();
        if (keys.contains(TypeInfoKey.LOWER_MULTIPLICITY) && keys.contains(TypeInfoKey.UPPER_MULTIPLICITY)) {

            // Execute verification
            final BigInteger lowerMulti = typeInfo.getTypeInfoValue(TypeInfoKey.LOWER_MULTIPLICITY);
            final BigInteger upperMulti = typeInfo.getTypeInfoValue(TypeInfoKey.UPPER_MULTIPLICITY);
            if (lowerMulti != null && upperMulti != null) {
                final IEcucDefinition ecucDefinition = defAccess.def(def);
                final BigInteger lowerMultiMdf = ecucDefinition.getMultiplicity().getLower();
                final BigInteger upperMultiMdf = ecucDefinition.getMultiplicity().getUpper();

                verifyMultiplicityLowerUpperByValues(defRef, def, lowerMulti, upperMulti, lowerMultiMdf, upperMultiMdf);
            }
        }

    }

    /**
     * Verify multiplicity lower upper by values.
     * <p>
     * EVAL00114929: DefinitionVerifier: Change the DefVerifier to apply the same rules as DefinitionRestriction classes.<br />
     * EVAL00113538: Project Standard Configuration: Support overwriting of MICORSAR definitions during project load
     * </p>
     *
     * <p>
     * The calculation formula is the following:<br />
     * DefRef: m:n; <br/>
     * Mdf:q:p <br /> ==>
     * m<=q<=n && m<=p<=n
     *
     * </p>
     *
     * @param defRef the def ref
     * @param mdfDef the mdf def
     * @param lowerMultiDefRef the lower multi def ref
     * @param upperMultiDefRef the upper multi def ref
     * @param lowerMultiMdf the lower multi mdf
     * @param upperMultiMdf the upper multi mdf
     */
    private void verifyMultiplicityLowerUpperByValues(TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?> defRef, MIParamConfMultiplicity mdfDef, BigInteger lowerMultiDefRef,
            BigInteger upperMultiDefRef, BigInteger lowerMultiMdf, BigInteger upperMultiMdf) {

        /*
         * Check for compatibility
         */
        if (!checkMultiplicityCompatibility(lowerMultiDefRef, upperMultiDefRef, lowerMultiMdf)) {
            reportInvalidMultiplicity(defRef, mdfDef, lowerMultiDefRef, upperMultiDefRef, lowerMultiMdf, upperMultiMdf);
        }

        if (processMultiConfContainerUpperMultiplicity(defRef, mdfDef, lowerMultiDefRef, upperMultiDefRef, lowerMultiMdf, upperMultiMdf)) {
            /*
             * If the method returns true, the def was a container and was processed as MultiConfContainer, So ignore the next UpperMultiplicity Check.
             */
            return;
        }

        if (!checkMultiplicityCompatibility(lowerMultiDefRef, upperMultiDefRef, upperMultiMdf)) {
            reportInvalidMultiplicity(defRef, mdfDef, lowerMultiDefRef, upperMultiDefRef, lowerMultiMdf, upperMultiMdf);
        }

    }

    /**
     * Report invalid multiplicity.
     *
     * @param defRef the def ref
     * @param mdfDef the mdf def
     * @param lowerMultiDefRef the lower multi def ref
     * @param upperMultiDefRef the upper multi def ref
     * @param lowerMultiMdf the lower multi mdf
     * @param upperMultiMdf the upper multi mdf
     */
    private void reportInvalidMultiplicity(TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?> defRef, MIParamConfMultiplicity mdfDef, BigInteger lowerMultiDefRef,
            BigInteger upperMultiDefRef, BigInteger lowerMultiMdf, BigInteger upperMultiMdf) {
        reportInvalidDefinitionDependency(
                defRef,
                mdfDef,
                "The DefRef Multiplicity " + ModelUtil.getMultiplicityValueAsString(lowerMultiDefRef) + ":" + ModelUtil.getMultiplicityValueAsString(upperMultiDefRef)
                        + " is not compatible to actual definition multiplicity " + ModelUtil.getMultiplicityValueAsString(lowerMultiMdf) + ":"
                        + ModelUtil.getMultiplicityValueAsString(upperMultiMdf) + ".");
    }

    /**
     * EVAL00111275: DefinitionVerifier: Relax the verification of DefRef of MultiConfContainer.
     *
     * @param upperMulti
     * @param upperMultiMdf
     * @param def
     * @return If the method returns true, the def was a container and was processed as MultiConfContainer, So ignore the next UpperMultiplicity Check.
     *
     */
    private boolean processMultiConfContainerUpperMultiplicity(TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?> defRef, MIParamConfMultiplicity mdfDef,
            BigInteger lowerMultiDefRef, BigInteger upperMultiDefRef, BigInteger lowerMultiMdf, BigInteger upperMultiMdf) {

        if (mdfDef instanceof MIParamConfContainerDef) {
            final MIParamConfContainerDef contDef = (MIParamConfContainerDef) mdfDef;
            if (Boolean.TRUE.equals(contDef.getMultipleConfigurationContainer())) {
                // This is a MultiConfContainer in the MDFDefinition.
                // So every Multiplicity, except 0 is correct

                if (upperMultiMdf.compareTo(BigInteger.ZERO) == 0) {
                    reportInvalidMultiplicity(defRef, mdfDef, lowerMultiDefRef, upperMultiDefRef, lowerMultiMdf, upperMultiMdf);
                }
                return true;
            }
        }

        return false;
    }

    /**
     * checkMultiplicityCompatibility verifies one mdf multiplicity against the DefRef multiplicities.
     *
     * <p>
     * The calculation formula is the following:<br />
     * DefRef: lowerMultiDefRef:upperMultiDefRef; <br/>
     * Mdf: multiMdf <br /> ==>
     * lowerMultiDefRef<= multiMdf <= upperMultiDefRef
     *
     * </p>
     *
     * @param upperMulti
     * @param upperMultiMdf
     * @return
     */
    // This is not private, for unit testing purpose!
    boolean checkMultiplicityCompatibility(BigInteger lowerMultiDefRef, BigInteger upperMultiDefRef, BigInteger multiMdf) {

        if (lowerMultiDefRef.compareTo(multiMdf) <= 0 && multiMdf.compareTo(upperMultiDefRef) <= 0) {
            return true;
        }

        // All other things are incompatible
        return false;
    }

    private static String getFieldName(Field field) {
        return field.getDeclaringClass().getCanonicalName() + "." + field.getName();
    }

    private void reportIllegalProcessingFieldInternal(Field field, String msg) {
        reportIllegalProcessingFieldInternal(field, msg, null);
    }

    private void reportIllegalProcessingFieldInternal(Field field, String msg, Throwable ex) {
        reportIllegalProcessingField("The field " + getFieldName(field) + msg, ex);

    }

    /*
     *Internal Types
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedFilter(MsrPlatform.class)
    public enum EProcessingType {
        OPTIONAL,
        REQUIRED;
    }

    /*
     * Protected methods
     */
    /**
     * Report illegal processing field.
     *
     *
     * @param msg the msg
     * @param ex the ex
     */
    @PublishedMethod
    protected void reportIllegalProcessingField(String msg, Throwable ex) {
        throw new IllegalArgumentException(msg, ex);
    }

    @PublishedMethod
    protected abstract void reportMissingDefinitionDependency(DefRef defRef);

    @PublishedMethod
    protected abstract void reportInvalidDefinitionDependency(TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?> typedDefRef, MIParamConfMultiplicity defObj,
            String errorMsg);

    /**
     * Reports, when the DefRef is missing, but has an {@link OptionalDefinitionDependency}.
     *
     * @param defRefContent the def ref content
     */
    @PublishedMethod
    protected void reportMissingOptionalDefinitionDependency(DefRef defRefContent) {
        // Default noting to do
    }

}
