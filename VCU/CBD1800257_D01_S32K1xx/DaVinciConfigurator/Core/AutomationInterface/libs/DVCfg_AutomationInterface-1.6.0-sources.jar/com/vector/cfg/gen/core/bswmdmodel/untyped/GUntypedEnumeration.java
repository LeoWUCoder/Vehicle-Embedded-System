package com.vector.cfg.gen.core.bswmdmodel.untyped;

import java.util.Collections;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasIllegalValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasNoValueException;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractEnumeration;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.gen.core.utils.formatting.primitives.EnumGenElement;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.enums.ModelEnumUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Enumeration parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public final class GUntypedEnumeration extends GAbstractEnumeration<com.vector.cfg.gen.core.bswmdmodel.GIEnumParameter.GIEnumClass> {

    private List<String> validEnumLiterals;

    /**
     * Constructor.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     */
    private GUntypedEnumeration(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MITextualValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);

    }

    /**
     * @param abstractBswmdModelAccess
     * @param defRef
     * @param mdfCfgElement
     * @param parent
     * @param isOnlyOneElement
     * @return
     */
    @KeepSecretFromPublishedApi
    public static GUntypedEnumeration create(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MITextualValue parameter, GIContainer parent,
            boolean isOnlyOneElement) {
        if (parameter != null) {
            final GIModelObject value = modelAccess.getRelatedElement(parameter);
            if (value != null) {
                return (GUntypedEnumeration) value;
            }
        }
        final GUntypedEnumeration bswmdRef = new GUntypedEnumeration(modelAccess, defRef, parameter, parent, isOnlyOneElement);
        if (parameter != null) {
            modelAccess.setRelatedElement(bswmdRef, parameter);
        }
        return bswmdRef;
    }

    /**
     * Returns the parameters value as Enumeration literal (Java enum instance).
     *
     * @return The value object
     *
     * @exception BswmdModelParameterHasNoValueException
     * <ul>
     * <li>if the value of the parameter is null</li>
     * </ul>
     * @exception BswmdModelParameterHasIllegalValueException
     * <ul>
     * <li>if the value of the parameter is illegal</li>
     * </ul>
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    @Override
    public GIEnumClass getValue() {
        throw new UnsupportedOperationException(
                "An untyped GIEnumParameter (GUntypedEnumeration) could not return a valid Java Enum literal, because we do not know the valid enumeration values at compile time! Please use one of the methods getValueMdf(),  getAsCustomEnum(Enum) instead!");
    }

    private List<String> getValidEnumLiterals() {
        if (validEnumLiterals == null) {
            validEnumLiterals = Collections.unmodifiableList(ModelEnumUtil.getValidEnumLiteralsFromEnumDefinition(getDefinition()));
        }
        return validEnumLiterals;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getValueMdf() {
        try {
            switchView();

            final String valueLoc = getValueInternal();
            getModelVerifier().assertParameterValueNotNull(this, valueLoc);
            getModelVerifier().assertEnumerationHasLegalLiteral(this, getValidEnumLiterals(), valueLoc);

            setValueChecked();
            return valueLoc;

        } finally {
            restoreView();
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public EnumGenElement formatValue() {
        return F.formatEnum(this);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("BswmdModel GUntypedEnumeration:");
        builder.append(getObjectLink());
        return builder.toString();
    }

}
