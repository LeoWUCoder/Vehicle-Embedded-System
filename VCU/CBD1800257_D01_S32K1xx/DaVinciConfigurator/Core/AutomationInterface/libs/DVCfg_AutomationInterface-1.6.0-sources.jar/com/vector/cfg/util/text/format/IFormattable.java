package com.vector.cfg.util.text.format;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IFormattable} allows to format the value of an object into a string representation with a format pattern.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IFormattable {

    /**
     * Formats the value of the current instance using the specified format.
     *
     * @param formatPattern The formatting pattern to control the format
     * @return the formatted string.
     */
    @PublishedMethod
    String toString(String formatPattern);
}
