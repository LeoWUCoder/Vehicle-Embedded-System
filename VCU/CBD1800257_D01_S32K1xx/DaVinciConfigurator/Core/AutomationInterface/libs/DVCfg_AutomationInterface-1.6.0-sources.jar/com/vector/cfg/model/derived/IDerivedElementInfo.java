package com.vector.cfg.model.derived;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.operations.IModelOperationsPublished;

/**
 * {@link IDerivedElementInfo} provides information about derived containers or removed derived sub containers. This wrapper is valid for instances of type
 * {@link MIHasContainer}.
 *
 * <div class="extdoc" id="Common"> The {@link IDerivedElementInfo} can be used to retrieve information about element or delete it:
 * <ul>
 * <li>{@link #getRemovedDerivedSubContainers()}: Retrieves the removed children, which could be used to restore them the children</li>
 * <li>{@link #isDerived()}: returns <code>true</code> if the element is derived</li>
 * <li>{@link #delete()}: deletes the element regardless if it is derived or not</li>
 * </ul>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDerivedElementInfo {

    /**
     * <div class="extdoc" id="delete"> The method {@link #delete()} deletes the {@link MIContainer} regardless, if it is derived or not.
     *
     * This method behaves as follows:
     * <ul>
     * <li>If the container is a derived container it calls the derived container deletion operation to delete it.
     * <li>All other containers with be deleted by means of {@link IModelOperationsPublished#deleteFromModel(ru.novosoft.mdf.ext.MIObject) moRemove()}
     * </ul>
     *
     * </div>
     */
    @PublishedMethod
    void delete();

    @PublishedMethod
    Collection<IRemovedDerivedContainerInfo> getRemovedDerivedSubContainers();

    /**
     * Returns <code>true</code> if this element contains a removed derived container with the specified name.
     * <p>
     * The behavior in variant projects depends on the variant context which is active when this method is being called:
     * <ul>
     * <li>In a single variant view, this method reports the state for this variant and doesn't take other variants into account</li>
     * <li>In the unfiltered view, this method returns <code>true</code> when at least one variant contains a removed derived container</li>
     * </ul>
     * </p>
     *
     * @param containerName the shortname of the removed container
     * @return <code>true</code>, if a container with this name was removed.
     */
    @PublishedMethod
    boolean isRemovedSubContainer(String containerName);

    /**
     * Returns <code>true</code>, if the element is derived. So if the CE has a initial value (the object is derived) but is still deletable.
     *
     *
     * @return true, if is derived
     */
    @PublishedMethod
    boolean isDerived();
}
