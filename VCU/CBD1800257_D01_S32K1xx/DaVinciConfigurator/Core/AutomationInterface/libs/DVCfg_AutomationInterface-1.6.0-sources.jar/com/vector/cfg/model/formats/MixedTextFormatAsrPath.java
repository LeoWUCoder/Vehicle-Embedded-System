package com.vector.cfg.model.formats;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.cfg.model.access.AsrPath;

/**
 * {@link AsrPath} mixed text formats.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class MixedTextFormatAsrPath {

    /**
     * Only prints the last Shortname. Formats the AsrPath.
     */
    @PublishedField
    public static final String ASRPATH_FORMAT_LAST_SHORTNAME = "lastShortname";

    /**
     * Formats the DAsrPathefRef without the "AsrPath" text before.
     */
    @PublishedField
    public static final String ASRPATH_FORMAT_SHORT = "short";

    /**
     * Formats the AsrPath with the text "AsrPath" before.
     */
    @PublishedField
    public static final String ASRPATH_FORMAT_NORMAL = "normal";

    private MixedTextFormatAsrPath() {

    }

}
