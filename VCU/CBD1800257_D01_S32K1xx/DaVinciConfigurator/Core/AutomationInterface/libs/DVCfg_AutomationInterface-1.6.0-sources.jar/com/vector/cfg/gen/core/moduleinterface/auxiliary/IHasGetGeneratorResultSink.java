package com.vector.cfg.gen.core.moduleinterface.auxiliary;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGenerationProcessor;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;

/**
 * The Class {@link IHasGetGeneratorResultSink} provides a getter semantic for {@link IGeneratorResultSink}s. E.g. A {@link IGenerationProcessor} is a
 * {@link IHasGetGeneratorResultSink}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasGetGeneratorResultSink {

    /**
     * Gets the current resultSink.
     *
     *
     * @return resultSink
     */
    @PublishedMethod
    IGeneratorResultSink getResultSink();
}
