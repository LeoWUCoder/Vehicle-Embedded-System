package com.vector.cfg.model.access.ecucdefinition.elements;

import java.util.Collection;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationVariant;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" id="Common"> <b>{@link IEcucModuleDefinition}</b> is the interface of the module definition wrapper. It provides the following method(s): </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucModuleDefinition extends IEcucDefinition {

    @Override
    @PublishedMethod
    MIModuleDef getDef();

    /**
     * Returns the ApiServicePrefix of CDDs.
     *
     * For CDD modules this attribute holds the apiServicePrefix. The shortName of the module definition of a Complex Driver is always "CDD". Therefore for CDD modules the module
     * apiServicePrefix is described with this attribute.
     *
     * @return
     */
    @PublishedMethod
    Optional<String> getApiServicePrefix();

    /**
     * Optional reference from the Vendor SpecificModuleDefinition to the Standardized Module Definition it refines. In case this EcucModuleDef has the category
     * STANDARDIZED_MODULE_DEFINITION this reference shall not be provided. In case this EcucModuleDef has the category VENDOR_SPECIFIC_MODULE_DEFINITION this reference is
     * mandatory.
     *
     * @return the RefinedModuleDef
     */
    @PublishedMethod
    Optional<MIModuleDef> getRefinedModuleDef();

    /**
     * <div class="extdoc" id="getSupportedConfigurationVariants"> The {@link #getSupportedConfigurationVariants()} method returns a collection of supported configuration variants.
     * Never returns <code>null</code> but an empty collection if no supported config variants are specified.
     * <p>
     * The returned collection never contains the following literals:
     * <ul>
     * <li>{@link EEcucConfigurationVariant#PRECONFIGURED_CONFIGURATION}</li>
     * <li>{@link EEcucConfigurationVariant#RECOMMENDED_CONFIGURATION}</li>
     * </ul>
     *
     * </p>
     * <p>
     * This method is for post-build loadable only!
     * </p>
     * <p>
     * <b>Remark about AUTOSAR versions:</b> Prior to AUTOSAR 4.2.1 the module definitions used the following valid values:
     * <ul>
     * <li><code>VARIANT-PRE-COMPILE</code></li>
     * <li><code>VARIANT-LINK-TIME</code></li>
     * <li><code>VARIANT-POST-BUILD-LOADABLE</code></li>
     * <li><code>VARIANT-POST-BUILD-SELECTABLE</code></li>
     * </ul>
     * <code>VARIANT-POST-BUILD</code> was invalid! With AUTOSAR 4.2.1 and later, the following values are valid (because the loadable and selectable specifications have been
     * separated):
     * <ul>
     * <li><code>VARIANT-PRE-COMPILE</code></li>
     * <li><code>VARIANT-LINK-TIME</code></li>
     * <li><code>VARIANT-POST-BUILD</code></li>
     * </ul>
     * <code>VARIANT-POST-BUILD-LOADABLE</code> and <code>VARIANT-POST-BUILD-SELECTABLE</code> are invalid!
     * </p>
     * <p>
     * This method takes the AUTOSAR version into account and returns the post-build loadable relevant specification only.
     * </p>
     * </div>
     *
     * @return
     */
    @PublishedMethod
    Collection<EEcucConfigurationVariant> getSupportedConfigurationVariants();

    /**
     * <div class="extdoc" id="supportsPostBuildVariance"> The {@link #supportsPostBuildVariance()} method returns <code>true</code> if this module configuration supports
     * post-build selectable.
     * <p>
     * <b>Remark about AUTOSAR versions:</b> Prior to AUTOSAR 4.2.1 the module definitions <code>supportedSupportedConfigurationVariants</code> defined both, post-build loadable
     * and selectable support. With AUTOSAR 4.2.1 the <code>supportedSupportedConfigurationVariants</code> specifies post-build loadable only and this method returns the value of
     * the new <code>postBuildVariantSupport</code> flag.
     * </p>
     * </div>
     *
     * @return
     */
    @PublishedMethod
    boolean supportsPostBuildVariance();

}
