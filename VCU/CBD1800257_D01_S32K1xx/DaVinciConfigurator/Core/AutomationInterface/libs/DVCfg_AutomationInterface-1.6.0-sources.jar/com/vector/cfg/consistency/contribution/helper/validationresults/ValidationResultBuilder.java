package com.vector.cfg.consistency.contribution.helper.validationresults;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.ISolvingActionContainer;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.IValidationSeverityResultId;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.internal.contribution.helper.validationresults.ValidationResult;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.view.config.variant.IInvariantView;
import com.vector.cfg.model.view.config.variant.IPredefinedVariantView;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * A builder for {@link IValidationResult ValidationResults}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class ValidationResultBuilder extends AbstractResultBuilder<ValidationResultBuilder> {

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(ValidationResultBuilder.class);

    /**
     * Constructor for ValidationResultBuilder.
     *
     * @param resultId
     * @param severityType
     * @param descriptionBuilder
     * @param description
     */
    private ValidationResultBuilder(IValidationResultId resultId, EValidationSeverityType severityType, IMixedTextBuilder descriptionBuilder, IMixedText description) {
        super(resultId, severityType, descriptionBuilder, description);

    }

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     * <p>
     * The descriptionPattern parameter is a {@link MixedText} pattern.<br />
     * See {@link MixedText#format(String, Object...)} with the parameters descriptionPattern and patternArguments for more details.
     * </p>
     *
     * @param resultId The IValidationResultId of the {@link IValidationResult}
     * @param severityType The Severity of the result
     * @param formatPattern The description pattern for {@link IMixedTextBuilder#appendFormat(String, Object...)}
     * @param patternArguments The arguments for the descriptionPattern
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * <li>if formatPattern is null</li>
     * <li>if patternArguments is null</li>
     * </ul>
     */
    @PublishedMethod
    public static ValidationResultBuilder newBuilder(IValidationResultId resultId, EValidationSeverityType severityType, String formatPattern, Object... patternArguments) {
        if (formatPattern == null) {
            throw new IllegalArgumentException("formatPattern is null");
        }
        if (patternArguments == null) {
            throw new IllegalArgumentException("patternArguments is null");
        }
        return newBuilder(resultId, severityType, MixedText.newBuilder().appendFormat(formatPattern, patternArguments).flushResult());
    }

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     * <p>
     * The descriptionPattern parameter is a {@link MixedText} pattern.<br />
     * See {@link MixedText#format(String, Object...)} with the parameters descriptionPattern and patternArguments for more details.
     * </p>
     *
     * @param resultId The IValidationSeverityResultId of the {@link IValidationResult}
     * @param formatPattern The description pattern for {@link IMixedTextBuilder#appendFormat(String, Object...)}
     * @param patternArguments The arguments for the descriptionPattern
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     * @see IMixedTextBuilder
     * @see IMixedText
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if formatPattern is null</li>
     * <li>if patternArguments is null</li>
     * </ul>
     */
    @PublishedMethod
    public static ValidationResultBuilder newBuilder(IValidationSeverityResultId resultId, String formatPattern, Object... patternArguments) {
        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (formatPattern == null) {
            throw new IllegalArgumentException("formatPattern is null");
        }
        if (patternArguments == null) {
            throw new IllegalArgumentException("patternArguments is null");
        }
        return newBuilder(resultId, resultId.getSeverity(), MixedText.newBuilder().appendFormat(formatPattern, patternArguments).flushResult());
    }

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     * @param resultId The IValidationResultId of the {@link IValidationResult}
     * @param severityType The Severity of the result
     * @param description The detailed description text of the result
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     * @see MixedText#newBuilder()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * <li>if description is null</li>
     * </ul>
     */
    @PublishedMethod
    public static ValidationResultBuilder newBuilder(IValidationResultId resultId, EValidationSeverityType severityType, IMixedText description) {

        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (severityType == null) {
            throw new IllegalArgumentException("severityType is null");
        }
        if (description == null) {
            throw new IllegalArgumentException("description is null");
        }

        return new ValidationResultBuilder(resultId, severityType, null, description);

    }

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     * @param resultId The IValidationSeverityResultId of the {@link IValidationResult}
     * @param description The detailed description text of the result in IMixedTextFormat
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     * @see MixedText#newBuilder()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if description is null</li>
     * </ul>
     */
    @PublishedMethod
    public static ValidationResultBuilder newBuilder(IValidationSeverityResultId resultId, IMixedText description) {

        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (description == null) {
            throw new IllegalArgumentException("description is null");
        }

        return newBuilder(resultId, resultId.getSeverity(), description);

    }

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     * @param resultId The IValidationSeverityResultId of the {@link IValidationResult}
     * @param description The detailed description text of the result
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if description is null</li>
     * </ul>
     */
    @PublishedMethod
    public static ValidationResultBuilder newBuilder(IValidationSeverityResultId resultId, String description) {
        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (description == null) {
            throw new IllegalArgumentException("description is null");
        }

        return newBuilder(resultId, resultId.getSeverity(), MixedText.newBuilder().append(description).flushResult());

    }

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     *
     * @param resultId The IValidationResultId of the {@link IValidationResult}
     * @param severityType The Severity of the result
     * @param description The description
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * <li>if description is null</li>
     * </ul>
     */
    @PublishedMethod
    public static ValidationResultBuilder newBuilder(IValidationResultId resultId, EValidationSeverityType severityType, String description) {
        if (description == null) {
            throw new IllegalArgumentException("description is null");
        }
        return newBuilder(resultId, severityType, MixedText.newBuilder().append(description).flushResult());
    }

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     * <p>
     * This method should only be used, if you want to construct the description text programmatically with an {@link IMixedTextBuilder}, otherwise you should call the other
     * newBuilder() methods.
     * </p>
     *
     * <p>
     * <b>Attention:</b> You have to use the {@link #getMixedTextBuilder()} method to set the description text of this result, otherwise the {@link #buildResult()} method will
     * throw an {@link IllegalArgumentException}.
     * </p>
     *
     * @param resultId The IValidationSeverityResultId of the {@link IValidationResult}
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * </ul>
     */
    @PublishedMethod
    public static ValidationResultBuilder newBuilder(IValidationSeverityResultId resultId) {
        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }

        return newBuilder(resultId, resultId.getSeverity());

    }

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build a {@link IValidationResult}.
     *
     * <p>
     * This method should only be used, if you want to construct the description text programmatically with an {@link IMixedTextBuilder}, otherwise you should call the other
     * newBuilder() methods.
     * </p>
     *
     * <p>
     * <b>Attention:</b> You have to use the {@link #getMixedTextBuilder()} method to set the description text of this result, otherwise the {@link #buildResult()} method will
     * throw an {@link IllegalArgumentException}.
     * </p>
     *
     * @param resultId The IValidationSeverityResultId of the {@link IValidationResult}
     * @param severityType The Severity of the result
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * </ul>
     */
    @PublishedMethod
    public static ValidationResultBuilder newBuilder(IValidationSeverityResultId resultId, EValidationSeverityType severityType) {
        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (severityType == null) {
            throw new IllegalArgumentException("severityType is null");
        }

        return new ValidationResultBuilder(resultId, severityType, MixedText.newBuilder(), null);

    }

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build a {@link IValidationResult}.
     *
     * @param resultId The IValidationResultId of the {@link IValidationResult}
     * @param severityType The Severity of the result
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * </ul>
     */
    @PublishedMethod
    public static ValidationResultBuilder newBuilder(IValidationResultId resultId, EValidationSeverityType severityType) {
        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (severityType == null) {
            throw new IllegalArgumentException("severityType is null");
        }

        return new ValidationResultBuilder(resultId, severityType, MixedText.newBuilder(), null);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @KeepSecretFromPublishedApi
    protected ValidationResultBuilder getThis() {
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @KeepSecretFromPublishedApi
    protected IValidationResult buildResultInternal(IValidationResultId resultId, EValidationSeverityType severityType, Collection<IValidationResultMarkerType> markerSet,
            IMixedText description, List<IDescriptor> erroneousCEs,
            List<IDescriptor> dependentCEs, ISolvingActionContainer<ISolvingAction> solvingActionContainer, Throwable innerException,
            Set<IPredefinedVariantView> predefinedVariantSet, Set<IInvariantView> invariantViewSet, Object additionalDistinguishingObjectParam) {
        return new ValidationResult(resultId, severityType, markerSet, description, erroneousCEs, dependentCEs, solvingActionContainer,
                innerException, predefinedVariantSet, invariantViewSet, additionalDistinguishingObjectParam);
    }

}