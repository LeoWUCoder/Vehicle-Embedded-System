package com.vector.cfg.model.view.config;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.IModelObject;
import com.vector.cfg.model.mdf.MIObject;

/**
 * <div class="extdoc" id="Common">
 * <h3>IViewedModelObject</h3>The {@link IViewedModelObject} is a container for one {@link MIObject} and an {@link IModelView} that was used when viewing the {@link MIObject}.
 *
 * <p>
 * The interface provides getter for the {@link MIObject}, and the {@link IModelView} which was active during creation of the {@link IViewedModelObject}. So the
 * {@link IViewedModelObject} represents a tuple of {@link MIObject} and {@link IModelView}.
 *
 * This could be used to preserve the state/tuple of a {@link MIObject} and {@link IModelView}, for later retrieval.
 * <p>
 *
 * <p>
 * Examples:
 * <ul>
 * <li>BswmdModel objects</li>
 * <li>Elements for validation results, retrieved in a certain view</li>
 * <li>Model Query API like ModelTraverser, to preserve {@link IModelView} information</li>
 * </ul>
 * </p>
 *
 * <p>
 * Notes:<br/>
 * A {@link IViewedModelObject} is immutable and will not update any state. Especially not when the visibility of the {@link #getMdfObject()}, is changed after the construction
 * of the {@link IViewedModelObject}.
 * </p>
 * <p>
 * It is not guaranteed, that the {@link MIObject} is visible in the creation {@link IModelView}, after the model is changed. It is also possible to create an
 * {@link IViewedModelObject} of a {@link MIObject} and a {@link IModelView}, where the {@link MIObject} is invisible.
 * </p>
 * </div>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see MIObject
 * @see IModelView
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@Immutable
public interface IViewedModelObject {

    /**
     * <div class="extdoc" id="Using_getCreationModelView"> The method {@link #getCreationModelView()} returns the {@link IModelView} of the {@link IViewedModelObject}, which
     * was active when the model object was viewed {@link IViewedModelObject}. </div>
     *
     * @return the creation model view of the {@link IViewedModelObject}
     *
     * <p>
     * The method will never return <code>null</code>.
     * </p>
     */
    @PublishedMethod
    @Nonnull
    IModelView getCreationModelView();

    /**
     * Returns the {@link MIObject} of this {@link IViewedModelObject}.
     *
     * <p>
     * Attention: The returned {@link MIObject} could be invisible in the current active {@link IModelView}! You have to check the visibility in the client side code!
     * </p>
     *
     * <p>
     * The method will never return <code>null</code>.
     * </p>
     *
     * @return The {@link MIObject} of this {@link IViewedModelObject}.
     */
    @PublishedMethod
    @Nonnull
    MIObject getMdfObject();

    /**
     * Converts the {@link #getMdfObject()} object to the passed type. This is mainly used for Groovy type conversion.
     *
     * @param <T> the type to cast to
     * @param clazz the clazz
     * @return the {@link #getMdfObject()} object casted to clazz, or <code>null</code>, if the types are incompatible.
     */
    @PublishedMethod
    @Nullable
    default <T> T asType(Class<T> clazz) {
        if (IModelObject.class.isAssignableFrom(clazz)) {
            return clazz.cast(getMdfObject());
        }
        return null;
    }
}
