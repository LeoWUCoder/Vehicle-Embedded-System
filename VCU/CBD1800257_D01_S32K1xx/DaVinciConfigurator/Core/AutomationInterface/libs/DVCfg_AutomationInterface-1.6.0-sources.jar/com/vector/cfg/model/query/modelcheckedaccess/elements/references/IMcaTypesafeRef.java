package com.vector.cfg.model.query.modelcheckedaccess.elements.references;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaRequest;
import com.vector.cfg.model.query.modelcheckedaccess.elements.params.IMcaParamWithoutType;
import com.vector.cfg.model.query.modelcheckedaccess.elements.params.IMcaTypesafeParam;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaDefinitionUndefinedException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaNotExistsException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongQuantityException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongTypeException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceHasNoRefTargetException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceWrongTargetDefinitionException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceWrongTypeException;
import com.vector.cfg.model.query.modelcheckedaccess.tuple.IModelTuple;
import com.vector.cfg.model.query.modelcheckedaccess.tuple.IModelTupleList;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess request interface for references in a type safe manner.
 *
 * <p>
 * You can process the request by adding a method call to your request.
 * </p>
 * <p>
 * Example:<br/>
 * <code>mca.reference(..) -->.getReference()<-- or -->.asRefToContainer()<--</code> ...
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelCheckedAccess
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IMcaTypesafeRef<REF_TARGET, PARAM extends MIParameterValue> extends IMcaReference<IMcaTypesafeRef<REF_TARGET, PARAM>> {

    /**
     * Executes the model request and returns a single ReferenceTarget value, with the type defined by a TypeOperation (See {@link IMcaRefWithoutType TypeOperations}).
     *
     * <p>
     * The requested reference must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IMcaTypesafeRef#getManyRefTargets() getManyRefTargets()} instead.
     * </p>
     *
     * @return The ReferenceTarget value of the reference for the request
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaNotExistsException
     * <ul>
     * <li>if no reference was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one reference value was found</li>
     * </ul>
     * @exception McaReferenceHasNoRefTargetException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference has no reference target</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference pointing to an invalid RefTarget</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     */
    @PublishedMethod
    REF_TARGET getRefTarget();

    /**
     * Executes the model request and returns a single defaultElement defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * If the reference does not exist or has no value. The defaultElement defaultValue is returned.
     * </p>
     *
     * <p>
     * The requested reference must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use {@link IMcaTypesafeParam#getManyValues()
     * getManyValues()} instead.
     * </p>
     *
     * @param defaultValue the default value
     *
     * @return The value of the parameter for the request
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one parameter value was found</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the parameter has an illegal value</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no parameter</li>
     * </ul>
     */
    @PublishedMethod
    REF_TARGET getRefTargetOrDefault(REF_TARGET defaultValue);

    /**
     * Executes the model request and returns a single ReferenceTarget value, with the type defined by a TypeOperation (See {@link IMcaRefWithoutType TypeOperations}).
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<REF_TARGET> getRefTargetAsRequest();

    /**
     * Executes the model request and returns a list of ReferenceTarget value of references, with the type defined by a TypeOperation (See {@link IMcaTypesafeRef TypeOperations}).
     *
     * <p>
     * If no reference was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if non or one
     * parameter was found.
     * </p>
     *
     * @return An unmodifiable List of ReferenceTarget values of references for the request.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaReferenceHasNoRefTargetException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference has no reference target</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference pointing to an invalid RefTarget</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if a reference has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     */
    @PublishedMethod
    List<REF_TARGET> getManyRefTargets();

    /**
     * Executes the model request and returns a list of ReferenceTarget value of references, with the type defined by a TypeOperation (See {@link IMcaTypesafeRef TypeOperations}).
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<List<REF_TARGET>> getManyRefTargetsAsRequest();

    /**
     * Executes the model request and returns a single ReferenceTarget; reference) tuple, with the type defined by a TypeOperation (See {@link IMcaRefWithoutType TypeOperations}).
     *
     * <p>
     * The requested reference must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IMcaTypesafeRef#getManyRefTargets() getManyRefTargets()} instead.
     * </p>
     *
     * @return The ReferenceTarget; reference) tuple of the reference for the request
     *
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaNotExistsException
     * <ul>
     * <li>if no reference was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one reference value was found</li>
     * </ul>
     * @exception McaReferenceHasNoRefTargetException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference has no reference target</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference pointing to an invalid RefTarget</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     */
    @PublishedMethod
    IModelTuple<REF_TARGET, PARAM> getRefTargetTuple();

    /**
     * Executes the model request and returns a single ReferenceTarget; reference) tuple, with the type defined by a TypeOperation (See {@link IMcaRefWithoutType TypeOperations}).
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<IModelTuple<REF_TARGET, PARAM>> getRefTargetTupleAsRequest();

    /**
     * Executes the model request and returns a list of (ReferenceTarget; reference) tuples, with the type defined by a TypeOperation (See {@link IMcaTypesafeRef TypeOperations}).
     *
     * <p>
     * If no reference was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if non or one
     * parameter was found.
     *
     * @return An unmodifiable List of (ReferenceTarget; reference) tuples of references for the request.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaReferenceHasNoRefTargetException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference has no reference target</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference pointing to an invalid RefTarget</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if a reference has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     */
    @PublishedMethod
    IModelTupleList<REF_TARGET, PARAM> getManyRefTargetTuples();

    /**
     * Executes the model request and returns a list of (ReferenceTarget; reference) tuples, with the type defined by a TypeOperation (See {@link IMcaTypesafeRef TypeOperations}).
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<IModelTupleList<REF_TARGET, PARAM>> getManyRefTargetTuplesAsRequest();

    /**
     * Executes the model request and returns a single reference, with the type defined by a TypeOperation (See {@link IMcaRefWithoutType TypeOperations}).
     *
     * <p>
     * The requested reference must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IMcaTypesafeRef#getManyReferences() getManyReferences()} instead.
     * </p>
     *
     * @return The reference for the request
     *
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaNotExistsException
     * <ul>
     * <li>if no reference was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one reference value was found</li>
     * </ul>
     * @exception McaReferenceHasNoRefTargetException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference has no reference target</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference pointing to an invalid RefTarget</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     */
    @PublishedMethod
    @Override
    PARAM getReference();

    /**
     * Executes the model request and returns a single reference, with the type defined by a TypeOperation (See {@link IMcaRefWithoutType TypeOperations}).
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    IMcaRequest<PARAM> getReferenceAsRequest();

    /**
     * Executes the model request and returns a list of references, with the type defined by a TypeOperation (See {@link IMcaTypesafeRef TypeOperations}).
     *
     * <p>
     * If no reference was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if non or one
     * parameter was found.
     *
     * @return An unmodifiable List of references for the request.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaReferenceHasNoRefTargetException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference has no reference target</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if doNotCheckHasRefTarget() was not called and the reference pointing to an invalid RefTarget</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if a reference has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    List<PARAM> getManyReferences();

    /**
     * Executes the model request and returns a list of references, with the type defined by a TypeOperation (See {@link IMcaTypesafeRef TypeOperations}).
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    IMcaRequest<List<PARAM>> getManyReferencesAsRequest();

    /**
     * Disables the hasRefTarget check for this model request.
     *
     * <p>
     * If the the reference has no reference target, no {@link McaReferenceHasNoRefTargetException} is thrown.
     * </p>
     *
     * @return This model request interface
     *
     */
    @PublishedMethod
    IMcaTypesafeRef<REF_TARGET, PARAM> doNotCheckHasRefTarget();

    /**
     * Disables the hasRefTarget check for this model request.
     *
     * <p>
     * If the the reference has no reference target, no {@link McaReferenceWrongTargetDefinitionException} or {@link McaReferenceWrongTypeException} is thrown.
     * </p>
     *
     * @return This model request interface
     *
     */
    @PublishedMethod
    IMcaTypesafeRef<REF_TARGET, PARAM> doNotCheckIllegalRefTarget();

    /**
     * Disables the valid RefTargetDefinition check for this model request. E.g. No definition/Instance of the target is checked.
     *
     * <p>
     * If the the reference has no reference target, no {@link McaReferenceWrongTargetDefinitionException} is thrown.
     * </p>
     *
     * @return This model request interface
     *
     */
    @PublishedMethod
    IMcaTypesafeRef<REF_TARGET, PARAM> doNotCheckValidRefTargetDefinition();

}
