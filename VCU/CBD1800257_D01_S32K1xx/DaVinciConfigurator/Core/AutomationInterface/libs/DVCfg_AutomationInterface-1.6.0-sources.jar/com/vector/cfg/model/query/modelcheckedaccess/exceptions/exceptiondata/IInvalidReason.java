package com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata;

import javax.annotation.Nullable;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.text.log.IUserMessage;
import com.vector.cfg.util.text.mixedtext.IMixedText;

/**
 * {@link IInvalidReason} provides information why a request into the MDF model was invalid.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
@NotThreadSafe
public interface IInvalidReason extends IUserMessage {

    /**
     * Gets the parent MIObject, or <code>null</code>, if no parent was specified.
     *
     * @return The Parent MIObject, or <code>null</code>, if no parent was specified.
     */
    @PublishedMethod
    @Nullable
    MIObject getParent();

    /**
     * Gets the DefinitionRef of the requested model element/s, or <code>null</code>, if no DefRef is available.
     *
     * @return The DefinitionRef of the requested model element/s.
     */
    @PublishedMethod
    @Nullable
    DefRef getDefRef();

    /**
     * Gets the element MIObject, which has cause the problem, or <code>null</code>, if no element is available.
     *
     * @return The element MIObject, which has cause the problem, or <code>null</code>, if no element is available.
     */
    @PublishedMethod
    @Nullable
    MIObject getElement();

    /**
     * {@inheritDoc}
     *
     * <p>
     * Gets the user message of the invalid condition.
     * </p>
     */
    @Override
    @PublishedMethod
    IMixedText getUserMessage();

    /**
     * Gets the active model view during the model request.
     *
     * @return the active model view during request
     */
    @PublishedMethod
    IModelView getActiveModelViewDuringRequest();

}
