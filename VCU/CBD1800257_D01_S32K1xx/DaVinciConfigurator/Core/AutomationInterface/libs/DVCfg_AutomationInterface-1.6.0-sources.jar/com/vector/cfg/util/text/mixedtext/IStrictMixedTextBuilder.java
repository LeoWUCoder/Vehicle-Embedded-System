package com.vector.cfg.util.text.mixedtext;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.text.format.FormattingService;

/**
 * An {@link IStrictMixedTextBuilder} can be used to easily create text that consists of plain text and enhanced text representations of objects in the Cfg
 * environment. So basically you don't have to take care for formating and stringifying objects, but just append everything you want.
 *
 * <p>
 * Difference between {@link IMixedTextBuilder} and {@link IStrictMixedTextBuilder} is that {@link IStrictMixedTextBuilder} will not truncate or add any
 * additional characters like whitespaces. The text will be added as is. But the added object are still formatted.
 * </p>
 *
 * <p>
 * Example:
 *
 * <pre>
 * <code class="Java" id="IStrictMixedTextBuilder example">
 * 	IStrictMixedTextBuilder builder = MixedText.newStrictBuilder();
 *  builder.append("Hello: \"");
 *  builder.append(person);
 *   builder.append("\");
 *  builder.appendNl();
 *  builder.append("\tProperties:");
 *  builder.appendNl();
 *  builder.append("\t\tAge: ");
 *  builder.append(person.age);
 *  builder.appendNl();
 *  builder.append("\t\tGender: ");
 *  builder.append(person.gender);
 *
 *  // Resulting MixedText
 *  Hello: "John"
 *    Properties:
 *      Age: 28
 *      Gender: Male
 *
 *  //-------Compare-------
 *
 *  // Result for the normal IMixedTextBuilder would output with newlines on
 *  Hello: " John "
 *  Properties:
 *  Age:28
 *  Gender: Male
 *
 *  // Result for the normal IMixedTextBuilder with newlines off
 *  Hello: " John "Properties:Age: 28 Gender: Male
 *
 *
 * </code>
 * </pre>
 *
 *
 * <h5>Creation</h5> Create a new {@link IStrictMixedTextBuilder} with {@link MixedText#newStrictBuilder()}.
 *
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IStrictMixedTextBuilder extends IMixedTextBuilder {

    /**
     * Appends the constant text.
     *
     * <p>
     * Note: This method will not truncate any whitespace
     * </p>
     *
     * @param text to append
     * @return this builder
     */
    @Override
    @PublishedMethod
    IStrictMixedTextBuilder append(String text);

    /**
     * Appends the passed {@link Object} with default format information at the current builder position.
     *
     * <p>
     * This method will format many object types correctly. See {@link FormattingService} for details.
     * </p>
     *
     * @param object the object to append
     * @return this builder
     */
    @Override
    @PublishedMethod
    IStrictMixedTextBuilder append(Object object);

    /**
     * Appends the passed {@link Object} with the passed format information at the current builder position.
     *
     * <p>
     * This method will format many object types correctly. See {@link FormattingService} for details.
     * </p>
     *
     * @param object the object to append
     * @param formatPattern The formatPattern to format the object.
     * @return this builder
     */
    @Override
    @PublishedMethod
    IStrictMixedTextBuilder append(Object object, String formatPattern);

    /**
     * Appends a newline at the current position. The value depends on the platform NL type.
     *
     * @return this builder
     */
    @PublishedMethod
    IStrictMixedTextBuilder appendNl();

    /**
     * Appends another {@link IMixedText} to this {@link IStrictMixedTextBuilder}. All contained parts of the passed {@link IMixedText} items are appended and
     * no object or formatting information is swallowed.
     *
     * @return this builder
     */
    @Override
    @PublishedMethod
    IStrictMixedTextBuilder append(IMixedText mixedText);

    /**
     * Each format item takes the following form and consists of the following components:
     * <p>
     * <b>{index[:formatString]}</b> <br />
     * formatString = letter {letter | digit | _}*(','letter {letter | digit | _}*)* <br />
     * The matching braces ("{" and "}") are required.
     * </p>
     *
     * <p>
     * <b>Index Component</b><br />
     * The mandatory index component, also called a parameter specifier, is a number starting from 0 that identifies a corresponding item in the list of
     * objects. That is, the format item whose parameter specifier is 0 formats the first object in the list, the format item whose parameter specifier is 1
     * formats the second object in the list, and so on.
     *
     * Each format item can refer to any object in the list. For example, if there are three objects, you can format the second, first, and third object by
     * specifying a composite format string like this: "{1} {0} {2}". An object that is not referenced by a format item is ignored. A IllegalArgumentException
     * results if a parameter specifier designates an item outside the bounds of the list of objects.
     *
     *
     * <p>
     * <b>Format Options</b><br />
     * Formatting options are published and documented via classes that follow this naming convention MixedTextFormat*. Look out for classes with this name to
     * find formatting options for a particular object type.<br />
     * Exemplary Format Strings:<br />
     * <ul>
     * <li>MIParameterValue :
     * <ul>
     * <li>noValue</li>
     * <li>onlyValue</li>
     * </ul>
     * </li>
     * <li>IFormattable :
     * <ul>
     * <li>The Format pattern is passed to the Formattable object, so every object can implement its own Format options.</li>
     * </ul>
     * </li>
     * </ul>
     * </p>
     *
     * <p>
     * <b>Escaping Braces</b><br />
     * Opening and closing braces are interpreted as starting and ending a format item. Consequently, you must use an escape sequence to display a literal
     * opening brace or closing brace. Specify two opening braces ("{{") in the fixed text to display one opening brace ("{"), or two closing braces ("}}") to
     * display one closing brace ("}"). Braces in a format item are interpreted sequentially in the order they are encountered. Interpreting nested braces is
     * not supported.
     * </p>
     *
     * @param formatPattern A composite format string.
     * @param arguments An array of objects to format.
     * @return This builder
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the formatPattern is null</li>
     * <li>if the formatPattern is invalid</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    IStrictMixedTextBuilder appendFormat(String formatPattern, Object... arguments);

    /**
     * Builds a new {@link IMixedText} instance of this {@link IStrictMixedTextBuilder}.
     *
     * @return the new created {@link IMixedText}.
     */
    @PublishedMethod
    IMixedText build();

    /**
     * Returns true if and only if this {@link IStrictMixedTextBuilder}contains the specified sequence of char values.
     *
     * @param containedString the string to search for
     * @return true if this builder contains the string, false otherwise
     */
    @PublishedMethod
    boolean containsString(CharSequence containedString);

    /*
     * Old deprecated API
     */
    /**
     * {@inheritDoc}
     *
     * @deprecated The {@link IStrictMixedTextBuilder} does not support this API, is does not make sense in the strict mode. Please use {@link #append(String)}
     * instead.
     */
    @Override
    @Deprecated
    @PublishedMethod
    IMixedTextBuilder append(String text, boolean dontAddConnectingSpace);

    /**
     * Builds a new {@link IMixedText} instance of this {@link IStrictMixedTextBuilder}.
     *
     * @return the new created {@link IMixedText}.
     */
    @Override
    @PublishedMethod
    IMixedText flushResult();

    /**
     * {@inheritDoc}
     *
     * @deprecated The {@link IStrictMixedTextBuilder} does not support this API, is does not make sense in the strict mode. Please use
     * {@link #append(IMixedText)} instead.
     */
    @Override
    @Deprecated
    @PublishedMethod
    IMixedTextBuilder append(IMixedText mixedText, boolean dontAddConnectingSpace);

}
