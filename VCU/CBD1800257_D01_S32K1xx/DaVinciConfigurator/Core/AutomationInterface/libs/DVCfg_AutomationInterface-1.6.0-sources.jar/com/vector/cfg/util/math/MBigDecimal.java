package com.vector.cfg.util.math;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import java.io.InvalidObjectException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.math.RoundingMode;

import com.google.common.collect.ImmutableMap;
import com.vector.annotations.obfuscation.Keep;
import com.vector.annotations.obfuscation.KeepName;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.math.SpecialMBigDecimal.NaNBigDecimal;
import com.vector.cfg.util.math.SpecialMBigDecimal.NegInfBigDecimal;
import com.vector.cfg.util.math.SpecialMBigDecimal.PosInfBigDecimal;

/**
 * A {@link MBigDecimal} provides the same functionality as {@link BigDecimal}, but could also have the following values:<br />
 * <ul>
 * <li>NaN</li>
 * <li>INF</li>
 * <li>-INF</li>
 * </ul>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@SuppressWarnings("restriction")
@Keep
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class MBigDecimal extends BigDecimal {
    private static final long serialVersionUID = -2114017373145698210L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(MBigDecimal.class);

    private static final int RADIX_BIN = 2;

    private static final int RADIX_OCT = 8;

    private static final int RADIX_HEX = 16;

    /**
     * A constant holding the positive infinity of type {@code MBigDecimal}.
     */
    @PublishedField
    public static final MBigDecimal POSITIVE_INFINITY = new PosInfBigDecimal();

    /**
     * A constant holding the negative infinity of type {@code MBigDecimal}.
     */
    @PublishedField
    public static final MBigDecimal NEGATIVE_INFINITY = new NegInfBigDecimal();

    /**
     * A constant holding a Not-a-Number (NaN) value of type {@code MBigDecimal}.
     */
    @PublishedField
    // CHECKSTYLE:OFF The field NaN should be called as NaN, because in the MBigDecimal class the field also is NaN not NAN.
    public static final MBigDecimal NaN = new NaNBigDecimal(); // CHECKSTYLE:ON

    // Constants
    /**
     * The value 0, with a scale of 0.
     *
     */
    @PublishedField
    public static final MBigDecimal ZERO = new MBigDecimal(0);

    /**
     * The value 1, with a scale of 0.
     */
    @PublishedField
    public static final MBigDecimal ONE = new MBigDecimal(1);

    @PublishedField
    public static final MBigDecimal NEGATIVE_ONE = new MBigDecimal(-1);

    /**
     * The value 10, with a scale of 0.
     */
    @PublishedField
    public static final MBigDecimal TEN = new MBigDecimal(10);

    /**
     * Cache for well known {@link MBigDecimal} instances.
     */
    private static final ImmutableMap<MBigDecimal, MBigDecimal> valueCache;

    private static final MBigDecimal[] zeroThroughTen;

    private static final int CACHE_ZERO_TO_TEN_ARRAY_SIZE = 11;

    /*
     * Unsafe fields to clone BigDecimal instances.
     */
    private static final sun.misc.Unsafe UNSAFE;

    private static final long intValOffset;

    private static final long intCompactOffset;

    private static final long scaleOffset;

    private static final long stringCacheOffset;

    private static final long precisionOffset;

    private static sun.misc.Unsafe getUnsafe() {
        try {
            final java.lang.reflect.Field fld = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
            fld.setAccessible(true);
            return (sun.misc.Unsafe) fld.get(MBigDecimal.class);
        } catch (final Exception e) {
            throw new RuntimeException("Could not retrieve sun.misc.Unsafe", e);
        }
    }

    /**
     * Static initializer of class MBigDecimal
     */
    static {
        zeroThroughTen = new MBigDecimal[CACHE_ZERO_TO_TEN_ARRAY_SIZE];
        final ImmutableMap.Builder<MBigDecimal, MBigDecimal> builder = ImmutableMap.builder();
        builder.put(NEGATIVE_ONE, NEGATIVE_ONE);

        builder.put(ZERO, ZERO);
        zeroThroughTen[0] = ZERO;

        builder.put(ONE, ONE);
        zeroThroughTen[1] = ONE;

        builder.put(TEN, TEN);
        zeroThroughTen[10] = TEN;

        for (int x = 2; x < 10; x++) {
            final MBigDecimal val = new MBigDecimal(x);
            builder.put(val, val);
            zeroThroughTen[x] = val;
        }
        valueCache = builder.build();

        /*
         * Unsafe section for cloning BigDecimal instances.
         */
        UNSAFE = getUnsafe();
        try {
            intValOffset = UNSAFE.objectFieldOffset(BigDecimal.class.getDeclaredField("intVal"));
            intCompactOffset = UNSAFE.objectFieldOffset(BigDecimal.class.getDeclaredField("intCompact"));
            scaleOffset = UNSAFE.objectFieldOffset(BigDecimal.class.getDeclaredField("scale"));
            stringCacheOffset = UNSAFE.objectFieldOffset(BigDecimal.class.getDeclaredField("stringCache"));
            precisionOffset = UNSAFE.objectFieldOffset(BigDecimal.class.getDeclaredField("precision"));
        } catch (NoSuchFieldException | SecurityException ex) {
            throw new RuntimeException("Could not evaluate BigDecimal fields.", ex);
        }

    }

    /**
     * Returns a new {@code BigDecimal} initialized to the value represented by the specified {@code String}, as performed by {@link BigDecimal#BigDecimal(String)}.
     *
     * @param s the string to be parsed.
     * @param mc the {@link MathContext} to use.
     * @return the {@code BigDecimal} value represented by the string argument.
     * @throws NullPointerException if the string is null
     * @throws NumberFormatException if the string does not contain a parsable {@code MBigDecimal}.
     * @see com.vector.cfg.util.math.MBigDecimal#valueOf(double)
     */
    private static MBigDecimal parseBigDecimal(final String s, MathContext mc) {
        checkNotNull(s);
        checkArgument(!s.isEmpty(), "Cannot parse a MBigDecimal value from empty string.");
        final String src = s.trim();

        if (src.equals(".0")) {
            return MBigDecimal.ZERO;
        } else if (src.equalsIgnoreCase(NaNBigDecimal.NAME)) {
            return NaN;
        } else if (src.equalsIgnoreCase(PosInfBigDecimal.NAME) || src.equalsIgnoreCase(PosInfBigDecimal.NAME2)
                || src.equalsIgnoreCase("Infinity") /* We have to parse the Java Double INF constant also! */ || src.equalsIgnoreCase("+Infinity")) {
            return POSITIVE_INFINITY;
        } else if (src.equalsIgnoreCase(NegInfBigDecimal.NAME) || src.equalsIgnoreCase("-Infinity")/* We have to parse the Java Double -INF constant also! */) {
            return NEGATIVE_INFINITY;
        }

        MBigDecimal mBigDecimal = parseBigDecimalFromAutosarHexBinOctFormat(src, mc);
        if (mBigDecimal != null) {
            return mBigDecimal;
        }
        mBigDecimal = new MBigDecimal(src, mc);
        return valueCacheGetOrDefault(mBigDecimal, mBigDecimal);
    }

    /**
     * The AUTOSAR standard actually uses two different types of float values:
     * <ul>
     * <li><b>xsd.double</b> which are double (64 bits) floating-point numbers as defined by the IEEE. This type supports INF, -INF and NaN but no binary, octal or hex values. It
     * is being used e.g. in "BSW-TIMING-EVENT" field "PERIOD" which has type "TIME-VALUE--SIMPLE".</li>
     * <li><b>Primitive type Numerical</b> with
     * xsd.pattern="(0x[0-9a-f]+)|(0[0-7]+)|(0b[0-1]+)|(([+\-]?[1-9][0-9]+(\.[0-9]+)?|[+\-]?[0-9](\.[0-9]+)?)(E([+\-]?)[0-9]+)?)|\.0|INF|-INF|NaN". See
     * AUTOSAR_TPS_GenericStructureTemplate.pdf version 4.0.3, chapter 4.7 "Primitive Types", Type "Numerical"</li>
     * </ul>
     *
     * @param text
     * @param mc the {@link MathContext} to use.
     * @return the res
     */
    private static MBigDecimal parseBigDecimalFromAutosarHexBinOctFormat(String text, MathContext mc) {
        final char c0 = text.charAt(0);
        if (c0 == '0') {
            if (text.length() >= 2) {
                final char c1 = Character.toLowerCase(text.charAt(1));
                if (c1 == 'x') {
                    text = text.substring(2); // Remove prefix
                    if (text.isEmpty()) {
                        // Special case to handle AUTOSAR 4.0.3 regular expression errors in the schema (allows "0x")
                        return MBigDecimal.ZERO;
                    }
                    return parseBigDecimalByRadix(text, RADIX_HEX, mc);
                } else if (c1 == 'b') {
                    text = text.substring(2); // Remove prefix
                    if (text.isEmpty()) {
                        // Special case to handle AUTOSAR 4.0.3 regular expression errors in the schema (allows "0b")
                        return MBigDecimal.ZERO;
                    }
                    return parseBigDecimalByRadix(text, RADIX_BIN, mc);
                } else {
                    // Do not accept Octal values containing . e or E
                    if (text.indexOf('.') == -1) {
                        if (text.indexOf('e') == -1) {
                            if (text.indexOf('E') == -1) {
                                return parseBigDecimalByRadix(text, RADIX_OCT, mc);
                            }
                        }
                    }
                }
            } else {
                return MBigDecimal.ZERO;
            }
        }

        return null;
    }

    private static MBigDecimal parseBigDecimalByRadix(final String text, final int radix, MathContext mc) {
        final BigInteger bigInteger = new BigInteger(text, radix);
        final MBigDecimal value = MBigDecimal.valueOf(bigInteger, mc);
        return value;
    }

    /**
     * Returns a new {@code BigDecimal} initialized to the value represented by the specified {@code String}, as performed by {@link BigDecimal#BigDecimal(String)}.
     *
     * @param s the {@link BigDecimal} to be converted to an {@link MBigDecimal}
     * @return the {@code BigDecimal} value represented by the string argument.
     * @throws NullPointerException if the s is null
     */
    @PublishedMethod
    public static MBigDecimal valueOf(final BigDecimal s) {
        checkNotNull(s);
        if (s instanceof MBigDecimal) {
            return (MBigDecimal) s;
        }
        return createMFromBig(s);
    }

    /**
     * Returns a new {@code BigDecimal} initialized to the value represented by the specified {@code String}, as performed by {@link BigDecimal#BigDecimal(String)}.
     *
     * @param s the string to be parsed.
     * @return the {@code BigDecimal} value represented by the string argument.
     * @throws NullPointerException if the string is null
     * @throws NumberFormatException if the string does not contain a parsable {@code MBigDecimal}.
     * @see com.vector.cfg.util.math.MBigDecimal#valueOf(String)
     */
    @PublishedMethod
    public static MBigDecimal valueOf(final String s) {
        return parseBigDecimal(s, MathContext.UNLIMITED);
    }

    /**
     * Returns a new {@code BigDecimal} initialized to the value represented by the specified {@code String}, as performed by {@link BigDecimal#BigDecimal(String)}.
     *
     * @param s the string to be parsed.
     * @param mc the {@link MathContext} to use.
     * @return the {@code BigDecimal} value represented by the string argument.
     * @throws NullPointerException if the string is null
     * @throws NumberFormatException if the string does not contain a parsable {@code MBigDecimal}.
     * @see com.vector.cfg.util.math.MBigDecimal#valueOf(String)
     */
    @PublishedMethod
    public static MBigDecimal valueOf(final String s, MathContext mc) {
        return parseBigDecimal(s, mc);
    }

    /**
     * Translates a {@code double} into a {@code MBigDecimal}, using the {@code double}'s canonical string representation provided by the {@link Double#toString(double)} method.
     *
     * <p>
     * <b>Note:</b> This is generally the preferred way to convert a {@code double} (or {@code float}) into a {@code BigDecimal}, as the value returned is equal to that resulting
     * from constructing a {@code BigDecimal} from the result of using {@link Double#toString(double)}.
     *
     * @param val {@code double} to convert to a {@code BigDecimal}.
     * @return a {@code BigDecimal} whose value is equal to or approximately equal to the value of {@code val}.
     * @throws NumberFormatException if {@code val} is infinite or NaN.
     */
    @PublishedMethod
    public static MBigDecimal valueOf(final double val) {
        return valueOf(Double.toString(val));
    }

    /**
     * Translates a {@code double} into a {@code BigDecimal}, with rounding according to the context settings. The scale of the {@code BigDecimal} is the smallest value such that
     * <tt>(10<sup>scale</sup> &times; val)</tt> is an integer.
     *
     * <p>
     * The results of this constructor can be somewhat unpredictable and its use is generally not recommended; see the notes under the {@link #BigDecimal(double)} constructor.
     *
     * @param val {@code double} value to be converted to {@code BigDecimal}.
     * @param mc the context to use.
     * @throws ArithmeticException if the result is inexact but the RoundingMode is UNNECESSARY.
     * @throws NumberFormatException if {@code val} is infinite or NaN.
     */
    @PublishedMethod
    public static MBigDecimal valueOf(double val, MathContext mc) {
        return valueOf(Double.toString(val), mc);
    }

    /**
     * Translates an {@code int} into a {@code BigDecimal}. The scale of the {@code BigDecimal} is zero.
     *
     * @param val {@code int} value to be converted to {@code BigDecimal}.
     */
    @PublishedMethod
    public static MBigDecimal valueOf(int val) {
        if (val >= 0 && val < zeroThroughTen.length) {
            return zeroThroughTen[val];
        }

        final MBigDecimal mBigDecimal = new MBigDecimal(val);
        return valueCacheGetOrDefault(mBigDecimal, mBigDecimal);
    }

    /**
     * Translates a {@code long} value into a {@code BigDecimal} with a scale of zero. This {@literal "static factory method"} is provided in preference to a ( {@code long})
     * constructor because it allows for reuse of frequently used {@code BigDecimal} values.
     *
     * @param val value of the {@code BigDecimal}.
     * @return a {@code BigDecimal} whose value is {@code val}.
     */
    @PublishedMethod
    public static MBigDecimal valueOf(long val) {
        if (val >= 0 && val < zeroThroughTen.length) {
            return zeroThroughTen[(int) val];
        }

        final MBigDecimal mBigDecimal = new MBigDecimal(val);
        return valueCacheGetOrDefault(mBigDecimal, mBigDecimal);
    }

    /**
     * Translates a {@code BigInteger} into a {@code MBigDecimal} rounding according to the context settings. The scale of the {@code MBigDecimal} is zero.
     *
     * @param val {@code BigInteger} value to be converted to {@code MBigDecimal}.
     * @param mc the context to use.
     * @throws ArithmeticException if the result is inexact but the rounding mode is {@code UNNECESSARY}.
     */
    @PublishedMethod
    public static MBigDecimal valueOf(BigInteger val) {
        final MBigDecimal mBigDecimal = new MBigDecimal(val);
        return valueCacheGetOrDefault(mBigDecimal, mBigDecimal);
    }

    /**
     * Translates a {@code BigInteger} unscaled value and an {@code int} scale into a {@code BigDecimal}. The value of the {@code BigDecimal} is
     * <tt>(unscaledVal &times; 10<sup>-scale</sup>)</tt>.
     *
     * @param unscaledVal unscaled value of the {@code BigDecimal}.
     * @param scale scale of the {@code BigDecimal}.
     */
    @PublishedMethod
    public static MBigDecimal valueOf(BigInteger unscaledVal, int scale) {
        final MBigDecimal mBigDecimal = new MBigDecimal(unscaledVal, scale);
        return valueCacheGetOrDefault(mBigDecimal, mBigDecimal);
    }

    /**
     * Translates a {@code BigInteger} unscaled value and an {@code int} scale into a {@code MBigDecimal}, with rounding according to the context settings. The value of the
     * {@code MBigDecimal} is <tt>(unscaledVal &times;
     * 10<sup>-scale</sup>)</tt>, rounded according to the {@code precision} and rounding mode settings.
     *
     * @param unscaledVal unscaled value of the {@code MBigDecimal}.
     * @param scale scale of the {@code BigDecimal}.
     * @param mc the context to use.
     * @throws ArithmeticException if the result is inexact but the rounding mode is {@code UNNECESSARY}.
     */
    @PublishedMethod
    public static MBigDecimal valueOf(BigInteger unscaledVal, int scale, MathContext mc) {
        return new MBigDecimal(unscaledVal, scale, mc);
    }

    /**
     * Translates a {@code BigInteger} into a {@code MBigDecimal} rounding according to the context settings. The scale of the {@code MBigDecimal} is zero.
     *
     * @param val {@code BigInteger} value to be converted to {@code MBigDecimal}.
     * @param mc the context to use.
     * @throws ArithmeticException if the result is inexact but the rounding mode is {@code UNNECESSARY}.
     */
    @PublishedMethod
    public static MBigDecimal valueOf(BigInteger val, MathContext mc) {
        return new MBigDecimal(val, mc);
    }

    /**
     * Translates an {@code int} into a {@code MBigDecimal}, with rounding according to the context settings. The scale of the {@code MBigDecimal}, before any rounding, is zero.
     *
     * @param val {@code int} value to be converted to {@code MBigDecimal}.
     * @param mc the context to use.
     * @throws ArithmeticException if the result is inexact but the rounding mode is {@code UNNECESSARY}.
     */
    @PublishedMethod
    public static MBigDecimal valueOf(int val, MathContext mc) {
        return new MBigDecimal(val, mc);
    }

    /**
     * Translates a {@code long} into a {@code MBigDecimal}, with rounding according to the context settings. The scale of the {@code MBigDecimal}, before any rounding, is zero.
     *
     * @param val {@code long} value to be converted to {@code MBigDecimal}.
     * @param mc the context to use.
     * @throws ArithmeticException if the result is inexact but the rounding mode is {@code UNNECESSARY}.
     */
    @PublishedMethod
    public static MBigDecimal valueOf(long val, MathContext mc) {
        return new MBigDecimal(val, mc);
    }

    /*
     * ----------------------------------------------- MBigDecimal Section -----------------------------------------------
     */

    private MBigDecimal(BigInteger val) {
        super(val);
    }

    private MBigDecimal(BigInteger unscaledVal, int scale) {
        super(unscaledVal, scale);
    }

    private MBigDecimal(double val, MathContext mc) {
        super(val, mc);
    }

    private MBigDecimal(double val) {
        super(val);
    }

    private MBigDecimal(int val) {
        super(val);
    }

    private MBigDecimal(long val) {
        super(val);
    }

    private MBigDecimal(String val, MathContext mc) {
        super(val, mc);
    }

    private MBigDecimal(BigInteger unscaledVal, int scale, MathContext mc) {
        super(unscaledVal, scale, mc);
    }

    private MBigDecimal(BigInteger val, MathContext mc) {
        super(val, mc);
    }

    private MBigDecimal(int val, MathContext mc) {
        super(val, mc);
    }

    private MBigDecimal(long val, MathContext mc) {
        super(val, mc);
    }

    MBigDecimal(final String bigDecimalValue) {
        super(bigDecimalValue);
    }

    private static MBigDecimal valueCacheGetOrDefault(MBigDecimal key, MBigDecimal defaultValue) {
        final MBigDecimal v = valueCache.get(key);
        return ((v != null) || valueCache.containsKey(key))
                ? v
                : defaultValue;
    }

    /**
     * Creates a {@link MBigDecimal} by copying all data fields from the passed {@link BigDecimal} into the new created {@link MBigDecimal} instance.
     *
     * <p>
     * This method uses the Unsafe class to read and writer private final fields. This shall ensure, that the {@link MBigDecimal} returns {@link MBigDecimal} with the exact same
     * content as the passed {@link BigDecimal} instance.
     *
     * @param src the src
     * @return the m big decimal
     */
    private static MBigDecimal createMFromBig(BigDecimal src) {
        final MBigDecimal newVal = new MBigDecimal(0);
        UNSAFE.putObject(newVal, intValOffset, UNSAFE.getObject(src, intValOffset));
        UNSAFE.putInt(newVal, scaleOffset, UNSAFE.getInt(src, scaleOffset));
        UNSAFE.putInt(newVal, precisionOffset, UNSAFE.getInt(src, precisionOffset));
        UNSAFE.putLong(newVal, intCompactOffset, UNSAFE.getLong(src, intCompactOffset));
        // The last put is volatile to guarantee visibility of the previous put statements and the next one of an x86 platform.
        // No Volatile read required => No Store/Load barrier is needs on x86 arch, so it is correct that the field in BigDecimal is not marked as volatile.
        // See http://gee.cs.oswego.edu/dl/jmm/cookbook.html for Store/Load barriers
        UNSAFE.putObjectVolatile(newVal, stringCacheOffset, UNSAFE.getObject(src, stringCacheOffset));

        return valueCacheGetOrDefault(newVal, newVal);
    }

    private MBigDecimal[] createMFromBigArray(BigDecimal[] divideAndRemainder) {

        final MBigDecimal[] ar = new MBigDecimal[2];
        ar[0] = createMFromBig(divideAndRemainder[0]);
        ar[1] = createMFromBig(divideAndRemainder[1]);
        return ar;
    }

    private void checkOperand(BigDecimal other) {
        this.checkOperand();
        if (other instanceof SpecialMBigDecimal) {
            ((SpecialMBigDecimal) other).notSupported();
        }
    }

    private void checkOperand() {
        if (this instanceof SpecialMBigDecimal) {
            ((SpecialMBigDecimal) this).notSupported();
        }
    }

    /*
     * Public MBigDecimal Interface
     */

    /**
     * Returns {@code true} if this {@code MBigDecimal} value is a Not-a-Number (NaN), {@code false} otherwise.
     *
     * @return {@code true} if the value represented by this object is NaN; {@code false} otherwise.
     */
    @PublishedMethod
    public boolean isNaN() {
        return false;
    }

    /**
     * Returns {@code true} if this {@code MBigDecimal} value is infinitely large in magnitude, {@code false} otherwise.
     *
     * @return {@code true} if the value represented by this object is positive infinity or negative infinity; {@code false} otherwise.
     */
    @PublishedMethod
    public boolean isInfinite() {
        return false;
    }

    /**
     * Returns {@code true} if the specified number is a Not-a-Number (NaN) value, {@code false} otherwise.
     *
     * @param v the value to be tested.
     * @return {@code true} if the value of the argument is NaN; {@code false} otherwise.
     */
    @PublishedMethod
    public static boolean isNaN(final BigDecimal v) {
        checkNotNull(v);
        if (v instanceof MBigDecimal) {
            return ((MBigDecimal) v).isNaN();
        }
        return false;
    }

    /**
     * Returns {@code true} if the specified number is infinitely large in magnitude, {@code false} otherwise.
     *
     * @param v the value to be tested.
     * @return {@code true} if the value of the argument is positive infinity or negative infinity; {@code false} otherwise.
     */
    @PublishedMethod
    public static boolean isInfinite(final BigDecimal v) {
        checkNotNull(v);
        if (v instanceof MBigDecimal) {
            return ((MBigDecimal) v).isInfinite();
        }
        return false;

    }

    /**
     *
     * Compares two {@code MBigDecimal} objects numerically. There are two ways in which comparisons performed by this method differ from those performed by the Java language
     * numerical comparison operators (&lt;, &lt;=, ==, &gt;=, &gt;) when applied to primitive {@code double} values:
     * <ul>
     * <li>{@code MBigDecimal.NaN} is considered by this method to be equal to itself and greater than all other {@code MBigDecimal} values (including
     * {@code MBigDecimal.POSITIVE_INFINITY}).
     * <li>{@code 0.0d} is considered by this method to be greater than {@code -0.0d}.
     * </ul>
     * This ensures that the <i>natural ordering</i> of {@code MBigDecimal} objects imposed by this method is <i>consistent with equals</i>.
     *
     * @param val {@code MBigDecimal} to which this {@code BigDecimal} is to be compared.
     * @return -1, 0, or 1 as this {@code MBigDecimal} is numerically less than, equal to, or greater than {@code val}.
     */
    @Override
    @PublishedMethod
    public final int compareTo(final BigDecimal val) {
        if (this == val) {
            return 0;
        }
        if (val == NaN) {
            // All Values are smaller than NaN
            return -1;
        }
        if (this == NaN) {
            // All Values are smaller than NaN
            return 1;
        }
        if (val == POSITIVE_INFINITY) {
            // All Values are smaller than POSITIVE_INFINITY except NaN
            return -1;
        }
        if (this == POSITIVE_INFINITY) {
            // All Values are smaller than POSITIVE_INFINITY except NaN
            return 1;
        }
        if (val == NEGATIVE_INFINITY) {
            // All Values are greater than NEGATIVE_INFINITY except NaN
            return 1;
        }
        if (this == NEGATIVE_INFINITY) {
            // All Values are greater than NEGATIVE_INFINITY except NaN
            return -1;
        }

        return super.compareTo(val);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public final boolean equals(Object x) {
        if (x == null) {
            return false;
        }
        if (this == x) {
            return true;
        }
        if (x == NaN || x == POSITIVE_INFINITY || x == NEGATIVE_INFINITY) {
            /*
             * If the elements are both one of the literals above, the check for this == x, above would already returned true
             */
            return false;
        }

        return super.equals(x);
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Note: MBigDecimal.hashCode() doesn't require special handling for NaN, INF and -INF, because they are special values but also valid BigDecimal values. So they have a defined
     * hashcode values from the base implementation.
     * </p>
     */
    @Override
    public final int hashCode() {
        return super.hashCode();
    }

    /*
     * BigDecimal API
     */
    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal add(BigDecimal augend) {
        checkOperand(augend);
        return createMFromBig(super.add(augend));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal add(BigDecimal augend, MathContext mc) {
        checkOperand(augend);
        return createMFromBig(super.add(augend, mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal subtract(BigDecimal subtrahend) {
        checkOperand(subtrahend);
        return createMFromBig(super.subtract(subtrahend));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal subtract(BigDecimal subtrahend, MathContext mc) {
        checkOperand(subtrahend);
        return createMFromBig(super.subtract(subtrahend, mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal multiply(BigDecimal multiplicand) {
        checkOperand(multiplicand);
        return createMFromBig(super.multiply(multiplicand));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal multiply(BigDecimal multiplicand, MathContext mc) {
        checkOperand(multiplicand);
        return createMFromBig(super.multiply(multiplicand, mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal divide(BigDecimal divisor, int scale, int roundingMode) {
        checkOperand(divisor);
        return createMFromBig(super.divide(divisor, scale, roundingMode));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal divide(BigDecimal divisor, int scale, RoundingMode roundingMode) {
        checkOperand(divisor);
        return createMFromBig(super.divide(divisor, scale, roundingMode));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal divide(BigDecimal divisor, int roundingMode) {
        checkOperand(divisor);
        return createMFromBig(super.divide(divisor, roundingMode));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal divide(BigDecimal divisor, RoundingMode roundingMode) {
        checkOperand(divisor);
        return createMFromBig(super.divide(divisor, roundingMode));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal divide(BigDecimal divisor) {
        checkOperand(divisor);
        return createMFromBig(super.divide(divisor));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal divide(BigDecimal divisor, MathContext mc) {
        checkOperand(divisor);
        return createMFromBig(super.divide(divisor, mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal divideToIntegralValue(BigDecimal divisor) {
        checkOperand(divisor);
        return createMFromBig(super.divideToIntegralValue(divisor));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal divideToIntegralValue(BigDecimal divisor, MathContext mc) {
        checkOperand(divisor);
        return createMFromBig(super.divideToIntegralValue(divisor, mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal remainder(BigDecimal divisor) {
        checkOperand(divisor);
        return createMFromBig(super.remainder(divisor));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal remainder(BigDecimal divisor, MathContext mc) {
        checkOperand(divisor);
        return createMFromBig(super.remainder(divisor, mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal[] divideAndRemainder(BigDecimal divisor) {
        checkOperand(divisor);
        return createMFromBigArray(super.divideAndRemainder(divisor));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal[] divideAndRemainder(BigDecimal divisor, MathContext mc) {
        checkOperand(divisor);
        return createMFromBigArray(super.divideAndRemainder(divisor, mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal min(BigDecimal val) {
        checkOperand(val);
        return createMFromBig(super.min(val));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal max(BigDecimal val) {
        checkOperand(val);
        return createMFromBig(super.max(val));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal pow(int n) {
        checkOperand();
        return createMFromBig(super.pow(n));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal pow(int n, MathContext mc) {
        checkOperand();
        return createMFromBig(super.pow(n, mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal abs() {
        checkOperand();
        return createMFromBig(super.abs());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal abs(MathContext mc) {
        checkOperand();
        return createMFromBig(super.abs(mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal negate() {
        checkOperand();
        return createMFromBig(super.negate());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal negate(MathContext mc) {
        checkOperand();
        return createMFromBig(super.negate(mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal plus() {
        checkOperand();
        return createMFromBig(super.plus());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal plus(MathContext mc) {
        checkOperand();
        return createMFromBig(super.plus(mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal round(MathContext mc) {
        checkOperand();
        return createMFromBig(super.round(mc));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal setScale(int newScale, RoundingMode roundingMode) {
        checkOperand();
        return createMFromBig(super.setScale(newScale, roundingMode));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal setScale(int newScale, int roundingMode) {
        checkOperand();
        return createMFromBig(super.setScale(newScale, roundingMode));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal setScale(int newScale) {
        checkOperand();
        return createMFromBig(super.setScale(newScale));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal movePointLeft(int n) {
        checkOperand();
        return createMFromBig(super.movePointLeft(n));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal movePointRight(int n) {
        checkOperand();
        return createMFromBig(super.movePointRight(n));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal scaleByPowerOfTen(int n) {
        checkOperand();
        return createMFromBig(super.scaleByPowerOfTen(n));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal stripTrailingZeros() {
        checkOperand();
        return createMFromBig(super.stripTrailingZeros());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public MBigDecimal ulp() {
        checkOperand();
        return createMFromBig(super.ulp());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public int signum() {
        checkOperand();
        return super.signum();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public int scale() {
        checkOperand();
        return super.scale();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public BigInteger unscaledValue() {
        checkOperand();
        return super.unscaledValue();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public int precision() {
        checkOperand();
        return super.precision();
    }

    /*
     * --------------------------------------------------------- Serialization ---------------------------------------------------------
     */
    /**
     * This class is used to serialize all {@link MBigDecimal} instances, regardless of implementation type. It captures their "logical contents" and they are MBigDecimal using
     * public static factories. This is necessary to ensure that the existence of a particular implementation type is an implementation detail.
     *
     */
    @Keep
    @PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
    private static class SerializationProxy<E extends MBigDecimal> implements java.io.Serializable {

        private static final long serialVersionUID = 7275373216237289550L;

        private final String name;

        SerializationProxy(final MBigDecimal val) {
            name = val.toString();
        }

        private Object readResolve() {
            final MBigDecimal parsedBigDecimal = MBigDecimal.valueOf(name);
            return parsedBigDecimal;
        }

    }

    @KeepName
    Object writeReplace() {
        return new SerializationProxy<>(this);
    }

    /**
     * Read object.
     *
     * @param stream the stream
     * @throws InvalidObjectException the invalid object exception
     */
    // readObject method for the serialization proxy pattern
    // See Effective Java, Second Ed., Item 78.
    private void readObject(final java.io.ObjectInputStream stream) throws java.io.InvalidObjectException {
        throw new java.io.InvalidObjectException("Proxy required");
    }

    /*
     * --------------------------------------------------------- Big Decimal Implementation -----------------------------------------------------------
     */

}
