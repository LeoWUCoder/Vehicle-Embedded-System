package com.vector.cfg.model.query.modelcheckedaccess.exceptions;

import java.util.Collections;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IInvalidParentForDefinitionExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaInvalidParentForDefinitionException extends McaException {

    private static final long serialVersionUID = 6776584904050833528L;

    private final IInvalidParentForDefinitionExData exData;

    /**
     * Constructor for McaParameterWrongTypeException.
     *
     * @param wrongTypeExDataList
     */
    @PublishedMethod
    public McaInvalidParentForDefinitionException(IInvalidParentForDefinitionExData exData) {
        super(Collections.singletonList(exData));
        this.exData = exData;
    }

    /**
     * Gets a {@link IInvalidParentForDefinitionExData} object with detailed information about the exception cause.
     *
     * @return The exception cause data object
     */
    @PublishedMethod
    @Override
    public IInvalidParentForDefinitionExData getExceptionData() {
        return exData;
    }

}
