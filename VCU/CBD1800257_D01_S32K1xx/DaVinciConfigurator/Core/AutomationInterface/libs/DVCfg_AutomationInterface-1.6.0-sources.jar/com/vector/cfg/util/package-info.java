/**
 * Basic utility of the DaVinci Configurator. Main class {@link com.vector.cfg.util.IProjectContext} which represents a loaded project internally.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util;