package com.vector.cfg.model.query.modelcheckedaccess;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.enums.IModelEnum;
import com.vector.cfg.model.enums.ModelEnumUtil;
import com.vector.cfg.model.exceptions.ModelCeHasNoDefinitionException;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfContainerDef;
import com.vector.cfg.model.query.modelcheckedaccess.elements.EElementType;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaInvalidRequestException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.params.IParamHasIllegalValueExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.params.IParamHasNoValueExData;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterHasIllegalValueException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterHasNoValueException;
import com.vector.cfg.model.query.modelcheckedaccess.internal.ModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.internal.ModelCheckedAccessInternalUtil;
import com.vector.cfg.model.query.modelcheckedaccess.internal.exceptiondata.InvalidRequestExData;
import com.vector.cfg.model.query.modelcheckedaccess.internal.exceptiondata.params.ParamHasIllegalExData;
import com.vector.cfg.model.query.modelcheckedaccess.internal.exceptiondata.params.ParamHasNoValueExData;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public final class ModelCheckedAccessUtil {

    private static final ILogger logger = Logger.INSTANCE.createLogger(ModelCheckedAccessUtil.class);

    private ModelCheckedAccessUtil() {

    }

    /**
     * Gets the java enum value object by an {@link MITextualValue} and the JavaEnum class object.
     *
     * @param <T> the generic type
     * @param param the model parameter
     * @param enumType the class object of the enum type to which should be converted.
     * @return An enum object of the type enumType.
     *
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if the param value has no representation in the Java enum.</li>
     * </ul>
     * @see ModelEnumUtil
     * @see IModelEnum
     */
    @PublishedMethod
    public static <T extends Enum<T>> T getJavaEnumValueByMdfObject(MITextualValue param, Class<T> enumType) {

        String paramValue = ModelUtil.getValueString(param);
        assertParamHasValue(param, paramValue);

        if (paramValue != null && !paramValue.isEmpty()) {
            final T value = ModelEnumUtil.getEnumLiteralFromAutosarValue(paramValue, enumType);

            if (value != null) {
                return value;
            }
        }

        // Illegal Enum Literal found => Report it
        if (paramValue == null || paramValue.isEmpty()) {
            paramValue = "<empty>";
        }
        final List<IParamHasIllegalValueExData> list = new ArrayList<>();
        list.add(new ParamHasIllegalExData(param.getParent(), param, param.getDefinitionRef().getRefTarget(), paramValue, ModelEnumUtil.getValidValues(enumType)));
        throw new McaParameterHasIllegalValueException(list);

    }

    /**
     * Returns the internal parameter value representation of Enum parameters.
     *
     * <p>
     * <b>CAUTION:</b> Please do NOT use this method. Instead use {@link IModelAccess#getValueString(com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue)}. This
     * method is only for internal purpose!
     * </p>
     *
     * @param param
     * @return
     */
    @PublishedMethod
    public static String getValueStringForEnumParameter(final MITextualValue param) {
        return ModelUtil.getValueString(param);
    }

    private static void assertParamHasValue(MIParameterValue param, String value) {

        if (value == null) {
            final List<IParamHasNoValueExData> list = new ArrayList<>();
            list.add(new ParamHasNoValueExData(param.getParent(), param, param.getDefinitionRef().getRefTarget()));
            throw new McaParameterHasNoValueException(list);
        }

    }

    /**
     * This Method only supports INTEGER SymbolicNameParameter.<br/>
     * The passed container is used to find the corresponding SymbolicNameParameter of type integer. The symbolic name value of the SymbolicNameParameter is returned.
     * <p>
     * The method does a {@link ModelCheckedAccess} request for an integer parameter, which has the flag SymbolicNameValue in its definition.
     * </p>
     *
     *
     * @param container the container
     * @return the symbolic name value
     *
     * @exception NullPointerException
     * <ul>
     * <li>if container is null.</li>
     * </ul>
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if container has no definition.</li>
     * </ul>
     * @exception McaInvalidRequestException
     * <ul>
     * <li>if there is no parameter which has the SymbolicNameValue flag set in its definition.</li>
     * </ul>
     * @exception McaParameterXXXException
     * <ul>
     * <li>if the request mca.parameter(xxx).asInt().getValue() has a failure.</li>
     * </ul>
     */
    @PublishedMethod
    public static BigInteger getSymbolicNameValue(MIContainer container) {

        checkNotNull(container, "Container is null");
        DefRef.create(container);
        checkArgument(container.getDefinitionRef() != null, "The container definition does not exist");
        checkArgument(container.getDefinitionRef().getRefTarget() != null, "The container definition does not exist");

        final MIConfigParameter definition = getSymbolicNameParameterDefinition(container);
        if (definition == null) {
            throw new McaInvalidRequestException(new InvalidRequestExData(ModelCheckedAccessInternalUtil.getCurrentModelView(container), DefRef.create(container),
                    EElementType.PARAMETER, "The parent container "
                            + ModelAccessUtil.toStringMDFObject(container) + " has no parameter with the definition which specifies a SymbolicNameValue."));
        }
        final DefRef defRef = DefRef.create(definition);

        return ModelUtil.getService(container, IModelCheckedAccess.class).parameter(container, defRef).asInt().getValue();
    }

    /**
     * This Method only supports integer, enumeration and float SymbolicNameParameter.<br/>
     * The passed container is used to find the corresponding SymbolicNameParameter of types integer, enumeration or float. The symbolic name value of the SymbolicNameParameter is
     * returned.
     * <p>
     * The method does a {@link ModelCheckedAccess} request for an integer or enumeration parameter, which has the flag SymbolicNameValue in its definition.
     * </p>
     *
     *
     * @param container the container that contains the SymbolicNameParameter
     * @return the symbolic name value
     *
     * @exception NullPointerException
     * <ul>
     * <li>if container is null.</li>
     * </ul>
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if container has no definition.</li>
     * </ul>
     * @exception McaInvalidRequestException
     * <ul>
     * <li>if there is no parameter which has the SymbolicNameValue flag set in its definition.</li>
     * </ul>
     * @exception McaParameterXXXException
     * <ul>
     * <li>if the request mca.parameter(xxx).asInt().getValue() has a failure.</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the SymbolicNameParameter of the passed container is not of type enumeration, int or float.</li>
     * </ul>
     *
     */
    @KeepSecretFromPublishedApi
    public static Object getSymbolicNameValueGeneric(MIContainer container) {
        checkNotNull(container, "Container is null");
        DefRef.create(container);
        checkArgument(container.getDefinitionRef() != null, "The container definition does not exist");
        checkArgument(container.getDefinitionRef().getRefTarget() != null, "The container definition does not exist");

        final MIConfigParameter definition = getSymbolicNameParameterDefinition(container);
        if (definition == null) {
            throw new McaInvalidRequestException(new InvalidRequestExData(ModelCheckedAccessInternalUtil.getCurrentModelView(container), DefRef.create(container),
                    EElementType.PARAMETER, "The parent container "
                            + ModelAccessUtil.toStringMDFObject(container) + " has no parameter with the definition which specifies a SymbolicNameValue."));
        }
        final DefRef defRef = DefRef.create(definition);
        final IModelAccess ma = ModelUtil.getProjectContext(container).getService(IModelAccess.class);
        final MIParameterValue param = ModelUtil.getService(container, IModelCheckedAccess.class).parameter(container, defRef).getParam();

        switch (ma.getParameterTypeSafe(param)) {
        case INTEGER:
            return ModelUtil.getService(container, IModelCheckedAccess.class).parameter(container, defRef).asInt().getValue();

        case ENUMERATION:
            return ModelUtil.getService(container, IModelCheckedAccess.class).parameter(container, defRef).asEnum().getValue();

        case FLOAT:
            return ModelUtil.getService(container, IModelCheckedAccess.class).parameter(container, defRef).asFloat().getValue();

        default:
            throw new IllegalArgumentException(
                    "The method ModelCheckedAccessUtil.getSymbolicNameValueGeneric(MIContainer) only supports SymbolicNameValues of type enum, int or float. The SymbolicNameValue of the passed container is of type: "
                            + ma.getParameterTypeSafe(param));
        }
    }

    private static MIConfigParameter getSymbolicNameParameterDefinition(MIContainer container) {
        checkNotNull(container);
        try {

            final MIContainerDef refTarget = container.getDefinitionRef().getRefTarget();
            final List<MIConfigParameter> parameter = ((MIParamConfContainerDef) refTarget).getParameter();

            for (final MIConfigParameter definition : parameter) {

                final boolean isSybolicName = definition.getSymbolicNameValue();

                if (isSybolicName) {
                    return definition;
                }

            }
        } catch (final Exception ex) {
            logger.debug(ex);
            return null;
        }

        return null;
    }

}
