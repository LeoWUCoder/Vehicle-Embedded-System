package com.vector.cfg.model.query.modelcheckedaccess.elements.container;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
//CHECKSTYLE:OFF
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaCommonElement;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaRequest;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaDefinitionUndefinedException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaNotExistsException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongQuantityException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongTypeException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

//CHECKSTYLE:ON
/**
 * The ModelCheckedAccess request interface for container ({@link MIHasContainer})
 *
 * <p>
 * You can process the request by adding a method call to your request.
 * </p>
 * <p>
 * Example:<br/>
 * <code>mca.container(..) -->.getManyContainers()<--</code>
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelCheckedAccess
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IMcaContainer extends IMcaCommonElement<IMcaContainer> {

    /**
     * Executes the model request and returns a single container ({@link MIContainer}).
     *
     * <p>
     * The requested container must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IMcaContainer#getManyContainers() } instead.
     * </p>
     *
     * @return The container for the request
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     *
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element has the wrong type</li>
     * </ul>
     */
    @PublishedMethod
    MIContainer getContainer();

    /**
     * Executes the model request and returns a single container ({@link MIContainer}).
     *
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<MIContainer> getContainerAsRequest();

    /**
     * Executes the model request and returns a list of containers ({@link MIContainer}).
     *
     * <p>
     * If no container was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if no or one element
     * was found.
     * </p>
     *
     * @return A unmodifiable List of containers for the request.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved elements has the wrong type</li>
     * </ul>
     *
     */
    @PublishedMethod
    List<MIContainer> getManyContainers();

    /**
     * Executes the model request and returns a list of containers ({@link MIContainer}).
     *
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<List<MIContainer>> getManyContainersAsRequest();
}
