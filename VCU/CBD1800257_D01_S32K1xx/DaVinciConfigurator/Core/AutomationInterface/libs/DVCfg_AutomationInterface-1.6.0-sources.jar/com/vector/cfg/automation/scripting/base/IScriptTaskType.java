package com.vector.cfg.automation.scripting.base;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Set;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.servicecontext.IServiceContext;
import com.vector.cfg.util.text.log.IUserMessage;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * {@link IScriptTaskType} defines the possible execution point of the {@link IScriptTask} and the arguments passed to the {@link IScriptTask} during execution.
 * <p>
 * The DaVinci Configurator provides multiple task types for different execution points in the system. The types are defined in different classes:
 * <ul>
 * <li>com.vector.cfg.automation.scripting.api.EDefaultProjectScriptTaskType</li>
 * <li>com.vector.cfg.automation.scripting.api.EDefaultApplicationScriptTaskType</li>
 * </ul>
 * </p>
 *
 * <p>
 * Every {@link IScriptTask} instance has to defined the argument types and the return type of the script task. See the specific task type for the correct type information.
 * </p>
 *
 * <p>
 * The are two categories of {@link IScriptTaskType}:
 * <ul>
 * <li>{@link IProjectScriptTaskType}: Task which are only executable with a loaded project</li>
 * <li>{@link IApplicationScriptTaskType}: Tasks which are executable with a running Configuration, but not necessary a loaded project.</li>
 * </ul>
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * This is a value class, which means the implementation check for value equality (see equals, hashCode).
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 *
 * @see IScriptTask
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IScriptTaskType extends IUserMessage {

    /**
     * Return the user readable name of the type. this is display in the UI and in the console.
     *
     * @return the user readable name
     */
    @PublishedMethod
    String getUserReadableName();

    /**
     * Defines the signature of the {@link IScriptTask#call(IServiceContext, Object...)} method.
     *
     * @return the signature
     */
    @PublishedMethod
    IScriptTaskTypeSignature getSignature();

    /**
     * Checks if the passed scriptTask is executable with the passed arguments according to the {@link IScriptTaskType}.
     *
     * <p>
     * This can be used, that a special {@link IScriptTaskType}, can determine the execution by the runtime arguments passed to the {@link IScriptTask}.
     * </p>
     *
     * @param scriptTask the script task to check for. The task must have this task type
     * @param reasonBuilder the {@link INotExecutableReasonBuilder} to add the reason, why it is not executable
     * @param args the args to the {@link IScriptTask}
     * @return true, if the {@link IScriptTask} is executable
     */
    @PublishedMethod
    default boolean isExecutable(IScriptTask scriptTask, INotExecutableReasonBuilder reasonBuilder, Object[] args) {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    default IMixedText getUserMessage() {
        return MixedText.fromConstantString(getUserReadableName());
    }

    /**
     * The {@link IProjectScriptTaskType} marks the {@link IScriptTask} to be a task for {@link EScriptTaskCategory#PROJECT}. This is used to provide overloaded methods in
     * interface for the different types.
     *
     * @see IScriptTaskType
     * @see IScriptTask
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IProjectScriptTaskType extends IScriptTaskType {

    }

    /**
     * The {@link IApplicationScriptTaskType} marks the {@link IScriptTask} to be a task for {@link EScriptTaskCategory#APPLICATION}. This is used to provide overloaded methods
     * in interface for the different types.
     *
     * @see IScriptTaskType
     * @see IScriptTask
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IApplicationScriptTaskType extends IScriptTaskType {

    }

    /**
     * The IInitScriptTaskType defines the task type used by the init task, when a script is loaded.
     */
    public interface IInitScriptTaskType extends IApplicationScriptTaskType {

    }

    /**
     * The {@link IScriptTaskTypeSignature} defines the signature of the {@link IScriptTask#call(IServiceContext, Object...)} method.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IScriptTaskTypeSignature {

        /**
         * Gets the argument types of the task to execute.
         *
         * <p>
         * If <code>null</code>, the arguments are variable arguments with no specific type.
         * </p>
         *
         * <p>
         * This defines the <code>Object...</code> arguments of the method: {@link IScriptTask#call(IServiceContext, Object...)}.
         * </p>
         *
         * @return the argument types
         */
        @PublishedMethod
        @Nullable
        List<Type> getArgumentTypes();

        /**
         * Gets the return type of the task to execute.
         *
         * <p>
         * If the task returns nothing (void) the return type shall be {@link Void}.class
         * </p>
         *
         * <p>
         * This defines the return type of the method: {@link IScriptTask#call(IServiceContext, Object...)}.
         * </p>
         *
         * @return the return type
         */
        @PublishedMethod
        @Nonnull
        Type getReturnType();

        /**
         * Returns the {@link EScriptTaskTypeFeature}s of this {@link IScriptTaskTypeSignature}.
         *
         * <p>
         * Note: The {@link Set} is unmodifiable and could not be changed by clients.
         * </p>
         *
         * @return the type features
         */
        @PublishedMethod
        Set<EScriptTaskTypeFeature> getTypeFeatures();

    }

    /**
     * {@link EScriptTaskTypeFeature} describes properties of a certain {@link IScriptTaskTypeSignature}.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    enum EScriptTaskTypeFeature {

        /**
         * Defines that the {@link IScriptTaskType} could be called without any context. E.g. a PROJECT or APPLICATION script is {@link #STANDALONE_EXECUTABLE}. All types
         * defined with this feature, will be displayed on the command line.
         */
        STANDALONE_EXECUTABLE,

        /**
         * Defines that the {@link IScriptTaskType} is called automatically from the DaVinci Configurator code, without any trigger of the client, at a task type specified code
         * point.
         */
        AUTOMATIC_EXECUTION,

    }

}
