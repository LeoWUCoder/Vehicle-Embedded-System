package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * A functional interface for {@link MIHasDefinition} object creation. A instance of this interface is created by a lambda expression.
 * <p>
 * e.g.:
 * <p>
 * <code>
 * (mdfparent, def) -> modelOperations.createContainerByDefinition(mdfparent, def);
 * </code>
 * </p>
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
@FunctionalInterface
public interface ICreateMdfObjectFunction<VALUE extends MIHasDefinition> {

    @PublishedMethod
    VALUE create(MIHasContainer parent, DefRef defRef);
}
