/**
 * Interfaces for the CeState API to retrieve states of Model objects.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.model.state;