package com.vector.cfg.util.text.mixedtext;

import com.google.common.base.Objects;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class FormatSpec {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(FormatSpec.class);

    private FormatSpec() {

    }

    private static final class FormatSpecImpl implements IFormatSpec {

        private final boolean useQualifiedNames;

        private final boolean leaveCtrlCharacters;

        private FormatSpecImpl(boolean useQualifiedNames, boolean leaveCtrlCharacters) {
            this.useQualifiedNames = useQualifiedNames;
            this.leaveCtrlCharacters = leaveCtrlCharacters;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public int hashCode() {
            return Objects.hashCode(leaveCtrlCharacters, useQualifiedNames);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }

            if (this.getClass().isAssignableFrom(obj.getClass())) {
                return this == obj;
            }

            if (obj instanceof IFormatSpec) {
                final IFormatSpec other = (IFormatSpec) obj;
                return (leaveCtrlCharacters == other.leaveCtrlCharacters() && useQualifiedNames == other.useQualifiedNames());
            } else {
                return false;
            }
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean useQualifiedNames() {
            return useQualifiedNames;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public boolean leaveCtrlCharacters() {
            return leaveCtrlCharacters;
        }
    }

    private static final FormatSpecImpl useQualifiedNamesLeaveCtrlCharacters = new FormatSpecImpl(true, true);

    private static final FormatSpecImpl notUseQualifiedNamesLeaveCtrlCharacters = new FormatSpecImpl(false, true);

    private static final FormatSpecImpl useQualifiedNamesNotLeaveCtrlCharacters = new FormatSpecImpl(true, false);

    private static final FormatSpecImpl notUseQualifiedNamesNotLeaveCtrlCharacters = new FormatSpecImpl(false, false);

    /**
     * returns an interned FormatSpec which implements equals() and hashCode().
     *
     * @param formatSpec
     * @return
     */
    @PublishedMethod
    public static IFormatSpec getInternedFormatSpec(IFormatSpec formatSpec) {
        return getInternedFormatSpec(formatSpec.useQualifiedNames(), formatSpec.leaveCtrlCharacters());
    }

    /**
     * returns an interned FormatSpec which implements equals() and hashCode().
     *
     * @param useQualifiedNames
     * @param leaveCtrlCharacters
     * @return
     */
    @PublishedMethod
    public static IFormatSpec getInternedFormatSpec(boolean useQualifiedNames, boolean leaveCtrlCharacters) {
        if (useQualifiedNames) {
            if (leaveCtrlCharacters) {
                return useQualifiedNamesLeaveCtrlCharacters;
            } else {
                return useQualifiedNamesNotLeaveCtrlCharacters;
            }
        } else {
            if (leaveCtrlCharacters) {
                return notUseQualifiedNamesLeaveCtrlCharacters;
            } else {
                return notUseQualifiedNamesNotLeaveCtrlCharacters;
            }
        }
    }
}
