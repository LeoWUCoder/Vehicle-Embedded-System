package com.vector.cfg.model.query.modelcheckedaccess.exceptions;

import static com.vector.davinci.util.base.VUtil.NL;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The base type of all ModelCheckAccess exceptions.
 * <p>
 * Attention: All ModelCheckAccess exceptions are RuntimeExceptions!
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaException extends ModelException {
    private static final long serialVersionUID = -1387201317520083992L;

    private final List<? extends IExData> exDataList;

    private Set<MIObject> errorList;

    private Set<MIObject> ceList;

    /*
     * Data which is generated if needed
     */
    private String message = null;

    private boolean mdfObjectsInitialized = false;

    /**
     * Instantiates a new mca exception.
     *
     * @param exDataList the ex data list
     */
    @PublishedMethod
    public McaException(List<? extends IExData> exDataList) {
        super(null);
        this.exDataList = exDataList;

    }

    /**
     * Gets a list of {@link IExData} object with detailed information about the exception cause.
     *
     * @return The list of IExData objects
     * @See IExData
     */
    @PublishedMethod
    public List<? extends IExData> getExceptionDataList() {
        return exDataList;
    }

    /**
     * Gets the exception data.
     *
     * @return the exception data
     */
    @PublishedMethod
    @Nullable
    public IExData getExceptionData() {

        if (!exDataList.isEmpty()) {
            return exDataList.get(0);
        }
        return null;
    }

    /**
     * @param exDataList2
     * @return
     */
    private static String buildMessage(List<? extends IExData> exDataList) {
        final StringBuilder builder = new StringBuilder();

        for (final IExData data : exDataList) {

            builder.append(data.toString());
            builder.append(NL);
        }

        return builder.toString();

    }

    /**
     * @param data
     * @param builder
     */
    private static void addMdfObjects(Set<MIObject> errorList, Set<MIObject> ceList, IExData data) {
        if (data.getElement() != null) {
            errorList.add(data.getElement());

            // When Element exists insert Parent only as depended not as erroneous
            if (data.getParent() != null) {
                ceList.add(data.getParent());
            }

        } else {
            if (data.getDefinitionMDFObject() != null) {
                errorList.add(data.getDefinitionMDFObject());

                if (data.getParent() != null) {
                    // When Element exists insert Parent as depended
                    ceList.add(data.getParent());
                }
            } else {

                if (data.getParent() != null) {
                    // When Element does not exist insert Parent as erroneous
                    errorList.add(data.getParent());

                }

            }
        }

    }

    private synchronized void initMdfObjects() {

        if (!mdfObjectsInitialized) {

            final Set<MIObject> errorListLoc = new HashSet<>();
            final Set<MIObject> ceListLoc = new HashSet<>();
            for (final IExData data : exDataList) {
                addMdfObjects(errorListLoc, ceListLoc, data);
            }

            errorList = Collections.unmodifiableSet(errorListLoc);
            ceList = Collections.unmodifiableSet(ceListLoc);
            mdfObjectsInitialized = true;
        }
    }

    /**
     * Returns all CEs which are erroneous in this Exception.
     */
    @PublishedMethod
    public Collection<MIObject> getErroneousCEs() {

        initMdfObjects();

        return errorList;
    }

    /**
     * Returns all CEs which are involved in this exception, like parent CEs.
     */
    @PublishedMethod
    public Collection<MIObject> getCEs() {

        initMdfObjects();

        return ceList;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public synchronized String getMessage() {
        if (message == null) {
            message = buildMessage(exDataList);
        }

        return message;
    }

}
