package com.vector.cfg.model.query.modelcheckedaccess.exceptions.params;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.params.IParamHasIllegalValueExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Thrown when a parameter has an illegal value
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaParameterHasIllegalValueException extends McaParameterException {

    private static final long serialVersionUID = -6091417769363619219L;

    private final List<IParamHasIllegalValueExData> exDataList;

    /**
     * Constructor for McaParameterWrongTypeException.
     *
     * @param wrongTypeExDataList
     */
    @PublishedMethod
    public McaParameterHasIllegalValueException(List<IParamHasIllegalValueExData> exDataList) {
        super(exDataList);
        this.exDataList = exDataList;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<IParamHasIllegalValueExData> getExceptionDataList() {
        return exDataList;
    }
}
