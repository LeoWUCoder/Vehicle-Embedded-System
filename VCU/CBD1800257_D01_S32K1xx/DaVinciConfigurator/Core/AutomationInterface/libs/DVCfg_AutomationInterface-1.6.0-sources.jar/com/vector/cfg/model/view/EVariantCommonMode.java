package com.vector.cfg.model.view;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;

/**
 * This enum specifies the different types of the variant common change mode. See
 * {@link IModelViewManager#executeWithVariantCommonModelChanges(EVariantCommonMode)} for example.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EVariantCommonMode {

    /**
     * Variant common changes are turned off.
     */
    OFF,

    /**
     * Apply the variant common change mode only to the following object types.
     *
     * <ul>
     * <li>Containers and parameters which don't support post-build variance by definition
     * <li>Containers and parameters which are children of a module configuration which doesn't implement post-build variance
     * </ul>
     */
    DEFINITION_BASED,

    /**
     * Apply the variant common change mode to all containers and parameters independent of their definition.
     */
    ALL,

}
