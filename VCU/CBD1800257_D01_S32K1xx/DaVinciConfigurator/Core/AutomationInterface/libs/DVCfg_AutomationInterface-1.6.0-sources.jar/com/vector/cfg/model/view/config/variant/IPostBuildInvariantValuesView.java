package com.vector.cfg.model.view.config.variant;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.varianthandling.MIVariationPoint;
import com.vector.cfg.model.view.IModelViewManager;

/**
 * <div class="extdoc" id="IPostBuildInvariantValuesView">
 * <h4>The PostBuild InvariantValues model view</h4>
 *
 * <!--Index:InvariantValues model view--> The {@link IPostBuildInvariantValuesView} contains only elements which have <b>one</b> of the following properties:
 * <ul>
 * <li>The element and no parent has any {@link MIVariationPoint} with a post-build condition</li>
 * <li>All variant siblings have the same value and exist in all variants. Then one of the siblings is contained in the {@link IPostBuildInvariantValuesView}</li>
 * </ul>
 *
 * So the semantic of the InvariantValues model view is that all values are equal in all variants.
 *
 * You could retrieve an instance of {@link IPostBuildInvariantValuesView} by calling <code>IModelViewManager. getInvariantValuesView()</code>.
 *
 * <pre>
 * <code class="Java" id="Retrieving an InvariantValues model view">
 * IModelViewManager viewMgr =...;
 * IPostBuildInvariantValuesView invariantView = viewMgr.getPostBuildInvariantValuesView();
 * // Use the invariantView like any other model view
 * </code>
 * </pre>
 *
 *
 * <h5>Example</h5> The figure <!--LaTeX:\vref{fig:InvariantValuesExample}--> describes an example for a module with containers and the visibility in the
 * {@link IPostBuildInvariantValuesView}.
 * <ul>
 * <li>Container A is invisible because it is contained in variant 1 only</li>
 * <li>Container B and C are visible because they are contained in all variants</li>
 * <li>Parameter a is visible because it is contained in all variants with the same value</li>
 * <li>Parameter b is invisible: It is contained in all variants but with different values</li>
 * <li>Parameter c is invisible because it is contained in variant 3 only</li>
 *
 * </ul>
 * <img src="{@docRoot} /../_doc/InvariantValuesView_ModelExample.png" alt="Example of a model structure and the visibility of the IInvariantValuesView" id=
 * "fig:InvariantValuesExample" data-latex-style="scale=0.46" />
 *
 * <p>
 * <h5>Specification</h5> See also the
 * <a href= "https://vistrgensvn1.vi.vector.int/svn/AUTOSAR/Solution/ECU Configuration/CFG5/20_Design/Variant Handling/BaseFunctionality/PBS-InvariantViews.pptx"
 * >specification</a> for details of the {@link IPostBuildInvariantValuesView}.
 * </p>
 *
 * </div>
 *
 * <p>
 * The EVALs EVAL00115839, EVAL00116235 describe the changes.
 * </p>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelViewManager
 * @see IInvariantView
 * @see IPostBuildInvariantEcucDefView
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
public interface IPostBuildInvariantValuesView extends IInvariantValuesView, IPostBuildInvariantView {

}
