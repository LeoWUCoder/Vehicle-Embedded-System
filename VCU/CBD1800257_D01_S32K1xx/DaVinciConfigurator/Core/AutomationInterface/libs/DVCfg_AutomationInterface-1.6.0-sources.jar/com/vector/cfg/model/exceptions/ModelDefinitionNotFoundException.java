package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelDefinitionNotFoundException extends ModelDefinitionInvalidException {

    private static final long serialVersionUID = -6434102402230715794L;

    private final String definitionPath;

    /**
     * Constructor.
     */
    @PublishedMethod
    public ModelDefinitionNotFoundException(String definitionPath) {
        super("The definition '" + definitionPath + "' doesn't exist", definitionPath);
        this.definitionPath = definitionPath;
    }

    /**
     * Constructor.
     */
    @PublishedMethod
    public ModelDefinitionNotFoundException(DefRef defRef) {
        this("The definition '" + defRef + "' doesn't exist", defRef);
    }

    /**
     * Constructor.
     */
    @PublishedMethod
    public ModelDefinitionNotFoundException(String msg, DefRef defRef) {
        super(msg, defRef);
        this.definitionPath = defRef.getDefRefString();
    }

    @Override
    @PublishedMethod
    public String getDefinition() {
        return definitionPath;
    }

}
