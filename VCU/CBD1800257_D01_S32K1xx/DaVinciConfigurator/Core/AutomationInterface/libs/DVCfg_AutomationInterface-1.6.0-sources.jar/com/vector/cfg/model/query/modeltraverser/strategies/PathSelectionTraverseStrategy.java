package com.vector.cfg.model.query.modeltraverser.strategies;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
//CHECKSTYLE:OFF
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.query.modeltraverser.Path;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

//CHECKSTYLE:ON
/**
 * The {@link PathSelectionTraverseStrategy} provides a base implementation for the {@link IPathSelectionTraverseStrategy} interface. See {@link IPathSelectionTraverseStrategy}
 * for code samples and usage.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see ITraverseStrategy
 * @see Path
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public abstract class PathSelectionTraverseStrategy<PARENT_CFG extends MIHasDefinition, ELEM_CFG extends MIHasDefinition> extends TraverseStrategy implements
        IPathSelectionTraverseStrategy {

    /**
     * Instantiates a new traverser strategy.
     *
     * @param projectContext the project context
     * @param parentDefRef the parent {@link DefRef}, could be <code>null</code>, if the {@link ITraverseStrategy} is for the MainElement.
     * @param elementDefRef the element {@link DefRef} which shall be processed.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the projectContext parameter is null</li>
     * <li>if the elementDefRef parameter is null</li>
     * </ul>
     *
     */
    @PublishedMethod
    protected PathSelectionTraverseStrategy(@Nonnull IProjectContext projectContext, @Nullable TypedDefRef<?, PARENT_CFG, ?> parentDefRef,
            @Nonnull TypedDefRef<?, ELEM_CFG, ?> elementDefRef) {
        super(projectContext, parentDefRef, elementDefRef);

    }

    /*
     * Interface impl
     */

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    public TypedDefRef<?, PARENT_CFG, ?> getParentDefRef() {
        return (TypedDefRef<?, PARENT_CFG, ?>) super.getParentDefRef();
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    public TypedDefRef<?, ELEM_CFG, ?> getDefRef() {
        return (TypedDefRef<?, ELEM_CFG, ?>) super.getDefRef();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public final boolean acceptPathTraversal(MIHasDefinition currentElem) {

        final ELEM_CFG elem = getDefRef().asDefinitionOf(currentElem);
        if (elem != null) {
            return acceptPathTraversalInternal(elem);
        }
        return false;
    }

    /**
     * Is called for each element of type {@link #getDefRef()}.
     *
     * <p>
     * If the method returns true, to traversal is continued, otherwise the traversal will stop at this element.
     * </p>
     *
     * @param currentElem the current elem
     * @return true, if the traversal shall proceed.
     */
    @PublishedMethod
    protected abstract boolean acceptPathTraversalInternal(ELEM_CFG currentElem);

}
