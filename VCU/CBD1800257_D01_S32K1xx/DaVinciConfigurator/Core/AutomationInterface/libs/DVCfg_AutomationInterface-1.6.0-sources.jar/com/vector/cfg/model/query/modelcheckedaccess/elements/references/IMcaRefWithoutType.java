package com.vector.cfg.model.query.modelcheckedaccess.elements.references;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongTypeException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterWrongTypeException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceWrongTargetDefinitionException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceWrongTypeException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess request interface for references.
 *
 * <p>
 * You can process the request by adding a method call to your request.
 * </p>
 * <p>
 * Example:<br/>
 * <code>mca.reference(..) -->.getReference()<-- or -->.asRefToContainer()<--</code> ...
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelCheckedAccess
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IMcaRefWithoutType extends IMcaReference<IMcaRefWithoutType> {

    /**
     * Binds the model request to the reference type {@link MIReferenceValue} and the target type {@link MIContainer}.
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type MIReferenceValue or the TargetRef is no MIContainer</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if the retrieved element is has a wrong definition</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeRef<MIContainer, MIReferenceValue> asRefToContainer();

    /**
     * Binds the model request to the reference type {@link MIReferenceValue} and the target type {@link MIContainer}. The Reference must be a symbolic name reference.
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type MIReferenceValue or the TargetRef is no MIContainer</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if the retrieved element is has a wrong definition</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeRef<MIContainer, MIReferenceValue> asSymbolicNameRefToContainer();

    /**
     * Binds the model request to the reference type {@link MIReferenceValue} and the target type {@link MIParameterValue}. The Reference must be a symbolic name reference.
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type MIReferenceValue or the TargetRef is no MIContainer</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if the retrieved element is has a wrong definition</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeRef<MIParameterValue, MIReferenceValue> asSymbolicNameRefToParameter();

    /**
     * Binds the model request to the reference type {@link MIInstanceReferenceValue} and the target type {@link MIContainer}.
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type MIInstanceReferenceValue or the TargetRef is no MIContainer</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeRef<MIContainer, MIInstanceReferenceValue> asInstanceRefToContainer();

    /**
     * Binds the model request to the reference type {@link MIInstanceReferenceValue} (InstanceReference) and the target type specified by the class object refTargetClass.
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @param refTargetClass The target class. The regTarget must be an instance of this class object.
     * @return This model request interface
     *
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type MIInstanceReferenceValue or the TargetRef is not an instance of refTargetClass</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if the retrieved element has a wrong definition</li>
     * </ul>
     */
    @PublishedMethod
    <T extends MIReferrable> IMcaTypesafeRef<T, MIInstanceReferenceValue> asInstanceRef(Class<T> refTargetClass);

    /**
     * Binds the model request to the reference type {@link MIReferenceValue} and the target type {@link MIContainer}.
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type MIInstanceReferenceValue or the TargetRef is no MIContainer</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if the retrieved element has a wrong definition</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeRef<MIContainer, MIReferenceValue> asChoiceRefToContainer();

    /**
     * Binds the model request to the reference type {@link MIReferenceValue} (ForeignReference) and the target type specified by the class object refTargetClass.
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @param refTargetClass The target class. The regTarget must be an instance of this class object.
     * @return This model request interface
     *
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the reference has not the type MIReferenceValue or the TargetRef is not an instance of refTargetClass</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     * @exception McaReferenceWrongTargetDefinitionException
     * <ul>
     * <li>if the retrieved element has a wrong definition</li>
     * </ul>
     */
    @PublishedMethod
    <T extends MIReferrable> IMcaTypesafeRef<T, MIReferenceValue> asForeignRef(Class<T> refTargetClass);

    /**
     * Binds the model request to the type specified by the {@link TypedDefRef} parameter.
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the correct type</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef type is not allowed</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IMcaTypesafeRef<VALUE_TYPE, CONFIG_TYPE> typeBy(
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);
}
