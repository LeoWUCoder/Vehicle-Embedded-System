package com.vector.cfg.model.view.config.variant;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedDeprecated;
import com.vector.cfg.model.view.IModelViewManager;

/**
 * <h4>The Invariant EcuC definition model view</h4> The {@link IInvariantEcucDefView} is the base class for all {@link IInvariantEcucDefView}s in the system. The normally you
 * will use the {@link IPostBuildInvariantEcucDefView}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IModelViewManager
 * @see IInvariantView
 * @see IInvariantValuesView
 * @see IPostBuildInvariantEcucDefView
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedDeprecated("Please use the type IPostBuildInvariantEcucDefView instead.")
@Immutable
public interface IInvariantEcucDefView extends IInvariantView {

}
