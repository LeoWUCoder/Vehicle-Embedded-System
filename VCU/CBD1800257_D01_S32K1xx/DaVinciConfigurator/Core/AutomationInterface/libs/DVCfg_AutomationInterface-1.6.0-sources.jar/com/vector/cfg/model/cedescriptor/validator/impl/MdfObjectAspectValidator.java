package com.vector.cfg.model.cedescriptor.validator.impl;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.ReworkThisAtNextPublishedApiChange;
import com.vector.cfg.model.cedescriptor.aspect.IMdfObjectAspect;
import com.vector.cfg.model.cedescriptor.validator.AspectValidationException;
import com.vector.cfg.model.cedescriptor.validator.DescriptorAspectBuilderValidator;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@ReworkThisAtNextPublishedApiChange("GROOVY-8669 - This can be moved again in an internal package, when the Groovy Annotation loading bug was fixed.")
@SuppressWarnings("rawtypes")
public class MdfObjectAspectValidator extends DescriptorAspectBuilderValidator<IMdfObjectAspect> {

    /**
     * Constructor for MdfObjectAspectValidator.
     *
     */
    public MdfObjectAspectValidator() {
        super(IMdfObjectAspect.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void checkImpl(IMdfObjectAspect aspect) throws AspectValidationException {
        if (aspect.getObject() == null) {
            throw new AspectValidationException("An IMdfObjectAspect without a valid MdfObject is not allowed.");
        }
    }

}
