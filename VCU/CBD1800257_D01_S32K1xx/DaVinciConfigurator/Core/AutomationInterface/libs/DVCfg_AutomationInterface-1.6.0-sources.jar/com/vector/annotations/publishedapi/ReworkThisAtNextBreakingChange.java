package com.vector.annotations.publishedapi;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link ReworkThisAtNextBreakingChange} shall indicate that the annotated element will be reworked/removed at the next {@link PublishedApi} breaking change (major version
 * change).
 * 
 * <p>
 * The difference between {@link ReworkThisAtNextBreakingChange} and {@link ReworkThisAtNextPublishedApiChange}:
 * <ul>
 * <li>{@link ReworkThisAtNextBreakingChange} means the changes shall be made at the next breaking change (major version increment)</li>
 * <li>{@link ReworkThisAtNextPublishedApiChange} means the changes shall be made at next API extension (minor version increment).</li>
 * </ul>
 * </p>
 * 
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @since 1.0
 * @see PublishedApi
 * @see ReworkThisAtNextPublishedApiChange
 */
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.TYPE, ElementType.ANNOTATION_TYPE, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.METHOD, ElementType.PACKAGE })
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public @interface ReworkThisAtNextBreakingChange {

    /**
     * Returns the reason, why the API shall be changed at the next Breaking Change.
     *
     * @return the reason
     */
    String value() default "";
}
