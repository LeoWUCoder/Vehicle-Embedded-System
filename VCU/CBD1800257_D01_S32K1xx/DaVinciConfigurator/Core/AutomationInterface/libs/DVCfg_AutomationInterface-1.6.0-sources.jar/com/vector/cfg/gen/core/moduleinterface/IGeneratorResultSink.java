package com.vector.cfg.gen.core.moduleinterface;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageException;

/**
 * The IGeneratorResultSink is a consumer for GeneratorResults. You can report your {@link IGeneratorResult IGeneratorResults} to the IGeneratorResultSink.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @author virtu
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IGeneratorResult
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGeneratorResultSink extends IValidationResultSink, IGeneratorPackageReferable {

    /**
     * Reports a {@link GeneratorPackageException GeneratorPackageException}. This method does not block the caller, it will cache the reported exception.
     *
     * @param ex The exception
     */
    @PublishedMethod
    void reportGeneratorException(GeneratorPackageException ex);

    /**
     * Reports a {@link IGeneratorResult GeneratorResult}. This method does not block the caller, it will cache the reported results.
     *
     * @param result The result
     */
    @PublishedMethod
    void reportGeneratorResult(IGeneratorResult result);

    /**
     * Reports a collections of {@link IGeneratorResult GeneratorResult}. This method does not block the caller, it will cache the reported results.
     *
     * @param <T> the generic type
     * @param resultList the list of {@link IValidationResult}s to report.
     */
    @PublishedMethod
    <T extends IValidationResult> void reportValidationResult(List<T> resultList);

    /**
     * Checks if a result was already reported.
     *
     * @return true, if a result was reported.
     */
    @PublishedMethod
    boolean isResultPresent();

    /**
     * Checks if a result which the Severity higher or equal to severity was already reported.
     *
     * @param severity The checked severity.
     * @return true, if a result was reported.
     * @see EValidationSeverityType
     */
    @PublishedMethod
    boolean isResultPresent(EValidationSeverityType severity);

}
