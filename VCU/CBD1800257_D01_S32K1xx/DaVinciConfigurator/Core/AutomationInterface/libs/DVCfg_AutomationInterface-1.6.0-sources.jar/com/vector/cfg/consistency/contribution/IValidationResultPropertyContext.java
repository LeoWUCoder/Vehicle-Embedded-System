package com.vector.cfg.consistency.contribution;

import java.util.Collection;

import org.eclipse.core.runtime.IAdapterFactory;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.helper.validationresults.IValidationResultMarkerType;
import com.vector.cfg.consistency.ui.IValidationResultUI;

/**
 * With this interface the properties of the validation result can be accessed.
 *
 * <div class="extdoc" id="ValidationResultProperty"> A ValidationResult may have properties that can be accessed in the external API of validation results only with
 * {@link IValidationResultUI#getValidationResultProperty(Class)}. In general the property classes are not defined by the consistency itself. It is up to the clients of this API
 * to define the properties according to their needs. </div>
 * <p>
 * <div class="extdoc" id="ValidationResultProperty_Definition"> It is possible to define arbitrary properties for validation results. To do so you have to define property
 * interfaces that represent the required properties and to implement and register adapter factories ({@link IAdapterFactory}) which adapt the property classes to external
 * validation results ({@link IValidationResultUI}).
 * <p>
 * The receivers of the validation results can get any of the properties at the external API of the validation result with
 * {@link IValidationResultUI#getValidationResultProperty(Class)}.
 * </p>
 * </div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 *
 */

@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF, DomainType.AUTOMATION_IF_INTERNAL_ADDONS })
public interface IValidationResultPropertyContext {

    /**
     * This method returns the property of the validation result related to the type <T> or null.
     *
     * @return the property
     */
    @KeepSecretFromPublishedApi
    <T> T getValidationResultProperty(Class<T> propertyClass);

    /**
     * Returns the markers added to the validation result.
     *
     * @return Collection of all markers added to the validation result
     */
    @PublishedMethod
    Collection<IValidationResultMarkerType> getMarkers();

}
