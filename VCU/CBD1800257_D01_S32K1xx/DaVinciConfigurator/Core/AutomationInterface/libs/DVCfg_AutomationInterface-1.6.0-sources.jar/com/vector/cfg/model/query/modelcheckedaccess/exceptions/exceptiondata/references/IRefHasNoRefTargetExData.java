package com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.references;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceHasNoRefTargetException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess exception data for the {@link McaReferenceHasNoRefTargetException}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see McaReferenceHasNoRefTargetException
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IRefHasNoRefTargetExData extends IRefExData {

}
