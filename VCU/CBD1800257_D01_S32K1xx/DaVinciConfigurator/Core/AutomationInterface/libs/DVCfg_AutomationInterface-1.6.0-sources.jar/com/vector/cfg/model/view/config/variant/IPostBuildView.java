package com.vector.cfg.model.view.config.variant;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;

/**
 * {@link IPostBuildView} defines a {@link IModelView} for PostBuild data. Normally you would used the {@link IPostBuildPredefinedVariantView} for variant data or
 * {@link IPostBuildInvariantValuesView} for invariant data.
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IModelViewManager
 * @see IPostBuildPredefinedVariantView
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
public interface IPostBuildView extends IModelView {

    /**
     * Returns the corresponding {@link IPreBuildView} of this {@link IPostBuildView}.
     * <p>
     * Note: The {@link IPreBuildView} must exist also in an PreBuild invariant project.
     * </p>
     *
     * @return the corresponding pre build view
     */
    @KeepSecretFromPublishedApi
    @Nonnull
    IPreBuildView getPreBuildView();
}
