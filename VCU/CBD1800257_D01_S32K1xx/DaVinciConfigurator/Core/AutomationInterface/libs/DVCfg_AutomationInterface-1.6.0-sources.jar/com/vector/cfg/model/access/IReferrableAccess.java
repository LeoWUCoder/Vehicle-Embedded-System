package com.vector.cfg.model.access;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import org.eclipse.core.runtime.IStatus;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.exceptions.MultipleVariantObjectsException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIARObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIARRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;

/**
 * <div class="extdoc" id="Common">
 * <h2>IReferrableAccess</h2> The {@link IReferrableAccess} is a basic model service which provides some general methods for dealing with {@link MIReferrable} objects (all types
 * which have a shortname).
 *
 * <h3>Retrieving referrable objects</h3>
 *
 * Probably the most important methods in this service are
 * <ul>
 * <li>{@link #getAutosarPath(MIReferrable)}: Returns the AUTOSAR path of an object
 * <li>{@link #getReferrableByPath(String)}: Searches an object by its AUTOSAR path
 * <li>{@link #getReferrableByPath(MIARObject,String)}: Searches a child object by its relative AUTOSAR path below the specified parent object
 * </ul>
 *
 * <h3>Shortname validation</h3>
 *
 * When client code creates new MIReferrable objects in the model, it is essential that their shortname is valid below the related parent. Duplicate shortnames are not allowed
 * and lead to canceled model change transactions.
 * <ul>
 * <li>{@link #isValidShortname(MIARObject,String)}: Checks if the specified shortname is valid below the specified parent object. The method checks for example if this
 * shortname already exists and if the contained characters are valid for shortnames
 * <li>{@link #shortnameExists(MIARObject,String)}: Only checks if the shortname exists below the specified parent
 * <li>{@link #getValidShortname(MIARObject,String,int)}: Creates a valid unused shortname by adding a numerical postfix string if the specified shortname already exists
 * </ul>
 *
 * </div>
 *
 * <p>
 * <b>Post-build selectable issues:</b> <br/>
 *
 * <div class="extdoc" id="PbSelectable_issues"> Insert docu here </div>
 * </p>
 *
 * <p>
 * This is a ProjectService.
 * </p>
 * <p>
 * This ProjectService is threadsafe
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public interface IReferrableAccess {

    /**
     * Checks if the specified short-name is valid below the specified parent object.
     * <p>
     * The check fails if
     * <ul>
     * <li>At least one referrable child has the same name
     * <li>The short-name contains invalid characters or is too long
     * <li>The short-name is empty or doesn't exist
     * <li>There is a removed derived sub-container with this name (see <code>IDerivedContainerOperations</code>)
     * </ul>
     *
     * @param parent
     * @param name
     * @return Check result and reason if failed (via getMessage())
     * @throws IllegalArgumentException if parameters are <code>null</code>
     */
    @PublishedMethod
    IStatus isValidShortname(MIARObject parent, String name);

    /**
     * Returns {@code true} if the specified shortname is a valid shortname for a container below this parent but returns {@code false} in the following cases:
     * <ul>
     * <li>The shortname is empty or contains invalid characters.
     * <li>The shortname already exists. Either below this parent or - if the definition is a symbolic name container definition - module-wide
     * <li>The shortname is the name of a derived but deleted container - in case of a symbolic name container definition also module-wide
     * </ul>
     *
     * This method is intended to be called before creating a new container to check if the specified name can really be used.
     *
     * @param parent the (existing) parent of the new child container
     * @param name the shortname to be checked
     * @param defName the definition of the new child container ({@link EDefRefWildcard} wildcard is supported)
     * @return
     */
    @PublishedMethod
    IStatus isValidShortnameForContainer(MIARObject parent, String name, DefRef defRef);

    /**
     * Behaves in the same way as {@link #isValidShortnameForContainer(MIARObject, String, DefRef)}.
     *
     * @param parent the (existing) parent of the new child container
     * @param name the shortname to be checked
     * @param defName the definition name of the new child container
     * @return
     */
    @PublishedMethod
    IStatus isValidShortnameForContainer(MIHasContainer parent, String name, String defName);

    /**
     * Returns <code>true</code> if the shortname exists below the specified parent.
     * <p>
     * This method doesn't take removed derived containers into account. It just checks if this shortname exists in fact!
     *
     * @param parent
     * @param name
     * @return
     */
    @PublishedMethod
    boolean shortnameExists(MIARObject parent, String name);

    /**
     * This method first checks if the specified shortname plus a potentially added number postfix is too long according to the AUTOSAR schema rules (128 characters max). If it is
     * too long, a CRC32 of the original name is being calculated, the name is being truncated and the CRC32 is being added. The resulting name plus a potentially added postfix has
     * exactly 128 characters.
     * <p>
     * If the (potentially truncated) shortname does not exist below the specified parent it is returned without further changes. If it already exists, the method attaches an
     * underscore followed by a number starting from 1. The number postfix is being increased as long as the resulting shortname exists. Finally a new non-existing shortname is
     * returned.
     * </p>
     * <p>
     * The numDigits parameter specifies the minimum number of digits to be attached. The attached number is prefixed by '0' to fill this length. If the finally found number is
     * larger, it will not be cut to the specified number of digits - the number length is simply exceeded.
     * <p>
     * <b>Example:</b> If the shortname <code>"abc"</code> already exists and 3 is specified as minimum number of digits, the method starts trying <code>"abc_001"</code>.
     *
     * If the specified name already ends with a number sequence as specified above, the method returns the next unused one. The specified <code>numDigits</code> value will be
     * ignored in this case and the actually found number of digits will be used.
     * <p>
     * <b>Example:</b> If the shortname <code>"abc_009"</code> already exists, the method starts trying <code>"abc_010"</code>.
     *
     * @param parent
     * @param name is a shortname to be checked and used as basis for attached numbers
     * @param numDigits is the number of digits, the attached number shall be formated with. If this value is 1 or lower, no leading '0' will be attached. If it is larger that 32,
     * it will be set to 32.
     * @return The created shortname or <code>null</code> if the specified shortname contains invalid characters
     */
    @PublishedMethod
    String getValidShortname(MIARObject parent, String name, int numDigits);

    /**
     * Extended version of {@link #getValidShortname(MIARObject, String, int)}.<br/>
     * Additionally a blacklist may be provided which contains other names which may not be used (e.g. in case several Containers shall be created at once, additionalBlacklist
     * contains the other 'name-to-be').
     *
     * @param parent
     * @param name is a shortname to be checked and used as basis for attached numbers
     * @param numDigits is the number of digits, the attached number shall be formated with. If this value is 1 or lower, no leading '0' will be attached. If it is larger that 32,
     * it will be set to 32.
     * @return The created shortname or <code>null</code> if the specified shortname contains invalid characters
     */
    @KeepSecretFromPublishedApi
    String getValidShortname(MIARObject parent, String name, int numDigits, List<String> additionalBlacklist);

    /**
     * This method checks if the specified shortname exists below the <b>specified parent or module-wide for SymbolicNameValue container</b>. If not, the shortname is returned
     * without changes. If it already exists, the method attaches an underscore followed by a number starting from 1. The number postfix is being increased as long as the resulting
     * shortname exists. Finally a new non-existing shortname is returned.
     * <p>
     * <b>Remark:</b> This method uses the same shortname truncation algorithm as {@link #getValidShortname(MIARObject, String, int)}!
     * </p>
     *
     * @param parent
     * @param name
     * @param numDigits
     * @param defRef ({@link EDefRefWildcard} wildcard is supported)
     * @return
     */
    @PublishedMethod
    String getValidShortnameForContainer(MIARObject parent, String name, int numDigits, DefRef defRef);

    /**
     * This method works similar as {@link #getValidShortnameForContainer(MIARObject, String, int, DefRef)} but implements an additional check which checks whether the shortname is
     * already in use ( contained in passed blacklist).
     * <p>
     * <b>Remark:</b> This method uses the same shortname truncation algorithm as {@link #getValidShortname(MIARObject, String, int)}!
     * </p>
     *
     * @param parent
     * @param name
     * @param numDigits
     * @param defRef ({@link EDefRefWildcard} wildcard is supported)
     * @param blacklist
     * @return
     */
    @KeepSecretFromPublishedApi
    String getValidShortnameForContainer(MIARObject parent, String name, int numDigits, DefRef defRef, Collection<String> blacklist);

    /**
     * This method works similar as {@link #getValidShortnameForContainer(MIARObject, String, int, DefRef)} but implements an additional check which allows renaming a
     * SymbolicNameValue container to already used names of another SymbolicNameValue container as long as the SymbolicNameValue parameter values are equal.
     *
     * @param instanceToRename
     * @param name
     * @param numDigits
     * @return
     */
    @KeepSecretFromPublishedApi
    String getValidShortnameForContainerRename(MIContainer instanceToRename, String name, int numDigits);

    /**
     * This method checks if the specified shortname exists below the <b>specified parent or module-wide for SymbolicNameValue container</b>. If not, the shortname is returned
     * without changes. If it already exists, the method attaches an underscore followed by a number starting from 1. The number postfix is being increased as long as the resulting
     * shortname exists. Finally a new non-existing shortname is returned.
     * <p>
     * <b>Remark:</b> This method uses the same shortname truncation algorithm as {@link #getValidShortname(MIARObject, String, int)}!
     * </p>
     * <p>
     * <b>Caution: The parameter: defName must be the DefinitionName of the container! If not it is not possible to create the DefRef. (DefRef.create(DefRef: parent,String:
     * definition name of the container))</b>
     * <p>
     *
     * @param parent
     * @param name
     * @param numDigits
     * @param defName
     * @return
     */
    @PublishedMethod
    String getValidShortnameForContainer(MIARObject parent, String name, int numDigits, String defName);

    /**
     * This method increases postfix index and returns the calculated name, independent whether container with that name already exists.
     * <p>
     * <b>Remark:</b> This method uses the same shortname truncation algorithm as {@link #getValidShortname(MIARObject, String, int)}!
     * </p>
     *
     * @param parent
     * @param name
     * @param numDigits
     * @param defRef ({@link EDefRefWildcard} wildcard is supported)
     * @return
     */
    @KeepSecretFromPublishedApi
    String getNextShortnameForContainer(MIARObject parent, String name, int numDigits, DefRef defRef);

    /**
     * Returns <code>true</code> if the shortname exists already <b>below the specified parent or module-wide as shortname of a SymbolicNameValue Container</b>.
     * <p>
     * This method doesn't take removed derived containers into account. It just checks if this shortname exists in fact!
     *
     * @param parent
     * @param defref ({@link EDefRefWildcard} wildcard is supported)
     * @param name
     * @return
     */
    @PublishedMethod
    boolean shortnameExistsModuleWide(MIARObject parent, DefRef defref, String name);

    /**
     * Returns the AUTOSAR path of the specified referrable or throws an {@link IllegalStateException} if an error occurs. Errors occur in the following cases:
     * <ul>
     * <li>The object is not member of the AUTOSAR model tree
     * <li>The object or one of its parents doesn't have a shortname
     * </ul>
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return Absolute AUTOSAR path of the object and <b>never</b> <code>null</code>
     * @throws IllegalArgumentException if parameters are <code>null</code>
     * @throws IllegalStateException if another error occurred (e.g. if the object is not member of the model tree)
     */
    @PublishedMethod
    @Nonnull
    String getAutosarPath(MIReferrable obj);

    /**
     * Returns the AUTOSAR path of the specified referrable or throws an {@link IllegalStateException} if an error occurs. Errors occur in the following cases:
     * <ul>
     * <li>The object is not member of the AUTOSAR model tree
     * <li>The object or one of its parents doesn't have a shortname
     * </ul>
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return Absolute AUTOSAR path of the object and <b>never</b> <code>null</code>
     * @throws IllegalArgumentException if parameters are <code>null</code>, or the obj has an invalid path
     * @throws IllegalStateException if another error occurred (e.g. if the object is not member of the model tree)
     */
    @PublishedMethod
    @Nonnull
    AsrPath getAsrPath(MIReferrable obj);

    /**
     * Returns the AUTOSAR path of the specified referrable. In case of errors an absent path is being returned but an exception will never be thrown.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return Absolute AUTOSAR path if available
     */
    @PublishedMethod
    Optional<String> getAutosarPathWithoutException(MIReferrable obj);

    /**
     * Returns the AUTOSAR path of the specified referrable. In case of errors an absent path is being returned but an exception will never be thrown.
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return Absolute AUTOSAR path if available
     */
    @PublishedMethod
    Optional<AsrPath> getAsrPathWithoutException(MIReferrable obj);

    /**
     * <div class="extdoc" id="getReferrableByPath"> Retrieves a referrable object using its full (absolute) AUTOSAR path or <code>null</code> if not found.
     *
     * Be aware that this method throws a {@link MultipleVariantObjectsException} if more than one object have been found. Better use {@link #getReferrablesByPath(String)} in
     * variant projects to avoid that.
     *
     * </div>
     *
     * @param path
     * @return Found referrable or <code>null</code> if not found
     * @throws IllegalArgumentException if parameters are <code>null</code>
     * @throws MultipleVariantObjectsException if more than one object have been found
     */
    @PublishedMethod
    @Nullable
    MIReferrable getReferrableByPath(String path);

    /**
     * <div class="extdoc" id="getReferrableByPath"> Retrieves a referrable object using its full (absolute) AUTOSAR path or <code>null</code> if not found.
     *
     * Be aware that this method throws a {@link MultipleVariantObjectsException} if more than one object have been found. Better use {@link #getReferrablesByPath(AsrPath)} in
     * variant projects to avoid that.
     *
     * </div>
     *
     * @param path
     * @return Found referrable or <code>null</code> if not found
     * @throws IllegalArgumentException if parameters are <code>null</code>
     * @throws MultipleVariantObjectsException if more than one object have been found
     */
    @PublishedMethod
    @Nullable
    MIReferrable getReferrableByPath(AsrPath path);

    /**
     * <div class="extdoc" id="getReferrablesByPath"> Retrieves all referrables which have the specified full (absolute) AUTOSAR path.
     *
     * This method never returns <code>null</code>. If no object has been found it returns an empty collection instead.
     *
     * </div>
     *
     * @param path
     * @return Found referrables or an empty collection if not found
     * @throws IllegalArgumentException if parameters are <code>null</code>
     */
    @PublishedMethod
    Collection<MIReferrable> getReferrablesByPath(String path);

    /**
     * <div class="extdoc" id="getReferrablesByPath"> Retrieves all referrables which have the specified full (absolute) AUTOSAR path.
     *
     * This method never returns <code>null</code>. If no object has been found it returns an empty collection instead.
     *
     * </div>
     *
     * @param path
     * @return Found referrables or an empty collection if not found
     * @throws IllegalArgumentException if parameters are <code>null</code>
     */
    @PublishedMethod
    Collection<MIReferrable> getReferrablesByPath(AsrPath path);

    /**
     * Retrieves the definition of the module of a full (absolute) AUTOSAR path.
     *
     * @param definitionPath
     * @return The found module definition or <code>null</code>
     */
    @PublishedMethod
    @Nullable
    MIModuleDef getModuleDef(String definitionPath);

    /**
     * Retrieves the definition of the module of a full (absolute) AUTOSAR path.
     *
     * @param definitionPath
     * @return The found module definition or <code>null</code>
     */
    @PublishedMethod
    @Nullable
    MIModuleDef getModuleDef(AsrPath definitionPath);

    /**
     * Retrieves a child referrable below the specified parent using a relative AUTOSAR path (not starting with '/').
     *
     * @param parent
     * @param relativePath - relative path
     * @return Found referrable or <code>null</code> if not found
     * @throws IllegalArgumentException if parameters are <code>null</code>
     * @throws MultipleVariantObjectsException if more than one object have been found. Use {@link #getReferrablesByPath(MIARObject, String)} in this case
     */
    @PublishedMethod
    @Nullable
    MIReferrable getReferrableByPath(MIARObject parent, String relativePath);

    /**
     * Retrieves child referrables below the specified parent using a relative AUTOSAR path (not starting with '/').
     *
     * @param parent
     * @param relativePath - relative path
     * @return Found referrables or an empty collection if not found
     * @throws IllegalArgumentException if parameters are <code>null</code>
     */
    @PublishedMethod
    Collection<MIReferrable> getReferrablesByPath(MIARObject parent, String relativePath);

    /**
     * Collects all top-level objects in the referrable hierarchy.
     *
     * @return All top-level referrable objects
     */
    @PublishedMethod
    Collection<MIReferrable> getRootReferrables();

    /**
     * Collects all immediate children of the specified object in the referrable hierarchy.
     *
     * @param obj
     * @return All referrable child objects
     * @throws IllegalArgumentException if parameters are <code>null</code>
     */
    @PublishedMethod
    Collection<MIReferrable> getReferrableChildren(MIARObject obj);

    /**
     * Returns the referrable parent of the specified object (the next referrable on the root path).
     *
     * @param obj
     * @return The parent referrable or <code>null</code> if no parent exists (object is top-level referrable)
     * @throws IllegalArgumentException if parameters are <code>null</code>
     */
    @PublishedMethod
    MIReferrable getReferrableParent(MIObject obj);

    /**
     * Returns all unresolved reference objects which have the specified path as value.
     *
     * @param autosarPath
     * @return
     */
    @KeepSecretFromPublishedApi
    Collection<MIARRef> getUnresolvedReferencesByValue(String autosarPath);

    /**
     * Returns all unresolved reference objects which have the specified path as value.
     *
     * @param autosarPath
     * @return
     */
    @KeepSecretFromPublishedApi
    Collection<MIARRef> getUnresolvedReferencesByValue(AsrPath autosarPath);

}
