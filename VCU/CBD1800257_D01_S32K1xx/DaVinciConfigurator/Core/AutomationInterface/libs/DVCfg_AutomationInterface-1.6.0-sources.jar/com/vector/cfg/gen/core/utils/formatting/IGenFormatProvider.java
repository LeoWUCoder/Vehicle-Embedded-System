package com.vector.cfg.gen.core.utils.formatting;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * Proxy interface for Formatter Objects
 *
 * <p>
 * If you want to implement a formatter, you should consider to implement this interface too.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IGenFormatProvider {

    /**
     * Gets the formatter object.
     *
     * @return the formatter
     */
    @PublishedMethod
    IGenFormatter getFormatter();
}
