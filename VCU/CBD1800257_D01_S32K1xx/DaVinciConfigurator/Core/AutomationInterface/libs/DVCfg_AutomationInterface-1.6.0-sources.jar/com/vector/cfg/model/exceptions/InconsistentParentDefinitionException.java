package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class InconsistentParentDefinitionException extends ModelInconsistencyException {

    private static final long serialVersionUID = -9067261161060138425L;

    private final String parentDef;

    private final String childDef;

    /**
     * Constructor.
     */
    @PublishedMethod
    public InconsistentParentDefinitionException(String parentDef, String childDef) {
        super("The definition '" + parentDef + "' is not a parent of definition '" + childDef + "'");
        this.parentDef = parentDef;
        this.childDef = childDef;
    }

    @PublishedMethod
    public String getParentDef() {
        return parentDef;
    }

    @PublishedMethod
    public String getChildDef() {
        return childDef;
    }

}
