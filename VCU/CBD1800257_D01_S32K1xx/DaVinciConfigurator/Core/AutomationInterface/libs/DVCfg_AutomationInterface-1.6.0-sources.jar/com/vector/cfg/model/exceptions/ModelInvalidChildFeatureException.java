package com.vector.cfg.model.exceptions;

import static com.google.common.base.Preconditions.checkNotNull;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;

/**
 * Thrown to indicate that a parent object doesn't have a specific child feature.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelInvalidChildFeatureException extends ModelInconsistencyException {

    private static final long serialVersionUID = -4814820840552833462L;

    private final MIObject parent;

    private final String childFeatureName;

    @PublishedMethod
    public ModelInvalidChildFeatureException(@Nonnull MIObject parent, @Nonnull String childFeatureName) {
        super("'" + childFeatureName + "' is not a child feature of " + parent.getClass().getName());

        checkNotNull(parent, "parent is null");
        checkNotNull(childFeatureName, "childFeatureName is null");

        this.parent = parent;
        this.childFeatureName = childFeatureName;
    }

    @PublishedMethod
    public MIObject getParent() {
        return parent;
    }

    @PublishedMethod
    public String getChildFeatureName() {
        return childFeatureName;
    }

}
