package com.vector.cfg.model.state;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * This interfaces specifies the common basis for state of ECUC objects which can hold child containers.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IHasContainerStatePublished extends IEcucStatePublished {

}
