/**
 * The DynamicObject pattern provides runtime extension of API classes.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.scripting.dynamic;