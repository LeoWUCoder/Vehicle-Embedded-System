package com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.references;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceWrongTypeException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess exception data for the {@link McaReferenceWrongTypeException}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see McaReferenceWrongTypeException
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IRefWrongTargetDefExData extends IRefExData {

    /**
     * Gets a list of expected definition refs of the reference of the model request.
     *
     * @return The expected definition refs of the model request.
     */
    @PublishedMethod
    List<DefRef> getExpectedDefRefs();

    /**
     * Gets the actual definition ref of the reference of the model request.
     *
     * @return The actual type of the model request.
     */
    @PublishedMethod
    DefRef getActualDefRef();

    /**
     * Gets the actual target of the reference of the model request.
     *
     * @return The actual of the reference target of the model request.
     */
    @PublishedMethod
    MIObject getTarget();

}
