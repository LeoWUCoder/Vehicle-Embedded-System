package com.vector.cfg.automation.scripting.base;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IScriptTaskCode} defines the executable code of the {@link IScriptTask}. The {@link IScriptTaskCode} is a {@link FunctionalInterface} for Java script client, to use
 * lambda expression. Groovy client do not need to use the interface.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IScriptTask
 * @see IScriptExecutionContext
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@FunctionalInterface
public interface IScriptTaskCode<T extends IScriptExecutionContext> {

    /**
     * Contains the {@link IScriptTask} code, when the {@link IScriptTask} is executed.
     *
     * @param scriptContext the current {@link IScriptExecutionContext} of the running task execution.
     * @param arguments the arguments passed to the {@link IScriptTask}, the types are defined by the used {@link IScriptTaskType}.
     * @return the returned object of the task execution
     */
    @PublishedMethod
    Object execute(T scriptContext, List<Object> arguments);

}
