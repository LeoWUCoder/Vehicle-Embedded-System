package com.vector.cfg.gen.core.moduleinterface;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.multipleModuleGenerators.IModule;

/**
 * {@link IGenerator} defines the API to query and call an internal {@link IGeneratorPackage}. This is a facade for implemented generators.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF })
public interface IGenerator {

    /**
     * Gets the MSN of a Generator. E.g. Can, CanIf, NvM ...
     *
     * @return the MSN
     */
    @PublishedMethod
    String getMSN();

    /**
     * Returns the name of the generator displayed in various dialogs e.g. ProjectSetting, GenerateDialog, GenerationResult view, ...
     *
     * <p>
     * This should be a short description name of the Generator, normally the MSN of the module, when this is unique! Otherwise a really short description.
     * <ul>
     * <li>Com</li>
     * <li>CanS12x</li>
     * <li>Rte ContractPhase</li>
     * <li>Rte</li>
     * <li>TpCdd</li>
     * </ul>
     *
     *
     * @return the generator name
     */
    @PublishedMethod
    String getGeneratorName();

    /**
     * Returns the description of the generator.
     *
     * @return the descriptive name
     */
    @PublishedMethod
    String getDescription();

    /**
     * Gets the module information of this {@link IGenerator}.
     *
     * @return the module
     */
    @PublishedMethod
    IModule getModule();
}
