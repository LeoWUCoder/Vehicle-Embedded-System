package com.vector.cfg.util.servicecontext;

import java.lang.annotation.Annotation;
import java.lang.ref.WeakReference;

import javax.annotation.concurrent.ThreadSafe;

import com.google.inject.ConfigurationException;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.ProvisionException;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.IDisposable;

/**
 * Implementations of this interface allow retrieving system-wide services related to a specific context.
 * <p>
 * Service registration is being handled via an extension point.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IServiceContext extends IDisposable, AutoCloseable {

    /**
     * Returns the requested service instance by the passed {@link Class}.
     *
     * @param <T> the type of the instance to retrieve
     * @param type the class of the requested instance.
     * @return service instance
     * @throws IllegalArgumentException - if the argument is <code>null</code>
     * @throws ConfigurationException if this {@link IServiceContext} cannot find or create the provider.
     * @throws ProvisionException if there was a runtime failure while providing an instance.
     * @throws IllegalStateException if the serviceContext is already disposed. see {@link #isDisposed()}.
     */
    @PublishedMethod
    <T> T getInstance(Class<T> type);

    /**
     * Returns the requested service instance by the passed {@link Key}.
     *
     * @throws ConfigurationException if this injector cannot find or create the provider.
     * @throws ProvisionException if there was a runtime failure while providing an instance.
     */
    @KeepSecretFromPublishedApi
    <T> T getInstance(Key<T> key);

    /**
     * Returns the requested service instance by the passed {@link Class}.
     *
     * <p>
     * This request is thread-safe and all threads share the requested service instances.
     * </p>
     *
     * @param <T> the type of the instance to retrieve
     * @param service the class of the requested service.
     * @return service instance
     * @throws IllegalArgumentException - if the argument is <code>null</code>
     * @throws ConfigurationException if this {@link IServiceContext} cannot find or create the provider.
     * @throws ProvisionException if there was a runtime failure while providing an instance.
     * @throws IllegalStateException if the serviceContext is already disposed. see {@link #isDisposed()}.
     * @see #getService(Class)
     * @see #getInstance(Class)
     */
    @PublishedMethod
    default <T> T getAt(Class<T> service) {
        return getInstance(service);
    }

    /**
     * Injects dependencies into the fields and methods of {@code instance}. Ignores the presence or absence of an injectable constructor.
     *
     * @param instance to inject members on
     */
    @KeepSecretFromPublishedApi
    void injectMembers(Object instance);

    /**
     * Gets the underlying {@link Injector} of this {@link IServiceContext}. This could be used for special injection idioms.
     * <p>
     * For the standard cases, please use {@link #getInstance(Class)}!
     * </p>
     *
     * @return the injector
     */
    @KeepSecretFromPublishedApi
    Injector getInjector();

    /**
     * Returns the requested service instance by the passed {@link Class}.
     *
     * <p>
     * This request is thread-safe and all threads share the requested service instances.
     * </p>
     *
     * @param <T> the type of the service to retrieve
     * @param service the class of the requested service.
     * @return service instance
     * @throws IllegalArgumentException - if the argument is <code>null</code>
     * @throws ConfigurationException if this {@link IServiceContext} cannot find or create the provider.
     * @throws ProvisionException if there was a runtime failure while providing an instance.
     * @throws IllegalStateException if the serviceContext is already disposed. see {@link #isDisposed()}.
     */
    @PublishedMethod
    <T> T getService(Class<T> service);

    /**
     * Returns true, if the requested service is available. Otherwise false.
     *
     * <p>
     * This request is thread-safe and all threads share the requested service instances.
     * </p>
     *
     * @param <T> the type of the service to retrieve
     * @param serviceClass
     * @return true, if the service exists, otherwise false.
     *
     * @throws IllegalArgumentException - if the argument is <code>null</code>
     */
    @PublishedMethod
    <T> boolean isServiceAvailable(Class<T> serviceClass);

    /**
     * Returns true, if the requested service is available. Otherwise false.
     *
     * <p>
     * This request is thread-safe and all threads share the requested service instances.
     * </p>
     *
     * @param <T> the type of the service to retrieve
     * @param service key
     * @return true, if the service exists, otherwise false.
     *
     * @throws IllegalArgumentException - if the argument is <code>null</code>
     */
    @PublishedMethod
    <T> boolean isServiceAvailable(Key<T> key);

    /**
     * Returns true, if the {@link IServiceContext} was already disposed.
     *
     * This method with return <code>true</code>, when the dispose process was finished. During a running disposal {@link #isDisposed()} with return false. But the underlying
     * services are currently disposed.
     *
     * <p>
     * DAVID00133744: Gen-Arch#209: ServiceContext.isDisposed() shall not return true during disposal
     * </p>
     *
     * @return true, if this {@link IServiceContext} is disposed
     */
    @KeepSecretFromPublishedApi
    boolean isDisposed();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    void close();

    /**
     * Adds a new dispose listener.
     * <p>
     * The listener will be called, when this {@link IServiceContext} is disposed.
     * </p>
     *
     * <p>
     * Note: The Listeners are added via a {@link WeakReference}, so the listener is unregistered, if there is no other string reference to the
     * {@link IServiceContextDisposeListener}.
     * </p>
     *
     * @param <T> the generic type
     * @param listener the listener
     * @see DAVID00100210
     */
    @KeepSecretFromPublishedApi
    <T extends IServiceContext> void addDisposeListener(IServiceContextDisposeListener<T> listener);

    /**
     * Gets the <code>ServiceContributionHasMultipleImplementations</code> implementation annotation.
     *
     * <p>
     * This method has very special use cases, please do not use it unless you know what you are doing!
     * </p>
     *
     * @return the multiple contribution annotation class
     */
    @KeepSecretFromPublishedApi
    Class<? extends Annotation> getMultipleContributionAnnotationClass();

    @KeepSecretFromPublishedApi
    IServiceContextCreationOrigin getCreationOrigin();
}
