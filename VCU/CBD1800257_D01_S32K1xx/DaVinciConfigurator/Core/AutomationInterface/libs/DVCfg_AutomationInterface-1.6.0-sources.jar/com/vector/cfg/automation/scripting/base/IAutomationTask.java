package com.vector.cfg.automation.scripting.base;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * {@link IAutomationTask} is the base interface of all task which could run using the automation API. Normally the task is {@link IScriptTask}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IAutomationTask {

    /**
     * Return the task name, specified during task construction.
     *
     * @return the task name
     */
    @PublishedMethod
    String getName();

    /**
     * Returns the full qualified name of the task including the parent script name if available.
     *
     * @return the qualified name
     */
    @PublishedMethod
    String getQualifiedName();

    /**
     * Returns the default script logger.
     *
     * @return the script logger
     */
    @PublishedMethod
    default ILogger getScriptLogger() {
        return Logger.INSTANCE.createLogger(IAutomationTask.class);
    }

}
