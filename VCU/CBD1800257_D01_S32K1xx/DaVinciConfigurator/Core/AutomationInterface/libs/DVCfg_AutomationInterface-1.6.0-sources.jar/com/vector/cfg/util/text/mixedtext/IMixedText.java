package com.vector.cfg.util.text.mixedtext;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.util.text.mixedtext.parts.IMixedTextPart;

/**
 * <div class="extdoc" id="Common" data-target-doc="AutomationInterfaceDocumentation">{@link IMixedText} is a construct that represents a text, whereby parts of that text can
 * also hold the object which they represent. This allows a consumer e.g. a GUI to make the object-parts of the text clickable and to reformat these object-parts as wanted.<br/>
 * Consumers which don't need these advanced features can just call {@link IMixedText#toString()} which returns a default format of the text.</div>
 *
 * See also {@link IMixedTextBuilder}
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IMixedText {
    /**
     * getFormattedParts() will return a collection of IMixedTextPart. From any MixedTextPart one can get at least a plain String. Depending on what getPartType() returns, the
     * MixedTextPart supports further interfaces from package com.vector.cfg.business.mixedtext.parts to get access to the contained objects. One can use a
     * MixedText.newObjectResolver() to get different text formatting of any object type (e.g. for ToolTips).
     */
    @PublishedMethod
    @ReworkThisAtNextBreakingChange("Make the return type a list. The formatted part must have a order, so it must be a list!")
    Collection<IMixedTextPart> getFormattedParts(IFormatSpec spec);

    /**
     * Returns all Object, which are contained in this {@link IMixedText}.
     *
     * @return the contained objects
     */
    @KeepSecretFromPublishedApi
    Iterable<Object> getContainedObjects();

    @KeepSecretFromPublishedApi
    @ReworkThisAtNextBreakingChange("Make the return type a list. The formatted part must have a order, so it must be a list!")
    Collection<IMixedTextPart> getMixedTextParts();

    /**
     * getFormatedText() returns a simple concatenation of the parts returned by getFormattedParts().
     */
    @PublishedMethod
    String getFormattedText(IFormatSpec spec);

}
