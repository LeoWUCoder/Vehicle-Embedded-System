package com.vector.cfg.consistency.contribution.helper.validationresults;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Nullable;
import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Function;
import com.google.common.base.Optional;
import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.ISolvingActionContainer;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.contribution.IHasSolvingActionGroups;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.IUISolvingAction;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.IVariantSolvingAction;
import com.vector.cfg.consistency.contribution.helper.EAutoSolvingActionUsage;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SolvingActions;
import com.vector.cfg.consistency.coreinternal.ISolvingActionGroupInfo;
import com.vector.cfg.consistency.coreinternal.wrappedinterface.IHasWrappedInterfaces;
import com.vector.cfg.consistency.coreinternal.wrappedinterface.WrappedInterfaceUtil;
import com.vector.cfg.consistency.internal.resultprovisioning.SolvingActionContainerUtil;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.cedescriptor.IDescriptorBuilder;
import com.vector.cfg.model.cedescriptor.IDescriptorFactory;
import com.vector.cfg.model.cedescriptor.IDescriptorFactoryUtil;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.IViewedModelObject;
import com.vector.cfg.model.view.config.variant.IInvariantView;
import com.vector.cfg.model.view.config.variant.IPredefinedVariantView;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;

/**
 * The abstract implementation to build {@link IValidationResult}s. Please do NOT subclass this class!
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractResultBuilder<T extends AbstractResultBuilder<T>> implements IValidationResultBuilder<T> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractResultBuilder.class);

    private static final ISolvingActionGroup[] NO_SOLVING_ACTION_GROUPS = null;

    private final IValidationResultId resultId;

    private final EValidationSeverityType severityType;

    private final IMixedTextBuilder descriptionBuilder;

    private final IMixedText description;

    private final List<IDescriptor> erroneousCEs;

    private final List<IDescriptor> dependentCEs;

    private final Set<IValidationResultMarkerType> markerSet;

    private final Set<ISolvingAction> solvingActionSet;

    private final Set<IUISolvingAction> uiSolvingActionSet;

    private final Set<IPredefinedVariantView> explicitPredefinedVariantSet;

    private final Set<IInvariantView> explicitInvariantViewSet;

    private final Set<IModelView> implicitModelViewByElementsSet;

    @Nullable
    private IModelView implicitModelViewByConstruction;

    @Nullable
    private Throwable innerException;

    @Nullable
    private ISolvingAction autoSolvingAction;

    @Nullable
    private ISolvingAction preferredSolvingAction;

    @Nullable
    private IUISolvingAction preferredUISolvingAction;

    private Optional<IProjectContext> projectContext;

    private Object additionalDistinguishingObject;

    private final LinkedHashMultimap<ISolvingAction, ISolvingActionGroup> solvingAction2Groups = LinkedHashMultimap.create();

    @KeepSecretFromPublishedApi
    protected AbstractResultBuilder(IValidationResultId resultId, EValidationSeverityType severityType, IMixedTextBuilder descriptionBuilder,
            IMixedText description) {

        if (resultId.getId() > IValidationResultId.MAX_ID_VALUE) {
            throw new IllegalArgumentException("The integer value " + resultId.getId() + " in the ValidationResultId is bigger then the allowed max value: "
                    + IValidationResultId.MAX_ID_VALUE);
        }

        if (resultId.getId() <= 0) {
            throw new IllegalArgumentException("The integer value " + resultId.getId() + " in the ValidationResultId is less or equal 0. This is not allowed.");
        }

        if (descriptionBuilder != null && description != null) {
            throw new IllegalArgumentException("You can't use the descriptionBuilder and the description at the same time. you have to choose one of them.");
        }

        this.resultId = resultId;
        this.severityType = severityType;

        this.descriptionBuilder = descriptionBuilder;
        this.description = description;

        erroneousCEs = Lists.newArrayList();

        dependentCEs = Lists.newArrayList();

        solvingActionSet = new LinkedHashSet<>();

        markerSet = new LinkedHashSet<>();

        uiSolvingActionSet = new LinkedHashSet<>();

        explicitPredefinedVariantSet = Sets.newHashSet();
        explicitInvariantViewSet = Sets.newHashSet();
        implicitModelViewByElementsSet = Sets.newHashSet();
        projectContext = Optional.absent();

    }

    @KeepSecretFromPublishedApi
    protected final Optional<IProjectContext> getProjectContext() {
        return projectContext;
    }

    @KeepSecretFromPublishedApi
    protected final void initProjectContextByMDF(MIObject mdfObj) {
        if (projectContext.isPresent()) {
            return;
        }
        if (mdfObj == null) {
            return;
        }
        final IProjectContext pc = ModelUtil.getProjectContext(mdfObj);
        if (pc != null) {
            initProjectContext(pc);
        }
    }

    @KeepSecretFromPublishedApi
    protected final void initProjectContextByDescriptor(IDescriptor desc) {
        if (projectContext.isPresent()) {
            return;
        }
        if (desc == null) {
            return;
        }
        final IProjectContext pc = desc.getProjectContext();
        if (pc != null) {
            initProjectContext(pc);
        }
    }

    private void initProjectContext(IProjectContext projectContextLoc) {
        checkNotNull(projectContextLoc);
        if (projectContext.isPresent()) {
            return;
        }
        projectContext = Optional.of(projectContextLoc);

    }

    @KeepSecretFromPublishedApi
    protected final void addImplicitModelViewByElement(IViewedModelObject viewedModelObject) {
        addImplicitModelViewByElement(viewedModelObject.getCreationModelView());

    }

    @KeepSecretFromPublishedApi
    protected final void addImplicitModelViewByElement(IModelView modelView) {
        if (modelView == null) {
            return;
        }
        implicitModelViewByElementsSet.add(modelView);
    }

    @KeepSecretFromPublishedApi
    protected abstract T getThis();

    /*
     * -------------------------------------------------------------------------------------- Public API
     *
     * --------------------------------------------------------------------------------------
     */
    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T assignException(Throwable ex) {
        if (ex == null) {
            throw new IllegalArgumentException("ex is null");
        }
        if (innerException != null && innerException != ex) {
            throw new IllegalArgumentException("A Exception was already assigned, can't assign another exception", ex);
        }
        this.innerException = ex;

        return getThis();

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IMixedTextBuilder getMixedTextBuilder() {
        if (descriptionBuilder == null) {
            throw new IllegalArgumentException(
                    "There is no descriptionBuilder assigned to this builder. You have probaply constructed the Builder with an assigned Text. Then you can't change the text.");
        }

        return descriptionBuilder;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addMarker(IValidationResultMarkerType marker) {
        if (marker == null) {
            throw new IllegalArgumentException("marker is null");
        }
        markerSet.add(marker);
        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addErrorObject(MIObject erroneousMdfObject) {
        if (erroneousMdfObject == null) {
            throw new IllegalArgumentException("erroneousMdfObject is null");
        }
        initProjectContextByMDF(erroneousMdfObject);

        final IDescriptorFactory descriptorFactory = ModelUtil.getService(erroneousMdfObject, IDescriptorFactory.class);
        erroneousCEs.add(descriptorFactory.createBuilder(erroneousMdfObject).create());

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addErrorObject(IViewedModelObject erroneousModelObject) {
        if (erroneousModelObject == null) {
            throw new IllegalArgumentException("erroneousModelObject is null");
        }
        addImplicitModelViewByElement(erroneousModelObject);

        return addErrorObject(erroneousModelObject.getMdfObject());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addErrorObjectsFromMixedText(IMixedText mixedText) {
        if (mixedText == null) {
            throw new IllegalArgumentException("mixedText is null");
        }

        for (final Object obj : mixedText.getContainedObjects()) {
            if (obj instanceof MIObject) {
                this.addErrorObject((MIObject) obj);
            } else if (obj instanceof IViewedModelObject) {
                this.addErrorObject((IViewedModelObject) obj);
            }
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <R extends MIObject> T addErrorMdfObjectList(Collection<R> erroneousMdfCollection) {
        if (erroneousMdfCollection == null) {
            throw new IllegalArgumentException("erroneousMdfCollection is null");
        }

        for (final MIObject obj : erroneousMdfCollection) {
            initProjectContextByMDF(obj);
            final IDescriptorFactory descriptorFactory = ModelUtil.getService(obj, IDescriptorFactory.class);
            erroneousCEs.add(descriptorFactory.createBuilder(obj).create());
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <R extends IViewedModelObject> T addErrorViewedModelObjectList(Collection<R> erroneousModelCollection) {
        if (erroneousModelCollection == null) {
            throw new IllegalArgumentException("erroneousModelCollection is null");
        }

        for (final R obj : erroneousModelCollection) {
            addImplicitModelViewByElement(obj);
            addErrorObject(obj);
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addDependentObject(MIObject mdfObject) {
        if (mdfObject == null) {
            throw new IllegalArgumentException("mdfObject is null");
        }
        initProjectContextByMDF(mdfObject);

        final IDescriptorFactory descriptorFactory = ModelUtil.getService(mdfObject, IDescriptorFactory.class);
        dependentCEs.add(descriptorFactory.createBuilder(mdfObject).create());

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addDependentObject(IViewedModelObject dependentModelObject) {
        if (dependentModelObject == null) {
            throw new IllegalArgumentException("dependentModelObject is null");
        }

        addImplicitModelViewByElement(dependentModelObject);
        addDependentObject(dependentModelObject.getMdfObject());
        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addDependentObjectsFromMixedText(IMixedText mixedText) {
        if (mixedText == null) {
            throw new IllegalArgumentException("mixedText is null");
        }

        for (final Object obj : mixedText.getContainedObjects()) {
            if (obj instanceof MIObject) {
                addDependentObject((MIObject) obj);
            } else if (obj instanceof IViewedModelObject) {
                addDependentObject((IViewedModelObject) obj);
            }
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <R extends MIObject> T addDependentMdfObjectList(Collection<R> mdfCollection) {
        if (mdfCollection == null) {
            throw new IllegalArgumentException("mdfCollection is null");
        }

        for (final MIObject obj : mdfCollection) {
            initProjectContextByMDF(obj);
            final IDescriptorFactory descriptorFactory = ModelUtil.getService(obj, IDescriptorFactory.class);
            dependentCEs.add(descriptorFactory.createBuilder(obj).create());
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <R extends IViewedModelObject> T addDependentViewedModelObjectList(Collection<R> dependentModelCollection) {
        if (dependentModelCollection == null) {
            throw new IllegalArgumentException("dependentModelCollection is null");
        }

        for (final R obj : dependentModelCollection) {
            addImplicitModelViewByElement(obj);
            addDependentObject(obj);
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addErrorMissingObject(MIObject parentMdfObject, DefRef missingCeDefRef) {
        erroneousCEs.add(getMissingObject(parentMdfObject, missingCeDefRef));
        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addDependentMissingObject(MIObject parentMdfObject, DefRef missingCeDefRef) {
        dependentCEs.add(getMissingObject(parentMdfObject, missingCeDefRef));
        return getThis();
    }

    private IDescriptor getMissingObject(MIObject parentMdfObject, DefRef missingCeDefRef) {
        if (parentMdfObject == null) {
            throw new IllegalArgumentException("parentMdfObject is null");
        }
        if (missingCeDefRef == null) {
            throw new IllegalArgumentException("missingCeDefRef is null");
        }
        initProjectContextByMDF(parentMdfObject);

        if (parentMdfObject instanceof MIHasDefinition) {
            final IDescriptorFactoryUtil dfu = getProjectContext().get().getService(IDescriptorFactoryUtil.class);
            return dfu.createDescriptor(missingCeDefRef, null, (MIHasDefinition) parentMdfObject);
        } else {
            // use this older code that doesn't support intermediate definition levels between the parentMdfObject and the missingCeDefRef
            final IDescriptorFactory descriptorFactory = ModelUtil.getService(parentMdfObject, IDescriptorFactory.class);
            final IDescriptorBuilder parentBuilder = descriptorFactory.createBuilder(parentMdfObject);
            final IDescriptorBuilder builder = descriptorFactory.createBuilder(parentBuilder);
            builder.setDefRef(missingCeDefRef);
            return builder.create();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addErrorDescriptor(IDescriptor descriptor) {
        if (descriptor == null) {
            throw new IllegalArgumentException("descriptor is null");
        }
        initProjectContextByDescriptor(descriptor);
        erroneousCEs.add(descriptor);
        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <R extends IDescriptor> T addErrorDescriptorList(final Collection<R> descriptorList) {
        if (descriptorList == null) {
            throw new IllegalArgumentException("descriptorList is null");
        }

        for (final IDescriptor descriptor : descriptorList) {
            initProjectContextByDescriptor(descriptor);
            erroneousCEs.add(descriptor);
        }
        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addDependentDescriptor(IDescriptor descriptor) {
        if (descriptor == null) {
            throw new IllegalArgumentException("descriptor is null");
        }
        initProjectContextByDescriptor(descriptor);
        dependentCEs.add(descriptor);

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addDependentDescriptorList(Collection<? extends IDescriptor> descriptorList) {
        if (descriptorList == null) {
            throw new IllegalArgumentException("descriptorList is null");
        }

        for (final IDescriptor descriptor : descriptorList) {
            initProjectContextByDescriptor(descriptor);
            dependentCEs.add(descriptor);
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T setAutoSolvingAction(ISolvingAction autoSolvingActionParam) {
        return setAutoSolvingAction(autoSolvingActionParam, EAutoSolvingActionUsage.ONLY_AUTO_SOLVE);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T setAutoSolvingAction(ISolvingAction autoSolvingActionParam, EAutoSolvingActionUsage usage) {
        return setAutoSolvingAction(autoSolvingActionParam, usage, NO_SOLVING_ACTION_GROUPS);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T setAutoSolvingAction(ISolvingAction autoSolvingActionParam, EAutoSolvingActionUsage usage, ISolvingActionGroup... solvingActionGroups) {
        if (autoSolvingActionParam == null) {
            throw new IllegalArgumentException("autoSolvingActionParam is null");
        }

        if (this.autoSolvingAction != null && autoSolvingActionParam != autoSolvingAction) {
            throw new IllegalStateException("An AutoSolvingAction was already assign. Two AutoSolvingActions are not allowed.");
        }

        this.autoSolvingAction = autoSolvingActionParam;

        if (usage == EAutoSolvingActionUsage.ALSO_NORMAL_SOLVING_ACTION_AND_PREFERRED_ACTION) {
            setPreferredSolvingAction(autoSolvingActionParam, solvingActionGroups);
        } else if (usage == EAutoSolvingActionUsage.ALSO_NORMAL_SOLVING_ACTION) {
            addSolvingAction(autoSolvingActionParam, solvingActionGroups);
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T setPreferredSolvingAction(ISolvingAction preferredSolvingActionParam) {
        return setPreferredSolvingAction(preferredSolvingActionParam, NO_SOLVING_ACTION_GROUPS);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T setPreferredSolvingAction(ISolvingAction preferredSolvingActionParam, ISolvingActionGroup... solvingActionGroups) {
        if (preferredSolvingActionParam == null) {
            throw new IllegalArgumentException("preferredSolvingActionParam is null");
        }

        if (this.preferredSolvingAction != null && preferredSolvingActionParam != preferredSolvingAction) {
            throw new IllegalStateException("A PreferredSolvingAction was already assigned. Two PreferredSolvingActions are not allowed.");
        }

        if (preferredUISolvingAction != null) {
            throw new IllegalStateException("A preferred UI-SolvingAction was already set. There can be only one preferred solving action.");
        }

        this.preferredSolvingAction = preferredSolvingActionParam;

        // make sure it is also in the solving action list
        addSolvingAction(preferredSolvingActionParam, solvingActionGroups);

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T setPreferredUISolvingAction(IUISolvingAction uiSolvingAction) {
        checkNotNull(uiSolvingAction);
        if (preferredUISolvingAction != null && uiSolvingAction != preferredUISolvingAction) {
            throw new IllegalStateException("A preferred UI-SolvingAction was already assigned. Two preferred UI-SolvingActions are not allowed.");
        }
        if (preferredSolvingAction != null) {
            throw new IllegalStateException("A normal solving action was already set as preferred. There can be only one preferred solving action.");
        }
        preferredUISolvingAction = uiSolvingAction;
        addUISolvingAction(uiSolvingAction);
        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addSolvingAction(Collection<? extends ISolvingAction> solvingActions) {
        if (solvingActions == null) {
            throw new IllegalArgumentException("solvingActions is null");
        }

        solvingActionSet.addAll(solvingActions);

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addSolvingAction(ISolvingAction solvingAction) {
        return addSolvingAction(solvingAction, NO_SOLVING_ACTION_GROUPS);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addSolvingAction(ISolvingAction solvingAction, ISolvingActionGroup... solvingActionGroup) {
        if (solvingAction == null) {
            throw new IllegalArgumentException("solvingAction is null");
        }

        solvingActionSet.add(solvingAction);

        if (solvingActionGroup != null) {
            assignSolvingActionToGroup(solvingAction, solvingActionGroup);
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T assignSolvingActionToGroup(ISolvingAction solvingAction, ISolvingActionGroup... solvingActionGroup) {
        checkNotNull(solvingAction);
        checkNotNull(solvingActionGroup);
        solvingAction2Groups.putAll(solvingAction, Arrays.asList(solvingActionGroup));
        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <R extends IUISolvingAction> T addUISolvingAction(Collection<R> uiSolvingActions) {
        if (uiSolvingActions == null) {
            throw new IllegalArgumentException("uiSolvingActions is null");
        }

        uiSolvingActionSet.addAll(uiSolvingActions);

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addUISolvingAction(IUISolvingAction uiSolvingAction) {
        if (uiSolvingAction == null) {
            throw new IllegalArgumentException("uiSolvingAction is null");
        }

        uiSolvingActionSet.add(uiSolvingAction);

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addPredefinedVariantContext(IPredefinedVariantView predefinedVariantView) {
        if (predefinedVariantView == null) {
            throw new IllegalArgumentException("predefinedVariant is null");
        }
        explicitPredefinedVariantSet.add(predefinedVariantView);

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addPredefinedVariantContexts(Collection<IPredefinedVariantView> predefinedVariantViews) {
        if (predefinedVariantViews == null) {
            throw new IllegalArgumentException("predefinedVariants is null");
        }
        for (final IPredefinedVariantView view : predefinedVariantViews) {
            addPredefinedVariantContext(view);
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addInvariantViewContext(IInvariantView invariantView) {
        if (invariantView == null) {
            throw new IllegalArgumentException("invariantView is null");
        }
        explicitInvariantViewSet.add(invariantView);

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <R extends IInvariantView> T addInvariantViewContexts(Collection<R> invariantViews) {
        if (invariantViews == null) {
            throw new IllegalArgumentException("invariantViews is null");
        }
        for (final IInvariantView view : invariantViews) {
            addInvariantViewContext(view);
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T addModelViewContext(IModelView view) {
        if (view == null) {
            throw new IllegalArgumentException("view is null");
        }

        if (view instanceof IPredefinedVariantView) {
            addPredefinedVariantContext((IPredefinedVariantView) view);
        }
        if (view instanceof IInvariantView) {
            addInvariantViewContext((IInvariantView) view);
        }

        return getThis();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <R extends IModelView> T addModelViewContexts(Collection<R> views) {
        if (views == null) {
            throw new IllegalArgumentException("views is null");
        }
        for (final IModelView view : views) {
            addModelViewContext(view);
        }

        return getThis();
    }

    static class SolvingActionWithGroupInfo implements ISolvingAction, ISolvingActionGroupInfo, IHasWrappedInterfaces {

        private final ISolvingAction wrappedSolvingAction;

        private final Set<ISolvingActionGroup> groups;

        /**
         * Constructor for SolvingActionWithGroupInfo.
         *
         * @param input
         * @param groups
         */
        SolvingActionWithGroupInfo(ISolvingAction wrappedSolvingAction, Set<ISolvingActionGroup> groups) {
            this.wrappedSolvingAction = wrappedSolvingAction;
            this.groups = Collections.unmodifiableSet(groups);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public void run() {
            wrappedSolvingAction.run();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String getDescription() {
            return wrappedSolvingAction.getDescription();
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public Set<ISolvingActionGroup> getGroups() {
            return groups;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public <R> R extractInterface(Class<R> classObj) {
            return WrappedInterfaceUtil.extractInterface(classObj, this, wrappedSolvingAction);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IValidationResult buildResult() {

        final IMixedText descLoc;
        if (description != null) {
            descLoc = description;
        } else if (descriptionBuilder != null) {
            descLoc = descriptionBuilder.flushResult();

        } else {
            throw new IllegalStateException("INTERNAL ERROR: Description and DescriptionBuilder missing!");
        }

        if (descLoc.toString().isEmpty()) {
            throw new IllegalArgumentException(
                    "You have to specify a description text for the ValidationResult. Use description at newBuilder or fill text into the IMixedTextBuilder(getMixedTextBuilder()).");
        }

        setImplicitModelView();
        final Set<IPredefinedVariantView> predefinedVariantSet = buildPredefinedVariantSet();
        final Set<IInvariantView> invariantViewSet = buildInvariantViewSet();

        ISolvingActionContainer<ISolvingAction> solvingActionContainer = SolvingActionContainerUtil.create(autoSolvingAction, preferredSolvingAction, solvingActionSet,
                preferredUISolvingAction, uiSolvingActionSet);

        for (final ISolvingAction sa : solvingActionSet) {
            if (sa instanceof IHasSolvingActionGroups) {
                solvingAction2Groups.putAll(sa, ((IHasSolvingActionGroups) sa).getAssignedSolvingActionGroups());
            }
        }

        if (!solvingAction2Groups.isEmpty()) {
            // wrap group info
            solvingActionContainer = SolvingActionContainerUtil.wrap(solvingActionContainer,
                    new Function<ISolvingAction, ISolvingAction>() {
                        @Override
                        public ISolvingAction apply(ISolvingAction input) {
                            final Set<ISolvingActionGroup> groups = solvingAction2Groups.get(input);
                            if (groups.isEmpty()) {
                                return input;
                            } else {
                                return new SolvingActionWithGroupInfo(input, groups);
                            }
                        }
                    });
        }
        if (implicitModelViewByConstruction != null) {
            solvingActionContainer = SolvingActionContainerUtil.wrap(solvingActionContainer, new Function<ISolvingAction, ISolvingAction>() {
                @Override
                public ISolvingAction apply(ISolvingAction input) {
                    return assignModelViewToSolvingActionToExecuteIn(input);
                }
            });
        }

        return buildResultInternal(resultId, severityType, markerSet, descLoc, erroneousCEs, dependentCEs, solvingActionContainer, innerException, predefinedVariantSet,
                invariantViewSet, additionalDistinguishingObject);
    }

    @Nullable
    private ISolvingAction assignModelViewToSolvingActionToExecuteIn(@Nullable ISolvingAction saLoc) {
        if (saLoc == null) {
            return null;
        }
        if (saLoc instanceof IVariantSolvingAction) {
            // The passed solvingAction has already variant information, so we do not need to additionally wrap it.
            return saLoc;
        }
        if (implicitModelViewByConstruction != null) {
            return SolvingActions.executeInView(implicitModelViewByConstruction, saLoc);
        }
        return saLoc;
    }

    @KeepSecretFromPublishedApi
    protected abstract IValidationResult buildResultInternal(IValidationResultId resultIdParam, EValidationSeverityType severityTypeParam,
            Collection<IValidationResultMarkerType> markerCollection,
            IMixedText descriptionParam,
            List<IDescriptor> erroneousCEsParam, List<IDescriptor> dependentCEsParam, ISolvingActionContainer<ISolvingAction> solvingActionContainer, Throwable innerExceptionParam,
            Set<IPredefinedVariantView> predefinedVariantSetParam, Set<IInvariantView> invariantViewSetParam, Object additionalDistinguishingObjectParam);

    private Set<IPredefinedVariantView> buildPredefinedVariantSet() {
        if (!explicitInvariantViewSet.isEmpty() || !explicitPredefinedVariantSet.isEmpty()) {
            return explicitPredefinedVariantSet;
        }
        if (!implicitModelViewByElementsSet.isEmpty()) {
            final Set<IPredefinedVariantView> set = Sets.newHashSet();
            for (final IModelView view : implicitModelViewByElementsSet) {
                if (view instanceof IPredefinedVariantView) {
                    set.add((IPredefinedVariantView) view);
                }
            }
            return set;
        }
        if (implicitModelViewByConstruction instanceof IPredefinedVariantView) {
            return Collections.singleton((IPredefinedVariantView) implicitModelViewByConstruction);
        }
        return Collections.emptySet();
    }

    private Set<IInvariantView> buildInvariantViewSet() {
        if (!explicitInvariantViewSet.isEmpty() || !explicitPredefinedVariantSet.isEmpty()) {
            return explicitInvariantViewSet;
        }
        if (!implicitModelViewByElementsSet.isEmpty()) {
            final Set<IInvariantView> set = Sets.newHashSet();
            for (final IModelView view : implicitModelViewByElementsSet) {
                if (view instanceof IInvariantView) {
                    set.add((IInvariantView) view);
                }
            }
            return set;
        }
        if (implicitModelViewByConstruction instanceof IInvariantView) {
            return Collections.singleton((IInvariantView) implicitModelViewByConstruction);
        }
        return Collections.emptySet();
    }

    private void setImplicitModelView() {
        if (projectContext.isPresent()) {
            final IModelViewManager viewManager = projectContext.get().getService(IModelViewManager.class);
            if (viewManager != null) {
                implicitModelViewByConstruction = viewManager.getCurrentlyActiveView();
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public T setAdditionalDistinguishingObject(Object additionalDistinguishingObjectParam) {
        checkNotNull(additionalDistinguishingObjectParam);
        if (additionalDistinguishingObject != null) {
            throw new IllegalStateException("setAdditionalDistinguishingObject() may not be called multiple times");
        }
        additionalDistinguishingObject = additionalDistinguishingObjectParam;
        return getThis();
    }

}