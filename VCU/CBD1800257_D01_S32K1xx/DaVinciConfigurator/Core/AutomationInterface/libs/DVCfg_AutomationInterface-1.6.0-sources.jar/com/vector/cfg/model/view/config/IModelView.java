package com.vector.cfg.model.view.config;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.variant.IPostBuildView;

/**
 * This is the base-API of all model views.
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 * <p>
 * Implementations of this interface are comparable. This guarantees deterministic order of the model views in access methods of the {@link IModelViewManager} and generator
 * access services. In detail: The order is implemented as the alphabetical order of the model view names.
 * </p>
 *
 * <p>
 * The three interfaces <code>IUnfilteredView</code>, <code>IPreBuildView</code> and {@link IPostBuildView} define special meaning.
 *
 * <ul>
 * <li>The <code>IUnfilteredView</code> disables all other currently active views and also change modes.</li>
 * <li>The {@link IPostBuildView} also enables the corresponding <code>IPreBuildView</code> when it is activated.</li>
 * <li>The <code>IPreBuildView</code> deactivates the currently active {@link IPostBuildView} and replaces it with the <code>IPostBuildUnfilteredView</code>.</li>
 * </ul>
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
public interface IModelView extends Comparable<IModelView> {

    /**
     * Returns the views name.
     *
     * @return
     */
    @PublishedMethod
    String getName();

    /**
     * Executes the code under visibility of this model view.
     * <p>
     * <strong>The returned {@link IModelViewExecutionContext} must be used within a Java "try-with-resources" feature.</strong> It makes sure, that the old view is restored
     * when the try is completed.
     * </p>
     * <p>
     * Example:
     *
     * <pre>
     * <code>
     * public void foo(IModelView modelView) {
     *
     *     try (final {@link IModelViewExecutionContext} context = modelView.executeWithThisView()) {
     *         // do some operations
     *         ...
     *     }
     * }
     * </code>
     * </pre>
     *
     * </p>
     *
     * @return the i model view execution context
     */
    @PublishedMethod
    IModelViewExecutionContext executeWithThisView();

    /**
     * {@inheritDoc}
     *
     * <p>
     * Caution: {@link IModelView}s of different projects are <b>NOT</b> equal. So {@link #equals(Object)} will always yield <code>false</code> for views of different projects!
     * If you want to compare variance definition, please use method {@link #hasSameVarianceDefinitionAs(IModelView)}.
     * </p>
     *
     * <p>
     * Note: Only identity based equal is supported, so equals() for {@link IModelView} means the same as <code>==</code>!
     * </p>
     *
     */
    @Override
    boolean equals(Object other);

    /**
     * {@inheritDoc}
     *
     * <p>
     * Caution: {@link IModelView}s of different projects are <b>NOT</b> equal. So {@link #compareTo(Object)} will not yield <code>0</code> for views of different projects! If
     * you want to compare variance definition, please use method {@link #hasSameVarianceDefinitionAs(IModelView)}.
     * </p>
     *
     * <p>
     * {@link #compareTo(IModelView)} has a deterministic order over project boundaries, but does not specify the internal ordering, so you can sort {@link IModelView} of
     * different projects.
     * </p>
     *
     */
    @Override
    @PublishedMethod
    int compareTo(IModelView o);

    /**
     * Returns <code>true</code>, if this {@link IModelView} and the other {@link IModelView} have the same variance definition and are of the same {@link IModelView} subtype.
     * The same variance definition means have the same PreBuild and PostBuild values for each SwSysconst value or PostBuild criterion value.
     *
     * <p>
     * This will also work over different projects. So you can compare {@link IModelView} A from project Pa with {@link IModelView} B of project Pb, and this will yield
     * <code>true</code>, if A and B have the same variance definition.
     * </p>
     *
     * <p>
     * This can be used to find a corresponding {@link IModelView} in a different project.
     * </p>
     *
     * @param other the other
     * @return true, if both have the same type and variance definition.
     */
    @KeepSecretFromPublishedApi
    boolean hasSameVarianceDefinitionAs(IModelView other);

}
