package com.vector.cfg.model.query.modelcheckedaccess;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
//CHECKSTYLE:OFF
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaRequest;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaDefinitionUndefinedException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaNotExistsException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongQuantityException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterHasIllegalValueException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterHasNoValueException;
import com.vector.cfg.model.query.modelcheckedaccess.tuple.IModelTuple;
import com.vector.cfg.model.query.modelcheckedaccess.tuple.IModelTupleList;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

//CHECKSTYLE:ON
/**
 * <div class="extdoc" id="Common">
 *
 * <h2>IModelSimpleAccess</h2> The {@link IModelSimpleAccess} is an abstraction of the {@link IModelCheckedAccess} service, to provide a simple to use interface for the common
 * model requests. Every model request done the {@link IModelSimpleAccess} will throw the same exception types as the {@link IModelCheckedAccess} , when the request fails.
 *
 * The main idea of the {@link IModelSimpleAccess} is, that you don not need to specify the "real" type of an element. The type information is contained in the passed
 * {@link TypedDefRef}. So for the common cases the request code is much smaller than the {@link IModelCheckedAccess} code, and the code the type safe. When a type of an
 * {@link TypedDefRef} changes, you will get a compile error at the {@link IModelSimpleAccess} usages, if the change was incompatible.
 *
 *
 * You can use the IModelSimpleAccess only with {@link TypedDefRef} instances.
 *
 * <p>
 * All subsequent examples use the variable msa as an instance of the {@link IModelSimpleAccess} service.
 *
 * <pre>
 * <code class="Java" id="ModelSimpleAccess examples">
 *   MINumericalValue param = msa.getOneElement(PARAM_DEFREF);
 *   List<MINumericalValue> paramList = msa.getManyElements(PARAM_DEFREF);
 *   Boolean boolValue = msa.getOneValue(PARAM_DEFREF);
 *
 *   MIContainer container = msa.getOneElement(CONTAINER_DEFREF);
 * </code>
 * </pre>
 *
 * </p>
 * <h3>Possible requests</h3> The following types of request are possible:
 * <ul>
 * <li><code>getOneElement(MIHasDefinition, TypedDefRef)</code></li>
 * <li><code>getOneElement(TypedDefRef)</code></li>
 * <li><code>getOneElementAsRequest(MIHasDefinition, TypedDefRef)</code></li>
 * <li><code>getOneElementAsRequest(TypedDefRef)</code></li>
 * <li><code>getOneValue(MIHasDefinition, TypedDefRef)</code></li>
 * <li><code>getOneValue(TypedDefRef)</code></li>
 * <li><code>getOneValueTuple(MIHasDefinition, TypedDefRef)</code></li>
 * <li><code>getOneValueTuple(TypedDefRef)</code></li>
 * <li><code>getManyElements(MIHasDefinition, TypedDefRef)</code></li>
 * <li><code>getManyElements(TypedDefRef)</code></li>
 * <li><code>getManyElementsAsRequest(MIHasDefinition, TypedDefRef)</code></li>
 * <li><code>getManyElementsAsRequest(TypedDefRef)</code></li>
 * <li><code>getManyValues(MIHasDefinition, TypedDefRef)</code></li>
 * <li><code>getManyValues(TypedDefRef)</code></li>
 * <li><code>getManyValueTuples(MIHasDefinition, TypedDefRef)</code></li>
 * <li><code>getManyValueTuples(TypedDefRef)</code></li>
 * </ul>
 *
 * </div>
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IModelSimpleAccess {

    /*
     * Return One Section
     */

    /**
     * Executes the model request and returns a single ConfigurationElement(CE), relative to the parent element.
     *
     * <p>
     * The requested element must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IModelSimpleAccess#getManyElements(MIHasDefinition, TypedDefRef))} instead.
     * </p>
     *
     * @param parent the parent element
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> CONFIG_TYPE getOneElement(MIHasDefinition parent,
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a single ConfigurationElement(CE), relative to the parent element.
     *
     * <p>
     * The requested element must must have exactly one instance, otherwise this method will return an invalid request. If you are not sure use
     * {@link IModelSimpleAccess#getManyElements(MIHasDefinition, TypedDefRef))} instead.
     * </p>
     *
     * @param parent the parent element
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> IMcaRequest<CONFIG_TYPE> getOneElementAsRequest(MIHasDefinition parent,
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a single ConfigurationElement(CE).
     *
     * <p>
     * The requested element must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IModelSimpleAccess#getManyElements(TypedDefRef))} instead.
     * </p>
     *
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> CONFIG_TYPE getOneElement(TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a single ConfigurationElement(CE).
     *
     * <p>
     * The requested element must must have exactly one instance, otherwise this method will return an invalid request. If you are not sure use
     * {@link IModelSimpleAccess#getManyElements(TypedDefRef))} instead.
     * </p>
     *
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> IMcaRequest<CONFIG_TYPE> getOneElementAsRequest(
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a single value of a {@link MIParameterValue} ConfigurationElement(CE), relative to the parent element.
     *
     * <p>
     * The requested element must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IModelSimpleAccess#getManyValues(MIHasDefinition, TypedDefRef))} instead.
     * </p>
     *
     * @param parent the parent element
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> VALUE_TYPE getOneValue(MIHasDefinition parent,
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a single value of a {@link MIParameterValue} ConfigurationElement(CE).
     *
     * <p>
     * The requested element must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IModelSimpleAccess#getManyValues(TypedDefRef))} instead.
     * </p>
     *
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> VALUE_TYPE getOneValue(TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a single Tuple ({@link IModelTuple} of a {@link MIParameterValue} ConfigurationElement(CE), relative to the parent element.
     *
     * <p>
     * The requested element must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IModelSimpleAccess#getManyTuples(MIHasDefinition, TypedDefRef))} instead.
     * </p>
     *
     * @param parent the parent element
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IModelTuple<VALUE_TYPE, CONFIG_TYPE> getOneValueTuple(MIHasDefinition parent,
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a single Tuple ({@link IModelTuple} of a {@link MIParameterValue} ConfigurationElement(CE).
     *
     * <p>
     * The requested element must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IModelSimpleAccess#getManyTuples(TypedDefRef))} instead.
     * </p>
     *
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IModelTuple<VALUE_TYPE, CONFIG_TYPE> getOneValueTuple(
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /*
     * Return Many Section
     */

    /**
     * Executes the model request and returns a list of ConfigurationElements (CE), relative to the parent element.
     *
     *
     *
     * @param parent the parent element
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> List<CONFIG_TYPE> getManyElements(MIHasDefinition parent,
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a list of ConfigurationElements (CE), relative to the parent element.
     *
     *
     *
     * @param parent the parent element
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> IMcaRequest<List<CONFIG_TYPE>> getManyElementsAsRequest(MIHasDefinition parent,
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a list of ConfigurationElements (CE).
     *
     *
     *
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> List<CONFIG_TYPE> getManyElements(
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a list of ConfigurationElements (CE).
     *
     *
     *
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> IMcaRequest<List<CONFIG_TYPE>> getManyElementsAsRequest(
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a a list of values of the requested {@link MIParameterValue} ConfigurationElements (CE), relative to the parent element.
     *
     *
     *
     * @param parent the parent element
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> List<VALUE_TYPE> getManyValues(MIHasDefinition parent,
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a list of values of the requested {@link MIParameterValue} ConfigurationElements (CE).
     *
     *
     *
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> List<VALUE_TYPE> getManyValues(
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a list of Tuples ({@link IModelTuple} of the requested {@link MIParameterValue} ConfigurationElements (CE), relative to the parent
     * element.
     *
     *
     *
     * @param parent the parent element
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IModelTupleList<VALUE_TYPE, CONFIG_TYPE> getManyValueTuples(
            MIHasDefinition parent, TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

    /**
     * Executes the model request and returns a list of Tuples ({@link IModelTuple} of the requested {@link MIParameterValue} ConfigurationElements (CE).
     *
     *
     *
     * @param defRef the definitionReference of the request element
     *
     * @return The ConfigruationElement
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no container was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one container was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * <li>if the passed DefRef type is not supported</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IModelTupleList<VALUE_TYPE, CONFIG_TYPE> getManyValueTuples(
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);
}
