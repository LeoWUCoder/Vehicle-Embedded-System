package com.vector.cfg.automation.scripting.base;

import java.nio.file.Path;

import com.google.inject.ConfigurationException;
import com.google.inject.ProvisionException;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.paths.IAutomationPathsApi;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.scripting.dynamic.IDynamicObjectAware;
import com.vector.cfg.util.servicecontext.IServiceContext;

/**
 * {@link IAutomationContext} class represents the execution context of the automation API, normally a script will use the sub type {@link IScriptExecutionContext}. The
 * {@link IAutomationContext} provides a base to use automation API with or without scripts and script tasks.
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IScriptExecutionContext
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IAutomationContext extends IDynamicObjectAware {

    /**
     * Returns the requested service instance by the passed {@link Class}.
     *
     * <p>
     * Normally this method is used to retrieve automation API instance from Java code clients, where these instance are not available like in Groovy.
     * </p>
     *
     * @param <T> the type of the instance to retrieve
     * @param type the class of the requested instance.
     * @return service instance
     * @throws IllegalArgumentException - if the argument is <code>null</code>
     * @throws ConfigurationException if this {@link IServiceContext} cannot find or create the provider.
     * @throws ProvisionException if there was a runtime failure while providing an instance.
     */
    @PublishedMethod
    <T> T getInstance(Class<T> clazz);

    /**
     * Returns the Thread, on which this {@link IAutomationContext} is running.
     *
     * @return the execution thread
     */
    @PublishedMethod
    Thread getExecutionThread();

    /**
     * Returns the currently running {@link IAutomationTask}.
     *
     * @return the currently running script task
     */
    @PublishedMethod
    IAutomationTask getScriptTask();

    /**
     * Returns the paths API to retrieve and resolve {@link Path} objects.
     * <p>
     * Possible paths are:
     * <ul>
     * <li>Script folder</li>
     * <li>Temp folder</li>
     * <li>SIP folder</li>
     * <li>Project folder</li>
     * </ul>
     *
     * @return the paths API
     * @see IAutomationPathsApi
     */
    @PublishedMethod
    IAutomationPathsApi getPaths();

    /**
     * The Interface IProjectAutomationContext defines the {@link IApplicationAutomationContext} with an IProjectContext as ServiceContext.
     */
    @PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IProjectAutomationContext extends IAutomationContext {

    }

    /**
     * The Interface IProject defines the base interface for all loaded Project of {@link IProjectAutomationContext} instances.
     */
    @PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IProject extends IDynamicObjectAware {
        /**
         * Returns the underlying {@link IProjectContext} of this Project.
         *
         * @return the project context
         */
        @PublishedMethod
        IProjectContext getProjectContext();
    }

    /**
     * The Interface IDomainApi defines the base interface for all loaded Domain API of the {@link IProject}.
     */
    @PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IDomainApi extends IDynamicObjectAware {

    }

    /**
     * The Interface IProjectAutomationContext defines the {@link IApplicationAutomationContext} with an IApplicationContext as ServiceContext.
     */
    @PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IApplicationAutomationContext extends IAutomationContext {

    }
}
