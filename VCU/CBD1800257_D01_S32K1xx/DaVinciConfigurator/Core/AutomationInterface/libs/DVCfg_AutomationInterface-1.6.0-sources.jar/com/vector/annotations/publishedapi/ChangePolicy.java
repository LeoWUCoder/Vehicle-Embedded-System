package com.vector.annotations.publishedapi;

/**
 * 
 * The policy for changes of a types with are marked by a {@link PublishedApi} annotation.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @since 1.0
 * @see PublishedApi
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
// @CHECKSTYLE:OFF Is an Enum for Annotations, and also PublishedAPI, so the name is not changeable.
public enum ChangePolicy {
    // @CHECKSTYLE:ON
    /**
     * All Changes to this type are forbidden. This means a change is a BREAKING CHANGE!
     */
    CHANGES_FORBIDDEN,

    /**
     * Method additions to this type are allowed. => You can add new methods, but you can't change existing methods or types.
     */
    ADDITIONS_ALLOWED,

    /**
     * This is no Published Class, but an base class of PublishedApi. The BaseClass must be exported with this annotation.
     */
    CLASS_DEPENDENCY;
}
