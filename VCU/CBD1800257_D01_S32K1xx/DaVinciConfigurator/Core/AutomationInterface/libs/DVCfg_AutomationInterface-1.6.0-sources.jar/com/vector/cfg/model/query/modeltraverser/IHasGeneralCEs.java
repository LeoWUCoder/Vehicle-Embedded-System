package com.vector.cfg.model.query.modeltraverser;

import java.util.Collection;
import java.util.Set;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Instances of type {@link IHasGeneralCEs}, could produce {@link IDescriptor}s for e.g. the Consistency to invalidate results.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IHasGeneralCEs {

    /**
     * Gets the dependent CEs as {@link IDescriptor} objects.
     *
     * @return the dependent CEs
     */
    @PublishedMethod
    Collection<IDescriptor> getGeneralCEs();

    /**
     * Gets the walked elements, this Set could contain deleted elements!
     *
     * @return the walked elements
     */
    @PublishedMethod
    Set<MIHasDefinition> getWalkedElements();

}
