package com.vector.cfg.core.app;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.util.Locale;
import java.util.concurrent.Callable;

import com.google.inject.BindingAnnotation;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.servicecontext.IServiceContext;
import com.vector.cfg.util.supervisor.IStateSupervisor;

/**
 * The application context provides all project independent services and access to the application state.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public interface IApplicationContext extends IStateSupervisor<IApplicationState>, IServiceContext {

    /**
     * This method will create a new ProjectContext.
     *
     * @return
     */
    IProjectContext createProjectContext();

    /**
     * Call this method to delete the ProjectContext.
     */
    void removeProjectContext();

    /**
     * Get the current {@link IProjectContext} instance.
     *
     * @return the project context.
     */
    IProjectContext getProjectContext();

    /**
     * Get the current application mode. Defaults to EApplicationMode.HEADLESS.
     *
     * @return
     */
    EApplicationMode getMode();

    /**
     * Set the current application mode. Needs to be set only if running in GUI mode, since the default is HEADLESS.
     */
    void setMode(EApplicationMode mode);

    /**
     * Sets the current eclipse context of the running application.
     *
     * @param context
     */
    void setEclipseApplicationContext(org.eclipse.equinox.app.IApplicationContext context);

    /**
     * Gets the eclipse application context.
     *
     * @return the eclipse application context
     */
    org.eclipse.equinox.app.IApplicationContext getEclipseApplicationContext();

    /**
     * Get the locale, that was active at the point the {@code IApplicationContext} was created.
     *
     * Always use this locale, since this stays constant even if the user changes the system locale during runtime. In this case he needs to restart the application.
     *
     * @return
     */
    Locale getLocale();

    @Retention(RUNTIME)
    @Target({ ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD, ElementType.TYPE })
    @BindingAnnotation
    public @interface ApplicationContextService {

    }

    /**
     * Returns true, if the {@link IApplicationContext}, was already initialized. So the Injector inside was created. If the {@link IApplicationContext} is disposed, the method
     * will return <code>false</code>
     *
     * @return true, if initialized.
     *
     */
    boolean isInitialized();

    /**
     * Activates this {@link IApplicationContext} on the current thread during the execution of the {@link Callable}.
     * 
     * @param code
     * @return the returned value of code.
     */
    <T> T with(Callable<T> call);

    /**
     * Activates this {@link IApplicationContext} on the current thread during the execution of the {@link Runnable}.
     *
     * @param code
     */
    void with(Runnable run);

}
