package com.vector.annotations.publishedapi;

/**
 * DomainType specifies in which "domain" shall the {@link PublishedApi} classes visible and usable.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see PublishedApiDomain
 * @see PublishedApiVersionInfo
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
// @CHECKSTYLE:OFF Is an Enum for Annotations, and also PublishedAPI, so the name is not changeable.
public enum DomainType {
    // @CHECKSTYLE:ON
    /**
     * Marks the class, that it is visible in the Generators.
     */
    GENERATORS,

    /**
     * Marks the class, that it is visible for the Vector internal Generators. So these classes are NOT visible in the customer GenDevKit.
     */
    GENERATOR_INTERNAL_ADDONS,

    /**
     * Marks the class, that it is visible in the AutomationInterface clients.
     */
    AUTOMATION_IF,

    /**
     * Marks the class, that it is visible for the Vector internal AutomationInterface clients.
     */
    AUTOMATION_IF_INTERNAL_ADDONS,

    /**
     * Marks the class, that it is visible for server communication like server api or daemon communication.
     */
    SERVER_IF,
}
