/**
 * Type definition of {@link com.vector.cfg.gen.core.gencore.generationsteps.IGenerationStep}s.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.gencore.generationsteps;