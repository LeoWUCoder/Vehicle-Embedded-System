package com.vector.cfg.util.platform.publishedapi.filters;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilterValue;

@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public final class AMsrPlatform implements PublishedFilterValue {

    private AMsrPlatform() {

    }
}