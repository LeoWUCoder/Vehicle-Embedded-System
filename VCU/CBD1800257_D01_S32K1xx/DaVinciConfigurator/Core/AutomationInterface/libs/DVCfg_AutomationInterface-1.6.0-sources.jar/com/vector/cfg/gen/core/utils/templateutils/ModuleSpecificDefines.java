package com.vector.cfg.gen.core.utils.templateutils;

import java.text.MessageFormat;
import java.util.regex.Pattern;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.business.msr.model.det.DetDefRef;
import com.vector.cfg.core.derivative.DerivativeInfo;
import com.vector.cfg.core.derivative.EImplementationProperties;
import com.vector.cfg.core.derivative.ImplementationProperty;
import com.vector.cfg.core.project.IProjectUserSettings;
import com.vector.cfg.gen.core.bswmdmodel.GIModuleConfiguration;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.exceptions.ValidationFailedException;
import com.vector.cfg.gen.core.moduleinterface.platform.GenPlatformServiceException;
import com.vector.cfg.gen.core.moduleinterface.platform.IGenPlatformService;
import com.vector.cfg.gen.core.moduleinterface.platform.IGenPlatformService.EAtomicVariableAccess;
import com.vector.cfg.gen.core.moduleinterface.platform.IGenPlatformService.EBitOrder;
import com.vector.cfg.gen.core.moduleinterface.platform.IGenPlatformService.EDummyStatementKind;
import com.vector.cfg.gen.core.moduleinterface.platform.IGenPlatformService.IGenPlatformValueRequest;
import com.vector.cfg.gen.core.utils.GenConstants;
import com.vector.cfg.gen.core.utils.exceptions.GeneralParameterException;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.gen.core.utils.frameworkinternal.GeneratorUtilFrameworkHelper;
import com.vector.cfg.gen.core.utils.generatorpackage.GeneratorPackageUtil;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.EDefRefWildcard;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationVariant;
import com.vector.cfg.model.access.ecuconfiguration.IEcuConfigurationAccess;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucModuleConfiguration;
import com.vector.cfg.model.access.ecuconfiguration.elements.ModuleConfigurationPostBuildSettings;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBooleanParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBswImplementation;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBswImplementationARRef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEnumerationParamDef;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaRequest;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * ModuleSpecificDefines provides the methods generate* to get the GeneralDefine block for a specific generator.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public final class ModuleSpecificDefines {

    private static final String POSTFIX_DEV_ERROR_DETECT_MODULE_PARAMETER = "SafeBswChecks";

    private static final String CONST_V = "(v)";

    private static final String MISRA_PRQA_S_3453 = " /* PRQA S 3453 */ /* MD_MSR_FctLikeMacro */ ";

    private static final ILogger logger = Logger.INSTANCE.createLogger(ModuleSpecificDefines.class);

    private static final int CONST_16 = 16;

    private static final int CONST_32 = 32;

    private static final int CONST_64 = 64;

    /*
     * Constants
     */
    private static final String ATOMIC_8 = "Atomic8BitAccess";

    private static final String ATOMIC_16 = "Atomic16BitAccess";

    private static final String ATOMIC_32 = "Atomic32BitAccess";

    private static final String ATOMIC_64 = "Atomic64BitAccess";

    private static final Pattern C_IDENTIFIER_PATTERN = Pattern.compile("^([^A-Za-z])|([^A-Za-z0-9_])", Pattern.DOTALL);

    private static final String CONFIG_VARIANT_PB_LOADABLE = "CONFIGURATION_VARIANT_POSTBUILD_LOADABLE";

    private static final String CONFIG_VARIANT_LT = "CONFIGURATION_VARIANT_LINKTIME";

    private static final String CONFIG_VARIANT_PC = "CONFIGURATION_VARIANT_PRECOMPILE";

    private static final String OS_TYPE_AUTOSAR = "AUTOSAR";

    private static final String OS_TYPE_OSEK = "OSEK";

    private static final DefRef ECUC_DEFREF = DefRef.create(EDefRefWildcard.MICROSAR, "EcuC");

    private static final DefRef BOARD_DEFREF = DefRef.create("/MICROSAR", "Board");

    private static final DefRef ECUC_CRC_CHECK = DefRef.create("/MICROSAR", "EcuC/EcucGeneral/CrcCheck");

    private static final DefRef BOARD_CRC_CHECK = DefRef.create("/MICROSAR", "Board/BoardGeneral/BoardPCAndLTCRCCheck");

    private static final DefRef BOARD_OS_TYPE = DefRef.create("/MICROSAR", "Board/BoardGeneral/BoardOsType");

    /*
     * Private fields
     */
    private final IProjectUserSettings projectUserSettings;

    private final IProjectContext projectContext;

    private final IGeneratorPackage generatorPackage;

    private final IModelCheckedAccess mca;

    private final IEcuConfigurationAccess eca;

    private String msnUpperCase;

    private String msn;

    @PublishedMethod
    public ModuleSpecificDefines(final IGeneratorPackage generatorPackage) {
        this.projectContext = generatorPackage.getProjectContext();
        this.generatorPackage = generatorPackage;
        this.mca = projectContext.getService(IModelCheckedAccess.class);
        this.eca = projectContext.getService(IEcuConfigurationAccess.class);
        this.projectUserSettings = projectContext.getService(IProjectUserSettings.class);

        msn = generatorPackage.getMSN();
        msnUpperCase = generatorPackage.getMSN().toUpperCase();
    }

    private String escapeNonCIdentChars(final String input) {
        return C_IDENTIFIER_PATTERN.matcher(input).replaceAll("_");
    }

    private void setMsn(final String msnLoc) {
        msn = msnLoc;
        msnUpperCase = msnLoc.toUpperCase();
    }

    private DerivativeInfo getDerivateInfo() {

        final DerivativeInfo derivative = projectUserSettings.getDerivative(msn);

        return derivative;
    }

    private ImplementationProperty getImplPropertyValue(final EImplementationProperties prop) {

        return projectUserSettings.getImplPropertyValue(msn, prop);

    }

    private String defineOsType(final String boardOsType, final String comment) {
        final String switchName = String.format("%s_OSTYPE_%s", msnUpperCase, escapeNonCIdentChars(boardOsType).toUpperCase());
        return getIfnDefDefine(switchName, null, comment);
    }

    /**
     * Generic description. <br>
     * #ifndef &lt;MSN&gt;_OSTYPE_AUTOSAR<br>
     * #define &lt;MSN&gt;_OSTYPE_AUTOSAR<br>
     * #endif <br>
     * <br>
     * Sample<br>
     * #ifndef FR_OSTYPE_AUTOSAR <br>
     * #define FR_OSTYPE_AUTOSAR <br>
     * #endif <br>
     *
     * @return
     */
    @ReworkThisAtNextBreakingChange("Check if OsType define can be removed from GeneralDefineBlock. Since ASR4 only the value 'AUTOSAR' is used.")
    private String defineOsType() {
        /*
         * #define FR_OSTYPE_AUTOSAR <br>
         */
        if (isBoardModulePresent(mca)) {
            final String osTypeToGenerate = getOsType(mca);
            final String osTypeComment = getOsTypeDefRef(mca);
            return defineOsType(osTypeToGenerate, osTypeComment);
        }
        return "";
    }

    /**
     * If neither ecuc nor board is present, an Exception will be thrown, this method catches the exception and returns an empty string.
     *
     * @param platformServiceRequest
     * @return
     */
    private String getDefRefString(IGenPlatformValueRequest<?, ?, ?, ?> platformServiceRequest) {
        try {
            return platformServiceRequest.getDefinition().getDefRefString();
        } catch (final GenPlatformServiceException e) {
            return "";
        }
    }

    /**
     * /MICROSAR/EcuC/EcucGeneral/DummyStatement --> #define MSN_USE_DUMMY_STATEMENT STD_OFF.
     *
     * @return
     */
    private String defineUseDummyStatement(IGenPlatformService platformService) {
        final IGenPlatformValueRequest<MIBooleanParamDef, MINumericalValue, Boolean, Boolean> useDummyStatementRequest = platformService.useDummyStatement();
        if (!useDummyStatementRequest.isValid()) {
            throwGenParameterException("DummyStatement", getDefRefString(useDummyStatementRequest));
        }
        final boolean useDummyStetement = useDummyStatementRequest.getValue();
        final String useDummyStetementComment = useDummyStatementRequest.getDefinition().getDefRefString();
        return defineUseDummyStatementInternal(useDummyStetement, useDummyStetementComment);
    }

    /**
     * /MICROSAR/EcuC/EcucGeneral/DummyStatement --> #define MSN_USE_DUMMY_STATEMENT STD_OFF .
     *
     * @param boardDummyStatement
     * @param comment
     * @return
     */
    private String defineUseDummyStatementInternal(final boolean boardDummyStatement, final String comment) {
        final String switchName = String.format("%s_USE_DUMMY_STATEMENT", msnUpperCase);

        return getIfnDefDefineAsymmetric(switchName, switchName, F.formatBool(boardDummyStatement).asStdOnOff().generate(), comment);
    }

    /**
     * Only return a statement if parameter /MICROSAR/EcuC/EcucGeneral/DummyStatementKind is present.<br/>
     * If absent -> "".<br/>
     * E.g. /MICROSAR/EcuC/EcucGeneral/DummyStatementKind --> B) #define MSN_DUMMY_STATEMENT(v) (void)(v)
     *
     * @return
     */
    // #ifndef FRTRCV_DUMMY_STATEMENT(v)<br/>
    // #define FRTRCV_DUMMY_STATEMENT(v) /* PRQA S 3453 */ /* MD_MSR_FctLikeMacro */ /* /MICROSAR/EcuC/EcucGeneral/DummyStatementKind */<br/>
    // #endif<br/>
    @VisibleForTesting
    String defineDummyStatement(IGenPlatformService platformService) {
        /*
         * Fetch EDummyStatementKind
         */
        final IGenPlatformValueRequest<MIEnumerationParamDef, MITextualValue, String, EDummyStatementKind> dummyStatementKindRequest = platformService.getDummyStatementKind();
        if (!dummyStatementKindRequest.isValid()) {
            /*
             * For backward compatibility: dont create define if param is missing. Use Case ASR3 and backward compatibility
             */
            return "";
        }
        final EDummyStatementKind dummyStatementKind = dummyStatementKindRequest.getValue();
        final String value = calculateValueForDummyStatementKind(dummyStatementKind);

        final String useDummyStetementComment = dummyStatementKindRequest.getDefinition().getDefRefString();
        return defineDummyStatementInternal(value, useDummyStetementComment);
    }

    /**
     * E.g. /MICROSAR/EcuC/EcucGeneral/DummyStatementKind --> B) #define MSN_DUMMY_STATEMENT(v) (void)(v)
     *
     * @param boardDummyStatement
     * @param comment
     * @return
     */
    private String defineDummyStatementInternal(final String value, final String comment) {
        final String switchName = String.format("%s_DUMMY_STATEMENT", msnUpperCase);

        return getIfnDefDefineAsymmetric(switchName, switchName + CONST_V, F.formatString(value).postfix(MISRA_PRQA_S_3453).generate(), comment);
    }

    /**
     * Only returns a statement if parameter /MICROSAR/EcuC/EcucGeneral/DummyStatementKind is present. <br/>
     * If absent -> "".<br/>
     * E.g. /MICROSAR/EcuC/EcucGeneral/DummyStatementKind --> B) #define MSN_DUMMY_STATEMENT_CONST(v) (void)(v)
     *
     * @return
     */
    @VisibleForTesting
    String defineDummyStatementConst(IGenPlatformService platformService) {
        /*
         * Fetch EDummyStatementKind
         */
        final IGenPlatformValueRequest<MIEnumerationParamDef, MITextualValue, String, EDummyStatementKind> dummyStatementKindRequest = platformService.getDummyStatementKind();
        if (!dummyStatementKindRequest.isValid()) {
            /*
             * For backward compatibility: dont create define if param is missing.
             */
            return "";
        }
        final EDummyStatementKind dummyStatementKind = dummyStatementKindRequest.getValue();
        final String value = (dummyStatementKind == EDummyStatementKind.None) ? "" : "(void)(v)";

        final String useDummyStetementComment = dummyStatementKindRequest.getDefinition().getDefRefString();
        return defineDummyStatementConstInternal(value, useDummyStetementComment);
    }

    /**
     * E.g. /MICROSAR/EcuC/EcucGeneral/DummyStatementKind --> B) #define MSN_DUMMY_STATEMENT_CONST(v) (void)(v)
     *
     * @param boardDummyStatement
     * @param comment
     * @return
     */
    private String defineDummyStatementConstInternal(final String value, final String comment) {
        final String switchName = String.format("%s_DUMMY_STATEMENT_CONST", msnUpperCase);
        return getIfnDefDefineAsymmetric(switchName, switchName + CONST_V, F.formatString(value).postfix(MISRA_PRQA_S_3453).generate(), comment);
    }

    /**
     *
     * Returns the appropriate postfix. <br/>
     * <div class="extdoc" id="Calculate_Dummy_Statement_Kind"> dummyStatementKind == None: <br/>
     * #define MSN_DUMMY_STATEMENT(v) <br/>
     * #define MSN_DUMMY_STATEMENT_CONST(v) <br/>
     * <br/>
     * dummyStatementKind == VoidCast: <br/>
     * #define MSN_DUMMY_STATEMENT(v) (void)(v) <br/>
     * #define MSN_DUMMY_STATEMENT_CONST(v) (void)(v) <br/>
     * <br/>
     * dummyStatementKind == SelfAssignment: <br/>
     * #define MSN_DUMMY_STATEMENT(v) (v)=(v) <br/>
     * #define MSN_DUMMY_STATEMENT_CONST(v) (void)(v) <br/>
     * <br/>
     * dummyStatementKind == UserDefined: <br/>
     * #define MSN_DUMMY_STATEMENT(v) USER_DUMMY_STATEMENT(v) <br/>
     * #define MSN_DUMMY_STATEMENT_CONST(v) (void)(v) <br/>
     * </div>
     *
     * @param dummyStatementKind
     * @return
     */
    private String calculateValueForDummyStatementKind(EDummyStatementKind dummyStatementKind) {
        switch (dummyStatementKind) {
        case None:
            return "";
        case SelfAssignment:
            return "(v)=(v)";
        case UserDefined:
            return "USER_DUMMY_STATEMENT(v)";
        case VoidCast:
            return "(void)(v)";
        default:
            throw new GeneralParameterException("The literal of DummyStatementKind is invalid: " + dummyStatementKind.toString()
                    + ". Supprted values are: None, SelfAssignment, UserDefined, VoidCast");
        }
    }

    private String defineCrcCheckInternal(final boolean boardPcAndLtCrcCheck, final String comment) {
        final String switchName = String.format("%s_CRC_CHECK", msnUpperCase);
        return getIfnDefDefine(switchName, F.formatBool(boardPcAndLtCrcCheck).asStdOnOff().generate(), comment);
    }

    /**
     * @return
     */
    @ReworkThisAtNextBreakingChange("The value for CRC Check in not even contained in the EcuC BSWMD anymore. The 'else case' is always performed -> return empty define.")
    private String defineCrcCheck() {
        final Optional<Boolean> optional = getCrcCheck(mca);
        if (!optional.isPresent()) {
            /*
             * EVAL00104569: Ensure that CRC check is optional
             */
            return "";
        }
        final boolean useCrcCheck = optional.get();
        final String useCrcCheckComment = getCrcCheckDefRef(mca);
        return defineCrcCheckInternal(useCrcCheck, useCrcCheckComment);
    }

    private String defineBoardAtomicBitAccessInBitfieldInternal(final boolean boardAtomicBitAccessInBitfield, final String comment) {
        final String switchName = String.format("%s_ATOMIC_BIT_ACCESS_IN_BITFIELD", msnUpperCase);
        return getIfnDefDefine(switchName, F.formatBool(boardAtomicBitAccessInBitfield).asStdOnOff().generate(), comment);
    }

    @VisibleForTesting
    String defineBoardAtomicBitAccessInBitfield(IGenPlatformService platformService) {
        /*
         * #define FR_ATOMIC_BIT_ACCESS_IN_BITFIELD STD_OFF <br>
         */
        final IGenPlatformValueRequest<MIBooleanParamDef, MINumericalValue, Boolean, Boolean> atomicBitAccessableInBitfieldRequest = platformService
                .isAtomicBitAccessableInBitfield();
        if (!atomicBitAccessableInBitfieldRequest.isValid()) {
            throwGenParameterException("AtomicBitAccessableInBitfield", getDefRefString(atomicBitAccessableInBitfieldRequest));
        }

        final boolean useAtomicBitAccess = atomicBitAccessableInBitfieldRequest.getValue();
        final String useAtomicBitAccessComment = atomicBitAccessableInBitfieldRequest.getDefinition().getDefRefString();

        return defineBoardAtomicBitAccessInBitfieldInternal(useAtomicBitAccess, useAtomicBitAccessComment);
    }

    private String defineBoardAtomicVariableAccessInternal(final int boardAtomicVariableAccess, final String comment) {
        final String switchName = String.format("%s_ATOMIC_VARIABLE_ACCESS", msnUpperCase);
        return getIfnDefDefine(switchName, F.formatInt(boardAtomicVariableAccess).asDecimal().toUint8().generate(), comment);
    }

    @VisibleForTesting
    String defineBoardAtomicVariableAccess(IGenPlatformService platformService) {
        final IGenPlatformValueRequest<MIEnumerationParamDef, MITextualValue, String, EAtomicVariableAccess> atomicVariableAccessRequest = platformService
                .getAtomicVariableAccess();
        if (!atomicVariableAccessRequest.isValid()) {
            throwGenParameterException("AtomicVariableAccess", getDefRefString(atomicVariableAccessRequest));
        }
        final String atomicVarialbleFromConfig = atomicVariableAccessRequest.getValue().name();
        final String atomicVarialbleFromConfigComment = atomicVariableAccessRequest.getDefinition().getDefRefString();
        int atomicVarialbleToGenerate = 8;
        if (atomicVarialbleFromConfig.equals(ATOMIC_8)) {
            atomicVarialbleToGenerate = 8;
        } else if (atomicVarialbleFromConfig.equals(ATOMIC_16)) {
            atomicVarialbleToGenerate = CONST_16;
        } else if (atomicVarialbleFromConfig.equals(ATOMIC_32)) {
            atomicVarialbleToGenerate = CONST_32;
        } else if (atomicVarialbleFromConfig.equals(ATOMIC_64)) {
            atomicVarialbleToGenerate = CONST_64;
        } else {
            logger.error("ModuleSpecificDefines.defineBoardAtomicVariableAccess(): Invalid value of AtomicVariableAccess: " + atomicVarialbleFromConfig);
        }
        return defineBoardAtomicVariableAccessInternal(atomicVarialbleToGenerate, atomicVarialbleFromConfigComment);
    }

    /**
     * Generic description. <br>
     * #ifndef &lt;MSN&gt;_CPU_&lt;Platform&gt; <br>
     * #define &lt;MSN&gt;_CPU_&lt;Platform&gt; <br>
     * #endif <br>
     * <br>
     * Sample<br>
     * #ifndef CAN_CPU_V85X <br>
     * #define CAN_CPU_V85X <br>
     * #endif <br>
     *
     * @return
     */
    private String definePlatform() {

        final ImplementationProperty cpu = getImplPropertyValue(EImplementationProperties.CPU_DEFINE);
        if (cpu == null) {
            return "";
        }
        final String switchName = String.format("%s_CPU_%s", msnUpperCase, escapeNonCIdentChars(cpu.getValue()).toUpperCase());
        return getIfnDefDefine(switchName, null, "");
    }

    /**
     * Generic description. <br>
     * #ifndef &lt;MSN&gt;_PROCESSOR_&lt;Derivative&gt; <br>
     * #define &lt;MSN&gt;_PROCESSOR_&lt;Derivative&gt; <br>
     * #endif <br>
     * <br>
     * Sample<br>
     * #ifndef CAN_PROCESSOR_FX4 <br>
     * #define CAN_PROCESSOR_FX4 <br>
     * #endif <br>
     *
     * @return
     */
    private String defineDerivative() {
        if (getDerivateInfo() == null) {
            return "";
        }
        final String derivateName = getDerivateInfo().getName();
        if (derivateName == null) {
            return "";
        }
        final String switchName = String.format("%s_PROCESSOR_%s", msnUpperCase, escapeNonCIdentChars(derivateName).toUpperCase());
        return getIfnDefDefine(switchName, null, "");
    }

    /**
     * Generic description. <br>
     * #ifndef &lt;MSN&gt;_COMP_&lt;Compiler&gt; <br>
     * #define &lt;MSN&gt;_COMP_&lt;Compiler&gt; <br>
     * #endif <br>
     * <br>
     * Sample<br>
     * #ifndef CAN_COMP_GHS <br>
     * #define CAN_COMP_GHS <br>
     * #endif <br>
     *
     * @return
     *
     */
    private String defineCompiler() {

        final ImplementationProperty compiler = getImplPropertyValue(EImplementationProperties.COMPILER);
        if (compiler == null) {
            return "";
        }
        // Correct code
        final String switchName = String.format("%s_COMP_%s", msnUpperCase, escapeNonCIdentChars(compiler.getValue()).toUpperCase());
        return getIfnDefDefine(switchName, null, "");
    }

    /**
     * Generic description. <br>
     * #ifndef &lt;MSN&gt;_GEN_GENERATOR_MSR <br>
     * #define &lt;MSN&gt;_GEN_GENERATOR_MSR <br>
     * #endif <br>
     * <br>
     * Sample<br>
     * #ifndef CAN_GEN_GENERATOR_MSR <br>
     * #define CAN_GEN_GENERATOR_MSR <br>
     * #endif <br>
     *
     * @return
     */
    private String defineGenerator() {

        final String switchName = String.format("%s_GEN_GENERATOR_MSR", msnUpperCase);
        return getIfnDefDefine(switchName, null, "");
    }

    /**
     * Generic description. <br>
     * #ifndef &lt;MSN&gt;_CPUTYPE_BITORDER_&lt;ORDER&gt; <br>
     * #define &lt;MSN&gt;_CPUTYPE_BITORDER_&lt;ORDER&gt; <br>
     * #endif <br>
     * <br>
     * Sample<br>
     * #ifndef CAN_CPUTYPE_BITORDER_LSB2MSB <br>
     * #define CAN_CPUTYPE_BITORDER_LSB2MSB <br>
     * #endif <br>
     *
     * @return
     */
    @VisibleForTesting
    String defineCpuOrder(IGenPlatformService platformService) {
        final IGenPlatformValueRequest<MIEnumerationParamDef, MITextualValue, String, EBitOrder> bitOrderRequest = platformService.getBitOrder();
        if (!bitOrderRequest.isValid()) {
            throwGenParameterException("BitOrder", getDefRefString(bitOrderRequest));
        }
        // fetch LSB2MSB
        String lsb2Msb = bitOrderRequest.getValue().name();
        final String lsb2MsbComment = bitOrderRequest.getDefinition().getDefRefString();
        lsb2Msb = renameBitOrder(lsb2Msb);
        /*
         * #define <MSN>_CPUTYPE_BITORDER_LSB2MSB
         */

        final String switchName = String.format("%s_CPUTYPE_BITORDER_%s", msnUpperCase, escapeNonCIdentChars(lsb2Msb));
        return getIfnDefDefine(switchName, null, lsb2MsbComment);
    }

    /**
     * Creates a ModuleVariatn define statement as specified in EVAL00103266. <br/>
     * Sample for COM:<br/>
     * <code>
          #ifndef COM_CONFIGURATION_VARIANT_PRECOMPILE <br/>
          #define COM_CONFIGURATION_VARIANT_PRECOMPILE 1<br/>
          #endif<br/>
          #ifndef COM_CONFIGURATION_VARIANT_LINKTIME<br/>
          #define COM_CONFIGURATION_VARIANT_LINKTIME 2<br/>
          #endif<br/>
          #ifndef COM_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE<br/>
          #define COM_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE 3<br/>
          #endif<br/>

          #ifndef COM_CONFIGURATION_VARIANT<br/>
          #define COM_CONFIGURATION_VARIANT <Symbolic name of the selected variant, e.g. COM_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE><br/>
          #endif<br/>

          #ifndef COM_POSTBUILD_VARIANT_SUPPORT<br/>
          #define COM_POSTBUILD_VARIANT_SUPPORT STD_ON<br/>
          #endif<br/>
      </code>
     *
     * @return
     */
    private String defineModuleVariant() {

        final StringBuilder sb = new StringBuilder();
        sb.append(MessageFormat.format("#ifndef {1}_CONFIGURATION_VARIANT_PRECOMPILE{0}#define {1}_CONFIGURATION_VARIANT_PRECOMPILE 1{0}#endif{0}", GenConstants.LINE_SEPARATOR,
                msnUpperCase));
        sb.append(MessageFormat.format("#ifndef {1}_CONFIGURATION_VARIANT_LINKTIME{0}#define {1}_CONFIGURATION_VARIANT_LINKTIME 2{0}#endif{0}", GenConstants.LINE_SEPARATOR,
                msnUpperCase));
        sb.append(MessageFormat.format("#ifndef {1}_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE{0}#define {1}_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE 3{0}#endif{0}",
                GenConstants.LINE_SEPARATOR, msnUpperCase));

        /*
         * Fetch all ConfigVariants and check that they are equal!
         */
        final ImmutableList<MIModuleConfiguration> moduleConfigList = generatorPackage.getGenerationProcessor().getModuleConfigList();
        assertAllConfigsHaveTheSamePostBuildSettings(moduleConfigList);

        /*
         * COM_CONFIGURATION_VARIANT
         */
        if (moduleConfigList.size() > 0) {
            final MIModuleConfiguration currentModuleConfig = moduleConfigList.get(0);
            final IEcucModuleConfiguration cfg = eca.cfg(currentModuleConfig);
            final ModuleConfigurationPostBuildSettings postBuildSettings = cfg.getPostBuildSettings();
            final EEcucConfigurationVariant configurationVariant = postBuildSettings.getConfigurationVariant();

            if (configurationVariant == null) {
                final GeneratorResultBuilder rb;
                rb = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModuleConfigFailureId(generatorPackage),
                        "ConfigVariant of ModuleConfiguration {0} must not be null.", currentModuleConfig.getName());
                rb.addErrorObject(currentModuleConfig);
                throw new ValidationFailedException(rb.buildResult());
            }

            boolean configVariantCastErrorOccured = false;
            if (configurationVariant instanceof EEcucConfigurationVariant) {
                try {
                    sb.append(createModuleVariantDefineString(configurationVariant));
                    sb.append(defineVariantSupport(postBuildSettings.supportsVariance()));
                } catch (final IllegalStateException e) {
                    configVariantCastErrorOccured = true;
                }
            } else {
                configVariantCastErrorOccured = true;
            }
            if (configVariantCastErrorOccured) {
                final GeneratorResultBuilder rb;
                rb = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModuleConfigFailureId(generatorPackage),
                        "ImlementationConfigVariant of ModuleConfiguration {0} is invalid. It is not of Type MIConfigurationVariant.", currentModuleConfig.getName());
                rb.addErrorObject(currentModuleConfig);
                throw new ValidationFailedException(rb.buildResult());
            }
        }
        return sb.toString();
    }

    // @formatter:off
    /**
     * <div class="extdoc" id="Generate_Dev_Error">
     * This method creates the define statements for <br> MSN_DEV_ERROR_DETECT and MSN_DEV_ERROR_REPORT. <br/>
     * E.g.<br/>
     * #ifndef CDDINST_DEV_ERROR_DETECT <br/>
     * #define CDDINST_DEV_ERROR_DETECT STD_OFF <br/>
     * #endif <br/>
     * #ifndef CDDINST_DEV_ERROR_REPORT <br/>
     * #define CDDINST_DEV_ERROR_REPORT STD_OFF <br/>
     * #endif <br/>
     * <br/>
     * Uses the MSN WITHOUT VendorApiInfix and Vendor Id for a the passed module configuration. <br/>
     * The values are evaluated according the following table: <br/>
     * SafeBswChecks:<br/>
     * Since MicrosarRelease 18, the module local switch <Ma>SafeBswChecks is used.<br/>
     * If not found this switch is used: /MICROSAR/EcuC/EcucGeneral/EcuCSafeBswChecks <br/>
     * MsnDevErrorDetect: <br/>
     * /MICROSAR/Msn/MsnGeneral/MsnDevErrorDetect <br/>
     * If the value of MsnDevErrorDetect can not be determined, false is used as default value.<br/>
     *
        <table>
          <tr>
            <th>SafeBswChecks</th>
            <th>Msn_DevError</th>
            <th>Generated</th>
          </tr>
          <tr>
            <th>Generate</th>
            <th>Detect</th>
            <th>code</th>
          </tr>
          <tr>
            <td>true/false</td>
            <td>true</td>
            <td>#define MSN_DEV_ERROR_DETECT STD_ON</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td>#define MSN_DEV_ERROR_REPORT STD_ON</td>
          </tr>
          <tr>
            <td>true</td>
            <td>false</td>
            <td>#define MSN_DEV_ERROR_DETECT STD_ON</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td>#define MSN_DEV_ERROR_REPORT STD_OFF</td>
          </tr>
          <tr>
            <td>false</td>
            <td>false</td>
            <td>#define MSN_DEV_ERROR_DETECT STD_OFF</td>
          </tr>
          <tr>
            <td></td>
            <td></td>
            <td>#define MSN_DEV_ERROR_REPORT STD_OFF</td>
          </tr>
        </table>
     * </div>
     * @return The define statements.
     */
    // @formatter:on
    @PublishedMethod
    public String generateDevError() {
        return generateDevError(generatorPackage.getGenerationProcessor().getModuleConfigList().get(0));
    }

    // @formatter:off
    /**
     * see doc of generateDevError().
     *
     * MSN restrictions :
     * Uses the MSN WITHOUT VendorApiInfix and Vendor Id for a the passed module configuration. <br/>
     * CDD:<br/>
     * In case of CDD module the short name of the module configuration is returned or if apiServicePrefix is available, this value is used instead. <br/>
     * In case of CDD no VendorApiInfix or Vendor Id is applied. <br/>
     *
     * VTT:<br/>
     * If a VTT module is passed, the corresponding real module is used instead. <br/>
     * If no Real module could be found, the VTT module is used as default.<br/>
     * Only active module configuration are taken into account for the real module lookup. <br/>
     *
     * @param moduleConfiguration The module configuration to evaluate. This overrides the module configuration from the generator package.
     * @return The define statements.
     */
    // @formatter:on
    @PublishedMethod
    public String generateDevError(final MIModuleConfiguration moduleConfiguration) {
        final IGenPlatformService platformService = projectContext.getService(IGenPlatformService.class);
        return generateDevErrorInternal(moduleConfiguration, null, platformService);
    }

    // @formatter:off
    /**
     * see doc of generateDevError().
     *
     * @param moduleConfiguration The module configuration to evaluate. This overrides the module configuration from the generator package.
     * @param definitionDevErrorDetect The definition to the DevErrorDetect parameter OR Null if it shall be looked up automatically.
     * @return The define statements.
     */
    // @formatter:on
    private String generateDevErrorInternal(final MIModuleConfiguration moduleConfiguration, DefRef definitionDevErrorDetect, IGenPlatformService platformService) {
        if (moduleConfiguration == null) {
            throw new IllegalArgumentException("MIModuleConfiguration must not be null");
        }

        final boolean valueSafeBswChecks;
        final boolean valueMsnDevErrorDetect;
        final DefRef detDefRef;

        /*
         * Get Mip
         */
        final String internalMip = GeneratorPackageUtil.getMipResolveVttModules(moduleConfiguration);

        if (internalMip == null) {
            throw new IllegalArgumentException(MessageFormat.format("ModuleDefinition of ModuleConfiguration {0} could not be resolved.", moduleConfiguration.getName()));
        }

        if (definitionDevErrorDetect == null) {
            detDefRef = DetDefRef.getDevErrorDetectDefRefRelative(moduleConfiguration);
        } else {
            detDefRef = definitionDevErrorDetect;
        }

        valueSafeBswChecks = getSafeBswChecksValue(detDefRef, moduleConfiguration, platformService);

        /*
         * Make DefRef relative to avoid problems while resolving the StMD for ASR3. Because the Cfg5 has no ASR3 StMD. (Refinement can not be resolved...)
         */

        final IMcaRequest<Boolean> valueAsRequest = mca.parameter(moduleConfiguration, detDefRef.getDefRefStringWithoutModuleDef())
                .asBool()
                .getValueAsRequest();
        if (valueAsRequest.isValid()) {
            valueMsnDevErrorDetect = valueAsRequest.getResult();
        } else {
            valueMsnDevErrorDetect = false;
        }

        return defineDevErrorInternal(valueSafeBswChecks, valueMsnDevErrorDetect, internalMip.toUpperCase());

    }

    /**
     * Use the module local EcuCSafeBsw switch, if present <br/>
     * If not, use the switch in the EcuC module <br/>
     * And finally if no switch was found at all, return false. <br/>
     * DAVID00133796: FEAT-1824: Implement module local override for ModuleSpecificDefines.generateDevError() <br/>
     *
     * @param definitionDevErrorDetect The position of the DevErrorDetect switch of the module. The EcuCSafeBsw switch needs to be an sibling of this switch.
     * @param internalMa <Ma> of the current module
     * @return
     */
    private boolean getSafeBswChecksValue(DefRef definitionDevErrorDetect, MIModuleConfiguration moduleConfiguration, IGenPlatformService platformService) {
        final String internalMa = GeneratorPackageUtil.getMaResolveVttModules(moduleConfiguration);

        /*
         * 1. Use the switch from the module. (Sibling of definitionDevErrorDetect)
         */
        final DefRef defRefSafeBswCheckOfModule = DefRef.create(definitionDevErrorDetect.getParentDefRef(), internalMa + POSTFIX_DEV_ERROR_DETECT_MODULE_PARAMETER);
        final IMcaRequest<Boolean> valueAsRequest = mca.parameter(defRefSafeBswCheckOfModule).asBool().getValueAsRequest();
        if (valueAsRequest.isValid()) {
            return valueAsRequest.getResult();
        }

        /*
         * 2. Try the switch from the EcuC Module
         */
        final IGenPlatformValueRequest<MIBooleanParamDef, MINumericalValue, Boolean, Boolean> ecucSafeBswChecks = platformService.getEcucSafeBswChecks();
        // EcuC SafeBswChecks switch from the EcuC module
        if (ecucSafeBswChecks.isValid()) {
            return ecucSafeBswChecks.getValue();
        }

        /*
         * 3. Return false
         */
        return false;
    }

    // @formatter:off
    /**
     * This method creates the define statements for MSN_DEV_ERROR_DETECT and MSN_DEV_ERROR_REPORT. <br/>
     * E.g.<br/>
     * #ifndef CDDINST_DEV_ERROR_DETECT <br/>
     * #define CDDINST_DEV_ERROR_DETECT STD_OFF <br/>
     * #endif <br/>
     * #ifndef CDDINST_DEV_ERROR_REPORT <br/>
     * #define CDDINST_DEV_ERROR_REPORT STD_OFF <br/>
     * #endif <br/>
     * <br/>
     * The values are evaluated according the following table: <br/>
     * /MICROSAR/EcuC/EcucGeneral/EcuCSafeBswChecks <br/>
     * /MICROSAR/Msn/MsnGeneral/MsnDevErrorDetect <br/>
     * If the value of MsnDevErrorDetect can not be determined, false is used as default value.<br/>
     *
     *
        <table>
          <tr>
            <th >SafeBswChecksGenerate</th>
            <th >Msn_DevErrorDetect</th>
            <th >Generated code</th>
          </tr>
          <tr>
            <td >true/false</td>
            <td >true</td>
            <td >#define MSN_DEV_ERROR_DETECT STD_ON<br>#define MSN_DEV_ERROR_REPORT STD_ON</td>
          </tr>
          <tr>
            <td >true</td>
            <td >false</td>
            <td >#define MSN_DEV_ERROR_DETECT STD_ON<br>#define MSN_DEV_ERROR_REPORT STD_OFF</td>
          </tr>
          <tr>
            <td >false</td>
            <td >false</td>
            <td >#define MSN_DEV_ERROR_DETECT STD_OFF<br>#define MSN_DEV_ERROR_REPORT STD_OFF</td>
          </tr>
        </table>
     *
     * MSN restrictions :
     * Uses theMSN WITHOUT VendorApiInfix and Vendor Id for a the passed module configuration. <br/>
     * CDD:<br/>
     * In case of CDD module the short name of the module configuration is returned or if apiServicePrefix is available, this value is used instead. <br/>
     * In case of CDD no VendorApiInfix or Vendor Id is applied. <br/>
     *
     * VTT:<br/>
     * If a VTT module is passed, the corresponding real module is used instead. <br/>
     * If no Real module could be found, the VTT module is used as default.<br/>
     * Only active module configuration are taken into account for the real module lookup. <br/>
     *
     * @param moduleConfiguration The module configuration to evaluate. This overrides the module configuration from the generator package.
     * @param definitionDevErrorDetect The definition reference to the DevErrorDetect switch. If no automatic resolution shall be performed, the dedifnition can be passed directly
     *
     * @return The define statements.
     */
    // @formatter:on
    @PublishedMethod
    public String generateDevError(final MIModuleConfiguration moduleConfiguration, DefRef definitionDevErrorDetect) {
        if (definitionDevErrorDetect == null) {
            throw new IllegalArgumentException("The passed definition reference to the DevErrorDetect parameter must not be null.");
        }
        final IGenPlatformService platformService = projectContext.getService(IGenPlatformService.class);
        return generateDevErrorInternal(moduleConfiguration, definitionDevErrorDetect, platformService);
    }

    private String defineDevErrorInternal(final boolean valueSafeBswChecks, final boolean valueMsnDevErrorDetect, final String msnInternal) {
        final String errorDetect = String.format("%s_DEV_ERROR_DETECT", msnInternal);
        final String errorReport = String.format("%s_DEV_ERROR_REPORT", msnInternal);

        final StringBuilder sb = new StringBuilder();
        if (valueMsnDevErrorDetect) {
            sb.append(getIfnDefDefine(errorDetect, F.formatBool(true).asStdOnOff().generate(), null));
            sb.append(GenConstants.LINE_SEPARATOR);
            sb.append(getIfnDefDefine(errorReport, F.formatBool(true).asStdOnOff().generate(), null));
            return sb.toString();
        } else if (valueSafeBswChecks) {
            sb.append(getIfnDefDefine(errorDetect, F.formatBool(true).asStdOnOff().generate(), null));
            sb.append(GenConstants.LINE_SEPARATOR);
            sb.append(getIfnDefDefine(errorReport, F.formatBool(false).asStdOnOff().generate(), null));
            return sb.toString();
        } else {
            sb.append(getIfnDefDefine(errorDetect, F.formatBool(false).asStdOnOff().generate(), null));
            sb.append(GenConstants.LINE_SEPARATOR);
            sb.append(getIfnDefDefine(errorReport, F.formatBool(false).asStdOnOff().generate(), null));
            return sb.toString();
        }
    }

    private void throwGenParameterException(String parameterName, String parameterDefRef) {
        throw new GeneralParameterException(parameterName + " could not be resolved. " + parameterDefRef);
    }

    /**
     * The method {@link #defineVariantSupport(Boolean)} creates the Variant support defines. See the sample below:<br/>
     *
     * <pre>
     * <code>
     * #ifndef COM_POSTBUILD_VARIANT_SUPPORT
     * #define COM_POSTBUILD_VARIANT_SUPPORT STD_ON
     * #endif
     * </code>
     * </pre>
     *
     * @param boolean1
     * @return The defines as String
     */
    private String defineVariantSupport(final Boolean supportsVariance) {
        boolean value = false;
        if (supportsVariance != null) {
            value = supportsVariance.booleanValue();
        }

        return MessageFormat.format("#ifndef {1}_POSTBUILD_VARIANT_SUPPORT{0}#define {1}_POSTBUILD_VARIANT_SUPPORT {2}{0}#endif", GenConstants.LINE_SEPARATOR, msnUpperCase, F
                .formatBool(value).asStdOnOff());
    }

    /**
     * Creates a statement like.
     *
     * <pre>
     * <code>
     * #ifndef COM_CONFIGURATION_VARIANT
     * #define COM_CONFIGURATION_VARIANT &lt;Symbolic name of the selected variant, e.g. COM_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE&gt;
     * #endif
     * </code>
     * </pre>
     *
     * @param configVariant
     * @return The defines as String
     */
    String createModuleVariantDefineString(final EEcucConfigurationVariant configVariant) {
        switch (configVariant) {
        case VARIANT_PRE_COMPILE:
            return (MessageFormat.format("#ifndef {2}_CONFIGURATION_VARIANT{0}#define {2}_CONFIGURATION_VARIANT {2}_{1}{0}#endif{0}", GenConstants.LINE_SEPARATOR,
                    CONFIG_VARIANT_PC, msnUpperCase));

        case VARIANT_LINK_TIME:
            return (MessageFormat.format("#ifndef {2}_CONFIGURATION_VARIANT{0}#define {2}_CONFIGURATION_VARIANT {2}_{1}{0}#endif{0}", GenConstants.LINE_SEPARATOR,
                    CONFIG_VARIANT_LT, msnUpperCase));

        case VARIANT_POST_BUILD_LOADABLE:
            return (MessageFormat.format("#ifndef {2}_CONFIGURATION_VARIANT{0}#define {2}_CONFIGURATION_VARIANT {2}_{1}{0}#endif{0}", GenConstants.LINE_SEPARATOR,
                    CONFIG_VARIANT_PB_LOADABLE, msnUpperCase));

        default:
            // Is later converted to ValidationFailedEx
            throw new IllegalStateException("Invalid Configuration Variant: " + configVariant.name() + " ");
        }
    }

    /**
     * Checks if all passed ModuleConfigurations have the same Module Configuration Variant.
     *
     * @exception IllegalStateException. If not all ModuleConfigurationVariants of the passed ModuleConfigurations are identical.
     * @param moduleConfigList
     */
    private void assertAllConfigsHaveTheSamePostBuildSettings(final ImmutableList<MIModuleConfiguration> moduleConfigList) {

        ModuleConfigurationPostBuildSettings referenceConfigVariant = null;
        for (final MIModuleConfiguration miModuleConfiguration : moduleConfigList) {
            if (referenceConfigVariant == null) {
                /*
                 * set first config variant as reference config variant.
                 */
                referenceConfigVariant = eca.cfg(miModuleConfiguration).getPostBuildSettings();
            } else {
                final ModuleConfigurationPostBuildSettings currentConfigVariant = eca.cfg(miModuleConfiguration).getPostBuildSettings();
                if (!currentConfigVariant.equals(referenceConfigVariant)) {
                    final GeneratorResultBuilder rb;
                    rb = GeneratorResultBuilder
                            .newBuilder(
                                    CommonGeneratorResultIds.getModuleConfigFailureId(generatorPackage),
                                    "Multiple instances of the module {0} with different Configuration Variants were found. Not all instances of this module have the same Configuration Variant.",
                                    miModuleConfiguration.getName());
                    rb.addErrorObject(miModuleConfiguration);
                    throw new ValidationFailedException(rb.buildResult());
                }
            }
        }

    }

    /**
     * Creates a symmetric Define Statement with or without Value . <br/>
     * Pass null for value if no value shall be generated. <br/>
     * Pass null for comment if no comment shall be generated. <br/>
     *
     * If (a) and (b) are equal this method should be used.<br/>
     * #ifndef (a) <br/>
     * #def (b) <br/>
     * #endif <br/>
     * E.g.<br/>
     * #ifndef NM_DUMMY_STATEMENT <br/>
     * #define NM_DUMMY_STATEMENT <br/>
     * #endif <br/>
     *
     * @param switchName Name of the switch
     * @param value Value, If null the value is skipped.
     * @param comment Comment, If null or "" the comment is skipped.
     * @return The defines as String
     */
    private String getIfnDefDefine(final String switchName, final String value, final String comment) {
        return getIfnDefDefineAsymmetric(switchName, switchName, value, comment);
    }

    /**
     * Creates a Define Statement with Value with asymmetric ifndef statement. <br/>
     * Usually the method {@link getIfnDefDefine()} shall be used.<br/>
     * If (a) and (b) are NOT equal this method should be used.<br/>
     * #ifndef (a) <br/>
     * #def (b) <br/>
     * #endif <br/>
     * E.g.<br/>
     * #ifndef NM_DUMMY_STATEMENT <br/>
     * #define NM_DUMMY_STATEMENT(v) <br/>
     * #endif <br/>
     *
     * @param switchNameIfnDef Name of the ifndef switch
     * @param switchNameDefine Name of the define switch
     * @param value Value. If null, the value is skipped.
     * @param comment Comment. If null or "" the comment is skipped.
     * @return The defines as String
     */
    private String getIfnDefDefineAsymmetric(final String switchNameIfnDef, final String switchNameDefine, final String value, final String comment) {
        if ((value == null) || (value.isEmpty())) {
            /*
             * Without value
             */
            if ((comment == null) || (comment.isEmpty())) {
                return MessageFormat.format("#ifndef {0}{1}#define {3}{1}#endif", switchNameIfnDef, GenConstants.LINE_SEPARATOR, value, switchNameDefine);
            } else {
                return MessageFormat.format("#ifndef {0}{1}#define {3} /* {2} */{1}#endif", switchNameIfnDef, GenConstants.LINE_SEPARATOR, comment, switchNameDefine);
            }
        } else {
            /*
             * With value
             */
            if ((comment == null) || (comment.isEmpty())) {
                return MessageFormat.format("#ifndef {0}{1}#define {3} {2}{1}#endif", switchNameIfnDef, GenConstants.LINE_SEPARATOR, value, switchNameDefine);
            } else {
                return MessageFormat.format("#ifndef {0}{1}#define {4} {2} /* {3} */{1}#endif", switchNameIfnDef, GenConstants.LINE_SEPARATOR, value, comment, switchNameDefine);
            }
        }

    }

    /**
     * Creates the GeneralDefine block.<br>
     * The module shortname is used as prefix. (in most cases shortname of the moduledefinition, except CCD) <MSN>_<Definetype><br>
     * This method can not be used for CDD modules. Use generalDefineBlock(MIModuleConfig) instead.<br/>
     * The GeneralDefine block contains the following statements: (Sample for FRTRCV) <br>
     * <br/>
     * #ifndef FRTRCV_OSTYPE_AUTOSAR <br/>
     * #define FRTRCV_OSTYPE_AUTOSAR <br/>
     * #endif<br/>
     * #ifndef FRTRCV_USE_DUMMY_STATEMENT<br/>
     * #define FRTRCV_USE_DUMMY_STATEMENT STD_ON<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CRC_CHECK<br/>
     * #define FRTRCV_CRC_CHECK STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_ATOMIC_BIT_ACCESS_IN_BITFIELD<br/>
     * #define FRTRCV_ATOMIC_BIT_ACCESS_IN_BITFIELD STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_ATOMIC_VARIABLE_ACCESS<br/>
     * #define FRTRCV_ATOMIC_VARIABLE_ACCESS 16U <br/>
     * #endif<br/>
     * #ifndef FRTRCV_PROCESSOR_CANOE<br/>
     * #define FRTRCV_PROCESSOR_CANOE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_COMP_ANSI_C<br/>
     * #define FRTRCV_COMP_ANSI_C<br/>
     * #endif<br/>
     * #ifndef FRTRCV_GEN_GENERATOR_MSR<br/>
     * #define FRTRCV_GEN_GENERATOR_MSR<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CPUTYPE_BITORDER_LSB2MSB<br/>
     * #define FRTRCV_CPUTYPE_BITORDER_LSB2MSB <br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT_PRECOMPILE 1<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT_LINKTIME<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT_LINKTIME 2<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE 3<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT FRTRCV_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_POSTBUILD_VARIANT_SUPPORT<br/>
     * #define FRTRCV_POSTBUILD_VARIANT_SUPPORT STD_OFF<br/>
     * #endif<br/>
     *
     * @return The defines as String
     */
    @PublishedMethod
    public String generalDefineBlock() {
        return generalDefineBlock(generatorPackage.getGenerationProcessor().getModuleConfigList().get(0));
    }

    /**
     * Creates the GeneralDefine block.<br>
     * This method should only be used for CDD modules. Otherwise generalDefineBlock() should be used. The module shortname is used as prefix. (in most cases shortname of the
     * moduledefinition, except CCD) <MSN>_<Definetype><br>
     * The GeneralDefine block contains the following statements: (Sample for FRTRCV) <br>
     * <br/>
     * #ifndef FRTRCV_OSTYPE_AUTOSAR <br/>
     * #define FRTRCV_OSTYPE_AUTOSAR <br/>
     * #endif<br/>
     * #ifndef FRTRCV_USE_DUMMY_STATEMENT<br/>
     * #define FRTRCV_USE_DUMMY_STATEMENT STD_ON<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CRC_CHECK<br/>
     * #define FRTRCV_CRC_CHECK STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_ATOMIC_BIT_ACCESS_IN_BITFIELD<br/>
     * #define FRTRCV_ATOMIC_BIT_ACCESS_IN_BITFIELD STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_ATOMIC_VARIABLE_ACCESS<br/>
     * #define FRTRCV_ATOMIC_VARIABLE_ACCESS 16U <br/>
     * #endif<br/>
     * #ifndef FRTRCV_PROCESSOR_CANOE<br/>
     * #define FRTRCV_PROCESSOR_CANOE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_COMP_ANSI_C<br/>
     * #define FRTRCV_COMP_ANSI_C<br/>
     * #endif<br/>
     * #ifndef FRTRCV_GEN_GENERATOR_MSR<br/>
     * #define FRTRCV_GEN_GENERATOR_MSR<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CPUTYPE_BITORDER_LSB2MSB<br/>
     * #define FRTRCV_CPUTYPE_BITORDER_LSB2MSB <br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT_PRECOMPILE 1<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT_LINKTIME<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT_LINKTIME 2<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE 3<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT FRTRCV_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_POSTBUILD_VARIANT_SUPPORT<br/>
     * #define FRTRCV_POSTBUILD_VARIANT_SUPPORT STD_OFF<br/>
     * #endif<br/>
     *
     * @return The defines as String
     */
    @PublishedMethod
    public String generalDefineBlock(final GIModuleConfiguration moduleConfig) {
        return generalDefineBlock(moduleConfig.getMdfObject());
    }

    /**
     * Creates the GeneralDefine block.<br>
     * This method should only be used for CDD modules. Otherwise generalDefineBlock() should be used. The module shortname is used as prefix. (in most cases shortname of the
     * moduledefinition, except CCD) <MSN>_<Definetype><br>
     * The GeneralDefine block contains the following statements: (Sample for FRTRCV) <br>
     * <br/>
     * #ifndef FRTRCV_OSTYPE_AUTOSAR <br/>
     * #define FRTRCV_OSTYPE_AUTOSAR <br/>
     * #endif<br/>
     * #ifndef FRTRCV_DUMMY_STATEMENT(v)<br/>
     * #define FRTRCV_DUMMY_STATEMENT(v) /* PRQA S 3453 ... <br/>
     * #endif<br/>
     * #ifndef FRTRCV_CRC_CHECK<br/>
     * #define FRTRCV_CRC_CHECK STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_ATOMIC_BIT_ACCESS_IN_BITFIELD<br/>
     * #define FRTRCV_ATOMIC_BIT_ACCESS_IN_BITFIELD STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_ATOMIC_VARIABLE_ACCESS<br/>
     * #define FRTRCV_ATOMIC_VARIABLE_ACCESS 16U <br/>
     * #endif<br/>
     * #ifndef FRTRCV_PROCESSOR_CANOE<br/>
     * #define FRTRCV_PROCESSOR_CANOE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_COMP_ANSI_C<br/>
     * #define FRTRCV_COMP_ANSI_C<br/>
     * #endif<br/>
     * #ifndef FRTRCV_GEN_GENERATOR_MSR<br/>
     * #define FRTRCV_GEN_GENERATOR_MSR<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CPUTYPE_BITORDER_LSB2MSB<br/>
     * #define FRTRCV_CPUTYPE_BITORDER_LSB2MSB <br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT_PRECOMPILE 1<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT_LINKTIME<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT_LINKTIME 2<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE 3<br/>
     * #endif<br/>
     * #ifndef FRTRCV_CONFIGURATION_VARIANT<br/>
     * #define FRTRCV_CONFIGURATION_VARIANT FRTRCV_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_POSTBUILD_VARIANT_SUPPORT<br/>
     * #define FRTRCV_POSTBUILD_VARIANT_SUPPORT STD_OFF<br/>
     * #endif<br/>
     *
     * @return The defines as String
     */
    @PublishedMethod
    public String generalDefineBlock(final MIModuleConfiguration moduleConfig) {
        if (moduleConfig == null) {
            final GeneratorResultBuilder rb;
            rb = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModuleConfigFailureId(generatorPackage),
                    "Passed ModuleConfiguration of generator {0} must not be null", generatorPackage.getMSN());
            throw new ValidationFailedException(rb.buildResult());
        }
        final String msnLoc = GeneratorPackageUtil.getMaResolveVttModules(moduleConfig);
        return generalDefineBlock(GeneratorUtilFrameworkHelper.getFrameworkInternalToken(), msnLoc);
    }

    /**
     * Creates the GeneralDefine block with vendor specific postfix.<br>
     * The module configuration from the GenerationProcessor is used implicit.<br/>
     * The module shortname is extended by the vendorId and the vendor specific name (VendorApiInfix) from the BWM implementation node from the BSWMD.<br/>
     * <MSN>_<VendorId>_<VendorApiInfix><br/>
     * E.g. CanTrcv_30_Tja1040<br/>
     * This method can not be used for CDD modules. Use generalDefineBlockWithVendor(MIModuleConfig) instead.<br/>
     * The GeneralDefine block contains the following statements: (Sample for FRTRCV_30_TJA1080DIO) <br>
     * <br/>
     * #ifndef FRTRCV_30_TJA1080DIO_OSTYPE_AUTOSAR <br/>
     * #define FRTRCV_30_TJA1080DIO_OSTYPE_AUTOSAR <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_USE_DUMMY_STATEMENT<br/>
     * #define FRTRCV_30_TJA1080DIO_USE_DUMMY_STATEMENT STD_ON<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_DUMMY_STATEMENT_CONST<br/>
     * #define FRTRCV_30_TJA1080DIO_DUMMY_STATEMENT_CONST(v) (void)(v) /* PRQA S 3453 * / /* MD_MSR_FctLikeMacro * / /* /MICROSAR/EcuC/EcucGeneral/DummyStatementKind * /<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CRC_CHECK<br/>
     * #define FRTRCV_30_TJA1080DIO_CRC_CHECK STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_ATOMIC_BIT_ACCESS_IN_BITFIELD<br/>
     * #define FRTRCV_30_TJA1080DIO_ATOMIC_BIT_ACCESS_IN_BITFIELD STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_ATOMIC_VARIABLE_ACCESS<br/>
     * #define FRTRCV_30_TJA1080DIO_ATOMIC_VARIABLE_ACCESS 16U <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_PROCESSOR_CANOE<br/>
     * #define FRTRCV_30_TJA1080DIO_PROCESSOR_CANOE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_COMP_ANSI_C<br/>
     * #define FRTRCV_30_TJA1080DIO_COMP_ANSI_C<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_GEN_GENERATOR_MSR<br/>
     * #define FRTRCV_30_TJA1080DIO_GEN_GENERATOR_MSR<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CPUTYPE_BITORDER_LSB2MSB<br/>
     * #define FRTRCV_30_TJA1080DIO_CPUTYPE_BITORDER_LSB2MSB <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE 1<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_LINKTIME<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_LINKTIME 2<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE 3<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_POSTBUILD_VARIANT_SUPPORT<br/>
     * #define FRTRCV_30_TJA1080DIO_POSTBUILD_VARIANT_SUPPORT STD_OFF<br/>
     * #endif<br/>
     *
     * @return see statement above.
     */
    @PublishedMethod
    public String generalDefineBlockWithVendor() {
        return generalDefineBlockWithVendor(generatorPackage.getGenerationProcessor().getModuleConfigList().get(0));
    }

    /**
     * Creates the GeneralDefine block with vendor specific postfix.<br>
     * This method should only be used for CDD modules. Otherwise generalDefineBlockWithVendor() should be used. <br/>
     * The module shortname is extended by the vendorId and the vendor specific name (VendorApiInfix) from the BWM implementation node from the BSWMD.<br/>
     * <MSN>_<VendorId>_<VendorApiInfix><br/>
     * E.g. CanTrcv_30_Tja1040<br/>
     * The GeneralDefine block contains the following statements: (Sample for FRTRCV_30_TJA1080DIO) <br>
     * <br/>
     * #ifndef FRTRCV_30_TJA1080DIO_OSTYPE_AUTOSAR <br/>
     * #define FRTRCV_30_TJA1080DIO_OSTYPE_AUTOSAR <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_USE_DUMMY_STATEMENT<br/>
     * #define FRTRCV_30_TJA1080DIO_USE_DUMMY_STATEMENT STD_ON<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_DUMMY_STATEMENT_CONST<br/>
     * #define FRTRCV_30_TJA1080DIO_DUMMY_STATEMENT_CONST(v) (void)(v) /* PRQA S 3453 * / /* MD_MSR_FctLikeMacro * / /* /MICROSAR/EcuC/EcucGeneral/DummyStatementKind * /<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CRC_CHECK<br/>
     * #define FRTRCV_30_TJA1080DIO_CRC_CHECK STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_ATOMIC_BIT_ACCESS_IN_BITFIELD<br/>
     * #define FRTRCV_30_TJA1080DIO_ATOMIC_BIT_ACCESS_IN_BITFIELD STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_ATOMIC_VARIABLE_ACCESS<br/>
     * #define FRTRCV_30_TJA1080DIO_ATOMIC_VARIABLE_ACCESS 16U <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_PROCESSOR_CANOE<br/>
     * #define FRTRCV_30_TJA1080DIO_PROCESSOR_CANOE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_COMP_ANSI_C<br/>
     * #define FRTRCV_30_TJA1080DIO_COMP_ANSI_C<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_GEN_GENERATOR_MSR<br/>
     * #define FRTRCV_30_TJA1080DIO_GEN_GENERATOR_MSR<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CPUTYPE_BITORDER_LSB2MSB<br/>
     * #define FRTRCV_30_TJA1080DIO_CPUTYPE_BITORDER_LSB2MSB <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE 1<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_LINKTIME<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_LINKTIME 2<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE 3<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_POSTBUILD_VARIANT_SUPPORT<br/>
     * #define FRTRCV_30_TJA1080DIO_POSTBUILD_VARIANT_SUPPORT STD_OFF<br/>
     * #endif<br/>
     *
     * @param moduleConfig Moduleconfiguration to fetch the module short name from.
     * @return
     */
    @PublishedMethod
    public String generalDefineBlockWithVendor(final GIModuleConfiguration moduleConfig) {
        return generalDefineBlockWithVendor(moduleConfig.getMdfObject());
    }

    /**
     * Creates the GeneralDefine block with vendor specific postfix.<br>
     * This method should only be used for CDD modules. Otherwise generalDefineBlockWithVendor() should be used. <br/>
     * The module shortname is extended by the vendorId and the vendor specific name (VendorApiInfix) from the BWM implementation node from the BSWMD.<br/>
     * <MSN>_<VendorId>_<VendorApiInfix><br/>
     * E.g. CanTrcv_30_Tja1040<br/>
     * The GeneralDefine block contains the following statements: (Sample for FRTRCV_30_TJA1080DIO) <br>
     * <br/>
     * #ifndef FRTRCV_30_TJA1080DIO_OSTYPE_AUTOSAR <br/>
     * #define FRTRCV_30_TJA1080DIO_OSTYPE_AUTOSAR <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_USE_DUMMY_STATEMENT<br/>
     * #define FRTRCV_30_TJA1080DIO_USE_DUMMY_STATEMENT STD_ON<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_DUMMY_STATEMENT_CONST<br/>
     * #define FRTRCV_30_TJA1080DIO_DUMMY_STATEMENT_CONST(v) (void)(v) /* PRQA S 3453 * / /* MD_MSR_FctLikeMacro * / /* /MICROSAR/EcuC/EcucGeneral/DummyStatementKind * /<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CRC_CHECK<br/>
     * #define FRTRCV_30_TJA1080DIO_CRC_CHECK STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_ATOMIC_BIT_ACCESS_IN_BITFIELD<br/>
     * #define FRTRCV_30_TJA1080DIO_ATOMIC_BIT_ACCESS_IN_BITFIELD STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_ATOMIC_VARIABLE_ACCESS<br/>
     * #define FRTRCV_30_TJA1080DIO_ATOMIC_VARIABLE_ACCESS 16U <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_PROCESSOR_CANOE<br/>
     * #define FRTRCV_30_TJA1080DIO_PROCESSOR_CANOE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_COMP_ANSI_C<br/>
     * #define FRTRCV_30_TJA1080DIO_COMP_ANSI_C<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_GEN_GENERATOR_MSR<br/>
     * #define FRTRCV_30_TJA1080DIO_GEN_GENERATOR_MSR<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CPUTYPE_BITORDER_LSB2MSB<br/>
     * #define FRTRCV_30_TJA1080DIO_CPUTYPE_BITORDER_LSB2MSB <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE 1<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_LINKTIME<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_LINKTIME 2<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE 3<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_POSTBUILD_VARIANT_SUPPORT<br/>
     * #define FRTRCV_30_TJA1080DIO_POSTBUILD_VARIANT_SUPPORT STD_OFF<br/>
     * #endif<br/>
     *
     * @param moduleConfig Moduleconfiguration to fetch the module short name from.
     * @return
     */
    @PublishedMethod
    public String generalDefineBlockWithVendor(final MIModuleConfiguration moduleConfig) {
        if (moduleConfig == null) {
            final GeneratorResultBuilder rb;
            rb = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModuleConfigFailureId(generatorPackage),
                    "Passed ModuleConfiguration of generator {0} must not be null", generatorPackage.getMSN());
            throw new ValidationFailedException(rb.buildResult());
        }
        final String msnLoc = GeneratorPackageUtil.getMaResolveVttModules(moduleConfig);

        /*
         * Get Vendor Id and Vendor Specific Name
         */
        final MIBswImplementationARRef moduleDescription = moduleConfig.getModuleDescription();
        final MIBswImplementation impl = moduleDescription.getRefTarget();

        final String vendorApiInfix = impl.getVendorApiInfix();
        if (vendorApiInfix == null) {
            final GeneratorResultBuilder rb;
            rb = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModuleConfigFailureId(generatorPackage),
                    "VendorApiInfix of ModuleConfiguration {0} must not be null.", moduleConfig.getName());
            rb.addErrorObject(moduleConfig);
            throw new ValidationFailedException(rb.buildResult());
        }

        if (impl.getVendorId() == null) {
            final GeneratorResultBuilder rb;
            rb = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModuleConfigFailureId(generatorPackage),
                    "VendorId of ModuleConfiguration {0} must not be null.", moduleConfig.getName());
            rb.addErrorObject(moduleConfig);
            throw new ValidationFailedException(rb.buildResult());
        }
        final String vendorId = String.valueOf(impl.getVendorId());

        return generalDefineBlock(GeneratorUtilFrameworkHelper.getFrameworkInternalToken(), msnLoc.concat("_").concat(vendorId).concat("_").concat(vendorApiInfix));
    }

    /**
     * Creates the GeneralDefine block with vendor specific postfix manually.<br>
     * This method allows you to specify the vendorApiInfix and the vendorId manually and should only be used in special use cases.<br/>
     * Usually you should prefer generalDefineBlockWithVendor(final MIModuleConfiguration moduleConfig) which appends the vendor parameter automatically from the BSW Implementation
     * node from the BSWMD.<br/>
     *
     * The module short name is extended by the vendorId and the vendor specific name (VendorApiInfix).<br/>
     * <MSN>_<VendorId>_<VendorApiInfix><br/>
     * E.g. CanTrcv_30_Tja1040<br/>
     * The GeneralDefine block contains the following statements: (Sample for FRTRCV_30_TJA1080DIO) <br>
     * <br/>
     * #ifndef FRTRCV_30_TJA1080DIO_OSTYPE_AUTOSAR <br/>
     * #define FRTRCV_30_TJA1080DIO_OSTYPE_AUTOSAR <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_USE_DUMMY_STATEMENT<br/>
     * #define FRTRCV_30_TJA1080DIO_USE_DUMMY_STATEMENT STD_ON<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_DUMMY_STATEMENT_CONST<br/>
     * #define FRTRCV_30_TJA1080DIO_DUMMY_STATEMENT_CONST(v) (void)(v) /* PRQA S 3453 * / /* MD_MSR_FctLikeMacro * / /* /MICROSAR/EcuC/EcucGeneral/DummyStatementKind * /<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CRC_CHECK<br/>
     * #define FRTRCV_30_TJA1080DIO_CRC_CHECK STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_ATOMIC_BIT_ACCESS_IN_BITFIELD<br/>
     * #define FRTRCV_30_TJA1080DIO_ATOMIC_BIT_ACCESS_IN_BITFIELD STD_OFF <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_ATOMIC_VARIABLE_ACCESS<br/>
     * #define FRTRCV_30_TJA1080DIO_ATOMIC_VARIABLE_ACCESS 16U <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_PROCESSOR_CANOE<br/>
     * #define FRTRCV_30_TJA1080DIO_PROCESSOR_CANOE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_COMP_ANSI_C<br/>
     * #define FRTRCV_30_TJA1080DIO_COMP_ANSI_C<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_GEN_GENERATOR_MSR<br/>
     * #define FRTRCV_30_TJA1080DIO_GEN_GENERATOR_MSR<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CPUTYPE_BITORDER_LSB2MSB<br/>
     * #define FRTRCV_30_TJA1080DIO_CPUTYPE_BITORDER_LSB2MSB <br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE 1<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_LINKTIME<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_LINKTIME 2<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_POSTBUILD_LOADABLE 3<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT<br/>
     * #define FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT FRTRCV_30_TJA1080DIO_CONFIGURATION_VARIANT_PRECOMPILE<br/>
     * #endif<br/>
     * #ifndef FRTRCV_30_TJA1080DIO_POSTBUILD_VARIANT_SUPPORT<br/>
     * #define FRTRCV_30_TJA1080DIO_POSTBUILD_VARIANT_SUPPORT STD_OFF<br/>
     * #endif<br/>
     *
     * @param vendorApiInfix String which is used as <VendorApiInfix>. The passed String is not escaped or modified.
     * @param vendorId String which is used as <VendorId>. The passed String is not escaped or modified.
     * @param moduleConfig Moduleconfiguration to fetch the module short name from.
     * @return
     */
    @PublishedMethod
    public String generalDefineBlockWithVendor(final MIModuleConfiguration moduleConfig, final String vendorApiInfix, final String vendorId) {
        if (moduleConfig == null) {
            final GeneratorResultBuilder rb;
            rb = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModuleConfigFailureId(generatorPackage),
                    "Passed ModuleConfiguration of generator {0} must not be null", generatorPackage.getMSN());
            throw new ValidationFailedException(rb.buildResult());
        }
        final String msnLoc = GeneratorPackageUtil.getMaResolveVttModules(moduleConfig);

        return generalDefineBlock(GeneratorUtilFrameworkHelper.getFrameworkInternalToken(), msnLoc.concat("_").concat(vendorId).concat("_").concat(vendorApiInfix));
    }

    /**
     * Internal method to create the GeneralDefine block.
     * <p>
     * THIS METHOD IS FRAMEWORK INTERNAL. Do not use this method!. Use {@link #generalDefineBlock(MIModuleConfiguration)} instead!
     * </p>
     *
     * @param token the token
     * @param msn the msn
     * @return the string
     */
    @PublishedMethod
    public String generalDefineBlock(final Object token, final String msnLoc) {
        GeneratorUtilFrameworkHelper.ensureTokenIsCorrect(token);
        if (msn == null) {
            throw new IllegalArgumentException("Passed msn must not be null");
        }
        final IGenPlatformService platformService = projectContext.getService(IGenPlatformService.class);

        final StringBuilder sb = new StringBuilder();

        // overwrite local msn with the current one
        setMsn(msnLoc);

        append2Sp(sb, defineOsType());
        append2Sp(sb, defineUseDummyStatement(platformService));
        append2Sp(sb, defineDummyStatement(platformService));
        append2Sp(sb, defineDummyStatementConst(platformService));
        append2Sp(sb, defineCrcCheck());
        append2Sp(sb, defineBoardAtomicBitAccessInBitfield(platformService));
        append2Sp(sb, defineBoardAtomicVariableAccess(platformService));
        append2Sp(sb, definePlatform());
        append2Sp(sb, defineDerivative());
        append2Sp(sb, defineCompiler());
        append2Sp(sb, defineGenerator());
        append2Sp(sb, defineCpuOrder(platformService));
        append2Sp(sb, defineModuleVariant());

        // build result
        return sb.toString();
    }

    /**
     * Renames the BitOrder of the board switch "Board/BoardGeneral/BoardBitOrder", because the Bswmd file of the Board has different literals as the embedded code.
     * <p>
     * See EVAL00088774
     * </p>
     *
     * @param lsb2Msb
     * @return The remapped BitOrder
     */
    private String renameBitOrder(final String lsb2Msb) {
        if (lsb2Msb.equals("LSB_to_MSB")) {
            return "LSB2MSB";
        }
        if (lsb2Msb.equals("MSB_to_LSB")) {
            return "MSB2LSB";
        }
        return lsb2Msb;
    }

    /**
     * Appends the string to the Stringbuilder and appends a "NewLine".
     *
     * @param sb StringBuilder Destination
     * @param s string to append
     */
    private void append2Sp(final StringBuilder sb, final String s) {
        if (sb == null) {
            throw new IllegalArgumentException("Passed stringBuilder must not be null");
        }
        if (s != null && !s.isEmpty()) {
            sb.append(s.concat(GenConstants.LINE_SEPARATOR));
        }
    }

    /**
     * Returns the AtomicBitAccessInBitfield value. If a MICROSAR EcuC Module is found the value is taken from this module. I it is absent, the Board module is used.<br/>
     * If neither EcuC nor Board module was found a GeneralParameterException is thrown.
     *
     * <p>
     * EVAL00104569: If the CrcCeck parameter does not exist in the EcuC module {@link Optional#absent()} is returned.
     * </p>
     *
     * @param mca
     * @return the Switch CrcCheck, or absent, if the parameter does not exist.
     * @throws GeneralParameterException
     */
    private static Optional<Boolean> getCrcCheck(IModelCheckedAccess mca) {
        final IMcaRequest<MIModuleConfiguration> ecuc = mca.moduleConfig(ECUC_DEFREF).getModuleConfigAsRequest();
        if (ecuc.isValid()) {

            /*
             * EVAL00104569: Ensure that CRC check is optional
             */
            final IMcaRequest<Boolean> request = mca.parameter(ECUC_CRC_CHECK).asBool().getValueAsRequest();
            if (!request.isValid()) {
                return Optional.absent();
            }
            /*
             * Microsar EcuC Module found.
             */
            final Boolean value = request.getResult();

            return Optional.of(value);
        } else {
            final IMcaRequest<MIModuleConfiguration> board = mca.moduleConfig(BOARD_DEFREF).getModuleConfigAsRequest();
            if (board.isValid()) {
                /*
                 * Microsar Board Module found. EcuC is not present.
                 */
                final Boolean value = mca.parameter(BOARD_CRC_CHECK).asBool().getValue();
                return Optional.of(value);
            }
            /*
             * No EcuC and no Board present.
             */
            throw new GeneralParameterException("CrcCheck could not be resolved. No EcuC or Board Module was found.");
        }
    }

    /**
     * Returns the DefRef of the location the parameter is used. <br/>
     * If a static value without reference to the configuration is used, an empty string is returned.
     *
     * @param mca
     * @return DefRef, or "".
     */
    private static String getCrcCheckDefRef(IModelCheckedAccess mca) {
        final IMcaRequest<MIModuleConfiguration> ecuc = mca.moduleConfig(ECUC_DEFREF).getModuleConfigAsRequest();
        if (ecuc.isValid()) {
            /*
             * Microsar EcuC Module found.
             */
            return ECUC_CRC_CHECK.getDefRefString();
        } else {
            final IMcaRequest<MIModuleConfiguration> board = mca.moduleConfig(BOARD_DEFREF).getModuleConfigAsRequest();
            if (board.isValid()) {
                return BOARD_CRC_CHECK.getDefRefString();

            }
            /*
             * No EcuC and no Board present.
             */
            return "";
        }
    }

    /**
     * Returns the Board OsType value. This parameter is only present in the Board module.<br/>
     * If absent (Usecase for AS4) "AUTOSAR" is returned.
     *
     * @param mca
     * @return Returns "AUTOSAR", "OSEK" or in case of AUTOSAR3 and an invalid parameter value "None"
     * @throws GeneralParameterException
     */
    private static String getOsType(IModelCheckedAccess mca) {

        final IMcaRequest<MIModuleConfiguration> board = mca.moduleConfig(BOARD_DEFREF).getModuleConfigAsRequest();
        if (board.isValid()) {
            /*
             * Microsar Board Module found. EcuC is not present.
             */
            final String osType = mca.parameter(BOARD_OS_TYPE).asEnum().getValue().toUpperCase();
            if (osType.toUpperCase().equals(OS_TYPE_AUTOSAR)) {
                return OS_TYPE_AUTOSAR;
            } else if (osType.toUpperCase().equals(OS_TYPE_OSEK)) {
                return OS_TYPE_OSEK;
            } else {
                return "None";
            }
        } else {
            /*
             * No Board present. In this case AUTOSAR 4 -> return AUTOSAR
             */
            return OS_TYPE_AUTOSAR;
        }
    }

    /**
     * Returns the DefRef of the location the parameter is used. <br/>
     * If a static value without reference to the configuration is used, an empty string is returned.
     *
     * @param mca
     * @return DefRef, or "".
     */
    private static String getOsTypeDefRef(IModelCheckedAccess mca) {
        final IMcaRequest<MIModuleConfiguration> board = mca.moduleConfig(BOARD_DEFREF).getModuleConfigAsRequest();
        if (board.isValid()) {
            /*
             * Microsar Board Module found. EcuC is not present.
             */
            return BOARD_OS_TYPE.getDefRefString();
        } else {
            /*
             * No Board present. In this case AUTOSAR 4 -> OsType is always AUTOSAR No DefRef is needed.
             */
            return "";
        }

    }

    private static boolean isBoardModulePresent(IModelCheckedAccess mca) {
        return mca.moduleConfig(BOARD_DEFREF).getModuleConfigAsRequest().isValid();
    }

}
