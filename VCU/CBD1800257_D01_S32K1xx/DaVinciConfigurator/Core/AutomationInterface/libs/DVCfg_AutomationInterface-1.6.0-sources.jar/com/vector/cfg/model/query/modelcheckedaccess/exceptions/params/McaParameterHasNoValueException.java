package com.vector.cfg.model.query.modelcheckedaccess.exceptions.params;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.params.IParamHasNoValueExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Thrown when a parameter has no value.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaParameterHasNoValueException extends McaParameterException {

    private static final long serialVersionUID = -114855441665636489L;

    private final List<IParamHasNoValueExData> exDataList;

    /**
     * Constructor for McaParameterWrongTypeException.
     *
     * @param wrongTypeExDataList
     */
    @PublishedMethod
    public McaParameterHasNoValueException(List<IParamHasNoValueExData> exDataList) {
        super(exDataList);
        this.exDataList = exDataList;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<IParamHasNoValueExData> getExceptionDataList() {
        return exDataList;
    }
}
