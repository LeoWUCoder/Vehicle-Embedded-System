package com.vector.cfg.model.view;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.view.config.IModelView;

/**
 * {@link IModelViewExecutionContext} defines one {@link IModelView} execution on the current stack. This should only be used in Java Try with resource pattern. The
 * {@link #close()} has to be called after the block of the {@link IModelView} switch is left.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IModelViewExecutionContext extends AutoCloseable {

    /**
     * Resets the switch {@link IModelView} to the previous {@link IModelView} on the current Thread.
     */
    @Override
    @PublishedMethod
    void close();

    @KeepSecretFromPublishedApi
    IModelViewExecutionContext SAME_VIEW_CONFIG_EXEC_CONTEXT = new IModelViewExecutionContext() {

        @Override
        public void close() {
        }

        @Override
        public String toString() {
            return "ModelViewExecutionContext [same view as outer context, so no info available]";
        }

    };

}
