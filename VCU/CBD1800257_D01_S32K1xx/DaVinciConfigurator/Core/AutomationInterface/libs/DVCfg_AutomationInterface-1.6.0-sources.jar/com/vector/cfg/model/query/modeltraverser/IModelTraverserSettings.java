package com.vector.cfg.model.query.modeltraverser;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IInvalidTraverserView;
import com.vector.cfg.model.query.modeltraverser.ModelTraverserFactory.ETraverserVersion;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Common"> <!--LaTeX:\label{sec:IModelTraverserSettings}-->
 *
 * <h5>ModelTraverser creation settings</h5> The {@link IModelTraverserSettings} represents the configuration passed to the {@link IModelTraverser} during construction. The
 * interface is used to query properties of the settings during the execution (runtime) of the {@link IModelTraverser}.
 *
 *
 * <p>
 * An {@link IModelTraverserSettings} is retrieved by calling {@link IModelTraverser#getCreationSettings()}.
 * </p>
 *
 *
 * <p>
 * The settings are <b>not</b> changeable after construction of an {@link IModelTraverser}.
 * </p>
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
@PublishedFilter(MsrPlatform.class)
public interface IModelTraverserSettings {

    /**
     * Returns the API version of the {@link IModelTraverser}.
     *
     * @return the version
     */
    @PublishedMethod
    ETraverserVersion getTraverserVersion();

    /**
     * Returns <code>true</code>, if {@link IInvalidTraverserView} provide {@link IInvalidViewReasons}.
     *
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="InvalidViewsProvideInvalidViewReasons">
     *
     * The method {@link IModelTraverserSettings#isInvalidViewReasonsSupportEnabled()} returns <code>true</code>, if the {@link IModelTraverser} was configured during construction
     * to provide {@link IInvalidViewReasons} at the {@link IInvalidTraverserView}s. </div>
     *
     * @return true, if the {@link IInvalidTraverserView} will provide {@link IInvalidViewReasons}.
     */
    @PublishedMethod
    boolean isInvalidViewReasonsSupportEnabled();
}
