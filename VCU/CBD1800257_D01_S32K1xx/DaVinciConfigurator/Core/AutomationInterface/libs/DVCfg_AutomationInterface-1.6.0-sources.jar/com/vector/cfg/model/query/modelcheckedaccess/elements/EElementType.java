package com.vector.cfg.model.query.modelcheckedaccess.elements;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Enumeration of the different element types of the {@link IModelCheckedAccess} request interface.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelCheckedAccess
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public enum EElementType {

    /**
     * <code>CONTAINER</code> marks the element as container.
     */
    CONTAINER("Container"),

    /**
     * <code>PARAMETER</code> marks the element as parameter.
     */
    PARAMETER("Parameter"),

    /**
     * <code>REFERENCE</code> marks the element as reference.
     */
    REFERENCE("Reference"),
    /**
     * <code>MODULE_CONFIGURATION</code> marks the element as module configuration.
     */
    MODULE_CONFIGURATION("Module Configuration"),

    /**
     * <code>REVERSE_REFERENCE</code> marks the element as an request for an reverse lookup of reference parameters.
     */
    REVERSE_REFERENCE("Reverse Reference");

    private final String descriptiveName;

    EElementType(String descriptiveName) {
        this.descriptiveName = descriptiveName;

    }

    @PublishedMethod
    public String getDescriptiveName() {
        return descriptiveName;
    }
}
