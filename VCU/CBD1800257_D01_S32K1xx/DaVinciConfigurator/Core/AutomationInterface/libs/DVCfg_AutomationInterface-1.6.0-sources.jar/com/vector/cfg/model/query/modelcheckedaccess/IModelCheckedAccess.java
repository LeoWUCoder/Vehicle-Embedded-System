package com.vector.cfg.model.query.modelcheckedaccess;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.enums.IModelEnum;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.query.modelcheckedaccess.elements.container.IMcaContainer;
import com.vector.cfg.model.query.modelcheckedaccess.elements.moduleconfig.IMcaModuleConfig;
import com.vector.cfg.model.query.modelcheckedaccess.elements.params.IMcaParamWithoutType;
import com.vector.cfg.model.query.modelcheckedaccess.elements.references.IMcaRefWithoutType;
import com.vector.cfg.model.query.modelcheckedaccess.elements.references.IMcaReverseReference;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaException;
import com.vector.cfg.util.IProjectService;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" id="Common">
 * <h2>IModelCheckedAccess</h2> The IModelCheckedAccess provides a checked interface to the {@link IModelAccess} interface and the Ecu configuration data, like Containers,
 * Parameters and ModuleConfigurations.
 * <p>
 * Checked means every method call will check the access and will throw a subtype of {@link McaException}, when something goes wrong. You do not have to check against
 * <code>null</code>.
 * </p>
 *
 * <p>
 * Example:
 *
 * <pre>
 * <code class="Java" id="ModelCheckedAccess examples">
 * 	 //Request a single parameter
 *   MINumericalValue param = modelcheckedaccess.parameter("/MICROSAR/.../NmPassiveModeEnabled").asBool().getParam();
 *
 *   //Request multiple containers
 *   List<MIContainer> containerList = mca.container("/MICROSAR/.../NmChannelConfig").getManyContainers();
 *
 *   //Request multiple parameters
 *   List<MINumericalValue> paramList = mca.parameter("/MICROSAR/.../CanIdValue").asInt().getManyParams();
 * </code>
 * </pre>
 *
 * </p>
 *
 *
 * <h3>General</h3> The service has four main entry points, depending whether what you want to get from the service (ModuleConfig, Container, Parameter or Reference):
 *
 * <ul>
 * <li><code>mca.parameter()</code> - Will start a request for a parameter</li>
 * <li><code>mca.container()</code> - Will start a request for a container</li>
 * <li><code>mca.reference()</code> - Will start a request for a reference</li>
 * <li><code>mca.moduleConfig()</code> - Will start a request for a moduleConfig</li>
 * <li><code>mca.reverseReference()</code> - Will start a request for a reverse resolution of reference parameters (See section "Find the reference parameters pointing to a
 * specific object (reverse mapping)")
 * </ul>
 * Then you can concatenate a type specifier for parameters or references (This will be described in the following chapters). E.g. <code>mca.parameter(...).asInt().</code>
 *
 * To complete the modelRequest you have to decide what you want to get. The following possibilities exists, listed by type:
 *
 * <h5>Container:</h5>
 *
 * <ul>
 * <li><code>getContainer()</code> - Will return one container</li>
 * <li><code>getManyContainers()</code> - Will return a list of containers</li>
 * </ul>
 *
 * <h5>Parameter:</h5>
 *
 * <ul>
 * <li><code>getParam()</code> - Will return one parameter</li>
 * <li><code>getManyParams()</code> - Will return a list of parameters</li>
 * <li><code>getValue()</code> - Will return one value of the parameter</li>
 * <li><code>getManyValues()</code> - Will return a list of values</li>
 * <li><code>getValueTuple()</code> - Will return one value/parameter tuple</li>
 * <li><code>getManyValueTuples()</code> - Will return a list of value/parameter tuples</li>
 * </ul>
 *
 * <h5>Reference:</h5>
 *
 * <ul>
 * <li><code>getReference()</code> - Will return one reference</li>
 * <li><code>getManyReferences()</code> - Will return a list of references</li>
 * <li><code>getRefTarget()</code> - Will return one refTarget of the references</li>
 * <li><code>getManyRefTargets()</code> - Will return a list of refTargets</li>
 * <li><code>getRefTargetTuple()</code> - Will return one refTarget/reference tuple</li>
 * <li><code>getManyRefTargetTuples()</code> - Will return a list of refTarget/reference tuples</li>
 * </ul>
 *
 * <h5>ModuleConfig:</h5>
 *
 * <ul>
 * <li><code>getModuleConfig()</code> - Will return one moduleConfig</li>
 * <li><code>getManyModuleConfigs()</code> - Will return a list of moduleConfigs</li>
 * </ul>
 *
 * <h5>ReverseReference:</h5>
 *
 * <ul>
 * <li><code>getReference()</code> - Will return one reference parameter which points to the specified target</li>
 * <li><code>getManyReferences()</code> - Will return a collection of reference parameters which points to the specified target</li>
 * </ul>
 *
 * For every request listed above, there exist a equivalent method which ends with <code>AsRequest()</code> . E.g. <code>getParamAsRequest()</code>. This method call will never
 * throw any exception. You can ask the IMcaRequest object, if the request is valid <code>isValid() == true</code>. If the request is valid, you can retrieve the result with
 * <code>getResult() </code>, without getting any exception. If you call <code>getResult()</code> on an invalid request, you will get the same exception as without
 * <code>xxxAsRequest()</code>.
 *
 *
 * <h3>Type specification for references or parameters</h3> Parameter or references have subtypes like Integer, String, Reference to a container and so on. Between the request
 * start (e.g. <code>mca.parameter()</code>) and the execution ( e.g. <code>getValue()</code>), you can specify the type of the request. Examples:
 * <ul>
 * <li><code>
 * .asInt()</code></li>
 * <li><code>
 * .asBool()</code></li>
 * <li><code>
 * .asFloat()</code></li>
 * <li><code>.asRefToContainer()</code></li>
 * </ul>
 *
 * <h3>Enumerations</h3> Enumerations are represented as Strings in the MDF model, but normally you want use Java enums in your code. You can transform AUTOSAR enum literals
 * into Java enums.
 *
 * <pre>
 * <code class="Java" id="ModelCheckedAccess and Java enums">
 * mca.parameter(<Your enum DefRef>).asEnum(<JAVA_Enum class>).getXXX();
 *
 * //Example:
 * EMyEnum value = mca.parameter(ENUM_DEFREF).asEnum(EMyEnum.class).getValue();
 * </code>
 * </pre>
 *
 * The example above will return the value of the parameter "ENUM_DEFREF" as a literal of the Java enum "EMyEnum".
 *
 * The algorithm tries to map the AUTOSAR literals to the Java literals by name. If your Java enum implements the {@link IModelEnum} interface (See {@link IModelEnum} interface
 * for an example code), you can control the mapping. For example you can map more AUTOSAR literals (e.g. As3 / As4 values) to the same Java literal with a different name.
 *
 * </div>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 * <p>
 * This interface is a ProjectService. See {@link IProjectService}
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see McaException
 * @see IProjectService
 * @see IModelAccess
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IModelCheckedAccess {

    /**
     * Returns an the project service {@link IModelSimpleAccess}, which corresponds to this {@link IModelCheckedAccess}.
     *
     * @return the ModelSimpleAccess project service.
     */
    @PublishedMethod
    IModelSimpleAccess simple();

    /**
     * Starts a new model request for a parameter ({@link MIParameterValue}), by a DefintionRef.
     *
     * <p>
     * Example:<br/>
     * <code>
        mca.parameter("DefRef").asBool(). ...
     * </code>
     * </p>
     *
     * @param definitionRef DefRef of the Parameter. This DefRef must be absolute.
     * @return A model request interface. Append .asString() for example, to specify the type.
     */
    @PublishedMethod
    IMcaParamWithoutType parameter(String definitionRef);

    /**
     * Starts a new model request for a parameter ({@link MIParameterValue}), by a DefinitionRef object.
     *
     * <p>
     * Example:<br/>
     * <code>
        mca.parameter(defRefObject).asBool(). ...
     * </code>
     * </p>
     *
     * @param definitionRef DefRef of the Parameter.
     * @return A model request interface. Append .asString() for example, to specify the type.
     */
    @PublishedMethod
    IMcaParamWithoutType parameter(DefRef definitionRef);

    /**
     * Starts a new model request for a parameter ({@link MIParameterValue}), by a parent container ({@link MIContainer}) and a DefintionRef.
     *
     * <p>
     * Example:<br/>
     * <code>
        mca.parameter(myParent, "NmPassiveModeEnabled").asBool(). ...
     * </code>
     * </p>
     *
     * @param definitionRef DefRef of the Parameter. This DefRef can be absolute or relative.
     * @return A model request interface. Append .asString() for example, to specify the type.
     */
    @PublishedMethod
    IMcaParamWithoutType parameter(MIHasContainer parent, String definitionRef);

    /**
     * Starts a new model request for a parameter ({@link MIParameterValue}), by a parent container ({@link MIContainer}) and a DefinitionRef object.
     *
     * <p>
     * Example:<br/>
     * <code>
        mca.parameter(myParent, defRefObject).asBool(). ...
     * </code>
     * </p>
     *
     * @param definitionRef - DefRef of the Parameter.
     * @return A model request interface. Append .asString() for example, to specify the type.
     */
    @PublishedMethod
    IMcaParamWithoutType parameter(MIHasContainer parent, DefRef definitionRef);

    /**
     * Starts a new request for any Object and check if the Type, Multiplicity and more is correct, and returns a typesafe access to the element or Collection
     *
     * <p>
     * Example:<br/>
     * <code>
     *   mco.checkObject(myAnyThing).asParameter().asBool(). ...
     * </code>
     * </p>
     *
     * @param element Any Model Object
     * @return A model request interface.
     */
    @PublishedMethod
    IMcaParamWithoutType parameter(MIHasDefinition element);

    /**
     * Starts a new request for any Object and check if the Type, Multiplicity and more is correct, and returns a typesafe access to the element or Collection
     *
     * <p>
     * Example:<br/>
     * <code>
     *   mco.checkCollection(myAnyThing).asParameter().asBool(). ...
     * </code>
     * </p>
     *
     * @param objList Any Model Object List
     * @return The ModelCheckedObject interface
     */
    @PublishedMethod
    IMcaParamWithoutType parameter(List<? extends MIHasDefinition> elementList);

    /**
     * Starts a new model request for a container ({@link MIContainer}), with a DefintionRef.
     *
     * <p>
     * Example:<br/>
     * <code>
       mca.container("/MICROSAR/.../NmChannelConfig").getManyContainers();
     * </code>
     * </p>
     *
     * @param definitionRef DefRef of the Parameter. This DefRef must be absolute.
     * @return A model request interface.
     */
    @PublishedMethod
    IMcaContainer container(String definitionRef);

    /**
     * Starts a new model request for a container ({@link MIContainer}), with a DefintionRef object.
     *
     * <p>
     * Example:<br/>
     * <code>
       mca.container(defRefObject).getManyContainers();
     * </code>
     * </p>
     *
     * @param definitionRef DefRef of the Parameter.
     * @return A model request interface.
     */
    @PublishedMethod
    IMcaContainer container(DefRef definitionRef);

    /**
     * Starts a new model request for a container ({@link MIContainer}), by a parent container ({@link MIHasContainer}) and a DefinitionRef.
     *
     * <p>
     * Example:<br/>
     * <code>
       mca.container(myparentContainer, "NmChannelConfig").getManyContainers();
     * </code>
     * </p>
     *
     * @param parent the parent model object
     * @param definitionRef - DefRef of the Parameter. This DefRef can be absolute or relative.
     * @return A model request interface.
     */
    @PublishedMethod
    IMcaContainer container(MIHasContainer parent, String definitionRef);

    /**
     * Starts a new model request for a container ({@link MIContainer}), by a parent container ({@link MIHasContainer}) and a DefintionRef object.
     *
     * <p>
     * Example:<br/>
     * <code>
       mca.container(myparentContainer, defRefObject).getManyContainers();
     * </code>
     * </p>
     *
     * @param parent the parent model object
     * @param definitionRef DefRef of the Parameter.
     * @return A model request interface.
     */
    @PublishedMethod
    IMcaContainer container(MIHasContainer parent, DefRef definitionRef);

    /**
     * Starts a new model request for a reference ({@link MIParameterValue}), with a DefinitionRef.
     *
     * <p>
     * Example:<br/>
     * <code>
        mca.reference("DefRef").asRefToContainer(). ...
     * </code>
     * </p>
     *
     * @param definitionRef DefRef of the Parameter. This DefRef must be absolute.
     * @return A model request interface. Append .asRefToContainer() for example, to specify the type of the reference and the target.
     */
    @PublishedMethod
    IMcaRefWithoutType reference(String definitionRef);

    /**
     * Starts a new model request for a reference ({@link MIParameterValue}), with a DefintionRef object.
     *
     * <p>
     * Example:<br/>
     * <code>
        mca.reference(defRefObject).asRefToContainer(). ...
     * </code>
     * </p>
     *
     * @param definitionRef DefRef of the Parameter.
     * @return A model request interface. Append .asRefToContainer() for example, to specify the type of the reference and the target.
     */
    @PublishedMethod
    IMcaRefWithoutType reference(DefRef definitionRef);

    /**
     * Starts a new model request for a reference ({@link MIParameterValue}), by a parent container ({@link MIContainer}) and a DefintionRef.
     *
     * <p>
     * Example:<br/>
     * <code>
        mca.reference(parent, "DefRef").asRefToContainer(). ...
     * </code>
     * </p>
     *
     * @param parent the parent model object
     * @param definitionRef DefRef of the Parameter. This DefRef can be absolute or relative.
     * @return A model request interface. Append .asRefToContainer() for example, to specify the type of the reference and the target.
     */
    @PublishedMethod
    IMcaRefWithoutType reference(MIHasContainer parent, String definitionRef);

    /**
     * Starts a new model request for a reference ({@link MIParameterValue}), by a parent container ({@link MIContainer}) and a DefinitionRef object.
     *
     * <p>
     * Example:<br/>
     * <code>
        mca.reference(parent, defRefObject).asRefToContainer(). ...
     * </code>
     * </p>
     *
     * @param parent the parent model object
     * @param definitionRef DefRef of the Parameter. This DefRef can be absolute or relative.
     * @return A model request interface. Append .asRefToContainer() for example, to specify the type of the reference and the target.
     */
    @PublishedMethod
    IMcaRefWithoutType reference(MIHasContainer parent, DefRef definitionRef);

    /**
     * Starts a new request for any Object and check if the Type, Multiplicity and more is correct, and returns a typesafe access to the element or Collection
     *
     * <p>
     * Example:<br/>
     * <code>
     *   mco.checkObject(myAnyThing).asParameter().asBool(). ...
     * </code>
     * </p>
     *
     * @param element - Any Model Object
     * @return A model request interface.
     */
    @PublishedMethod
    IMcaRefWithoutType reference(MIHasDefinition element);

    /**
     * Starts a new request for any Object and check if the Type, Multiplicity and more is correct, and returns a typesafe access to the element or Collection
     *
     * <p>
     * Example:<br/>
     * <code>
     *   mco.checkCollection(myAnyThing).asParameter().asBool(). ...
     * </code>
     * </p>
     *
     * @param objList - Any Model Object List
     * @return The ModelCheckedObject interface
     */
    @PublishedMethod
    IMcaRefWithoutType reference(List<? extends MIHasDefinition> elementList);

    /**
     * Starts a new model request for a module configuration ({@link MIModuleCOnfiguration}), with a DefintionRef.
     *
     * <p>
     * Example:<br/>
     * <code>
       mca.moduleConfig("/MICROSAR/Nm").getModuleConfig();
     * </code>
     * </p>
     *
     * @param definitionRef - DefRef of the Parameter. This DefRef must be absolute.
     * @return A model request interface.
     */
    @PublishedMethod
    IMcaModuleConfig moduleConfig(String definitionRef);

    /**
     * Starts a new model request for a module configuration ({@link MIModuleCOnfiguration}), with a DefintionRef object.
     *
     * <p>
     * Example:<br/>
     * <code>
       mca.moduleConfig(defRefObj).getModuleConfig();
     * </code>
     * </p>
     *
     * @param definitionRef - DefRef of the Parameter. This DefRef must be absolute.
     * @return A model request interface.
     */
    @PublishedMethod
    IMcaModuleConfig moduleConfig(DefRef definitionRef);

    /**
     * Starts a new model request for a reverse lookup of references pointing to the specified target, which has the definition referenceParameterDefRef.
     *
     * <p>
     * Example:<br/>
     * <code>
       mca.reverseReference(myContainer, defRefOfReference).getReference();
     * </code>
     * </p>
     *
     * @param target - The target which is used to start the reverse lookup
     * @param referenceParameterDefRef - DefRef of the Reference parameter. This DefRef must be absolute.
     * @return A model request interface.
     */
    @PublishedMethod
    IMcaReverseReference reverseReference(MIReferrable target, DefRef referenceParameterDefRef);

}
