/**
 * The BswmdModel interface and base types of parameters.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.bswmdmodel.param;