package com.vector.cfg.util.version;

import org.osgi.framework.Version;

import com.google.common.base.Preconditions;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class VersionUtil {

    private VersionUtil() {
    }

    @PublishedMethod
    public static Version convertVectorVersionIntoOSGIVersion(final IVersion tempVersion) {
        final Version osgiVersion;
        String suffix = (tempVersion.hasBuild()) ? (Integer.toString(tempVersion.getBuild())) : ("");
        suffix += (tempVersion.hasSuffix()) ? (tempVersion.getSuffix()) : ("");
        osgiVersion = new Version(tempVersion.getMajor(), tempVersion.getMinor(), tempVersion.getPatchLevel(), suffix);
        return osgiVersion;
    }

    /**
     *
     * @param version1
     * @param version2
     * @return The higher version of the two given versions.
     */
    @KeepSecretFromPublishedApi
    public static IVersion getMaximumVersion(IVersion version1, IVersion version2) {
        if (version1 == version2) {
            return version1;
        }

        int result = version1.getMajor() - version2.getMajor();
        if (result != 0) {
            if (result < 0) {
                return version2;
            }
            return version1;
        }

        result = version1.getMinor() - version2.getMinor();
        if (result != 0) {
            if (result < 0) {
                return version2;
            }
            return version1;
        }

        result = version1.getPatchLevel() - version2.getPatchLevel();
        if (result != 0) {
            if (result < 0) {
                return version2;
            }
            return version1;
        }
        // equal
        return version1;
    }

    /**
     * Returns true if and only if the given version lies in [lowerBound,upperBound] .
     *
     * @throws IllegalArgumentException if upperBound is less than lowerBound.
     */
    @KeepSecretFromPublishedApi
    public static boolean checkVersionIsInRange(IVersion v, IVersion lowerBound, IVersion upperBound) {
        Preconditions.checkNotNull(v);
        if (lowerBound.compareTo(upperBound) > 0) {
            throw new IllegalArgumentException("LowerBound must be less than or equal to upper bound.");
        }

        final int lowerBoundCompare = lowerBound.compareTo(v);
        final int upperBoundCompare = upperBound.compareTo(v);
        return lowerBoundCompare <= 0 && upperBoundCompare >= 0;
    }
}
