/**
 * DaVinci Configurator {@link com.vector.cfg.util.text.mixedtext.IMixedText} part definitions.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.text.mixedtext.parts;