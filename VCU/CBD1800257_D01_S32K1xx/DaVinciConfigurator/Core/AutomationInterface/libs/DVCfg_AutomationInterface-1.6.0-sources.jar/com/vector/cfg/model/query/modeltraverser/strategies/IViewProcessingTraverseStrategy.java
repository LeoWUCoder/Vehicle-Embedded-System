package com.vector.cfg.model.query.modeltraverser.strategies;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IInvalidTraverserView;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.ITraverserView;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IValidTraverserView;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.model.query.modeltraverser.Path;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="TraverseStrategy"> An {@link IViewProcessingTraverseStrategy} adapts the traverse behavior of an
 * {@link IModelTraverser} after the view was created and before the verification checks were executed. There are two possible ways to change the behavior
 * <ul>
 * <li>You can reject a whole view by an element.<br/>
 * <code>acceptView(IInvalidTraverserView, MIHasDefinition, MIHasDefinition)</code></li>
 * <li>You can reject subtrees of an instance tree starting at the element.<br/>
 * <code>acceptElement(IInvalidTraverserView, MIHasDefinition, MIHasDefinition)</code></li>
 * </ul>
 *
 * <p>
 * <b>Accept methods only have InvalidViews:</b><br/>
 * The reason, why all <code>acceptXXX()</code> only have {@link IInvalidTraverserView}, is that all strategies are called <b>before</b> the View is verified internally. So a
 * strategy could for example process a view, which is currently invalid, and make it to an {@link IValidTraverserView} by removing subtrees of the view.
 * </p>
 * <p>
 * The Class {@link ViewProcessingTraverseStrategy} provides a basic implementation, which returns always <code>true</code> for the {@link IViewProcessingTraverseStrategy}.
 * <b>Please subclass the <code>ViewProcessing TraverseStrategy</code> to implement you own strategy.</b>
 * </p>
 *
 * <pre>
 * <code class="Java" id="IViewProcessingTraverseStrategy sample implementation">
 * ITraverseStrategy yourStrategy =
 *         new ViewProcessingTraverseStrategy<MIContainer, MINumericalValue>
 *         (projectContext, NM_GLOBAL_CONFIG_DEFREF, NM_COM_USER_DATA_ENABLED_DEFREF)
 *        {
 *
 *             protected boolean acceptViewInternal(IInvalidTraverserView currentView, MIContainer parent, MINumericalValue currentElem) {
 *                 //Decide to keep or discard view
 *                 return false;
 *             }
 *
 *             protected boolean acceptElementInternal(IInvalidTraverserView currentView, MIContainer parent, MINumericalValue currentElem) {
 *                 //Decide to keep or discard element
 *                 return false;
 *             }
 *         };
 * </code>
 * </pre>
 *
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 * @see TraverseStrategy
 * @see IModelTraverser
 * @see Path
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IViewProcessingTraverseStrategy extends ITraverseStrategy {

    /**
     * Gets the {@link DefRef} of the parent element in the definition tree. See {@link Path} for more details.
     *
     * @return the parent {@link DefRef}
     */
    @Override
    @PublishedMethod
    TypedDefRef<?, ?, ?> getParentDefRef();

    /**
     * Gets the {@link DefRef} of the element which should be processed in the definition tree. See {@link Path} for more details.
     *
     * @return the Element {@link DefRef}
     */
    @Override
    @PublishedMethod
    TypedDefRef<?, ?, ?> getDefRef();

    /**
     * {@link #acceptView(IInvalidTraverserView, MIHasDefinition, MIHasDefinition)} is call for each currentElement in the instance tree.
     * <p>
     * If true is returned the process continues. If false is returned, the whole {@link ITraverserView} is marked as {@link IInvalidTraverserView} and returned to the called of
     * the {@link IModelTraverser}.
     * </p>
     *
     * <p>
     * Attention:The parent parameter is <code>null</code>, if the currentElem is the MainElement (root) of the {@link IModelTraverser} execution!
     * </p>
     *
     * @param currentView the {@link IInvalidTraverserView} before the Multiplicity checks were performed.
     * @param parent the parent configuration element of the currentElement, matching to the {@link #getParentDefRef()}. Could be <code>null</code>.
     * @param currentElem the current element to process, which matches to the {@link #getDefRef()}.
     * @return true, if the view shall be kept, otherwise false.
     */
    @PublishedMethod
    boolean acceptView(IInvalidTraverserView currentView, MIHasDefinition parent, MIHasDefinition currentElem);

    /**
     * {@link #acceptElement(IInvalidTraverserView, MIHasDefinition, MIHasDefinition)} is call for each currentElement in the instance tree.
     * <p>
     * If true is returned the element is kept in the instance tree. If false is returned, the currentElem is removed from the instance tree.
     * </p>
     *
     * <p>
     * Attention:The parent parameter is <code>null</code>, if the currentElem is the MainElement (root) of the {@link IModelTraverser} execution!
     * </p>
     *
     * @param currentView the {@link IInvalidTraverserView} before the Multiplicity checks were performed.
     * @param parent the parent configuration element of the currentElement, matching to the {@link #getParentDefRef()}. Could be <code>null</code>.
     * @param currentElem the current element to process, which matches to the {@link #getDefRef()}.
     * @return true, if the currentElem shall be kept, otherwise false.
     */
    @PublishedMethod
    boolean acceptElement(IInvalidTraverserView currentView, MIHasDefinition parent, MIHasDefinition currentElem);
}
