package com.vector.cfg.model.state;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;

/**
 * This interface specifies the published subset of {@link ICeState}. It is intended for use in code generator implementations and validations.
 *
 * <h1>Creation policy</h1> Instances of related CeState implementations can be created by means of {@link CeStatePublishedFactory}.
 *
 * <h1>Implementation policy</h1> All published CeState APIs must guarantee that the provided information is <i>static</i>. That's essential because the methods published here
 * may e.g. be used in validation implementations in the code generators. Due to the lack of event support of published CeState APIs dynamic updates of non-static states are not
 * supported.
 *
 * A non-static state for example is {@link ICeState#isChangeable()}. A static state for example is the availability of a pre-configuration object since pre-configuration never
 * changes at runtime of the tool.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface ICeStatePublished {

    /**
     * Returns user-defined flag of a configuration element.
     *
     * <div class="extdoc" id="isUserDefined" data-target-doc="AutomationInterfaceDocumentation"> The method <code>isUserDefined()</code> returns <code>true</code>, if the ecuc
     * configuration element like parameters is flagged as user-defined.
     *
     * <pre>
     * <code class="Groovy" id="Retrieve the user-defined flag of an Ecuc parameter in Groovy">
     * MIParameterValue param = ...
     * def flag = param.ceState.userDefined
     * </code>
     * </pre>
     *
     * </div>
     *
     * @return <code>true</code> if the CE is userDefined.
     */
    @PublishedMethod
    boolean isUserDefined();

    /**
     * Getter method for MDF-Object which is being supervised by this state object.
     *
     * @return The supervised MDF object. If the MDF object has already been deleted, the returned value is Optional.absent.
     */
    @PublishedMethod
    Optional<MIObject> getSupervisedObject();

    /**
     * This method checks if the related object is changeable according to the current configuration phase. No further check are made, so there may be other reasons which deny
     * changing the object (the related ARXML file may be read-only for example).
     *
     * <h1>What does <i>change</i> mean for containers?</h1> It means changing immediate attributes of the container like its description text. It doesn't mean creation or
     * deletion of child objects. This has to be checked with the other methods in this interface.
     *
     * @return
     */
    @PublishedMethod
    boolean isChangeAllowedAccordingToCurrentConfigurationPhase();

    /**
     * This method checks if the related object is deletable according to the current configuration phase. No further check are made, so there may be other reasons which deny
     * changing the object (the related ARXML file may be read-only for example).
     *
     * @return
     */
    @PublishedMethod
    boolean isDeletionAllowedAccordingToCurrentConfigurationPhase();

}
