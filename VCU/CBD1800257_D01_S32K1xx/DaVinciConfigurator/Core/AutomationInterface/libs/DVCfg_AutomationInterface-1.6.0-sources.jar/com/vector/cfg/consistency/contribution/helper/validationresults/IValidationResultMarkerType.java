package com.vector.cfg.consistency.contribution.helper.validationresults;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * An {@link IValidationResultMarkerType} represents the type of a marker added to a validation result.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IValidationResultMarkerType {

    /**
     * The description of the specific value of the {@link IValidationResultMarkerType}.
     *
     * @return description
     */
    @PublishedMethod
    String getDescription();
}
