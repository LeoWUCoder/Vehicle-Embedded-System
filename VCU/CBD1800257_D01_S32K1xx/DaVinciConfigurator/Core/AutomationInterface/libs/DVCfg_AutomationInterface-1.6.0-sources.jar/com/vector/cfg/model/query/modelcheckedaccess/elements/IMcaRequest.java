package com.vector.cfg.model.query.modelcheckedaccess.elements;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.elements.params.IMcaTypesafeParam;
import com.vector.cfg.model.query.modelcheckedaccess.elements.references.IMcaTypesafeRef;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * IMcaRequest interface provides methods to check is a {@link IModelCheckedAccess} request is valid ({@link IMcaRequest#isValid()}) without throwing any {@link McaException}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IMcaTypesafeParam
 * @see IMcaTypesafeRef
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IMcaRequest<T> {

    /**
     * Checks if the request was valid. This method will never throw an {@link McaException}.
     *
     * <p>
     * If the method returns true, you can call {@link #getResult()} for the result object.
     * </p>
     *
     * @return true, if the Mca request was is valid.
     */
    @PublishedMethod
    boolean isValid();

    /**
     * Gets the result of the Mca request. If {@link #isValid()} returns false, this method will throw some kind of {@link McaException}.
     *
     * @return the result of the request.
     */
    @PublishedMethod
    T getResult();
}
