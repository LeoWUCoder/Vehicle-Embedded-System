package com.vector.cfg.model.formats;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.cfg.model.mdf.MIObject;

/**
 * {@link MIObject} mixed text formats.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class MixedTextFormatMDFObject {

    /**
     * Formats the DefRef without the DefRef text before.
     */
    @PublishedField
    public static final String NORMAL_FORMAT = "";

    /**
     * Formats the paramter without a value.
     */
    @PublishedField
    public static final String NO_VALUE_FORMAT = "noValue";

    /**
     * Formats the paramter with only the value, without definition name. E.g. "true", "0.25", "/ActiveEcuc/Com".
     */
    @PublishedField
    public static final String ONLY_VALUE_FORMAT = "onlyValue";

    private MixedTextFormatMDFObject() {

    }

}
