/**
 * DaVinci Configurator logging API for development and end user messages.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.log;