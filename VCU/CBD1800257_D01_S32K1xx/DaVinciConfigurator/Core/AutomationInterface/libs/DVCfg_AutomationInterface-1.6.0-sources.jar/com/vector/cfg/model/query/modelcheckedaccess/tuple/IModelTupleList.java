package com.vector.cfg.model.query.modelcheckedaccess.tuple;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.query.modelcheckedaccess.elements.params.IMcaTypesafeParam;
import com.vector.cfg.model.query.modelcheckedaccess.elements.references.IMcaTypesafeRef;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * This interface represents a list of {@link IModelTuple} of value model element pairs.
 *
 * <p>
 * Every tuple in this list has to the element(Parameter/Reference) the value (retrieved by getValue()) and Element (retrieved by getElement())
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 *
 * @see IMcaTypesafeParam
 * @see IMcaTypesafeRef
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IModelTupleList<VALUE, ELEM extends MIParameterValue> extends List<IModelTuple<VALUE, ELEM>> {

    /**
     * Gets a list of element in this list of {@link IModelTuple} object.
     * <p>
     * This is the same as to iterate over <code>this</code> and build a new list of the {@link IModelTuple#getElement()} elements.
     * </p>
     *
     * @return the element list
     */
    @PublishedMethod
    List<ELEM> getElementList();

    /**
     * Gets a list of values in this list of {@link IModelTuple} object.
     * <p>
     * This is the same as to iterate over <code>this</code> and build a new list of the {@link IModelTuple#getValue()} elements.
     * </p>
     *
     * @return the element list
     */
    @PublishedMethod
    List<VALUE> getValueList();
}
