package com.vector.cfg.util.text.mixedtext;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class FormatException extends RuntimeException {

    private static final long serialVersionUID = -2844174392511315968L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(FormatException.class);

    /**
     * Constructor for FormatException.
     *
     * @param string
     */
    @PublishedMethod
    public FormatException(String string) {
        super(string);
    }

}
