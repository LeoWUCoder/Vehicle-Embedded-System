package com.vector.cfg.model.query.modelcheckedaccess.elements.params;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.EParameterType;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.enums.IModelEnum;
import com.vector.cfg.model.enums.ModelEnumUtil;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.blockelements.MIDocumentationBlock;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIEcucAddInfoParamValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterWrongTypeException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess request interface for parameters ({@link MIParameterValue})
 *
 * <p>
 * You can process the request by adding a method call to your request.
 * </p>
 * <p>
 * Example:<br/>
 * <code>mca.parameter(..) -->.getParam()<-- or -->.asString()<---</code> ...
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelCheckedAccess
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IMcaParamWithoutType extends IMcaParam<IMcaParamWithoutType> {

    /**
     * Binds the model request to the type Boolean. Boolean in Java ({@link Boolean}) and BOOLEAN in MDF ({@link EParameterType}).
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type Boolean</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeParam<Boolean, MINumericalValue> asBool();

    /**
     * Binds the model request to the type Integer. BigInteger in Java ({@link BigInteger}) and INTEGER in MDF ({@link EParameterType}).
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type Integer</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeParam<BigInteger, MINumericalValue> asInt();

    /**
     * Binds the model request to the type String. String in Java ({@link String}) and STRING in MDF ({@link EParameterType}).
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type String</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeParam<String, MITextualValue> asString();

    /**
     * Binds the model request to the type Float. BigDecimal in Java ({@link BigDecimal}) and FLOAT in MDF ({@link EParameterType}).
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type Float</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeParam<BigDecimal, MINumericalValue> asFloat();

    /**
     * Binds the model request to the type String. String in Java ({@link String}) and ENUMERATION in MDF ({@link EParameterType}). >
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     *
     *
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type Enumeration</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeParam<String, MITextualValue> asEnum();

    /**
     * Binds the model request to the type of the classOfCustomEnum. You can use a Java ({@link Enum}) and ENUMERATION in MDF ({@link EParameterType}), for the access.
     *
     * <p>
     * If the Class classOfCustomEnum implements the {@link IModelEnum} interface. The literals are mapped via these information form the {@link IModelEnum} interface.
     * </p>
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @param classOfCustomEnum The enum class which is used to map the value
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type Enumeration</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parameter classOfCustomEnum is null</li>
     * </ul>
     * @see IModelEnum
     * @see ModelEnumUtil
     */
    @PublishedMethod
    <ENUM_CLASS extends Enum<ENUM_CLASS>> IMcaTypesafeParam<ENUM_CLASS, MITextualValue> asEnum(Class<ENUM_CLASS> classOfCustomEnum);

    /**
     * Binds the model request to the type Linker Symbol. String in Java ({@link String}) and LINKER_SYMBOL in MDF ({@link EParameterType}).
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type Linker Symbol</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeParam<String, MITextualValue> asLinkerSymbol();

    /**
     * Binds the model request to the type Function Name. String in Java ({@link String}) and FUNCTION_NAME in MDF ({@link EParameterType}).
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type Function Name</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeParam<String, MITextualValue> asFuncName();

    /**
     * Binds the model request to the type {@link MIEcucAddInfoParamValue}. {@link MIDocumentationBlock} in Java and ADD_INFO in MDF model ( {@link EParameterType}).
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type Function Name</li>
     * </ul>
     */
    @PublishedMethod
    IMcaTypesafeParam<MIDocumentationBlock, MIEcucAddInfoParamValue> asEcucAddInfoParam();

    /**
     * Binds the model request to the type specified by the {@link TypedDefRef} parameter.
     *
     * <p>
     * This is a TypeOperation.
     * </p>
     *
     * @return This model request interface
     *
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the correct type</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef type is not allowed</li>
     * </ul>
     */
    @PublishedMethod
    <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIParameterValue, VALUE_TYPE> IMcaTypesafeParam<VALUE_TYPE, CONFIG_TYPE> typeBy(
            TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef);

}
