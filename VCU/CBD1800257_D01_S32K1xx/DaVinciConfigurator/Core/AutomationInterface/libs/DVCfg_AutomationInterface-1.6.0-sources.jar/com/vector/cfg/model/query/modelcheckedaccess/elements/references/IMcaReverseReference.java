package com.vector.cfg.model.query.modelcheckedaccess.elements.references;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.IReferenceAccess;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaRequest;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaDefinitionUndefinedException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaNotExistsException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongQuantityException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess request interface for reverse lookup of reference parameters.
 *
 * <p>
 * See {@link IReferenceAccess#getReferenceParametersPointingTo(com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable, com.vector.cfg.model.access.DefRef)} for the same logic
 * in modelAccess.
 * </p>
 * <p>
 * You can process the request by adding a method call to your request.
 * </p>
 * <p>
 * Example:<br/>
 * <code>mca.reverseReference(..) -->.getReference();</code>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelCheckedAccess
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IMcaReverseReference {

    /**
     * Executes the model request and returns a single ReferenceParameter({@link MIReferenceValue}), with the definition specified in the
     * {@link IModelCheckedAccess#reverseReference(com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable, com.vector.cfg.model.access.DefRef)} method.
     *
     * <p>
     * The requested reference must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IMcaReverseReference#getManyReferences() getManyReferences()} instead.
     * </p>
     *
     * @return The ReferenceParameter which points to the target object.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaNotExistsException
     * <ul>
     * <li>if no reference was found</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one reference value was found</li>
     * </ul>
     */
    @PublishedMethod
    MIReferenceValue getReference();

    /**
     * Executes the model request and returns a single ReferenceParameter({@link MIReferenceValue}). See method {@link #getReference()}.
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<MIReferenceValue> getReferenceAsRequest();

    /**
     * Executes the model request and returns a list of ReferenceParameter({@link MIReferenceValue}), which are pointing to the target object.
     *
     * <p>
     * If no reference was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if non or one
     * parameter was found.
     * </p>
     *
     * @return An unmodifiable Collection of ReferenceParameter({@link MIReferenceValue}), which pointing to the target object, for the request.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     */
    @PublishedMethod
    Collection<MIReferenceValue> getManyReferences();

    /**
     * Executes the model request and returns a list of references. See {@link #getManyReferences()}.
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<Collection<MIReferenceValue>> getManyReferencesAsRequest();

}
