package com.vector.cfg.model.query.modeltraverser.strategies;

import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser;
import com.vector.cfg.model.query.modeltraverser.Path;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="TraverseStrategy"> An {@link ITraverseStrategy} adapts the traverse behavior of an
 * {@link IModelTraverser} element. There are many possible ways to change the behavior
 * <ul>
 * <li> {@link IViewProcessingTraverseStrategy} - You can reject a whole view by an element.<br/>
 * <code>acceptView(IInvalidTraverserView, MIHasDefinition, MIHasDefinition)</code></li>
 * <li> {@link IViewProcessingTraverseStrategy} - You can reject subtrees of an instance tree starting at the element. <br/>
 * <code>acceptElement(IInvalidTraverserView, MIHasDefinition, MIHasDefinition)</code></li>
 * <li>{@link IPathSelectionTraverseStrategy} - You can choose to integrate overlapping definition subtrees. <br/>
 * <code>acceptPathTraversal(IInvalidTraverserView, MIHasDefinition, MIHasDefinition)</code></li>
 * </ul>
 * <p>
 * A {@link ITraverseStrategy} is registered during the definition tree construction by calling the method {@link Path#appendStrategy(ITraverseStrategy)} on any
 * element you want. The associated {@link DefRef} of the {@link ITraverseStrategy} must correspond with the element of the definition tree.
 * </p>
 * <p>
 * The Class {@link TraverseStrategy} provides a basic implementation for the {@link ITraverseStrategy}. <b>Please subclass the {@link TraverseStrategy} to
 * implement you own strategy.</b>
 * </p>
 *
 * <p>
 * <b>Attention</b>: Your implementation must be <b>threadsafe</b>, because a {@link IModelTraverser} could be called by different threads!
 * </p>
 *
 *
 *
 * <pre>
 * <code class="Java" id="ITraverserStrategy registration">
 * ITraverserStrategy yourStrategy = ...;
 * // @formatter:off
 * final IModelTraverserPath path=
 *    rootElem(NM_CHANNEL_CONFIG_DEFREF).
 *      fork(
 *          elem(NM_GLOBAL_CONFIG_DEFREF).appendStrategy(yourStrategy)
 *          //This appends the Strategy to the NM_GLOBAL_CONFIG_DEFREF element
 *          )
 *    ;
 * // @formatter:on
 * </code>
 * </pre>
 *
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 * @see TraverseStrategy
 * @see IModelTraverser
 * @see IPathSelectionTraverseStrategy
 * @see IViewProcessingTraverseStrategy
 * @see Path
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface ITraverseStrategy {

    /**
     * Gets the {@link DefRef} of the parent element in the definition tree. See {@link Path} for more details.
     *
     * <p>
     * Attention: This could be <code>null</code>, if the element has no parent (MainElement).
     * </p>
     *
     * @return the parent {@link DefRef}
     */
    @PublishedMethod
    @Nullable
    TypedDefRef<?, ?, ?> getParentDefRef();

    /**
     * Gets the {@link DefRef} of the element which should be processed in the definition tree. See {@link Path} for more details.
     *
     * @return the Element {@link DefRef}
     */
    @PublishedMethod
    TypedDefRef<?, ?, ?> getDefRef();

}
