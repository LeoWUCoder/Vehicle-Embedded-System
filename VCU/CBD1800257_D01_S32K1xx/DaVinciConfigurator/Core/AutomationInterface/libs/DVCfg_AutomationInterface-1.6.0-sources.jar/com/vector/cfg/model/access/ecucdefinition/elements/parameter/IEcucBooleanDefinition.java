package com.vector.cfg.model.access.ecucdefinition.elements.parameter;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBooleanParamDef;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucBooleanDefinition extends IEcucParameterDefinition {

    /**
     * returns the optional default value. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<Boolean> getDefault();

    @Override
    @PublishedMethod
    MIBooleanParamDef getDef();

}
