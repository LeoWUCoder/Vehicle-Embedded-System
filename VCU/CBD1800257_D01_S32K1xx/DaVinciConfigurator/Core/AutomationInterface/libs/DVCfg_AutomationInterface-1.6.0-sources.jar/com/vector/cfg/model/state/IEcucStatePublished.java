package com.vector.cfg.model.state;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * This interfaces specifies the common basis for the ECUC related CeStates.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucStatePublished extends ICeStatePublished {

    /**
     * @return <code>true</code> if the pre-configuration specifies a value for the CE.
     */
    @PublishedMethod
    boolean hasPreConfigurationValue();

    /**
     * @return <code>true</code> if the initial configuration specifies a value for the CE.
     */
    @PublishedMethod
    boolean hasInitialValue();

    /**
     * @return <code>true</code> if the recommended configuration specifies a value for the CE.
     */
    @PublishedMethod
    boolean hasRecommendedValue();

    /**
     * @return the value specified by the pre-configuration.
     */
    @PublishedMethod
    MIObject getPreConfigurationValue();

    /**
     * @return the value specified by the initial configuration.
     */
    @PublishedMethod
    MIObject getInitialValue();

    /**
     * @return the value specified by the recommended configuration.
     */
    @PublishedMethod
    MIObject getRecommendedValue();

    /**
     * This method allows checking if the supervised object (module configuration, container or parameter) will be changeable in the post-build phase. Be aware that the semantic of
     * this method adds model consistency checks like the pre-configuration check. If an object is pre-configured it will not be changeable in the post-build phase in either case.
     *
     * This method has been implemented to support CRC calculation of model content which is not post-build data. It will be used in the ECUM generator.
     *
     * @return
     */
    @PublishedMethod
    boolean isChangeAllowedInPostBuildPhase();

    /**
     * This method allows checking if the supervised object (module configuration, container or parameter) will be deletable in the post-build phase. Be aware that the semantic of
     * this method adds model consistency checks like the pre-configuration check. If an object is pre-configured it will not be deletable in the post-build phase in either case.
     *
     * This method has been implemented to support CRC calculation of model content which is not post-build data. It will be used in the ECUM generator.
     *
     * @return
     */
    @PublishedMethod
    boolean isDeletionAllowedInPostBuildPhase();

    /**
     *
     * @return <code>true</code> if the parameters definition specifies PUBLISHED-INFORMATION (for all configuration variants).
     */
    @PublishedMethod
    boolean hasPublishedInformation();

    /**
     *
     * @return <code>true</code> if {@link #hasPublishedInformation()} returns true and the parameter value is the default value as specified by the definition.
     */
    @PublishedMethod
    boolean isPublishedInformation();

}