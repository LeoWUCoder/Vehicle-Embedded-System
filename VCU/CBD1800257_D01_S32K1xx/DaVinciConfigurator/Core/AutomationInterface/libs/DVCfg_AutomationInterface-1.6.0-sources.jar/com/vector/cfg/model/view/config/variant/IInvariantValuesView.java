package com.vector.cfg.model.view.config.variant;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedDeprecated;
import com.vector.cfg.model.view.IModelViewManager;

/**
 * <h4>The InvariantValues model view</h4> The {@link IInvariantValuesView} is the base class for all {@link IInvariantValuesView}s in the system. The normally you will use the
 * {@link IPostBuildInvariantValuesView}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IModelViewManager
 * @see IInvariantView
 * @see IPostBuildInvariantEcucDefView
 * @see IPostBuildInvariantValuesView
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedDeprecated("Please use the type IPostBuildInvariantValuesView instead.")
@Immutable
public interface IInvariantValuesView extends IInvariantView {

}
