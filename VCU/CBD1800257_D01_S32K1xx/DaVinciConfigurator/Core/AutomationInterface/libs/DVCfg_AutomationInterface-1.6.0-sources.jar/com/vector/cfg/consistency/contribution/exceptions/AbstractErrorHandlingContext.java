package com.vector.cfg.consistency.contribution.exceptions;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.concurrent.Callable;
import java.util.function.Consumer;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.util.exceptions.InterruptedRuntimeException;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The ErrorHandlingContext class abstract the execution of which which can cause {@link GeneratorPackageException}s or {@link ModelException}s and the
 * corresponding catch blocks.
 *
 * <p>
 * The {@link ErrorHandlingContext} will normally report the {@link IGeneratorResult}s to the {@link IGeneratorResultSink}. If you want a exception thrown after
 * the process you can call {@link #testForErrorAndThrowException()}.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see {@link GeneratorPackageException}
 * @see ModelException
 * @see IGeneratorResultSink
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractErrorHandlingContext implements IErrorHandlingContext {

    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractErrorHandlingContext.class);

    /*
     * Private members
     */
    private boolean errorOccured;

    private ICustomExceptionHandler customHandler = null;

    private final IValidationResultSink resultSink;

    /**
     * Instantiates a new error handling context.
     *
     * @param generatorPackageRef the generator package ref
     * @param resultSink the result sink
     */
    @PublishedMethod
    protected AbstractErrorHandlingContext(IValidationResultSink resultSink) {

        this.resultSink = checkNotNull(resultSink);

    }

    /**
     * Execute a {@link Runnable} object and catches all {@link GeneratorPackageException}s and some {@link ModelException}s when the executed code in the
     * runnable will throw such a exception.
     *
     * <p>
     * All caught exceptions are reported to the {@link IGeneratorResultSink}.
     * </p>
     *
     * <p>
     * If you want a {@link GeneratorPackageWrapperException} you can call {@link #testForErrorAndThrowException()} after all execute calls.
     * </p>
     *
     * @param runnable the runnable to executed to inner code.
     *
     * @exception ModelException
     * <ul>
     * <li>if the {@link ModelException} can not be transformed into a {@link IGeneratorResult}. See {@link ModelExceptionProcessor} for more detail.</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the callable is null</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    public void execute(Runnable runnable) {
        if (runnable == null) {
            throw new IllegalArgumentException("runnable is null");
        }
        executeInternal(runnable, null);
    }

    /**
     * Execute a {@link Callable} object and catches all {@link GeneratorPackageException}s and some {@link ModelException}s when the executed code in the
     * callable will throw such a exception.
     * <p>
     * All caught exceptions are reported to the {@link IGeneratorResultSink}.
     * </p>
     *
     * <p>
     * If you want a {@link GeneratorPackageWrapperException} you can call {@link #testForErrorAndThrowException()} after all execute calls.
     * </p>
     *
     * @param <T> the generic return type of the callable.
     * @param callable The callable to executed to inner code.
     * @return the returned object of the callable, or null if an exception occurred.
     *
     * @exception RuntimeException
     * <ul>
     * <li>if the callable has thrown a checked {@link Exception}.</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the callable is null</li>
     * </ul>
     *
     * @exception ModelException
     * <ul>
     * <li>if the {@link ModelException} can not be transformed into a {@link IGeneratorResult}. See {@link ModelExceptionProcessor} for more detail.</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public <T> T execute(Callable<T> callable) {
        if (callable == null) {
            throw new IllegalArgumentException("callable is null");
        }
        return (T) executeInternal(null, callable);
    }

    /**
     * Execute internal the runnable and/or Callable.
     *
     * @param runnable the runnable
     * @param callable the callable
     * @return the object
     */
    private Object executeInternal(Runnable runnable, Callable<?> callable) {

        try {

            if (runnable != null) {
                runnable.run();
            }

            if (callable != null) {
                return callable.call();
            }

        } catch (final Exception ex) {
            processExceptionInternal(ex);
        }

        return null;
    }

    private void processExceptionInternal(Exception ex) {
        if (logger.isDebugEnabled()) {
            logger.debug("Exception caught", ex);
        }

        InterruptedRuntimeException.throwExceptionIfRootCauseWasInterruptedException(ex);

        errorOccured = true;

        /*
         * Execute customHandle before converting the Exception into a IValidationResult, because the CustomHandler can rethrow the Exception.
         */
        if (getCustomHandler() != null) {
            if (ex instanceof ModelException) {
                getCustomHandler().onModelException(getResultSink(), (ModelException) ex);
            }
            getCustomHandler().onException(getResultSink(), ex);
        }

        if (!tryToHandleOccuredException(ex)) {

            if (getCustomHandler() != null) {
                /*
                 * Execute the unhandled exception handler before ignoring the exception
                 */
                getCustomHandler().onUnhandledException(getResultSink(), ex);

                if (getCustomHandler().suppressReThrowOfUnhandledExceptions()) {

                    if (logger.isDebugEnabled()) {
                        logger.debug("The caught ModelException should be rethrown, but is ignored by the CustomException handler.");
                    }

                    // IGNORE Exception
                    return;
                }
            }

            if (ex instanceof RuntimeException) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Rethrowing the caught RuntimeException");
                }
                throw (RuntimeException) ex;
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug("Rethrowing the caught Exception as a wrapped runtime exception.");
                }
                throw new RuntimeException("Checked exception caught from callable.", ex);
            }

        } else {
            /*
             * The exception was handled by the subclass
             */
            if (logger.isDebugEnabled()) {
                logger.debug("The caught Exception was handled by the subclass.");
            }
        }

    }

    /**
     * Try to handle occurred exception.
     *
     * <p>
     * The method shall return <code>true</code>, if the subclass has handled the exception!
     * </p>
     * .
     *
     * @param ex the ex
     * @return true, if the exception was handled.
     */
    @PublishedMethod
    protected abstract boolean tryToHandleOccuredException(Exception ex);

    /**
     * Test if previous {@link #execute(Callable)} or {@link #execute(Runnable)} calls have thrown an exception. If there was an exception the method will throw
     * a new {@link GeneratorPackageWrapperException} with all thrown inner exceptions.
     *
     * <p>
     * A call to this method is OPTIONAL. When no call is performed all caught exception are reported to the {@link IGeneratorResultSink}
     * </p>
     *
     * @exception GeneratorPackageWrapperException
     * <ul>
     * <li>if the were thrown exception during the execute calls.</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    public final void testForErrorAndThrowException() {
        if (errorOccured) {
            processTestForErrorAndThrowExInternal();
        }
    }

    @PublishedMethod
    protected abstract void processTestForErrorAndThrowExInternal();

    /**
     * Adds the custom exception handler, which is called when any runnable/callable raises an Exception.
     *
     * <p>
     * <b>Attention: You have to add your {@link ICustomExceptionHandler} before you call any execute method.</b>
     * </p>
     *
     * @param custom Your custom exception handler
     * @return This error handling context (fluent interface)
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the custom is null</li>
     * </ul>
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if there is already a customException handler</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    public final IErrorHandlingContext addCustomExceptionHandler(ICustomExceptionHandler custom) {
        if (custom == null) {
            throw new IllegalArgumentException("custom is null");
        }
        if (this.getCustomHandler() != null) {
            throw new IllegalStateException("There is already a custom exception handler. You can't replace the existing handler!");
        }

        this.customHandler = custom;

        return this;
    }

    /**
     * Gets the result sink.
     *
     * @return the result sink
     */
    @PublishedMethod
    protected IValidationResultSink getResultSink() {
        return resultSink;
    }

    /**
     * Gets the custom handler.
     *
     * @return the custom handler
     */
    @PublishedMethod
    protected final ICustomExceptionHandler getCustomHandler() {
        return customHandler;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <T> Consumer<T> checking(Consumer<T> consumer) {
        if (consumer == null) {
            throw new IllegalArgumentException("consumer is null");
        }
        return (t) -> {
            try {
                consumer.accept(t);
            } catch (final Exception ex) {
                processExceptionInternal(ex);
            }
        };
    }

}
