package com.vector.cfg.consistency.contribution.helper.validationresults;

import java.util.Collection;

import com.google.common.collect.Lists;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepInterfacesSecretFromPublishedApi;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.internal.props.GenerationHint;
import com.vector.cfg.consistency.props.IGenerationHint;
import com.vector.cfg.consistency.props.IPropertyAcknowledgable;
import com.vector.cfg.consistency.props.IPropertyGenerationHint;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.<BR>
 * <BR>
 * An {@link IValidationResultMarkerType} for validation results reporting license violations. <BR>
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@KeepInterfacesSecretFromPublishedApi({
        IPropertyGenerationHint.class,
        IPropertyAcknowledgable.class
})
public enum ELicenseViolationMarker implements IValidationResultMarkerType, IPropertyGenerationHint, IPropertyAcknowledgable {

    SIP_LICENSE("The SIP license is violated.");

    /*
    * Internal Section
    */

    private String description;

    private static final String LICENSE_VIOLATION_STRING = "The generated code contains features that are not licensed and thus serial production is not allowed. The code may include errors.";

    ELicenseViolationMarker(String description) {
        this.description = description;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getDescription() {
        return this.description;
    }

    @KeepSecretFromPublishedApi
    @Override
    public boolean isAcknowledgable() {
        return false;
    }

    @KeepSecretFromPublishedApi
    @Override
    public Collection<IGenerationHint> getGenerationHint() {
        final IMixedTextBuilder builder = MixedText.newBuilder();
        builder.append(LICENSE_VIOLATION_STRING);
        return Lists.newArrayList(new GenerationHint(builder.flushResult()));
    }

}