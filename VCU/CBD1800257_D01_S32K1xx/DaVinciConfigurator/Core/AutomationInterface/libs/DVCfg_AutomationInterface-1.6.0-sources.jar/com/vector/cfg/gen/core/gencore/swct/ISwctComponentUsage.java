package com.vector.cfg.gen.core.gencore.swct;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * {@link ISwctComponentUsage} represents a software component for the Swct generation process.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@PublishedFilter(MsrPlatform.class)
@NotThreadSafe
public interface ISwctComponentUsage {
    /**
     * Returns the name of the swct component.
     *
     * @return the name
     */
    @PublishedMethod
    String getName();

    /**
     * Gets the {@link AsrPath} of the underlying software component (MISwComponentType).
     *
     * @return the AUTOSAR path of the software component.
     */
    @PublishedMethod
    AsrPath getAsrPath();

    /**
     * Returns the a descriptive name of the Swct software component. This will contain the componentType name and optional the prototype names, if the names differ from the
     * component name.
     *
     * @return the descriptive name
     */
    @PublishedMethod
    String getDescriptiveName();

    /**
     * This method selects this{@link ISwctComponentUsage} to be executed. <br/>
     * Already selected generators are not removed by this method. <br/>
     * This is analogue to IGenerationSwctSettingsApi.selectComponents(...)
     */
    @PublishedMethod
    void select();

    /**
     * This method deselects this {@link ISwctComponentUsage}. <br/>
     * Already deselected generators will not issue an error. <br/>
     * This is analogue to IGenerationSwctSettingsApi.deselectComponents(...)
     */
    @PublishedMethod
    void deselect();

    /**
     * Returns <code>true</code>, if this component is selected.
     *
     * @return true, if is selected
     */
    @PublishedMethod
    boolean isSelected();
}
