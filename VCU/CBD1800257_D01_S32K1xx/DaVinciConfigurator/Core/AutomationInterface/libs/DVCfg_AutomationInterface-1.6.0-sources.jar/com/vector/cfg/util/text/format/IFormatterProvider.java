package com.vector.cfg.util.text.format;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IFormatterProvider {

    /**
     * Gets the formatter for the class object.
     *
     * <p>
     * If there is no formatter, <code>null</code> is returned
     * </p>
     *
     * @param <T> the generic type
     * @param clazz the clazz
     * @return the formatter
     */
    @PublishedMethod
    <T> IFormatter<T> getFormatter(Class<T> clazz);
}
