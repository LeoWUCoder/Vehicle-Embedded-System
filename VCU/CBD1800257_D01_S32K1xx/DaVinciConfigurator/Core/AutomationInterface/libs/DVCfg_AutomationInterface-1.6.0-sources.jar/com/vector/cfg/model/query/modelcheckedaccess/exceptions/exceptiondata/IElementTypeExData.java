package com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.elements.EElementType;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The base interface of all ModelCheckedAccess exception data classes which can be thrown by all types of elements
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IElementTypeExData extends IExData {

    /**
     * Gets the type (Container, Param, Ref) of the request.
     *
     * @return The type of the request.
     */
    @PublishedMethod
    EElementType getElementType();
}
