package com.vector.cfg.model.query.modeltraverser;

import java.util.Collection;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.exceptions.ModelDefinitionInvalidException;
import com.vector.cfg.model.exceptions.ModelDefinitionNotFoundException;
import com.vector.cfg.model.query.internal.modeltraverser.ModelTraverserInitializationException;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IInvalidTraverserView;
import com.vector.cfg.model.query.modeltraverser.variant.IVariantModelTraverser;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

//@NEWLINE_CONVERSION:OFF
/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Common">
 *
 * <h5>Construction via builder API</h5> <!--LaTeX:\label{sec:ModelTraverserBuilderAPI}-->
 *
 * For advanced {@link IModelTraverser} features you have to construct an {@link IModelTraverser} using an {@link IModelTraverserBuilder}. You can obtain an instance of the
 * builder from the {@link ModelTraverserFactory}. So the entry point to construct an instance is
 * <code>ModelTraverserFactory.newBuilder(ETraverserVersion, IProjectContext, ILogger, IModelTraverserPath)</code>.
 *
 * The path in the <code>newBuilder()</code> method is the normal {@link IModelTraverser} path.
 *
 * The figure <!--LaTeX:\vref{fig:ModelTraverserBuilder}--> describes the construction of an {@link IModelTraverser} with the builder API of the {@link IModelTraverserBuilder}.
 * The code sample below describes a simple construction of the {@link IModelTraverser} with the builder pattern.
 *
 *
 * <p>
 * <img src="{@docRoot} /../_doc/UML/IModelTraverserBuilder/ModelTraverserBuilder.png" alt="Structure of IModelTraverserBuilder to create an IModelTraverser" id=
 * "fig:ModelTraverserBuilder" data-latex-style=" scale=0.7" />
 * </p>
 *
 * <pre>
 * <code class="Java" id="Creation of a ModelTraverser with advanced features by builder API">
 *  final IModelTraverserPath path = ...;
 *
 *  IModelTraverser modelTraverser =
 *      ModelTraverserFactory.newBuilder(
 *          ETraverserVersion.VERSION_2,
 *          getProjectContext(),
 *          logger,
 *          path
 *          )
 *          // Advanced features here
 *          .enableInvalidViewsProvideInvalidViewReasons()
 *
 *          // Finish construction
 *          .build();
 *
 *  // Use the modelTraverser as any other ModelTraverser
 * </code>
 * </pre>
 *
 *
 * <pre>
 * <!--PlantUML: ModelTraverserBuilder
 *  class {@link IModelTraverserBuilder}{
 *   build():IModelTraverser
 *  }
 *  class {@link ModelTraverserFactory}{
 *      newBuilder():IModelTraverserBuilder
 *  }
 *  {@link IModelTraverser} <.. "<creates>" {@link IModelTraverserBuilder}
 *  {@link IModelTraverserBuilder} <.. "<creates>" {@link ModelTraverserFactory}
 *
 *  note right of {@link IModelTraverserBuilder}:Use builder API to set \nthe properties of the traverser
 * -->
 * </pre>
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IModelTraverserBuilder {

    /**
     * Enables that an {@link IInvalidTraverserView} will return {@link IInvalidViewReasons}, instead of throwing an exception.
     *
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="EnableInvalidViewsProvideInvalidViewReasons">
     *
     * You can enable the {@link IInvalidViewReasons} feature by calling {@link #enableInvalidViewReasonsSupport()} on the {@link IModelTraverserBuilder} during construction.
     *
     * <b>Note:</b> The {@link IInvalidViewReasons} feature is optional, so a call to the method is <em>not</em> required.
     *
     * <p>
     * This feature will decrease the traversal performance, so do not enable it, unless you are using the {@link IInvalidViewReasons} in your client code.
     * </p>
     *
     * <pre>
     * <code class="Java" id="Enable IInvalidViewReasons feature">
     *  IModelTraverserBuilder builder = ModelTraverserFactory.newBuilder(...);
     *
     *  // Enable reasons support
     *  builder.enableInvalidViewReasonsSupport();
     *
     *  IModelTraverser traverser = builder.build();
     * </code>
     * </pre>
     *
     * </div>
     *
     * @return This builder
     */
    @PublishedMethod
    IModelTraverserBuilder enableInvalidViewReasonsSupport();

    /**
     * Adds a {@link Collection} of predecessors for the {@link IModelTraverser}.
     *
     * @param predecessors the predecessors
     * @return This builder
     */
    @PublishedMethod
    IModelTraverserBuilder addPredecessors(Collection<IModelTraverser> predecessors);

    /**
     * Adds a {@link Collection} of predecessors for the {@link IModelTraverser}.
     *
     * @param predecessors the predecessors
     * @return This builder
     */
    @PublishedMethod
    IModelTraverserBuilder addPredecessors(IModelTraverser... predecessors);

    /**
     * Builds the the {@link IModelTraverser} with the specified {@link IModelTraverserSettings}.
     *
     * @return the created {@link IVariantModelTraverser}.
     *
     * @exception ModelTraverserInitializationException
     * <ul>
     * <li>if the passed path is not traversable by the loaded definition</li>
     * </ul>
     * @exception ModelDefinitionInvalidException
     * <ul>
     * <li>if the DefRef verification has failed, and reported an invalid definition</li>
     * </ul>
     * @exception ModelDefinitionNotFoundException
     * <ul>
     * <li>if the DefRef verification has failed, and reported an not existing definition</li>
     * </ul>
     */
    @PublishedMethod
    IModelTraverser build();
}
