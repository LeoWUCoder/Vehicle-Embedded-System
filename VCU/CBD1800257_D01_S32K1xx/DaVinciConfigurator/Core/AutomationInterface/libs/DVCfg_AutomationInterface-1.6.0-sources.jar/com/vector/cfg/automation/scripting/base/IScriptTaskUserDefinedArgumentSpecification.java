package com.vector.cfg.automation.scripting.base;

import java.util.Optional;
import java.util.function.Consumer;

import javax.annotation.Nullable;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.services.IAiScriptTask;
import com.vector.cfg.util.text.log.IUserMessage;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * {@link IScriptTaskUserDefinedArgumentSpecification} defines an script user defined argument created during {@link IScriptTask} by an IScriptTaskBuilder. This is the
 * specification of a possible argument, the argument itself could not be retrieved by this specification.
 *
 * <p>
 * The main use for this, is for code querying information about tasks, to know if the task has possible arguments.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @param <T> the value type of the argument.
 * @see IScriptCreationApi
 * @see IScriptTask
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptTaskUserDefinedArgumentSpecification<T> {

    /**
     * Gets the argument name.
     *
     * @return the argument name
     */
    @PublishedMethod
    String getArgumentName();

    /**
     * Gets the qualified argument name, prefixed with - or --, if the {@link #getArgumentName()} is more then one character.
     *
     * @return the qualified argument name
     */
    @PublishedMethod
    String getQualifiedArgumentName();

    /**
     * Gets the value type of the argument. Valid value types are:
     * <ul>
     * <li>String</li>
     * <li>Void</li>
     * <li>File</li>
     * <li>Path</li>
     * <li>Integer</li>
     * <li>Long</li>
     * <li>Double</li>
     * <li>Boolean</li>
     * </ul>
     *
     * @return the value type
     */
    @PublishedMethod
    Class<T> getValueType();

    /**
     * Gets the help text of the argument.
     *
     * @return the help
     */
    @PublishedMethod
    String getHelp();

    /**
     * Returns the default value, or <code>null</code>, if this is a required argument. Please also check for {@link #hasDefaultValue()}.
     *
     * @return the default value
     */
    @PublishedMethod
    @Nullable
    T getDefaultValue();

    /**
     * Returns <code>true</code>, if this argument is optional, otherwise the argument is required.
     *
     * @return true, if successful
     */
    @PublishedMethod
    boolean hasDefaultValue();

    /**
     * Returns the {@link Consumer} which validates the input, is present. This was set during construction of the argument.
     *
     * The consumer has to throw an exception to indicate a wrong value. The message of the exception is displayed to the user.
     *
     * @return the value validator
     */
    @PublishedMethod
    Optional<Consumer<T>> getValueValidator();

    public interface IScriptTaskUserDefinedArgumentSpecifications {

        /**
         * Returns the list of possible of user defined arguments for this {@link IAiScriptTask}.
         *
         * @return the user defined arguments
         */
        ImmutableList<IScriptTaskUserDefinedArgumentSpecification<?>> getUserDefinedArguments();

        /**
         * Validates the passed arguments and returns {@link Optional#empty()}, if the arguments are valid. Otherwise the return value contains the error message.
         *
         * @param argument the argument
         * @return the optional
         */
        Optional<String> validateArguments(String arguments);

    }

    /**
     * The {@link ScriptUserDefinedArgumentsException} is thrown when a {@link IScriptTaskUserDefinedArgumentSpecification} is invalid, or has an invalid value.
     *
     * @see IScriptTaskUserDefinedArgumentSpecification
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    //@CHECKSTYLE:OFF
    public class ScriptUserDefinedArgumentsException extends RuntimeException implements IUserMessage {
        //@CHECKSTYLE:ON
        private static final long serialVersionUID = 1L;

        @PublishedMethod
        public ScriptUserDefinedArgumentsException(String message, Throwable cause) {
            super(message, cause);
        }

        @PublishedMethod
        public ScriptUserDefinedArgumentsException(String message) {
            this(message, null);
        }

        /**
         * {@inheritDoc}
         */
        @Override
        @PublishedMethod
        public IMixedText getUserMessage() {
            return MixedText.fromConstantString(getMessage());
        }

    }
}
