package com.vector.cfg.util.activity.execresult;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.activity.model.client.IActivity;
import com.vector.cfg.util.activity.model.client.IActivityResult;
import com.vector.cfg.util.activity.model.client.IActivityState;
import com.vector.cfg.util.text.log.IUserMessage;
import com.vector.cfg.util.text.mixedtext.IMixedText;

/**
 * The class {@link IExecutionResult} represents the outcome of an operation.
 *
 * <p>
 * Please use the class {@link ExecutionResultBuilder} to construct object which implements the {@link IExecutionResult} interface.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IActivity
 * @see IActivityResult
 * @see IActivityState
 * @noimplement This interface is not intended to be implemented by clients.
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF, DomainType.AUTOMATION_IF_INTERNAL_ADDONS })
public interface IExecutionResult extends IUserMessage, IDebugable {

    /**
     * Returns <code>true</code>, if the {@link #getEffectiveExecutionResult()} is either {@link EExecutionResult#SUCCESSFUL} or {@link EExecutionResult#WARNING}.
     *
     * <p>
     * Returns <code>false</code>, if any error has occurred.
     * </p>
     *
     * @return <code>true</code>, if the execution was successful.
     */
    @PublishedMethod
    boolean isOk();

    /**
     * Returns the message without any activity content passed by the execution of the activity, or {@link Optional#absent()} if no message was passed.
     *
     * <p>
     * Please use {@link #getUserMessage()} to display a message to the user!
     * </p>
     *
     * @return the message
     */
    @PublishedMethod
    Optional<IMixedText> getMessage();

    /**
     * Returns a String which contain a message for the user.<br/>
     * This message shall not contain internal information or complex problem descriptions.<br/>
     * It shall be understandable for the customer.<br/>
     *
     * Returns the following things in the order of occurrence, if the thing existing the next will not be used:
     * <ul>
     * <li>The Message of the Result</li>
     * <li>The exception message, if existing</li>
     * </ul>
     *
     * @return User Message
     */
    @Override
    @PublishedMethod
    IMixedText getUserMessage();

    /**
     * Returns a String which contain a message for the user.<br/>
     * This message shall not contain internal information or complex problem descriptions.<br/>
     * It shall be understandable for the customer.<br/>
     *
     * Returns the following things in the order of occurrence, if the thing existing the next will not be used:
     * <ul>
     * <li>The Message of the Result</li>
     * <li>The exception message, if existing</li>
     * </ul>
     *
     *
     * And the messages of all subResults, recursively.
     *
     * @return User Message
     */
    @PublishedMethod
    IMixedText getUserMessageAndSubResults();

    /**
     * {@inheritDoc}
     *
     * Returns
     * <ul>
     * <li>The Message of the Result</li>
     * <li>The exception message, if existing</li>
     * <li>The messages of all subResults , see {@link #getSubResults()}.</li>
     * </ul>
     *
     */
    @Override
    String toString();

    /**
     * {@inheritDoc}
     *
     * Returns
     * <ul>
     * <li>The Message of the Result</li>
     * <li>The exception message + stacktraces, if existing</li>
     * <li>The messages and traces of all subResults , see {@link #getSubResults()}.</li>
     * </ul>
     *
     */
    @Override
    String toDebugString();

    /**
     * Gets the execution result of the operation. To evaluate, if any SubTaks ( {@link #getSubResults()}) had a problem, please use {@link #getEffectiveExecutionResult()}.
     *
     * @return the execution result
     */
    @PublishedMethod
    EExecutionResult getExecutionResult();

    /**
     * Gets the execution result with the highest severity of this and all SubResults.
     *
     * @return the execution result, including the {@link #getSubResults() SubResults}
     */
    @PublishedMethod
    EExecutionResult getEffectiveExecutionResult();

    /**
     * Gets the exception, if available.
     *
     * @return the exception
     */
    @PublishedMethod
    Optional<Throwable> getException();

    /**
     * Gets the sub results.
     *
     * @return the sub results
     */
    @PublishedMethod
    <T extends IExecutionResult> List<T> getSubResults();

    /**
     * Throws an {@link RuntimeException}, if the {@link #isOk()} method returns false, or the existing Exception, if an exception has occurred.
     */
    @PublishedMethod
    void propagateAsExceptionIfNotOk();

}
