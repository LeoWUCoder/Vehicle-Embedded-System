package com.vector.cfg.model.view.config.variant;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;

/**
 * <div class="extdoc" id="IInvariantView">
 * <h3>The Invariant model views</h3>
 *
 * <!--Index:Invariant model views--> There are use cases which require to see the invariant model content only. One example are generators for modules which don't support
 * variance at all.
 *
 * <p>
 * There are two different invariant views currently defined:
 *
 * <ul>
 * <li><b>Value based invariance</b> (values <i>are equal</i> in all variants):<br>
 * The {@link IPostBuildInvariantValuesView} contains objects were all variant siblings have the same value and exist in all variants. One of the siblings is contained</li>
 * <li><b>Definition based invariance</b> (values which <i>shall be equal</i> in all variants):<br>
 * The {@link IPostBuildInvariantEcucDefView} contains objects which are not allowed to be variant according to the BSWMD rules. One of the siblings is contained</li>
 * </ul>
 * </p>
 *
 * All Invariant views derive from the same interface {@link IInvariantView}, so if you want to use an invariant view and not specifying the exact view, you could use the
 * {@link IInvariantView} interface. The figure <!--LaTeX:\vref{fig:InvaraintViews}--> describes the hierarchy.
 *
 * <img src="{@docRoot} /../_doc/UML/IInvariantView/IInvariantViewHierarchy.png" alt="Invariant views hierarchy" id="fig:InvaraintViews" data-latex-style="scale=0.65" />
 *
 * <pre>
 * <!--PlantUML: IInvariantViewHierarchy
 * {@link IModelView} <|..{@link IInvariantView}
 * {@link IInvariantView} <|.. {@link IInvariantValuesView}
 * {@link IInvariantValuesView} <|.. {@link IPostBuildInvariantValuesView}
 * {@link IInvariantView} <|.. {@link IInvariantEcucDefView}
 * {@link IInvariantEcucDefView} <|.. {@link IPostBuildInvariantEcucDefView}
 * -->
 * </pre>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelViewManager
 * @see IPostBuildInvariantValuesView
 * @see IPostBuildInvariantEcucDefView
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
public interface IInvariantView extends IModelView {

    /**
     * Returns the {@link IModelView}, which is used as reference for the returned Model objects.
     *
     * <p>
     * Only elements visible in this view, are considered for the invariant calculation.
     *
     * @return the reference variant
     */
    @KeepSecretFromPublishedApi
    IModelView getReferenceVariantView();
}
