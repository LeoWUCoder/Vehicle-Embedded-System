package com.vector.cfg.gen.core.gencore.executionmodel;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGenerationStepSequence {

    /**
     * Returns all available Pre and Post external generation steps regardless their selection status.<br/>
     *
     * @return
     */
    @PublishedMethod
    List<IGenerationStepUsage> getSteps();

    /**
     * Returns only the selected Pre and Post external generation steps.<br/>
     *
     * @return
     */
    @PublishedMethod
    List<IGenerationStepUsage> getSelectedSteps();

    /**
     * Returns all available Pre external generation steps regardless their selection status.<br/>
     *
     * @return
     */
    @PublishedMethod
    List<IGenerationStepUsage> getPreSteps();

    /**
     * Returns only the selected Pre external generation steps.<br/>
     *
     * @return
     */
    @PublishedMethod
    List<IGenerationStepUsage> getSelectedPreSteps();

    /**
     * Returns all available Post external generation steps regardless their selection status.<br/>
     *
     * @return
     */
    @PublishedMethod
    List<IGenerationStepUsage> getPostSteps();

    /**
     * Returns only the selected Post external generation steps.<br/>
     *
     * @return
     */
    @PublishedMethod
    List<IGenerationStepUsage> getSelectedPostSteps();

    /**
     * Sets the current Object to read only. If read only is enabled, changes on this object result in an {@link IllegalStateException}. <br/>
     * The read only state is applied recursively to all child settings.
     */
    @KeepSecretFromPublishedApi
    void setReadOnly();
}
