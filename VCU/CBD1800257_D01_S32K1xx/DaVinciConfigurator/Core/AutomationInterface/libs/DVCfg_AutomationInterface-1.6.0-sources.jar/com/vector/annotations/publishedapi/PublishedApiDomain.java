package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <div class="extdoc" id="PublishedApiDomain"> The {@link PublishedApi} is divided into so called domains. The domains correspond to different use cases of the API classes. You
 * can find the currently available domain in the class {@link DomainType}.
 * 
 *
 * <p>
 * The {@link PublishedApiDomain} annotation restricts the visibility of the {@link PublishedApi} to a certain API domain. See {@link DomainType} enum for a list of valid domain
 * types.
 * <p>
 * This could also be applied to fields or methods to further restrict their usage, but the class domain have to contain the field or method domains.
 * </p>
 *
 * Usage example:
 *
 * <pre>
 * <code class="Java" id="PublishedApi annotation example">
 * &#64;PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
 * &#64;PublishedApiDomain({ DomainType.AUTOMATION_IF, DomainType.GENERATORS})
 * public interface MyInterface {
 *
 *   &#64;PublishedMethod
 *   &#64;PublishedApiDomain({DomainType.GENERATORS})
 *   void methodForGenOnly(); //The method is only visible for generators
 *
 *   &#64;PublishedField
 *   &#64;PublishedApiDomain({DomainType.AUTOMATION_IF})
 *   String fieldForAiOnly();  //The field is only visible for generators
 * }
 * </code>
 * </pre>
 *
 * </div>
 *
 * <p>
 * The {@link PublishedApiDomain} annotation <b>shall not be used by clients</b> using the published API. This is only for the export and tracking of the published API. So a
 * client shall not annotate any class or interface with the {@link PublishedApi} annotation.
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see PublishedApi
 * @see DomainType
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.CONSTRUCTOR })
public @interface PublishedApiDomain {

    /**
     * Defines the {@link DomainType}s where the {@link PublishedApi} is visible.
     *
     * @return the domain type[]
     */
    @PublishedMethod
    DomainType[] value();
}
