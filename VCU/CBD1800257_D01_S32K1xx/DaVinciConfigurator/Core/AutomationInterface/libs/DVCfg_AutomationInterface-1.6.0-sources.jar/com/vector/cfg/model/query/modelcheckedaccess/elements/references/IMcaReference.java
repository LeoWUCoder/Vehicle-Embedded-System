package com.vector.cfg.model.query.modelcheckedaccess.elements.references;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaCommonElement;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaRequest;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaDefinitionUndefinedException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaNotExistsException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongQuantityException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongTypeException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess request interface for references
 *
 * <p>
 * You can process the request by adding a method call to your request.
 * </p>
 * <p>
 * Example:<br/>
 * <code>mca.reference(..) -->.getReference()<-- or -->.asRefToContainer()<--</code> ...
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelCheckedAccess
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IMcaReference<PARAM extends IMcaCommonElement<PARAM>> extends IMcaCommonElement<PARAM> {

    /**
     * Executes the model request and returns a single reference.
     *
     * <p>
     * The requested reference must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IMcaReference#getManyReferences() } instead.
     * </p>
     *
     * @return The reference for the request
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no reference was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one reference value was found</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     */
    @PublishedMethod
    MIParameterValue getReference();

    /**
     * Executes the model request and returns a single reference.
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    <T extends MIParameterValue> IMcaRequest<T> getReferenceAsRequest();

    /**
     * Executes the model request and returns a list of references.
     *
     * <p>
     * If no reference was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if non or one
     * parameter was found.
     *
     * @return An unmodifiable List of references for the request.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no reference</li>
     * </ul>
     */
    @PublishedMethod
    <T extends MIParameterValue> List<T> getManyReferences();

    /**
     * Executes the model request and returns a list of references.
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    <T extends MIParameterValue> IMcaRequest<List<T>> getManyReferencesAsRequest();

}
