package com.vector.cfg.model.query.modelcheckedaccess.exceptions.references;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Thrown when a reference model request has failed.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaReferenceException extends McaException {

    private static final long serialVersionUID = 4324704736672368974L;

    @PublishedMethod
    public McaReferenceException(List<? extends IExData> exDataList) {
        super(exDataList);
    }
}
