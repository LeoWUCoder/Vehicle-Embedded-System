package com.vector.cfg.model.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 * Thrown to indicate that a {@link MIHasDefinition} object like Container has no corresponding definition.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ModelCeHasNoParentException extends ModelInconsistencyException {

    private static final long serialVersionUID = 2482920532629700690L;

    private final MIObject mdfObject;

    /**
     * Constructor.
     *
     * @param mdfObject the MIObject which has no parent
     * @param ex
     */
    @PublishedMethod
    public ModelCeHasNoParentException(MIObject mdfObject) {
        super("The parent object is missing for " + checkMdfObjNonNull(mdfObject).toString() + ".");

        this.mdfObject = mdfObject;
    }

    @PublishedMethod
    public MIObject getCe() {
        return mdfObject;
    }
}
