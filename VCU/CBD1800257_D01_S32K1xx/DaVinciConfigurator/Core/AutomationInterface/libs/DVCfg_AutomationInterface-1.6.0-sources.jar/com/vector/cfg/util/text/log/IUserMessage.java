package com.vector.cfg.util.text.log;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * Classes can implement this interface to provide a message for the user in a user readable manner. E.g. {@link Exception}s could implement the interface to mark, that the
 * {@link Exception} is preventable to the user, with a correct user readable text, without a stacktrace content.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IUserMessage {

    /**
     * Returns a {@link IMixedText} which contains a message for the user.<br>
     * This message shall not contain internal information or complex problem descriptions.<br>
     * It shall be understandable for the customer.<br/>
     *
     * @return User Message
     */
    @PublishedMethod
    default IMixedText getUserMessage() {
        return MixedText.fromConstantString(toString());
    }
}
