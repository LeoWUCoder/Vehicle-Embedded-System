package com.vector.annotations.publishedapi;

import static java.lang.annotation.ElementType.*;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * An element annotated with {@link PublishedDeprecated} shall not be used anymore. You shall change to an alternative which is described in {@link #value()}.
 * 
 *
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(value = { CONSTRUCTOR, FIELD, LOCAL_VARIABLE, METHOD, PACKAGE, PARAMETER, TYPE })
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public @interface PublishedDeprecated {

    /**
     * The description why the element was {@link PublishedDeprecated}.
     * 
     * @return the description
     */
    @PublishedMethod
    String value();

}
