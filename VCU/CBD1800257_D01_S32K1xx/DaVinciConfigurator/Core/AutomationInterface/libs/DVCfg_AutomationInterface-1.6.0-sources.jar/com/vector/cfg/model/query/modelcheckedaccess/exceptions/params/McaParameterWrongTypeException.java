package com.vector.cfg.model.query.modelcheckedaccess.exceptions.params;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.params.IParamWrongTypeExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Thrown when a parameter has the wrong type for the model request.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaParameterWrongTypeException extends McaParameterException {

    private static final long serialVersionUID = -272329547960454443L;

    private final List<IParamWrongTypeExData> wrongTypeExDataList;

    /**
     * Constructor for McaParameterWrongTypeException.
     *
     * @param wrongTypeExDataList
     */
    @PublishedMethod
    public McaParameterWrongTypeException(List<IParamWrongTypeExData> wrongTypeExDataList) {
        super(wrongTypeExDataList);
        this.wrongTypeExDataList = wrongTypeExDataList;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<IParamWrongTypeExData> getExceptionDataList() {
        return wrongTypeExDataList;
    }

}
