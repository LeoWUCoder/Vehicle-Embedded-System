package com.vector.cfg.util.log;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.internal.LogWrapper;

@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// @CHECKSTYLE:OFF Naming is OK it is a Singleton
public enum Logger {
    INSTANCE;
    // @CHECKSTYLE:ON
    /**
     * <code>USER_LOGGER_CONSTANT</code> describes the path to all User-Loggers (namespace) in the Cfg.
     */
    static final String USER_LOGGER_CONSTANT = "com.vector.cfg.user";

    Logger() {

    }

    @PublishedMethod
    public ILogger createLogger(final Class<?> clazz) {
        checkNotNull(clazz, "Parameter clazz must not be null!");

        final ILogger ret = LogWrapper.create(clazz);
        return ret;
    }

    @PublishedMethod
    public ILogger createLogger(final String loggerName) {
        checkNotNull(loggerName, "Parameter loggerName must not be null!");
        final ILogger ret = LogWrapper.create(loggerName);
        return ret;
    }

    @KeepSecretFromPublishedApi
    public ILogger createEndUserLogger(final Class<?> clazz) {
        checkNotNull(clazz, "Parameter clazz must not be null!");
        final ILogger ret = LogWrapper.createUserLogger(createUserLoggerString(clazz.getName()));
        return ret;
    }

    @KeepSecretFromPublishedApi
    public ILogger createEndUserLogger(final String loggerName) {
        checkNotNull(loggerName, "Parameter loggerName must not be null!");
        final ILogger ret = LogWrapper.createUserLogger(createUserLoggerString(loggerName));
        return ret;
    }

    /**
     * Creates the user logger string.
     *
     * @param loggerName the logger name
     * @return the string
     */
    static String createUserLoggerString(final String loggerName) {
        checkNotNull(loggerName);
        checkArgument(!loggerName.isEmpty());
        /*
         * Normally the format should be something like com.vector.cfg.user.com.vector.cfg.model.access.DefRef
         */
        return USER_LOGGER_CONSTANT + "." + loggerName;
    }

}
