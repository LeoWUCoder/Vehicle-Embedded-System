package com.vector.cfg.model.query.definitionverify;

import static com.google.common.base.Preconditions.checkNotNull;

import java.lang.reflect.Field;

import org.osgi.framework.Version;
import org.osgi.framework.VersionRange;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiVersionCheck;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.cfg.core.ECoreFeatureVersion;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * AbstractPublishedApiVersionVerifier is an abstract implementation to verify an {@link PublishedApiVersionCheck} annotation against the current Range in the System.
 * <p>
 * A subclass can override the error reporting. The standard case is throwing an {@link IllegalArgumentException}.
 * </p>
 *
 * <p>
 * A subclass has to implement a public interface to execute the check
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see PublishedApiVersionCheck
 * @See PublishedApi
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedFilter(MsrPlatform.class)
public abstract class AbstractPublishedApiVersionVerifier {
    // private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractPublishedApiVersionVerifier.class);

    /**
     * Instantiates a new {@link AbstractPublishedApiVersionVerifier}.
     *
     */
    protected AbstractPublishedApiVersionVerifier() {

    }

    /**
     * Gets the domain type to verify. A Subclass can specify which domainType shall be checked by the verification call!
     *
     * @return the domain type to verify
     */

    protected abstract DomainType getDomainTypeToVerify();

    /**
     * Executes the class verification.
     *
     * @param clazz the clazz
     */
    protected final void verifyClassInternal(Class<?> clazz) {
        checkNotNull(clazz);

        final PublishedApiVersionCheck anno = clazz.getAnnotation(PublishedApiVersionCheck.class);
        if (anno != null) {
            if (anno.domainType() == getDomainTypeToVerify()) {
                if (getDomainTypeToVerify() == DomainType.GENERATORS) {
                    final ECoreFeatureVersion currentCoreVersion = ECoreFeatureVersion.getCurrentVersion();

                    if (anno.fieldName() != null && !anno.fieldName().isEmpty()) {
                        checkVersionViaField(clazz, anno, currentCoreVersion);
                    } else {
                        checkVersionNumber(clazz, anno, currentCoreVersion, anno.version());
                    }
                } else {
                    throw new IllegalArgumentException("The DomainType " + getDomainTypeToVerify() + " is not yet supported");
                }
            }
        }

    }

    /**
     * @param resultId
     * @param clazz
     * @param anno
     * @param versionRange
     * @param currentCoreVersion
     */
    private void checkVersionViaField(Class<?> clazz, PublishedApiVersionCheck anno, ECoreFeatureVersion currentCoreVersion) {
        final String fieldName = anno.fieldName();
        try {
            final Field field = clazz.getDeclaredField(fieldName);
            try {
                field.setAccessible(true);

                final String version = (String) field.get(null);

                checkVersionNumber(clazz, anno, currentCoreVersion, version);

            } finally {
                field.setAccessible(false);
            }
        } catch (final Exception ex) {
            String msg = ex.getMessage();
            if (msg == null) {
                msg = "";
            }
            throw reportFailedVersionCheck(clazz, "<???>", currentCoreVersion.toString(), ex.getClass().getSimpleName() + ": " + msg);

        }

    }

    /**
     * Report failed version check.
     *
     * <p>
     * A Suballss can override this method to change the error handling
     * </p>
     *
     * @param clazz the clazz
     * @param expectedVersion the expected version
     * @param actualVersionRange the actual version range
     * @param description the description
     * @return the runtime exception
     */
    protected RuntimeException reportFailedVersionCheck(Class<?> clazz, String expectedVersion, String actualVersionRange, String description) {
        throw new IllegalArgumentException("PublishedApi VersionCheck failed. Expected: " + expectedVersion + ", but found: " + actualVersionRange
                + ". The class " + clazz.getName() + " requires the specified version." + description);
    }

    /**
     * Check version number.
     *
     * @param clazz the clazz
     * @param anno the anno
     * @param versionRange the version range
     * @param versionString the version string
     * @param currentCoreVersion
     */
    private void checkVersionNumber(Class<?> clazz, final PublishedApiVersionCheck anno, ECoreFeatureVersion currentCoreVersion, String versionString) {
        Version version = null;
        String versionStr = null;
        final VersionRange versionRange = currentCoreVersion.getCompatibleCoreVersionRange();
        final String versionRangeStr = currentCoreVersion.toStringWithRange();

        try {
            version = Version.parseVersion(versionString);
            if (version != null) {
                versionStr = version.toString();
                final Optional<ECoreFeatureVersion> expectedVersion = ECoreFeatureVersion.versionOf(versionStr);
                if (expectedVersion.isPresent()) {
                    versionStr = expectedVersion.get().toString();
                }
            }

        } catch (final RuntimeException ex) {
            String msg = ex.getMessage();
            if (msg == null) {
                msg = "";
            }
            throw reportFailedVersionCheck(clazz, "<???>", versionRangeStr, ex.getClass().getSimpleName() + ": " + msg);
        }

        if (version == null) {
            throw reportFailedVersionCheck(clazz, "<null>", versionRangeStr, "");

        }

        if (!versionRange.includes(version)) {
            throw reportFailedVersionCheck(clazz, versionStr, versionRangeStr, "");
        }

    }

}
