package com.vector.cfg.model.annotation;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.model.annotation.user.IUserAnnotation;
import com.vector.cfg.model.annotation.user.IUserAnnotationList;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.ar4x.genericstructure.generaltemplateclasses.documentation.annotation.MIAnnotation;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.specialdata.MISdg;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.IViewedModelObject;
import com.vector.cfg.util.text.log.IUserMessage;

/**
 * {@link IAnnotation} represents one actual annotation in the model. Each {@link IAnnotation} is hold by an {@link IAnnotationAccessor} and has one associated
 * {@link IAnnotationType}.
 *
 * <p>
 * The {@link IAnnotation} is created with an creation {@link IModelView}. All method will retrieve and set data in the creationModelView. The creationModelView is copied from
 * the {@link IAnnotationAccessor}.
 * </p>
 *
 * <div class="extdoc" id="UML">
 *
 * <pre>
 * <!--UMLaut: Classes
 * {@link IAnnotation}{
 *   super{*}
 *   methods{*}
 *   properties{*}
 * }
 * {@link IAnnotationAccessor}{
 *   super{*}
 *   methods{*}
 *   properties{*}
 * }
 * {@link IAnnotationList}{
 *   super{*}
 *   methods{*}
 *   properties{*}
 * }
 * {@link IAnnotationOptional}{
 *  super{*}
 *  methods{*}
 *  properties{*}
 * }
 *
 * {@link IUserAnnotation}{
 *  super{*}
 *  methods{*}
 *  properties{*}
 * }
 * {@link IUserAnnotationList}{
 *  super{*}
 *  methods{*}
 *  properties{*}
 * }
 *
 * {@link IBasicAnnotation}{
 *  super{*}
 *  methods{*}
 *  properties{*}
 * }
 *
 * {@link ILabeledAnnotation}{
 *  super{*}
 *  methods{*}
 *  properties{*}
 * }
 *
 * -->
 * </pre>
 *
 * The image describes the class hierarchy of the {@link IAnnotation} class and associated classes: <br>
 * <img src="{@docRoot}/../_doc/UML/IAnnotation/Classes.png" alt="Class hierarchy"> </div>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IAnnotation extends IViewedModelObject, IUserMessage {

    /**
     * Same as calling {@link #getAnnotationAccessor()}.{@link IAnnotationList#getType() getType()}.{@link IAnnotationType#getAnnotationTypeName() getAnnotationTypeName()}.
     *
     * @return
     */
    String getAnnotationTypeName();

    @Nonnull
    <T extends IAnnotation> IAnnotationAccessor<T> getAnnotationAccessor();

    /**
     * The method {@link #delete()} deletes the specified object from the model. This method must be called inside a transaction because it changes the model content.
     *
     */
    void delete();

    /**
     * Returns <code>true</code> if this annotation can be changed.
     *
     * @return <code>true</code> if changeable.
     */
    boolean isChangeable();

    /**
     * Returns <code>true</code> if this annotation can be deleted.
     *
     * @return <code>true</code> if deletable.
     */
    boolean isDeletable();

    /**
     * Returns the underlying element which was annotated with this {@link IAnnotation}.
     *
     *
     * @return the annotation owner
     */
    @Nonnull
    MIObject getAnnotationOwner();

    /**
     *
     * {@inheritDoc}
     *
     * <p>
     * This is the underlying annotation element of the MDF model, either an {@link MIAnnotation} or an {@link MISdg}.
     * </p>
     */
    @Override
    MIObject getMdfObject();

}