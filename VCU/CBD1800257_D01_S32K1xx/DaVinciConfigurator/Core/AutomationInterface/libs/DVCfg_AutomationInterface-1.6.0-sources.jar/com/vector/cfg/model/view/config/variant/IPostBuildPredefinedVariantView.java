package com.vector.cfg.model.view.config.variant;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.variance.IPredefinedVariant;
import com.vector.cfg.model.view.config.IPostBuildConfiguration;

/**
 * This is the API of a model view which provides variant specific access to the PostBuild specifc model. This view makes all objects visible which are contained in one specific
 * PostBuild predefined variant.
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@Immutable
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IPostBuildPredefinedVariantView extends IPredefinedVariantView, IPostBuildView {

    /**
     * @return the covered PredefinedVariant
     * @deprecated Client code shall not use the {@link IPredefinedVariant}, please use this {@link IPostBuildPredefinedVariantView}.
     */
    @Override
    @KeepSecretFromPublishedApi
    @Deprecated
    IPredefinedVariant getPredefinedVariant();

    /**
     * Returns the {@link IPostBuildConfiguration}.
     *
     * @return the postbuild configuration
     * @deprecated Client code shall not use the {@link IPostBuildConfiguration}, please use this {@link IPostBuildPredefinedVariantView}.
     */
    @KeepSecretFromPublishedApi
    @Deprecated
    IPostBuildConfiguration getPostBuildConfiguration();

}
