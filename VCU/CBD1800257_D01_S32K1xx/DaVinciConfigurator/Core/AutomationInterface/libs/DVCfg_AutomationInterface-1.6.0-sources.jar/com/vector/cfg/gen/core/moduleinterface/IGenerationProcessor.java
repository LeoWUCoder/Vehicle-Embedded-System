package com.vector.cfg.gen.core.moduleinterface;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasGetGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasSetGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GenerationFailedException;
import com.vector.cfg.gen.core.moduleinterface.exceptions.ValidationFailedException;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IGenerationOutputWriter;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;

/**
 * <div class="extdoc" id="Common">
 * <h5>GenerationProcessor</h5> An {@link IGenerationProcessor} will do the actual generation work. It is called during the generation phases
 * <ul>
 * <li>Validation - Will call {@link #buildDataStructures(IGeneratorResultSink)}</li>
 * <li>Generation - Will call {@link #generate()}
 * </ul>
 * An IGenerationProcessor must be registered at your {@link IGeneratorPackage}.
 *
 * <p>
 * Normally you will subclass the class <code>AbstractGenerationProcessor</code> and implement the missing methods, like {@link #buildDataStructures(IGeneratorResultSink)}.
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @author virtu
 * @noimplement This interface is not intended to be implemented by clients. Please use abstract class AbstractGenerationProcessor
 * @see IGeneratorPackage
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenerationProcessor extends IGeneratorPackageReferable, IHasSetGeneratorResultSink, IHasGetGeneratorResultSink {

    /**
     * The method will build the internal DataStructure used by the Generation process {@link IGenerationProcessor#generate()}, and validates the data during the creation.
     * <p>
     * Calling point:<br/>
     * This method is called during the Validation Phase.
     * </p>
     *
     * @param resultSink The method will append it results to the resultSink. The caller must provide an appropriate resultSink.
     *
     * @throws ValidationFailedException
     * <ul>
     * <li>if the validation of the DataStructure has failed. This will cancel the Validation and Generation.</li>
     * </ul>
     */
    @PublishedMethod
    void buildDataStructures(IGeneratorResultSink resultSink);

    /**
     * <code>generate()</code> creates the output files for the generator.
     *
     * <p>
     * Calling point:<br/>
     * This method is called during the Generation Phase.
     * </p>
     *
     * @throws GenerationFailedException
     * <ul>
     * <li>if the generation has failed. This will cancel the Generation.</li>
     * </ul>
     */
    @PublishedMethod
    void generate(IGeneratorResultSink resultSink, IGenerationOutputWriter writer);

    /**
     * <code>cleanDataStructures()</code> cleans up all internal data used the Generator to cache the configuration.
     *
     * <p>
     * Calling point:<br/>
     * <li>During the Validation Phase: after {@link IGenerationProcessor#buildDataStructures(IGeneratorResultSink)} is called</li>
     * <li>During the Generation Phase: after {@link IGenerationProcessor#generate(IGeneratorResultSink, IGenerationOutputWriter)} is called</li>
     * </p>
     *
     */
    @PublishedMethod
    void cleanDataStructures();

    /**
     * Gets the current resultSink.
     *
     * <p>
     * Attention:<br/>
     * A {@link IGeneratorResultSink} is only available during {@link #buildDataStructures(IGeneratorResultSink)} or
     * {@link #generate(IGeneratorResultSink, IGenerationOutputWriter)} method call.
     * </p>
     *
     * @return The current active resultSink
     *
     * @throws IllegalStateException
     * <ul>
     * <li>if no resultSink is currently available.</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    IGeneratorResultSink getResultSink();

    /**
     * Set the current ResultSink.
     * <p>
     * Attention: Do not use this method. It is for internal purpose.
     * </p>
     *
     * @param resultSink Sets the current ResultSink
     */
    @Override
    @PublishedMethod
    void setResultSink(IGeneratorResultSink resultSink);

    /**
     * Sets the {@link IGenOptions} for this Generator run.
     *
     * <p>
     * Attention: This method can only be called, when the {@link IGeneratorPackage} is already initialized.
     * </p>
     *
     * <p>
     * This method should only be called by the Framework, not by clients
     * </p>
     *
     * @param options The options object.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the options object is null</li>
     * </ul>
     */
    @PublishedMethod
    void setGenOptions(IGenOptions options);

    /**
     * Gets the {@link IGenOptions} for this Generator run.
     *
     * @return The current GenOptions.
     */
    @PublishedMethod
    IGenOptions getGenOptions();

    /**
     * Gets the current list of modules to generate.
     *
     * <p>
     * Attention:<br/>
     * A moduleList is only available during a {@link #calculate(IGeneratorResultSink)}, {@link #buildDataStructures(IGeneratorResultSink)} or
     * {@link #generate(IGeneratorResultSink, IGenerationOutputWriter)} method call.
     * </p>
     *
     * @return the module config list
     *
     * @throws IllegalStateException
     * <ul>
     * <li>if no resultSink is currently available.</li>
     * </ul>
     */
    @PublishedMethod
    ImmutableList<MIModuleConfiguration> getModuleConfigList();
}
