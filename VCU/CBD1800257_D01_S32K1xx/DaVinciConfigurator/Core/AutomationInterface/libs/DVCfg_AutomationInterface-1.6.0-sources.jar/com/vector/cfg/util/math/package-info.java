/**
 * Basic mathematics types and operations for DaVinci Configurator and AUTOSAR.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.util.math;