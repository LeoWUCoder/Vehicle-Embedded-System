package com.vector.cfg.automation.scripting.base;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.util.scripting.dynamic.DynamicTarget;
import com.vector.cfg.util.scripting.dynamic.IDynamicObjectAware;

/**
 * {@link IScriptTaskTypeExtensions} defines the extension point via {@link IDynamicObjectAware} to add {@link IScriptTaskType}s to the class <code>IScriptTaskTypeApi</code>.
 * This will add the fields contributed by the {@link DynamicTarget} classes to the available {@link IScriptTaskType}s.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@DynamicTarget({
        "com.vector.cfg.workflow.groovy.IWorkflowAutomationScriptTaskTypes"
})
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptTaskTypeExtensions extends IDynamicObjectAware {

}
