package com.vector.cfg.gen.core.moduleinterface;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link EGenerationPhaseType} defines the phase of the generation process. (E.g. {@link #CALCULATION}, {@link #VALIDATION}, {@link #GENERATION}, ...)
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.GENERATOR_INTERNAL_ADDONS, DomainType.AUTOMATION_IF, DomainType.AUTOMATION_IF_INTERNAL_ADDONS })
public enum EGenerationPhaseType {

    /**
     * <code>CW_PREPARATION</code> describes the {@link IGeneratorService} command phase to execute the Execution of the Custom Workflow steps. See
     * {@link ICustomWorkflowService}.
     */
    CW_PREPARATION("Custom Workflow Execution"),
    /**
     * <code>CALCULATION</code> describes the {@link IGeneratorService} command phase Calculation of generators.
     */
    CALCULATION("Calculation") {
        @Override
        public boolean isCalculation() {
            return true;
        }
    },
    /**
     * <code>VALIDATION</code> describes the {@link IGeneratorService} command phase Validation of generators.
     */
    VALIDATION("Validation") {

        @Override
        public boolean isValidation() {
            return true;
        }
    },
    /**
     * <code>GENERATION</code> describes the {@link IGeneratorService} command phase Generation of generators.
     */
    GENERATION("Generation") {

        @Override
        public boolean isGeneration() {
            return true;
        }
    };

    private final String descriptiveName;

    EGenerationPhaseType(String descriptiveName) {
        this.descriptiveName = descriptiveName;

    }

    /**
     * Returns <code>true</code>, if the enum is {@link #CALCULATION}.
     *
     * @return true, if is calculation
     */
    @PublishedMethod
    public boolean isCalculation() {
        return false;
    }

    /**
     * Returns <code>true</code>, if the enum is {@link #VALIDATION}.
     *
     * @return true, if is validation
     */
    @PublishedMethod
    public boolean isValidation() {
        return false;
    }

    /**
     * Returns <code>true</code>, if the enum is {@link #GENERATION}.
     *
     * @return true, if is generation
     */
    @PublishedMethod
    public boolean isGeneration() {
        return false;
    }

    @PublishedMethod
    public String getDescriptiveName() {
        return descriptiveName;
    }
}
