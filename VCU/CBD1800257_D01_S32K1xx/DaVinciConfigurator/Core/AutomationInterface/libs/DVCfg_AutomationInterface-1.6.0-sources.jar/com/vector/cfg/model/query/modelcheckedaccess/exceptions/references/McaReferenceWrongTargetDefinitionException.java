package com.vector.cfg.model.query.modelcheckedaccess.exceptions.references;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.references.IRefWrongTargetDefExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Thrown when a reference pointing to a refTarget, but the reference is not defined to point to this target.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaReferenceWrongTargetDefinitionException extends McaReferenceException {

    private static final long serialVersionUID = 2487672636503247427L;

    private final List<IRefWrongTargetDefExData> wrongTypeExDataList;

    /**
     * Constructor for McaParameterWrongTypeException.
     *
     * @param wrongTypeExDataList
     */
    @PublishedMethod
    public McaReferenceWrongTargetDefinitionException(List<IRefWrongTargetDefExData> wrongTypeExDataList) {
        super(wrongTypeExDataList);
        this.wrongTypeExDataList = wrongTypeExDataList;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<IRefWrongTargetDefExData> getExceptionDataList() {
        return wrongTypeExDataList;
    }

}
