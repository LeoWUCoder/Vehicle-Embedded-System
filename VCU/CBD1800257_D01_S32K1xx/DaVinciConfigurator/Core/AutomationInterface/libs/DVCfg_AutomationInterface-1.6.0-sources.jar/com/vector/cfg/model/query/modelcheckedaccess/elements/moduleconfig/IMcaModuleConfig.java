package com.vector.cfg.model.query.modelcheckedaccess.elements.moduleconfig;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaCommonElement;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaRequest;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaDefinitionUndefinedException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaNotExistsException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongQuantityException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongTypeException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess request interface for parameters ({@link MIParameterValue})
 *
 * <p>
 * You can process the request by adding a method call to your request.
 * </p>
 * <p>
 * Example:<br/>
 * <code>mca.parameter(..) -->.getParam()<-- or -->.asString()<--</code>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelCheckedAccess
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IMcaModuleConfig extends IMcaCommonElement<IMcaModuleConfig> {

    /**
     * Executes the model request and returns a single module configuration.
     *
     * <p>
     * The requested configuration must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IMcaModuleConfig#getManyModuleConfigs() } instead.
     * </p>
     *
     * @return The parameter for the request
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no configuration was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one configuration was found</li>
     * </ul>
     *
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element has the wrong type</li>
     * </ul>
     */
    @PublishedMethod
    MIModuleConfiguration getModuleConfig();

    /**
     * Executes the model request and returns one module configuration. ({@link MIModuleConfiguration}).
     *
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<MIModuleConfiguration> getModuleConfigAsRequest();

    /**
     * Executes the model request and returns a list of parameters.
     *
     * <p>
     * If no parameter was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if non or one
     * parameter was found.
     *
     * @return A unmodifiable List of parameters for the request.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved elements has the wrong type</li>
     * </ul>
     */
    @PublishedMethod
    List<MIModuleConfiguration> getManyModuleConfigs();

    /**
     * Executes the model request and returns a list of module configurations. ({@link MIModuleConfiguration}).
     *
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<List<MIModuleConfiguration>> getManyModuleConfigsAsRequest();
}
