package com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.params;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterHasIllegalValueException;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess exception data for the {@link McaParameterHasIllegalValueException}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see McaParameterHasIllegalValueException
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IParamHasIllegalValueExData extends IParamExData {
    @PublishedMethod
    String getValue();
}
