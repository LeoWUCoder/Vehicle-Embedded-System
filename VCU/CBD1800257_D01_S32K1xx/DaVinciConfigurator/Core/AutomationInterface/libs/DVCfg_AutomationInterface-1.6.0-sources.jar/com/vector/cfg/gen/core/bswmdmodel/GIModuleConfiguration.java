package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelAttributeNotExistsException;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucModuleDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.state.IModuleConfigurationStatePublished;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;
import com.vector.cfg.util.version.IVersion;

/**
 * Base interface of bswmd model module configuration.
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see MIModuleConfiguration
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
// CHECKSTYLE:OFF Class Naming problem
public interface GIModuleConfiguration extends GIHasContainer {
    // CHECKSTYLE:ON
    /**
     * Returns the configuration variant information.
     *
     * @return
     */
    @PublishedMethod
    GIConfigVariantInfo getConfigVariantInfo();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucModuleDefinition getEcucDefinition();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucModuleConfiguration getEcuConfiguration();

    /**
     * Returns the AUTOSAR schema version the currently referenced module definition of this {@link GIModuleConfiguration}.
     *
     * <p>
     * If no module definition is referenced or if no version is specified there, this method throws a {@link BswmdModelAttributeNotExistsException}.
     * </p>
     *
     * @return The AUTOSAR schema version of the module definition xml file
     *
     * @exception BswmdModelAttributeNotExistsException
     * <ul>
     * <li>If no module definition is referenced or if no version is specified there.</li>
     * </ul>
     */
    @PublishedMethod
    IVersion getArDefinitionSchemaVersion();

    /**
     * Returns the AUTOSAR version of the referenced BSW-implementation.
     *
     * <p>
     * If no BSW-implementation is referenced or if no version is specified there, this method throws a <code>{@link BswmdModelAttributeNotExistsException}</code> exception.
     * </p>
     *
     * @return The AR version of the referenced BSW-implementation.
     *
     * @exception BswmdModelAttributeNotExistsException
     * <ul>
     * <li>If no BSW-implementation is referenced or if no version is specified there.</li>
     * </ul>
     */
    @PublishedMethod
    IVersion getBswImplementationArVersion();

    /**
     * Returns the SOFTWARE version of the referenced BSW-implementation.
     *
     * <p>
     * If no BSW-implementation is referenced or if no version is specified there, this method throws a <code>{@link BswmdModelAttributeNotExistsException}</code> exception.
     * </p>
     *
     * @return The SOFTWARE version of the referenced BSW-implementation.
     *
     * @exception BswmdModelAttributeNotExistsException
     * <ul>
     * <li>If no BSW-implementation is referenced or if no version is specified there.</li>
     * </ul>
     */
    @PublishedMethod
    IVersion getBswImplementationSwVersion();

    /**
     * Return following name: <Module short name>_<Vendor Id>_<Vendor specific Name>. See requirement BSW00347.<br/>
     * E.g. Eep_21_LDExt<br/>
     * If instances shall be accessed an index has to be appended manually. See requirement BSW00413.
     *
     * @return String
     */
    @PublishedMethod
    String getModuleNameWithAPIInfix();

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    MIModuleConfiguration getMdfObject();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IModuleConfigurationStatePublished getCeState();

}
