package com.vector.cfg.automation.scripting.base;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.automation.scripting.base.IAutomationContext.IApplicationAutomationContext;

/**
 * {@link IProjectScriptExecutionContext} is the subtype of an {@link IScriptExecutionContext}, which provides access to the current DaVinci Configurator instance.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IScriptExecutionContext
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IApplicationScriptExecutionContext extends IScriptExecutionContext, IApplicationAutomationContext {

}
