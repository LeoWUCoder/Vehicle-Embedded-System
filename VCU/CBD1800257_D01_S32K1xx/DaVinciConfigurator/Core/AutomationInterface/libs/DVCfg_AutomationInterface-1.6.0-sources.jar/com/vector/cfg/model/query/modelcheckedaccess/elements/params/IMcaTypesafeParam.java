package com.vector.cfg.model.query.modelcheckedaccess.elements.params;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaRequest;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaDefinitionUndefinedException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaNotExistsException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongQuantityException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongTypeException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterHasIllegalValueException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterHasNoValueException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.params.McaParameterWrongTypeException;
import com.vector.cfg.model.query.modelcheckedaccess.tuple.IModelTuple;
import com.vector.cfg.model.query.modelcheckedaccess.tuple.IModelTupleList;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The ModelCheckedAccess request interface for parameters ({@link MIParameterValue}) in a type safe manner.
 *
 * <p>
 * You can process the request by adding a method call to your request.
 * </p>
 * <p>
 * Example:<br/>
 * <code>mca.parameter(..).asBool() -->.doNotCheckHasValue()<-- and|or -->.getValue()<--</code>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IModelCheckedAccess
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IMcaTypesafeParam<VALUE, PARAM extends MIParameterValue> extends IMcaParam<IMcaTypesafeParam<VALUE, PARAM>> {

    /**
     * Executes the model request and returns a single value defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * The requested parameter must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use {@link IMcaTypesafeParam#getManyValues()
     * getManyValues()} instead.
     * </p>
     *
     * @return The value of the parameter for the request
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no parameter was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one parameter value was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no parameter</li>
     * </ul>
     */
    @PublishedMethod
    VALUE getValue();

    /**
     * Executes the model request and returns a single value defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * If the parameter does not exist or has no value. The parameter defaultValue is returned.
     * </p>
     *
     * <p>
     * The requested parameter must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use {@link IMcaTypesafeParam#getManyValues()
     * getManyValues()} instead.
     * </p>
     *
     * @param defaultValue the default value
     *
     * @return The value of the parameter for the request
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one parameter value was found</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no parameter</li>
     * </ul>
     */
    @PublishedMethod
    VALUE getValueOrDefault(VALUE defaultValue);

    /**
     * Executes the model request and returns a single value, with the value type defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<VALUE> getValueAsRequest();

    /**
     * Executes the model request and returns a list of values defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * If no parameter was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if non or one
     * parameter was found.
     *
     * @return An unmodifiable List of values of parameters for the request.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no parameter</li>
     * </ul>
     */
    @PublishedMethod
    List<VALUE> getManyValues();

    /**
     * Executes the model request and returns a list of values, with the value type defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations} ).
     *
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<List<VALUE>> getManyValuesAsRequest();

    /**
     * Executes the model request and returns a single (value; parameter) tuple, with the value type defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * The requested parameter must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use
     * {@link IMcaTypesafeParam#getManyValueTuples() getManyValueTuples()} instead.
     * </p>
     *
     * @return The (value; parameter) tuple of the parameter for the request
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaNotExistsException
     * <ul>
     * <li>if no parameter was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one parameter value was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no parameter</li>
     * </ul>
     */
    @PublishedMethod
    IModelTuple<VALUE, PARAM> getValueTuple();

    /**
     * Executes the model request and returns single (value; parameter) tuple, with the value type defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<IModelTuple<VALUE, PARAM>> getValueTupleAsRequest();

    /**
     * Executes the model request and returns a list of (value; parameter) tuples, with the value type defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * If no parameter was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if non or one
     * parameter was found.
     *
     * @return An unmodifiable List of (value; parameter) tuples for the request.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no parameter</li>
     * </ul>
     */
    @PublishedMethod
    IModelTupleList<VALUE, PARAM> getManyValueTuples();

    /**
     * Executes the model request and returns a list of (value; parameter) tuples, with the value type defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    IMcaRequest<IModelTupleList<VALUE, PARAM>> getManyValueTuplesAsRequest();

    /**
     * Executes the model request and returns a single parameter, with the type defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * The requested parameter must must have exactly one instance, otherwise this method will throw an exception. If you are not sure use {@link IMcaTypesafeParam#getManyParams()
     * getManyParams()} instead.
     * </p>
     *
     * @return The parameter for the request
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaNotExistsException
     * <ul>
     * <li>if no parameter was found</li>
     * </ul>
     *
     * @exception McaWrongQuantityException
     * <ul>
     * <li>if more then one parameter value was found</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no parameter</li>
     * </ul>
     */
    @PublishedMethod
    @Override
    PARAM getParam();

    /**
     * Executes the model request and returns a single parameter, with the type defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    IMcaRequest<PARAM> getParamAsRequest();

    /**
     * Executes the model request and returns a list of parameters, with the type defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * If no parameter was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if non or one
     * parameter was found.
     *
     * @return An unmodifiable List of parameters for the request.
     *
     * @exception McaDefinitionUndefinedException
     * <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     * @exception McaParameterHasNoValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has no value</li>
     * </ul>
     * @exception McaParameterHasIllegalValueException
     * <ul>
     * <li>if doNotCheckHasValue() was not called and the parameter has an illegal value</li>
     * </ul>
     * @exception McaParameterWrongTypeException
     * <ul>
     * <li>if the parameter has not the type specified be the previous TypeOperation</li>
     * </ul>
     * @exception McaWrongTypeException
     * <ul>
     * <li>if the retrieved element is no parameter</li>
     * </ul>
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    List<PARAM> getManyParams();

    /**
     * Executes the model request and returns a list of parameters, with the type defined by a TypeOperation (See {@link IMcaParamWithoutType TypeOperations}).
     *
     * <p>
     * This method will <b>NEVER</b> throw any exception. You can test the returned object, if the modelRequest is valid {@link IMcaRequest#isValid()}.
     * </p>
     *
     * @return The model Request.
     *
     * @see IMcaRequest
     *
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    IMcaRequest<List<PARAM>> getManyParamsAsRequest();

    /**
     * Disables the hasValue check for this model request.
     *
     * <p>
     * If the the parameter has no value, no {@link McaParameterHasNoValueException} is thrown.
     * </p>
     *
     * @return This model request interface
     */
    @PublishedMethod
    IMcaTypesafeParam<VALUE, PARAM> doNotCheckHasValue();

    /**
     * Disables the IllegalValue check for this model request.
     *
     * <p>
     * If the the parameter has no value, no {@link McaParameterHasIllegalValueException} is thrown.
     * </p>
     *
     * @return This model request interface
     */
    @PublishedMethod
    IMcaTypesafeParam<VALUE, PARAM> doNotCheckIllegalValue();
}
