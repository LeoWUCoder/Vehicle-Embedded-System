package com.vector.cfg.model.access.ecuconfiguration.elements.parameter;

import java.math.BigInteger;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucIntegerDefinition;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IEcucIntegerParameter extends IEcucNumericalParameter<BigInteger> {

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucIntegerDefinition getEcucDefinition();

    /**
     * Sets the parameter value.
     *
     * @param value
     */
    @PublishedMethod
    void setValue(long value);

}
