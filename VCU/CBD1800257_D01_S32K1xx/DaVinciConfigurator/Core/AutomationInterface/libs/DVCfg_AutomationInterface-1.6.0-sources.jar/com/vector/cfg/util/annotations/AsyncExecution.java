package com.vector.cfg.util.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="AsyncExecution"> Indicates that the annotated lambda or closure is asynchronous executed. The code in the lambda or closure must be thread safe.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.SOURCE)
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@Documented
public @interface AsyncExecution {

    /**
     * The description.
     *
     * @return the description for the deferred execution
     */
    @PublishedMethod
    String description() default "";

}
