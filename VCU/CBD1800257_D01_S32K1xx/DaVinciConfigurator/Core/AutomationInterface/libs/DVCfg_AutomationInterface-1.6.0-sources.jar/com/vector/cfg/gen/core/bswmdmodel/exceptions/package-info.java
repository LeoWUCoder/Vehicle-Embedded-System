/**
 * Exceptions thrown by access methods of the generated BswmdModel.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.bswmdmodel.exceptions;