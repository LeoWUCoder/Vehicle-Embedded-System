package com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * The base interface of all ModelCheckedAccess exception data classes.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IInvalidReason
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public interface IExData extends IInvalidReason {

    /**
     * Gets the Parent MIObject, or <code>null</code>, if no parent was specified.
     *
     * @return The Parent MIObject, or <code>null</code>, if no parent was specified.
     */
    @Override
    @PublishedMethod
    MIHasDefinition getParent();

    /**
     * Gets the DefinitionRef of the requested model element/s.
     *
     * @return The DefinitionRef of the requested model element/s.
     */
    @Override
    @PublishedMethod
    DefRef getDefRef();

    /**
     * Gets the Definition MDF Object of the requested model element/s or <code>null</code>, if no element is available.
     *
     * @return The Definition MDF Object of the requested model element/s or <code>null</code>, if no element is available.
     */
    @PublishedMethod
    MIReferrable getDefinitionMDFObject();

    /**
     * Gets the element MIObject,which has cause the problem or <code>null</code>, if no element is available.
     *
     * @return The element MIObject,which has cause the problem or <code>null</code>, if no element is available.
     */
    @Override
    @PublishedMethod
    MIHasDefinition getElement();

    /**
     * Gets the active model view during the {@link IModelCheckedAccess} request.
     *
     * @return the active model view during request
     */
    @Override
    @PublishedMethod
    IModelView getActiveModelViewDuringRequest();
}
