package com.vector.cfg.gen.core.utils.generatorresult;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
//CHECKSTYLE:OFF
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.helper.validationresults.ValidationResultUtil;
import com.vector.cfg.gen.core.moduleinterface.IGenerationProcessor;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

//CHECKSTYLE:ON
/**
 * Utility class for static method which corresponds to the {@link IGeneratorResult} processing, like {@link IGeneratorResultSink}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GeneratorResultUtil {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GeneratorResultUtil.class);

    private GeneratorResultUtil() {

    }

    /**
     * Returns the current result sink of the generatorPackage, or <code>null</code> if no ResultSink is currently available.
     *
     * @param genPackageRef the {@link IGeneratorPackage} or a child ref {@link IGeneratorPackageReferable}.
     * @return the result sink, or <code>null</code>
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the genPackageRef is null</li>
     * </ul>
     *
     * @throws IllegalStateException<ul>
     * <li>if no resultSink is currently available.</li>
     * </ul>
     */
    @PublishedMethod
    public static IGeneratorResultSink getResultSink(IGeneratorPackageReferable genPackageRef) {
        if (genPackageRef == null) {
            throw new IllegalArgumentException("genPackageRef is null");
        }
        final IGeneratorPackage generatorPackage = genPackageRef.getGeneratorPackage();
        if (generatorPackage != null) {
            final IGenerationProcessor genPrc = generatorPackage.getGenerationProcessor();
            if (genPrc != null) {
                return genPrc.getResultSink();
            }

        }
        return null;
    }

    /**
     * Builds the Error and Information Handling Specification conform string of validation result.
     *
     * <pre>
     * [&lt;Severity&gt;] &lt;Origin&gt;&lt;ID&gt; - &lt;Summary&gt;
     * - &lt;Description&gt; &lt;Reference&gt;
     *
     * Help:
     * - &lt;Help&gt;
     * </pre>
     *
     * <p>
     * The Spec is: https://vistrpscsvn1.vi.vector.int/svn/SLP/Vector/MSR_Vector_SLP3/trunk/_doc/
     * 10_UserRequirements/RequirementSpecification_ErrorAndUserInformationHandling.doc
     * </p>
     *
     * @param result the result
     * @return the formatted string
     */
    @PublishedMethod
    public static String buildSpecConformStringOfValidationResult(IValidationResult result) {

        if (result == null) {
            throw new IllegalArgumentException("result is null");
        }

        return ValidationResultUtil.buildSpecConformStringOfValidationResult(result);
    }

    /**
     * Builds the Error and Information Handling Specification conform string of validation result like the mehtod buildSpecConformStringOfValidationResult AND
     * additionally appends the erroneous CEs. This appendix breaks the spec! This feature is required for outputs to the generated code.
     *
     * <pre>
     * [&lt;Severity&gt;] &lt;Origin&gt;&lt;ID&gt; - &lt;Summary&gt;
     * - &lt;Description&gt; &lt;Reference&gt;
     * E.g.<br/>
     * [Error] FEE90021 - Parameter does not exist<br/>
     * - Parameter FeeCfgChkParamBlockNumber does not exist. Element def.: /MICROSAR/Fee/FeeGeneral/FeeCfgChkParamBlockNumber Parent: /ActiveEcuC/Fee/FeeGeneral<br/>
     * Erroneous configuration elements:<br/>
     * /ActiveEcuC/Fee/FeeGeneral (DefRef: /MICROSAR/Fee/FeeGeneral)<br/>
     * [DefinitionRef: /MICROSAR/Fee/FeeGeneral/FeeCfgChkParamBlockNumber]<br/>
     *
     * </pre>
     *
     * <p>
     * The Spec is: https://vistrpscsvn1.vi.vector.int/svn/SLP/Vector/MSR_Vector_SLP3/trunk/_doc/
     * 10_UserRequirements/RequirementSpecification_ErrorAndUserInformationHandling.doc
     * </p>
     *
     * @param result the result
     * @return the formatted string
     */
    @PublishedMethod
    public static String buildSpecConformStringOfValidationResultWithErroneousCEs(IValidationResult result) {
        return ValidationResultUtil.buildSpecConformStringOfValidationResultWithErroneousCEs(result);
    }
}
