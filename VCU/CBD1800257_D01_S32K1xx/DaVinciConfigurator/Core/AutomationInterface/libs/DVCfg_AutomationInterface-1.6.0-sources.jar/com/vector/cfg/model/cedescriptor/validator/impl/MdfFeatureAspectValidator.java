package com.vector.cfg.model.cedescriptor.validator.impl;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.ReworkThisAtNextPublishedApiChange;
import com.vector.cfg.model.cedescriptor.aspect.IMdfFeatureAspect;
import com.vector.cfg.model.cedescriptor.validator.AspectValidationException;
import com.vector.cfg.model.cedescriptor.validator.DescriptorAspectBuilderValidator;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@ReworkThisAtNextPublishedApiChange("GROOVY-8669 - This can be moved again in an internal package, when the Groovy Annotation loading bug was fixed.")
public class MdfFeatureAspectValidator extends DescriptorAspectBuilderValidator<IMdfFeatureAspect> {

    /**
     * Constructor for MdfObjectAspectValidator.
     *
     */
    public MdfFeatureAspectValidator() {
        super(IMdfFeatureAspect.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void checkImpl(IMdfFeatureAspect aspect) throws AspectValidationException {
        if ((aspect.getFeature() == null) || (aspect.getFeature().length() == 0)) {
            throw new AspectValidationException("An IMdfFeatureAspect without a valid feature is not allowed.");
        }
    }

}
