package com.vector.cfg.util.text.mixedtext;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.internal.mixedtext.MixedTextBuilder;
import com.vector.cfg.util.text.internal.mixedtext.StrictMixedTextBuilder;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class MixedText {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(MixedText.class);

    private MixedText() {
    };

    @PublishedMethod
    public static IMixedTextBuilder newBuilder() {
        return new MixedTextBuilder();
    }

    /**
     * Creates a new {@link IStrictMixedTextBuilder} instance.
     *
     * <p>
     * The {@link IStrictMixedTextBuilder} does not truncate or add any whitespace or other characters to the {@link IMixedText} to create
     * </p>
     *
     *
     * @return the new builder
     */
    @PublishedMethod
    public static IStrictMixedTextBuilder newStrictBuilder() {
        return new StrictMixedTextBuilder();
    }

    /**
     * Each format item takes the following form and consists of the following components:
     * <p>
     * <b>{index[:formatString]}</b> <br />
     * formatString = letter {letter | digit | _}*(','letter {letter | digit | _}*)* <br />
     * The matching braces ("{" and "}") are required.
     * </p>
     *
     * <p>
     * <b>Index Component</b><br />
     * The mandatory index component, also called a parameter specifier, is a number starting from 0 that identifies a corresponding item in the list of objects. That is, the
     * format item whose parameter specifier is 0 formats the first object in the list, the format item whose parameter specifier is 1 formats the second object in the list, and
     * so on.
     *
     * Each format item can refer to any object in the list. For example, if there are three objects, you can format the second, first, and third object by specifying a
     * composite format string like this: "{1} {0} {2}". An object that is not referenced by a format item is ignored. A IllegalArgumentException results if a parameter
     * specifier designates an item outside the bounds of the list of objects.
     *
     *
     * <p>
     * <b>Format Options</b><br />
     * Formatting options are published and documented via classes that follow this naming convention MixedTextFormat*. Look out for classes with this name to find formatting
     * options for a particular object type.<br />
     * Exemplary Format Strings:<br />
     * <ul>
     * <li>MIParameterValue :
     * <ul>
     * <li>noValue</li>
     * <li>onlyValue</li>
     * </ul>
     * </li>
     * <li>IFormattable :
     * <ul>
     * <li>The Format pattern is passed to the Formattable object, so every object can implement its own Format options.</li>
     * </ul>
     * </li>
     * </ul>
     * </p>
     *
     * <p>
     * <b>Escaping Braces</b><br />
     * Opening and closing braces are interpreted as starting and ending a format item. Consequently, you must use an escape sequence to display a literal opening brace or
     * closing brace. Specify two opening braces ("{{") in the fixed text to display one opening brace ("{"), or two closing braces ("}}") to display one closing brace ("}").
     * Braces in a format item are interpreted sequentially in the order they are encountered. Interpreting nested braces is not supported.
     * </p>
     *
     * <p>
     * <b>Newlines</b><br />
     * The format string can contain the pattern {nl} to indicate a newline in the output string. All {nl} will be replaced by the platform dependent newline characters.
     * </p>
     *
     * @param formatPattern A composite format string.
     * @param arguments An array of objects to format.
     * @return The new created {@link IMixedText}.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the formatPattern is null</li>
     * <li>if the formatPattern is invalid</li>
     * </ul>
     */
    @PublishedMethod
    public static IMixedText format(String formatPattern, Object... arguments) {
        return newBuilder().appendFormat(formatPattern, arguments).flushResult();
    }

    /**
     * Creates a {@link IMixedText} containing only the passed {@link String} text. This will not evaluate any content of the passed string.
     *
     * @param text the text.
     * @return The new created {@link IMixedText} containing the text.
     */
    @PublishedMethod
    public static IMixedText fromConstantString(String text) {
        return newStrictBuilder().append(text).build();
    }
}
