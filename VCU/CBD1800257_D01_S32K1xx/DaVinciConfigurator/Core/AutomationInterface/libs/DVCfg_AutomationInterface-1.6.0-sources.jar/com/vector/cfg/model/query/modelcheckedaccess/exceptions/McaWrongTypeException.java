package com.vector.cfg.model.query.modelcheckedaccess.exceptions;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedFilter;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.exceptiondata.IWrongTypeExData;
import com.vector.cfg.util.platform.publishedapi.filters.MsrPlatform;

/**
 * Thrown when an element has the wrong type for the model request.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedFilter(MsrPlatform.class)
public class McaWrongTypeException extends McaException {

    private static final long serialVersionUID = 5795299237803779493L;

    private final List<IWrongTypeExData> wrongTypeExDataList;

    /**
     * Constructor for McaParameterWrongTypeException.
     *
     * @param wrongTypeExDataList
     */
    @PublishedMethod
    public McaWrongTypeException(List<IWrongTypeExData> wrongTypeExDataList) {
        super(wrongTypeExDataList);
        this.wrongTypeExDataList = wrongTypeExDataList;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<IWrongTypeExData> getExceptionDataList() {
        return wrongTypeExDataList;
    }

}
